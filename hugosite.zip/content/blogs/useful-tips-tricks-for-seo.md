---
title: 'Useful Tips & Tricks For Seo'
date: 2020-01-07T21:35:00.003+05:30
draft: false
url: /2020/01/useful-tips-tricks-for-seo.html
tags: 
- Tools
- SEO
- Website
- Sinium
- Tips_Tricks
---

[![](https://lh3.googleusercontent.com/-BcKcSIpQYLg/XhTUxmrjLOI/AAAAAAAAAp4/0Ah8z4qFdXcfy0E42qzjetigjvwpkWf3wCLcBGAsYHQ/s16000/IMG_20200108_002535_811.jpg)](https://lh3.googleusercontent.com/-BcKcSIpQYLg/XhTUxmrjLOI/AAAAAAAAAp4/0Ah8z4qFdXcfy0E42qzjetigjvwpkWf3wCLcBGAsYHQ/s1600/IMG_20200108_002535_811.jpg)

  
If you are starting a website or you are completely new to these website things, there are so many ways to build a complete and today it become to easy with the available resources we have and everybody can make a site and live up in min with free cme system from trusted global companies.

  

Even with the easyness the competition become really as daily lakhs of pages created daily as it's become very hard if you wrote an article about something's and its appear in google or any other

search engine.

  

So to do better and there is a solution to have a place in google search with a good seo and mainly content should be unique and quality.

  

**Seo** **Tips -**

**\- Domain Name**

**Yes,** first and foremost is choose a good domain name that apt your work and good word search capability as it will decide your future website run-up choose website domain consciously give some time if necessary.

  

**\- Content Management System**

  

There are free and paid content management systems either like blogger, wordpress, medium, squarespace, postach.io, pen.io and many more 

and most website give you unlimted space if you use thier subdomain else charged as they have have some of them have own paid services as some do offer free like blogger.

  

If you don't wanna paid service you can opt for free hosting sites to add your domain they are many available >

  

[byethost.com](byethost.com)

  

[awardspace.com](awardspace.com) 

  

[freehosting.com](freehosting.com)  

  

Choose your own cms or hosting according to your need as they have both pros and cons based on the preference and need of features vary on all of them.

  

As if you are choosing hosting instead of cms then choose a paid hosting if your are working for long time or professional then choosing hosting gives more security and privacy with guarantee of support and no down time.

  

**• Design**

  

Give more time to design as it matters alot that needed to apt the work and give a good look does reach more audience, of your can make your own design give more time to design, if not choose a good theme or template that is seo friendly or make it seo friendly.

  

• **Title** 

  

Give a tile that match your content and reflect your work in simple words and it does help alot in future.

  

**• Description of Your Site**

Take time use some trendy and grammar checked as it will appear below your site that make people click give a good description within keyword limit.

  

• **Meta Keywords**

Use trending words that going on for your page category and add them wisely as it will boost the audience reach.

  

**• Social Media**

Create accounts like facebook, Instagrams twitter so your posts can reach more people in this portal as it develops customer available, interaction and reach including that value.

  

**• Article - Title**

Good title makes people read your article, how, why use good title that ensure reach and viewship.

  

•** Article**

Google doesn't accept less length articles so give a good lenth and quality article and mainly quality over quantity keep this in mind.

  

**• Article Start And Ending**

Start with a travel going experience and end with a question mark or give a good supportive ending and don't bore of with unnecessary stuff make interesting and subjective.

  

**• Search Description**

Google or any search engines take some from article to show up in index so if your are ablevto give a good line description you can do that for a better reach and viewership.

  

**• site map**

Create a site for yor site map to inform search engines about updates of yor sites you can easily create a site map.

  

[https://www.xml-sitemaps.com/](https://www.xml-sitemaps.com/)  

  

Use the above website and save it and use whenever needed.

  

• **Google Analytics **

If you wanna better about your site visitors and reach of countries and most used devices and time that uses stayed on your website and many plenty of features add your site 

  

[www.googleanalytics.com](www.googleanalytics.com)  

  

• **Bing - Microsoft**

Add in bing and submit your site for using plenty of features and bing is giving 100$ advertising credit and have a look as it was second most global using search engine after google.

  

• **Backlinks**

Add Backlinks if necessary as it gives google to search for a specific site can get your udjence as your listed the link that people are searching for.

  

• **Tags or Lables**

Give Lables to your article as it gives designated keyboards to related articles

  

• **Category**

Make category and add the article's according to the category that it suits so it will maintain clean and easy of usage

  

**• Load**

•Google likes to rank website based on speed as the research that google released most users will leave page if it was more than 3seconds, even thought google says that most websites today atleast have 20seconds of load time.

  

•To decrease load time of your site you have to minimise scripts or content that reduce the request limit for a better speed.

  

•speed of the website based on several things like

internet speed, size of the website, resource etc.

  

• as earlier said do minimise scripts and other resources and reduce size and internet speed vary user to users so making a general speed.

  

\> To reduce size you have minimise HTML and CSS of your site as wordpress offers several plugins to do that you can install it and use.

  

But blogger doesn't have option now to do that go to htmlcompressor.com edit your XML template copy your code paste it in the site choose blogger tick minify html and css ut8 encoding and compress and compress ultra then you'll get compressed code copy it and paste it in your template.. done

  

\> Another way to reduce size is to optimise images to do that go to tinypng.com upload and get compressed img.

  

\- [tinypng.com](tinypng.com)

  

\- [highcompress.com](highcompress.com)

  

\- [compressor.io](compressor.io)

  

Some times that can compress imgs at different sizes with ability to choose compression rate.

  

You can even do compression with Adobe Photoshop and other compression softwares by reducing img quality.

  

In android you can use **pixel lab.**

  

If you still not satisfied, there is an easy way install telegram and upload to saved messages and get your image compressed.

  

If you are uploading in article blogger resizing to bigger size than you many uploading img in blogger android as the app doesn't have option to upload in google use website or use client blogger pro.

  

**• Submit Your Site **

**Yes,** one of the first thing after completing offline stuff submit your site to search engines for free.

  

There are several websites.

  

[https://www.entireweb.com/free\_submission/](https://www.entireweb.com/free_submission/)  

[https://www.submitexpress.com/free-tools/free-website-submission/](https://www.submitexpress.com/free-tools/free-website-submission/)

  

After submitting your site will be crawl by search engines.

  

Use this below sites, that have to ability to inform that your site is updated, 

  

[https://pingomatic.com/](https://pingomatic.com/)  

  

After completing of submit your website.

  

• **CDN**

Use cdns like cloudflare, keycdn etc as cloud flare optimize your site alot and do cover domain ownership giving security and free ssl.

  

• **SSL**

Security matters, get a free ssl as it validate and ensure your site is geniune and spam and if your site is shopping and must needed for secure payments as more likely geniune sites ranks

  

Http to Https > Red to Green : Stop And Go

  

**• Mobile Friendly**

Most of the users are from mobiles, the better the mobile it ranks the better the reach and usage take some time and work on it.

  

**Lastly content is more important even though this tips helps alot as new your content the better it will get audience.**

**Tricks >**

Yes, there are alot of tricks that can make your site better and check problem.

  

• **Seo Checker**

  

[Neilpatel.com](Neilpatel.com)  

  

[Prepostseo.com](Prepostseo.com)  

  

[Sinium.com](Sinium.com)  

  

Give your site a test with this site and check issues or where the site lack and fix them.

  

This Sites have several features like pinging, security, Backlinks builder, rewrite articles and many more must try as most of them tricks are there in the sites.

  

Use sinium mobile app.

  

**\> Ranking Tools**

  

**• Alexa Rank Checker**

**• Moz Rank Checker**

**• Page Authority**

**• Seo Report Card**

**\> Research Tools**

**• Adsense Calculator**

**• Broken Links Finder**

**• Code to Text Ratio**

**• Dmoz Listing**

**• Google Cache**

**• Link Analyser**

**• Mobile Friendly Test**

**• Page Size Checker**

**• Serp Keyword Position**

**• Social Stats**

**• Source Code**

**• Spider Simulator**

**• Links Counter**

**• Redirect Checker** 

  

**\> Performance Tools**

**• Gzip Compression**

**• Server Status**

**• Webpage Speed Test**

**• Image Optimized**

**\> On Page SEO **

**• Meta Tags Analyser**

**• Meta Tags Generator**

**• HTTP Headers**

**• Keywords Density**

**• Keyword Suggestions**

**\> Off Page SEO**

**• BackLinks Checker**

**• BackLinks Builder**

**• Seach Engine Pinger**

**\> Blog And News Seo**

**• Article Rewriter**

**• Word Counter**

  

**• Grammar Checker**

**• Wordpress Ninja**

**\> Domain Tools**

**• Class C Checker**

**• DNS Records**

**• Domain Age**

**• Domain Authority**

**• Domain Availability**

**• Domain IP lookup**

**• Reverse IP lookup**

**• Hosting Provider lookup**

**• URL Encoder And Decoder**

**• W****hois**

**\> Security Tools**

**• AVG Website Scan**

**• Google Malware Scan**

**• Black List Lookup**

**• MD5 Generator**

**• URL Rewriting Tool**

**\> Other Tools**

**• Email Extractor**

**• My Browser Info**

**• My IP Address**

**• Website Worth Estimate**

This tools have specific importance used according to your need some website to have some tools some not but sinium have most tools available : sinium.com or app and 

  

**Advertise**

Even though if you content have potential, do use some bucks to advertise as it will ensure more reach and growth

  

Finally, Check your Alexa and moz rank to get improve and updated timely.

  

Keep supporting : TechTracker.in