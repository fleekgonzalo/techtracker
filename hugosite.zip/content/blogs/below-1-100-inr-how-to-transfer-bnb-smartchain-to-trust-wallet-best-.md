---
title: 'Below 1$ / 100 INR | How To Transfer BNB Smartchain To Trust Wallet [ Best ]'
date: 2021-07-01T02:29:00.003+05:30
draft: false
url: /2021/07/below-1-100-inr-how-to-transfer-bnb.html
tags: 
- technology
- Buy
- 1$
- Trust Wallet
- BNB Smartchain
- transfer
---

 [![How To Transfer BNB Smartchain To Trust Wallet [ Best ]](https://lh3.googleusercontent.com/-aCkQxAHVBr8/YN4swQlLRsI/AAAAAAAAFW4/FURT-nW_zOsHH24KNy_wTv1Rq8XC9U_-wCLcBGAsYHQ/w400-h225/1625173179876700-0.png "How To Transfer BNB Smartchain To Trust Wallet [ Best ]")](https://lh3.googleusercontent.com/-aCkQxAHVBr8/YN4swQlLRsI/AAAAAAAAFW4/FURT-nW_zOsHH24KNy_wTv1Rq8XC9U_-wCLcBGAsYHQ/s1600/1625173179876700-0.png) 

  

If you do crypto trading or participate in crypto airdrops you may probably know about binance smartchain it is an crypto currency created by binance which have low transaction fee for trading, buying or swaping BEP 20 crypto currencies due to Binance smartchain low fees many Defi markets started depending on it most popularly PancakeSwap.finance.

  

PancakeSwap is a decentralised exchange platform to swap and trade numerous BEP20 tokens which is currently a popular exchange platform among crypto traders to swap thier crypto currencies but most  of the traders first buy binance smartchain to swap on PancapSwap.finance due to it's low gas fees compared to any other crypto currencies.

  

But, most crypto exchanges platforms not yet listed binance smartchain even though some crypto exchanges platforms listed  binance smartchain they already fixed big limit for withdrawal and high transaction fees to transfer to other wallets like trust wallet due to this reason low investment traders are unable to transfer or swap thier binance smartchain to get new BEP 20 tokens through pancakeswap.finance.

  

In this scenario, we have a workaround we found a way to get [binance](https://www.techtracker.in/2021/07/below-1-100-inr-how-to-transfer-bnb.html?m=1) smartchain for below 1$ / 100 INR and transfer it to trust wallet to swap and get your BEP 20 tokens at low gas fees, to do this you just need to install and do kyc on coindcx pro app and register on faucetpay.com and you must need trust wallet where you will connect to pancakeswap.finance using Dapp browser, this is little big procedure I really urge you to be monk like patience, if you have then let's know little more Info to get started.

  

\- **App Info** \- [Google Play -](https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp)

  

• **How to install Trust Wallet**

  

It is very easy to download Trust Wallet from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp)

  

\- **App Info** \- [Google Play](https://play.google.com/store/apps/details?id=com.coindcx) -

  

**• How to install CoinDCX Pro •**

  

It is very easy to download CoinDCX Pro from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.coindcx)

\- [Apkmirror](http://www.apkmirror.com/apk/coindcx-official/)

  

**• How to download FaucetPay App • **

It is very easy to download FaucetPay App from these platforms for free.

**\- **[Google Play](https://play.google.com/store/apps/details?id=faucetpay.free)

\- [Apkpure](https://www.google.com/amp/s/m.apkpure.com/faucetpay-faucets/faucetpay.free/amp)

  

• **How to register on** [Faucetpay.io](http://Faucetpay.io)

  

+ [**FaucetPay - Best Crypto Currency Micro Payment Wallet & Earning Platform With Very Low Fee!**](https://www.techtracker.in/2021/06/faucetpay-best-crypto-currency-micro.html?m=1)

  

• **How to get and transfer below 1$ / 100 INR binance smartchain to trust wallet to swap on** [Pancakeswap.finance](http://Pancakeswap.finance).

  

 [![](https://lh3.googleusercontent.com/-R2XHGHIuyWM/YN4su2n55gI/AAAAAAAAFW0/V7A6v06WyYYWd564FUo2jybLv3E8ZZlQACLcBGAsYHQ/s1600/1625173175104830-1.png)](https://lh3.googleusercontent.com/-R2XHGHIuyWM/YN4su2n55gI/AAAAAAAAFW0/V7A6v06WyYYWd564FUo2jybLv3E8ZZlQACLcBGAsYHQ/s1600/1625173175104830-1.png) 

  

\- First register yourself on CoinDCX Pro and do KYC, In funds tap on **DEPOSIT INR.**

 **[![](https://lh3.googleusercontent.com/-C8bZNonNWBc/YN4stjG2X3I/AAAAAAAAFWw/3l_sYq3nvF89PkTP9mglVJ2eGEqeOaxowCLcBGAsYHQ/s1600/1625173170381939-2.png)](https://lh3.googleusercontent.com/-C8bZNonNWBc/YN4stjG2X3I/AAAAAAAAFWw/3l_sYq3nvF89PkTP9mglVJ2eGEqeOaxowCLcBGAsYHQ/s1600/1625173170381939-2.png)** 

\- Enter alreast 100RS so you won't get unnecessary stops further and tap on **CONTINUE**.

  

 [![](https://lh3.googleusercontent.com/-JpRpTomM5k8/YN4ssf6KNHI/AAAAAAAAFWs/KG4PJIU-MboYFdTdu6dsxNwUHbedzAn7wCLcBGAsYHQ/s1600/1625173165297067-3.png)](https://lh3.googleusercontent.com/-JpRpTomM5k8/YN4ssf6KNHI/AAAAAAAAFWs/KG4PJIU-MboYFdTdu6dsxNwUHbedzAn7wCLcBGAsYHQ/s1600/1625173165297067-3.png) 

  

\- Tap on **Mobikwik Wallet ( Instant )**

  

 [![](https://lh3.googleusercontent.com/-DfPyIGn9wsc/YN4srD8xs3I/AAAAAAAAFWo/eyD_EUtuG7YwSOtsWUCsY-o2ruFTFMWmQCLcBGAsYHQ/s1600/1625173160235266-4.png)](https://lh3.googleusercontent.com/-DfPyIGn9wsc/YN4srD8xs3I/AAAAAAAAFWo/eyD_EUtuG7YwSOtsWUCsY-o2ruFTFMWmQCLcBGAsYHQ/s1600/1625173160235266-4.png) 

  

\- Tap on Wallets, Mobikwik, **Make Payment**

 **[![](https://lh3.googleusercontent.com/-nSQAbjNjtJI/YN4sp-MpzVI/AAAAAAAAFWk/dNeBPh5Qku8-RiyIspBCIqGX2TAVJMxQACLcBGAsYHQ/s1600/1625173153882758-5.png)](https://lh3.googleusercontent.com/-nSQAbjNjtJI/YN4sp-MpzVI/AAAAAAAAFWk/dNeBPh5Qku8-RiyIspBCIqGX2TAVJMxQACLcBGAsYHQ/s1600/1625173153882758-5.png) 

\-** Coindcx Pro only support deposits via mobiqwik which have debit card issues, so we suggest you to register on Mobikwik and add money to wallet by UPI, then login on Coindcx Pro and pay the Money for smooth process.

  

 [![](https://lh3.googleusercontent.com/-L6XEmkOLd6Q/YN4sobXRKuI/AAAAAAAAFWg/xjjqMAFmLF8RpbPtS6vBblttv7HRJyaKwCLcBGAsYHQ/s1600/1625173147625479-6.png)](https://lh3.googleusercontent.com/-L6XEmkOLd6Q/YN4sobXRKuI/AAAAAAAAFWg/xjjqMAFmLF8RpbPtS6vBblttv7HRJyaKwCLcBGAsYHQ/s1600/1625173147625479-6.png) 

  

\- Once, payment done for deposit you will get a notify email regarding do check it, In few minutes, if your deposit is successful it will be reflected in funds, Coindcx have some issues on bank deposits so many people rasing issues & complaints, they they taking months to resolve so, if possible try to do wallet payments only. It is has more success rate.

  

 [![](https://lh3.googleusercontent.com/-yDBPYADSIhk/YN4sm9nvQgI/AAAAAAAAFWY/yKO0VyCSQ_AK_D2Y42nhtPzantbgGLIvgCLcBGAsYHQ/s1600/1625173138824105-7.png)](https://lh3.googleusercontent.com/-yDBPYADSIhk/YN4sm9nvQgI/AAAAAAAAFWY/yKO0VyCSQ_AK_D2Y42nhtPzantbgGLIvgCLcBGAsYHQ/s1600/1625173138824105-7.png) 

  

\- Now, go back to Coindcx Pro app, in HOME, Tap on **DCXinsta**.  

  

 [![](https://lh3.googleusercontent.com/-JJXeXXXatk8/YN4skuT8JiI/AAAAAAAAFWU/nmzSN3QzLgU8A3mJ5v0v89lrlvUvksR5gCLcBGAsYHQ/s1600/1625173133009862-8.png)](https://lh3.googleusercontent.com/-JJXeXXXatk8/YN4skuT8JiI/AAAAAAAAFWU/nmzSN3QzLgU8A3mJ5v0v89lrlvUvksR5gCLcBGAsYHQ/s1600/1625173133009862-8.png) 

  

\- In select a coin to buy : choose Tron TRX then Enter the amount atleast 100 RS it's ok even it's lower then that but don't make it very low else you'll get issues, then tap on **BUY TRX **

 **[![](https://lh3.googleusercontent.com/-LBYhlB0wMWs/YN4sjIm1S9I/AAAAAAAAFWQ/Bzi3StnC5XYA30x9y-labJRFFTv8TZgBACLcBGAsYHQ/s1600/1625173126882107-9.png)](https://lh3.googleusercontent.com/-LBYhlB0wMWs/YN4sjIm1S9I/AAAAAAAAFWQ/Bzi3StnC5XYA30x9y-labJRFFTv8TZgBACLcBGAsYHQ/s1600/1625173126882107-9.png)** 

\- Go back, In funds, on portfolio check either TRX that you just buyed reflected on your account or not, if you got TRX then tap on **WITHDRAW**.

  

 [![](https://lh3.googleusercontent.com/-geee2_docp4/YN4sht5FIzI/AAAAAAAAFWM/pM76to2HwKkMTDkTNr2jt98q5XkvlWqZACLcBGAsYHQ/s1600/1625173114968527-10.png)](https://lh3.googleusercontent.com/-geee2_docp4/YN4sht5FIzI/AAAAAAAAFWM/pM76to2HwKkMTDkTNr2jt98q5XkvlWqZACLcBGAsYHQ/s1600/1625173114968527-10.png) 

  

\- Wait before you withdraw, you need to register on [faucetpay.io](http://faucetpay.io) and login, once you login on faucetpay tap on **DEPOSIT**

  

 [![](https://lh3.googleusercontent.com/-btWbaTzFSQU/YN4senGjPZI/AAAAAAAAFWI/BvhFI3el2pQF9Eo7fsvXsm56FYFHSnO2wCLcBGAsYHQ/s1600/1625173105254958-11.png)](https://lh3.googleusercontent.com/-btWbaTzFSQU/YN4senGjPZI/AAAAAAAAFWI/BvhFI3el2pQF9Eo7fsvXsm56FYFHSnO2wCLcBGAsYHQ/s1600/1625173105254958-11.png) 

  

\- Here, you will find **deposit addresses**. Just scroll down to find Tron TRX.

  

 [![](https://lh3.googleusercontent.com/-yL7lX72CpDE/YN4scNdHKFI/AAAAAAAAFWE/3fJqI3kM3sY1FYdxafXUYyIQdsh2mbLigCLcBGAsYHQ/s1600/1625173097676502-12.png)](https://lh3.googleusercontent.com/-yL7lX72CpDE/YN4scNdHKFI/AAAAAAAAFWE/3fJqI3kM3sY1FYdxafXUYyIQdsh2mbLigCLcBGAsYHQ/s1600/1625173097676502-12.png) 

  

  

\- if you found TRON TRX deposit address tap and copy it.

  

 [![](https://lh3.googleusercontent.com/-4fXSOM8X06w/YN4saBJUyfI/AAAAAAAAFV8/DnmMj_7oRd873GVsXEzQ63LWjT-f7MN7gCLcBGAsYHQ/s1600/1625173090784639-13.png)](https://lh3.googleusercontent.com/-4fXSOM8X06w/YN4saBJUyfI/AAAAAAAAFV8/DnmMj_7oRd873GVsXEzQ63LWjT-f7MN7gCLcBGAsYHQ/s1600/1625173090784639-13.png) 

  

\- If you are new to Coindcx Pro you may probably not set Withdrawal Password.

  

\- Tap on **Haven't set withdraw password yet? Click here to set.**

 **[![](https://lh3.googleusercontent.com/-ceVU2SsNQZ8/YN4sYYh3iTI/AAAAAAAAFV4/ZhGhRME8ZkYyvYJgQBP6HS03sTndiKfpQCLcBGAsYHQ/s1600/1625173084912776-14.png)](https://lh3.googleusercontent.com/-ceVU2SsNQZ8/YN4sYYh3iTI/AAAAAAAAFV4/ZhGhRME8ZkYyvYJgQBP6HS03sTndiKfpQCLcBGAsYHQ/s1600/1625173084912776-14.png)** 

**\-** SET WITHDRAWAL PASSWORD,

\- Enter CoinDCX Account Password

\- Tap on **SUBMIT**

 **[![](https://lh3.googleusercontent.com/-ZgrDhhkhmEo/YN4sXCT-FEI/AAAAAAAAFV0/1WcOP3B4hvIqeqYBNGL-HHSTTKtMfmrhwCLcBGAsYHQ/s1600/1625173079793010-15.png)](https://lh3.googleusercontent.com/-ZgrDhhkhmEo/YN4sXCT-FEI/AAAAAAAAFV0/1WcOP3B4hvIqeqYBNGL-HHSTTKtMfmrhwCLcBGAsYHQ/s1600/1625173079793010-15.png)** 

**\-** Enter the 6 digit OTP sent to your phone number and  email address and tap on **SUBMIT** 

  

 [![](https://lh3.googleusercontent.com/-A3tq5PWIEIg/YN4sV8SxrQI/AAAAAAAAFVw/K26Np8OKw4UbM9wzXMbe9Ien_YMM1AHlwCLcBGAsYHQ/s1600/1625173073252009-16.png)](https://lh3.googleusercontent.com/-A3tq5PWIEIg/YN4sV8SxrQI/AAAAAAAAFVw/K26Np8OKw4UbM9wzXMbe9Ien_YMM1AHlwCLcBGAsYHQ/s1600/1625173073252009-16.png) 

  

\- Again Tap on FUNDS & Withdraw

\- Select Tron crypto currency

\- Enter your Tron TRX Address that we just copied from faucetpay, Amount & withdrawal password & Tap on SEND.

  

 [![](https://lh3.googleusercontent.com/-TQKCa2G5FwY/YN4sUJUvp1I/AAAAAAAAFVo/mM2b2MZSmskz_M_AYdcynHPqIvMEwOjQgCLcBGAsYHQ/s1600/1625173064352671-17.png)](https://lh3.googleusercontent.com/-TQKCa2G5FwY/YN4sUJUvp1I/AAAAAAAAFVo/mM2b2MZSmskz_M_AYdcynHPqIvMEwOjQgCLcBGAsYHQ/s1600/1625173064352671-17.png) 

  

\- Now, TRX will be sent to your faucetpay Tron ( TRX ) Address, Kindly Go to faucetpay and check either TRON received in wallet or not in overview.

  

 [![](https://lh3.googleusercontent.com/-71_hhRaxXe4/YN4sRqCeBSI/AAAAAAAAFVk/k3Zjki0MrkcdPzqoBE5t1PTxunY7cYjzQCLcBGAsYHQ/s1600/1625173056249406-18.png)](https://lh3.googleusercontent.com/-71_hhRaxXe4/YN4sRqCeBSI/AAAAAAAAFVk/k3Zjki0MrkcdPzqoBE5t1PTxunY7cYjzQCLcBGAsYHQ/s1600/1625173056249406-18.png) 

  

  

\- In faucetpay user dashboard, Overview, check TRON ( TRX ) Balance, if you got it.

  

 [![](https://lh3.googleusercontent.com/-n9WtUYykNOs/YN4sPytLveI/AAAAAAAAFVc/qMcxq81WadkijuzMkrRI7GsJeuvbqbXLACLcBGAsYHQ/s1600/1625173048001197-19.png)](https://lh3.googleusercontent.com/-n9WtUYykNOs/YN4sPytLveI/AAAAAAAAFVc/qMcxq81WadkijuzMkrRI7GsJeuvbqbXLACLcBGAsYHQ/s1600/1625173048001197-19.png) 

  

\- Scroll up, and tap on **≡**

 **[![](https://lh3.googleusercontent.com/-lPNMZb29BE4/YN4sN-k6CFI/AAAAAAAAFVY/-md7IGUW9F4L9q6ZUbmED9xeLv5PAIPfACLcBGAsYHQ/s1600/1625173041979152-20.png)](https://lh3.googleusercontent.com/-lPNMZb29BE4/YN4sN-k6CFI/AAAAAAAAFVY/-md7IGUW9F4L9q6ZUbmED9xeLv5PAIPfACLcBGAsYHQ/s1600/1625173041979152-20.png)** 

**\-** Tap an **Trade & Coin Swap**

 **[![](https://lh3.googleusercontent.com/-6ktvEAeTZlI/YN4sMMIRfXI/AAAAAAAAFVU/PEL6_Nd6u7om_9JNpIBKPwKwjdWbMA3vgCLcBGAsYHQ/s1600/1625173032660135-21.png)](https://lh3.googleusercontent.com/-6ktvEAeTZlI/YN4sMMIRfXI/AAAAAAAAFVU/PEL6_Nd6u7om_9JNpIBKPwKwjdWbMA3vgCLcBGAsYHQ/s1600/1625173032660135-21.png)** 

**\-** Here, choose Convert From : Tron ( TRX ), Amount : Max, Convert To : Binance BEP20 ( BNB ) and tap on **Make Exchange**

 **[![](https://lh3.googleusercontent.com/-fdriHXqjZgM/YN4sKLOihBI/AAAAAAAAFVM/W24LrFRQMbYmIiVVDaTmKjczM5oSEUsTQCLcBGAsYHQ/s1600/1625173024514624-22.png)](https://lh3.googleusercontent.com/-fdriHXqjZgM/YN4sKLOihBI/AAAAAAAAFVM/W24LrFRQMbYmIiVVDaTmKjczM5oSEUsTQCLcBGAsYHQ/s1600/1625173024514624-22.png)** 

**\-** You can check **Completed Exchanges.**

 **[![](https://lh3.googleusercontent.com/-OLnOoVdMoxU/YN4sH03TLeI/AAAAAAAAFVI/jH_EXqd78dQ8XQ1jG2H9TpMc0DdB71xhQCLcBGAsYHQ/s1600/1625173013746314-23.png)](https://lh3.googleusercontent.com/-OLnOoVdMoxU/YN4sH03TLeI/AAAAAAAAFVI/jH_EXqd78dQ8XQ1jG2H9TpMc0DdB71xhQCLcBGAsYHQ/s1600/1625173013746314-23.png)** 

**\-** Go back to faucetpay.io user dashboard, In Overview, Scroll down, Find BINANCE BEP20 ( BNB ) if exchange successfully done you'll get balance.

  

 [![](https://lh3.googleusercontent.com/-ndAcpW6yGGE/YN4sFS99QFI/AAAAAAAAFVA/TpVx6NZgj6kql0oxJGjda5cdizaM5orlgCLcBGAsYHQ/s1600/1625172999755177-24.png)](https://lh3.googleusercontent.com/-ndAcpW6yGGE/YN4sFS99QFI/AAAAAAAAFVA/TpVx6NZgj6kql0oxJGjda5cdizaM5orlgCLcBGAsYHQ/s1600/1625172999755177-24.png) 

  

\- Scroll up again, Tap on **WITHDRAW**

 **[![](https://lh3.googleusercontent.com/-AtiC_boglPQ/YN4sBmISaZI/AAAAAAAAFU4/hR3_dAvnKl0LEYWSa65Y6QuXINcoOOaoACLcBGAsYHQ/s1600/1625172974191470-25.png)](https://lh3.googleusercontent.com/-AtiC_boglPQ/YN4sBmISaZI/AAAAAAAAFU4/hR3_dAvnKl0LEYWSa65Y6QuXINcoOOaoACLcBGAsYHQ/s1600/1625172974191470-25.png)** 

**\-** Read information and Scroll** down.**

 **[![](https://lh3.googleusercontent.com/-x5XYtroEZv0/YN4r7fAoZxI/AAAAAAAAFUs/khLdyxo56lY1yucyKrm4l3eqYRDlkJwEgCLcBGAsYHQ/s1600/1625172962533313-26.png)](https://lh3.googleusercontent.com/-x5XYtroEZv0/YN4r7fAoZxI/AAAAAAAAFUs/khLdyxo56lY1yucyKrm4l3eqYRDlkJwEgCLcBGAsYHQ/s1600/1625172962533313-26.png)** 

**\-** You have two types of withdrawals on faucetpay, instant withdrawal which take around 5 minutes, 4hr withdrawal which takes around 4hours, choose whichever you like, and tap on don't find your address **Link**. Let it be don't close browser.

  

 [![](https://lh3.googleusercontent.com/-r0owFPdzUws/YN4r4fBaZFI/AAAAAAAAFUo/b6puPpgTwu8IRwedSiR5NCjVN9VpFgcBgCLcBGAsYHQ/s1600/1625172956326261-27.png)](https://lh3.googleusercontent.com/-r0owFPdzUws/YN4r4fBaZFI/AAAAAAAAFUo/b6puPpgTwu8IRwedSiR5NCjVN9VpFgcBgCLcBGAsYHQ/s1600/1625172956326261-27.png) 

  

**\-** It's time for Trust Wallet, if you do BEP20 tokens trading you may very likely know about trust wallet, if you don't know trust wallet, it is a crypto wallet like any other.

  

\- Find BNB Smartchain token from Trust Wallet and copy Address.

  

 [![](https://lh3.googleusercontent.com/-wMlE0IyuhWU/YN4r2zpX4iI/AAAAAAAAFUk/8pfck_A9LSYIKopGX6nWu0DIzf75PprWgCLcBGAsYHQ/s1600/1625172947954877-28.png)](https://lh3.googleusercontent.com/-wMlE0IyuhWU/YN4r2zpX4iI/AAAAAAAAFUk/8pfck_A9LSYIKopGX6nWu0DIzf75PprWgCLcBGAsYHQ/s1600/1625172947954877-28.png) 

  

\- In faucetpay, user dashboard, **LINKED ADDRESSES, **

  

\- Paste the Binance smartchain Address that you just copied from Trust Wallet, 

  

\- Choose coin : Binance BEP20 ( BNB ) and tap on **Link** 

  

 [![](https://lh3.googleusercontent.com/--pGopkkGsdA/YN4r0wY5dlI/AAAAAAAAFUg/By_sURpvDOQHpfaDbPfI_BmvwTyjWftOwCLcBGAsYHQ/s1600/1625172939930554-29.png)](https://lh3.googleusercontent.com/--pGopkkGsdA/YN4r0wY5dlI/AAAAAAAAFUg/By_sURpvDOQHpfaDbPfI_BmvwTyjWftOwCLcBGAsYHQ/s1600/1625172939930554-29.png) 

  

\- Once more, Go back to faucetpay, user dashboard, Tap on **Withdrawals**.

  

\- choose Coin : Binance BEP20

  

\- Withdrawal amount : All

  

\- Tap on **Place Withdrawal**

 **[![](https://lh3.googleusercontent.com/-MNVofJtI6es/YN4ry86YJiI/AAAAAAAAFUY/fFyIsvaXjJ4jf3YhwbYEHai8a0NDT633QCLcBGAsYHQ/s1600/1625172932483059-30.png)](https://lh3.googleusercontent.com/-MNVofJtI6es/YN4ry86YJiI/AAAAAAAAFUY/fFyIsvaXjJ4jf3YhwbYEHai8a0NDT633QCLcBGAsYHQ/s1600/1625172932483059-30.png)** 

**\-** Open Trust Wallet, You will get binance smartchain balance, based on the type of withdrawal, instant or 4hr withdrawal.

  

 [![](https://lh3.googleusercontent.com/-7eMCtltt-qw/YN4rw4quEmI/AAAAAAAAFUU/B6V_Rs2KdHUAQlvmWW4ORDtikG-CBf5mQCLcBGAsYHQ/s1600/1625172922718857-31.png)](https://lh3.googleusercontent.com/-7eMCtltt-qw/YN4rw4quEmI/AAAAAAAAFUU/B6V_Rs2KdHUAQlvmWW4ORDtikG-CBf5mQCLcBGAsYHQ/s1600/1625172922718857-31.png) 

  

\- In Trust Wallet, Tap on DApps, Enter URL : pancakeswap.finance and search or find pancakeSwap in popular section, just tap on it to begin swapping BEP20 tokens.

  

 [![](https://lh3.googleusercontent.com/-Lqe9ssCaPjc/YN4rucPhhhI/AAAAAAAAFUQ/mcBC9BFbYVASDHgtjTkMgb2ouROCkKe-QCLcBGAsYHQ/s1600/1625172914984608-32.png)](https://lh3.googleusercontent.com/-Lqe9ssCaPjc/YN4rucPhhhI/AAAAAAAAFUQ/mcBC9BFbYVASDHgtjTkMgb2ouROCkKe-QCLcBGAsYHQ/s1600/1625172914984608-32.png) 

  

\- Tap on Ethereum SYMBOL

  

 [![](https://lh3.googleusercontent.com/-uUqsm4LN8Sw/YN4rsU5bwfI/AAAAAAAAFUM/QWV2Nt6psNIklsvSeb4zsAHNIxoXyY4AgCLcBGAsYHQ/s1600/1625172907003207-33.png)](https://lh3.googleusercontent.com/-uUqsm4LN8Sw/YN4rsU5bwfI/AAAAAAAAFUM/QWV2Nt6psNIklsvSeb4zsAHNIxoXyY4AgCLcBGAsYHQ/s1600/1625172907003207-33.png) 

  

\- Tap on **Smart Chain**

 **[![](https://lh3.googleusercontent.com/-sDcW4NBqcyw/YN4rqf9WkoI/AAAAAAAAFUI/n9BtvEu64S4RyS3EQz7toaov1y-9fB0cgCLcBGAsYHQ/s1600/1625172899060875-34.png)](https://lh3.googleusercontent.com/-sDcW4NBqcyw/YN4rqf9WkoI/AAAAAAAAFUI/n9BtvEu64S4RyS3EQz7toaov1y-9fB0cgCLcBGAsYHQ/s1600/1625172899060875-34.png)** 

**\-** Tap on **Connect**

 **[![](https://lh3.googleusercontent.com/-cdUnhp-Pe4o/YN4rokYGI5I/AAAAAAAAFUE/__25soZDp-Eymdc3oRwhqHqwFvpDS18SQCLcBGAsYHQ/s1600/1625172887397835-35.png)](https://lh3.googleusercontent.com/-cdUnhp-Pe4o/YN4rokYGI5I/AAAAAAAAFUE/__25soZDp-Eymdc3oRwhqHqwFvpDS18SQCLcBGAsYHQ/s1600/1625172887397835-35.png)** 

**\-** Tap on **Trust Wallet**

 **[![](https://lh3.googleusercontent.com/-mIf2xwCMvxw/YN4rljbl9fI/AAAAAAAAFUA/Hu3qUsi8S08cM-Y5YFASzTLpJ_KIa6DFgCLcBGAsYHQ/s1600/1625172879484639-36.png)](https://lh3.googleusercontent.com/-mIf2xwCMvxw/YN4rljbl9fI/AAAAAAAAFUA/Hu3qUsi8S08cM-Y5YFASzTLpJ_KIa6DFgCLcBGAsYHQ/s1600/1625172879484639-36.png)** 

**\-** Tap on **CONNECT**

 **[![](https://lh3.googleusercontent.com/-J_RLMzbkF70/YN4rjntWObI/AAAAAAAAFT8/G_8Q6-H-LDgVzJpjTcIYNL_3_UUoxaqIgCLcBGAsYHQ/s1600/1625172867505728-37.png)](https://lh3.googleusercontent.com/-J_RLMzbkF70/YN4rjntWObI/AAAAAAAAFT8/G_8Q6-H-LDgVzJpjTcIYNL_3_UUoxaqIgCLcBGAsYHQ/s1600/1625172867505728-37.png)** 

**\-** Your trust wallet will be connected to pancakeSwap, Tap on **≡** and tap on **Exchange**

 **[![](https://lh3.googleusercontent.com/-YhTn9NUKNhU/YN4rgguQGQI/AAAAAAAAFT4/Pd0nJY2lglMo4WVwATcI_ufAnx8DHiElgCLcBGAsYHQ/s1600/1625172848520049-38.png)](https://lh3.googleusercontent.com/-YhTn9NUKNhU/YN4rgguQGQI/AAAAAAAAFT4/Pd0nJY2lglMo4WVwATcI_ufAnx8DHiElgCLcBGAsYHQ/s1600/1625172848520049-38.png)** 

**\-** From : Select BNB & Set Max or enter the amount you like to swap.

  

\- To : Select Any BEP 20 Token that you want to swap.

  

\- Tap on **Swap**.

  

Congratulations, You successfully learned how to transfer below 1$ / 100INR binance smartchain and use it on pancakeSwap!

  

Atlast, this trick is incredible you can get below 1$ / 100 INR binance smartchain without high withdrawal / transaction fee, it is convenient, simple and easy, due to that now you can now easily get binance smartchain in low amount to utilise it on pancakeSwap to swap BEP tokens, and yeah it is little lengthy to read here, but if you do in real it will be easy. So do it if there is definate requirement.

  

Overall, All the apps are simple, clean, quick fast, newbie friendly it is very easy to use due to its simple user interface that gives clean user experience packed with the required features but we have to wait & see will this apps get major UI upgrades in future to make it even more better, as of now all three apps feels fabulous that give perfect user interface and user experience which you may like to use for sure.  

  

Moreover, it is worth to mention CoinDCX do not charge you for Tron TRX withdrawals to any wallet which is an added advantage that you won't find in other wallets, this is one of the very few tricks that will transfer your bnb smartchain balance to trust wallet to be utilised on pancakeswap or anywhere else, Indeed so, if you are searching for a trick to transfer low amount of binance smartchain to trust wallet that is very easy to use and understand then we suggest you to prefer and choose this CoinDCX, faucetpay, Trust Wallet combined trick it is an excellent choice that has potential to become your new favorite.

  

Finally**, **This is how you can transfer Binance Smartchain below 1$ / 100 INR  to Trust Wallet or any other, one of the best, free, simple, low transaction and withdrawal fees method in minutes online,  so, do you like it? If you are an existing user of trick then do say your experience and reason why do you like this trick in our comment section below, see ya :)