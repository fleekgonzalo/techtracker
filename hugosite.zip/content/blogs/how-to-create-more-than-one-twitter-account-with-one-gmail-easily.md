---
title: 'How To Create More Than One Twitter Account With One Gmail - Easily ?'
date: 2020-03-24T22:32:00.001+05:30
draft: false
url: /2020/03/how-to-create-more-than-one-twitter.html
tags: 
- How
- Create
- Gmail
- Account
- More
- Twitter
---

  

[![](https://lh3.googleusercontent.com/-QYMqDindg64/XoId6f-DdwI/AAAAAAAABSc/d1o8xbgaAW8VImudR8M7xVMOiZZe-Xp7wCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-21.jpeg)](https://lh3.googleusercontent.com/-QYMqDindg64/XoId6f-DdwI/AAAAAAAABSc/d1o8xbgaAW8VImudR8M7xVMOiZZe-Xp7wCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-21.jpeg)

  

Tech Tracker | if you want another twitter account with same gmail then you find there no option in the twitter even if you try with same gmail you probably get an error !                                                                                                                                        But, we found a trick that can give the ability to create unlimited twitter account with one gmail.                                                                                      

To create another account just go to twitter signup and enter your gmail, now here is the important part - if your gmail - 12345@gmail.com then ad 12345+ gmail.com. twitter recognize + symbol as another gmail so you are to able to unlimited accounts add + or ++ even +++ all works.

  

this trick is only working for gmail only.