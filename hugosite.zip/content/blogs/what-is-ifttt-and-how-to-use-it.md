---
title: 'What Is IFTTT And How To Use It ?'
date: 2020-02-02T22:55:00.001+05:30
draft: false
url: /2020/02/what-is-ifttt-and-how-to-use-it.html
---

**  

[![](https://lh3.googleusercontent.com/-p330U4x6j0w/Xjex_qRJJ8I/AAAAAAAABBk/vMJHalNfEfM3pCv5IBS5bbQqRWdR3K3MwCLcBGAsYHQ/s1600/IMG_20200203_110829_189.jpg)](https://lh3.googleusercontent.com/-p330U4x6j0w/Xjex_qRJJ8I/AAAAAAAABBk/vMJHalNfEfM3pCv5IBS5bbQqRWdR3K3MwCLcBGAsYHQ/s1600/IMG_20200203_110829_189.jpg)

**

**

What Is IFTTT And How To Use It ?**

  

IFTTT is a automatic tool to connect apps and website services and its content or work automatically interconnected to ping or share one service work to other.

  

**What is IFTTT ?**

  

In simple - IFTTT means if this than this.

  

IFTTT have many features that can do hards tasks make simple as it automatic lly use its own bots and servers to do that automatic stuff.

  

You can automate things like changing wallpaper, calling phone number with voice commends via interconnecting apps and its services with other apps or website services linking with IFTTT.

  

IFTTT is completely free and easy to use and mainly to access this features you have to authorize both the services that you like to use with IFTTT without access

of the apps or sites and related things.

  

IFTTT won't work as it definitely need users and its access to do the things that users insisted in IFTTT.

  

IFTTT named this interconnecting thing as applet as which Is alternative name of bots, IFTTT has many applets that can be used for many popular services.

  

**What Is Applet ?**

Applet is alternative name for not that IFTTT uses for connections multiple apps and site service.

  

Every applet need to connect 2 of the apps or sites and its services as the applet specifically created for it.

  

There are many popular and useful applets that we like mention some of them.

  

**\- Applets **

**• Say thanks to the new twitter follower for following you **

**\- by** **reloy**

**• Tweet Your Instagram's as native images in Twitter **

**\- by Instagram**

**• Google Home - Find My Phone**

**• Update Your Android Wallpaper with the NASA's image of the day.**

**• Get a Notification When The International space station passes over your house.**

These are some of IFTTT popular applets

as you can connect almost all popular services and connect the services to do the tasks easily.

  

But wait, not all the applets are available as some of the applets are made by IFTTT itself and some are made by third party developers.

  

If you don't find the applet you are looking for then you can contact IFTTT for request or you can make yourself a applet with IFTTT

  

Check the website : [www.IFTTT.com](www.IFTTT.com)

  

How to Use IFTTT and its Applets ?

  

\- Go to [www.IFTTT.com](www.IFTTT.com) or search for ifttt app in PlayStore or Appstore

  

\- Go to website or app and sign in or sign up with your login info.

  

\- Now After Log In Go To - Settings and make sure to set timezone to your country.

  

Once sign in process completed.

  

\- Search for the service that you like to connect.

  

\- Once you find the applet that you are looking for then tap on it.

  

\- Setting applet is simple and easy as it only requires authorization of the service that you like to connect.

  

• Let's take an example : blogger to Pinterest.

  

This applet post every fb blogger to Pinterest.

  

Tap on the Applet - Tap on Connect 

  

\- Login To The Service's And Authorize IFTTT then IFTTT access things that they require to connect both services.

  

Once you authorize, then tap again on connect and it will be connected successfully.

  

You can now edit applet and make changes that you like to do.

  

**\- Advantages Of IFTTT**

  

• Eventhough there are a lot of IFTTT kind of websites but IFTTT have app and site which is completely free and simple

  

• You can create unlimited applets

  

• You can create your own applets.

  

• No downtime and you can easily check if there any error and trouble shoot if necessary 

  

• You can view activity

  

• All major applets are free and popular.

  

• Use can add which things that you like add or exclude with ingredients option.

  

• You can see how many times applet runs

  

IFTTT - Do the stuff that you like to do with applets in seconds that with human it takes hrs of time and connecting two to three service's and doing its works in seconds is amazing as that you can manage many other things.

  

If you are maintaining same services but have to update same data on both services than using IFTTT do make it simple and setting up is easy.

  

However, the downtime and run failure can be seen sometimes if you encounter the bug or issue you can easily report it to IFTTT through email support.

  

Finally, **" You can save a lot of time "**