---
title: 'fw.tv -  create short-form videos and rank them on Google News.'
date: 2022-02-17T22:47:00.001+05:30
draft: false
url: /2022/02/fwtv-create-short-form-videos-and-rank.html
tags: 
- technology
- Videos
- Google search
- Short-form
- fw.tv
---

 [![](https://lh3.googleusercontent.com/-9FqnxIcJlaw/Yg6DOYb5DjI/AAAAAAAAJOo/xL9O-uYMUYIDSkogJF06AbM25-vx9PnawCNcBGAsYHQ/s1600/1645118260465694-0.png)](https://lh3.googleusercontent.com/-9FqnxIcJlaw/Yg6DOYb5DjI/AAAAAAAAJOo/xL9O-uYMUYIDSkogJF06AbM25-vx9PnawCNcBGAsYHQ/s1600/1645118260465694-0.png) 

  

  

Usually, people create short form videos for YouTube shorts or TikTok kinda apps, but they won't get ranked on google search engine even if ranked somehow on Google search still they won't be listed on Google news as Google won't consider them as stories, most bloggers know and create stories with images to rank on Google, however Google even started ranking Short-form videos.

  

There are very few platforms available on Internet where you can create short-form videos and rank them on Google, but not everyone know about them as now a days 

image stories are popular among bloggers, anyhow if you're interested to create short form videos and rank them on Google then you may use [fw.tv](http://fw.tv) aka Firework.

  

Firework is same as TikTok or YouTube shorts, but the short-form videos you create on Firework can be ranked on Google news and search engine which increase engagement and website revenue at once, this is why popular bloggers already setup and started using Firework, as of now it has 300,000+ publishers and creators on video community.

  

If you register as creater on Firework, then you can upload long and short form videos in 9:16 vertical format and monetize them even create your own custom video store or add from Shopify, Ecwd etc, so do you like it? are you interested in Firework? If yes let's know little more info before we register and explore more.

  

**• Firework official support •**

**Email :** [developer@fireworkhq.com](mailto:developer@fireworkhq.com)

**Website :** [](http://fireworkhq.com)[fw.tv](http://fw.tv)

**• How to download Firework • **

It is very easy to download Firework form these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.loopnow.kamino)

\- [App Store](https://apps.apple.com/app/apple-store/id1359999964)

\- [Samsung Store](https://galaxystore.samsung.com/detail/com.loopnow.m4s?langCd=en)

**• How to register on Firework and create short-form videos •**

 **[![](https://lh3.googleusercontent.com/-915J2yBKTeg/Yg6DM4MPnOI/AAAAAAAAJOk/e5W5sCXLZ-YabhedU2DvS0KNl5xc_Vb4gCNcBGAsYHQ/s1600/1645118255628610-1.png)](https://lh3.googleusercontent.com/-915J2yBKTeg/Yg6DM4MPnOI/AAAAAAAAJOk/e5W5sCXLZ-YabhedU2DvS0KNl5xc_Vb4gCNcBGAsYHQ/s1600/1645118255628610-1.png)** 

\- Go to [fw.tv](http://fw.tv)

  

 [![](https://lh3.googleusercontent.com/-QdpKwNp2bmo/Yg6DLrbdrDI/AAAAAAAAJOg/0kJ94Y3621UDHf_IcfUcXS_T6RXvEjIrQCNcBGAsYHQ/s1600/1645118249466338-2.png)](https://lh3.googleusercontent.com/-QdpKwNp2bmo/Yg6DLrbdrDI/AAAAAAAAJOg/0kJ94Y3621UDHf_IcfUcXS_T6RXvEjIrQCNcBGAsYHQ/s1600/1645118249466338-2.png) 

  

\- Sign up with Email, Google, Facebook, Phone number.

  

 [![](https://lh3.googleusercontent.com/-ge1RgyLckVQ/Yg6DKEC2vZI/AAAAAAAAJOY/4Snoe-gXWagv2lBNJWOFFkExCTlQegDLwCNcBGAsYHQ/s1600/1645118244349495-3.png)](https://lh3.googleusercontent.com/-ge1RgyLckVQ/Yg6DKEC2vZI/AAAAAAAAJOY/4Snoe-gXWagv2lBNJWOFFkExCTlQegDLwCNcBGAsYHQ/s1600/1645118244349495-3.png) 

  

\- If you're an publisher, open fw.tv app.

  

 [![](https://lh3.googleusercontent.com/-kqW4ItovvaM/Yg6DIyp3SgI/AAAAAAAAJOU/bEwkt0OS3K0KMf-bYNUByGqD-DrlRljpwCNcBGAsYHQ/s1600/1645118238699309-4.png)](https://lh3.googleusercontent.com/-kqW4ItovvaM/Yg6DIyp3SgI/AAAAAAAAJOU/bEwkt0OS3K0KMf-bYNUByGqD-DrlRljpwCNcBGAsYHQ/s1600/1645118238699309-4.png) 

  

\- login with Email, Google, Facebook, Phone number.

  

 [![](https://lh3.googleusercontent.com/-IEQWpqREGD4/Yg6DHdXd1eI/AAAAAAAAJOQ/0QtLSw_LfXwap2vbSr2a_b6ZkU7sXmSdgCNcBGAsYHQ/s1600/1645118231904933-5.png)](https://lh3.googleusercontent.com/-IEQWpqREGD4/Yg6DHdXd1eI/AAAAAAAAJOQ/0QtLSw_LfXwap2vbSr2a_b6ZkU7sXmSdgCNcBGAsYHQ/s1600/1645118231904933-5.png) 

  

\- Tap to + to create short form videos, just like YouTube shorts or TikTok.

  

 [![](https://lh3.googleusercontent.com/-8i19meSos9s/Yg6DFhI4wdI/AAAAAAAAJOM/6qZM6DR0F4EIWxwpgbjbznlC6y2dnbTYACNcBGAsYHQ/s1600/1645118226584659-6.png)](https://lh3.googleusercontent.com/-8i19meSos9s/Yg6DFhI4wdI/AAAAAAAAJOM/6qZM6DR0F4EIWxwpgbjbznlC6y2dnbTYACNcBGAsYHQ/s1600/1645118226584659-6.png) 

  

\- Once, short form video is created, Add Title, hashtags then tap on **Post**.

  

 [![](https://lh3.googleusercontent.com/-BRmV0cg-4CQ/Yg6DEWlRNkI/AAAAAAAAJOE/ZDNwdVrkPRsChpICTE99BKKqC4KyhqBawCNcBGAsYHQ/s1600/1645118220789702-7.png)](https://lh3.googleusercontent.com/-BRmV0cg-4CQ/Yg6DEWlRNkI/AAAAAAAAJOE/ZDNwdVrkPRsChpICTE99BKKqC4KyhqBawCNcBGAsYHQ/s1600/1645118220789702-7.png) 

  

\- Now go to your firework username url,  there you can find your published short form videos which you can share.

  

 [![](https://lh3.googleusercontent.com/-aXiBnCxVmXE/Yg6DCzij0vI/AAAAAAAAJOA/5_YZHREGmZY0YO-GGErbXZjQX0IY1ih4ACNcBGAsYHQ/s1600/1645118214491903-8.png)](https://lh3.googleusercontent.com/-aXiBnCxVmXE/Yg6DCzij0vI/AAAAAAAAJOA/5_YZHREGmZY0YO-GGErbXZjQX0IY1ih4ACNcBGAsYHQ/s1600/1645118214491903-8.png) 

  

\- If you're an creator, just go to [fw.tv](http://fw.tv) then tap on **≡**

 **[![](https://lh3.googleusercontent.com/-5LzHUN4-OPQ/Yg6DBXlrzVI/AAAAAAAAJN8/QCbQgVBy_RYUpRztT2S3yC8LYUDyFRS5ACNcBGAsYHQ/s1600/1645118209407600-9.png)](https://lh3.googleusercontent.com/-5LzHUN4-OPQ/Yg6DBXlrzVI/AAAAAAAAJN8/QCbQgVBy_RYUpRztT2S3yC8LYUDyFRS5ACNcBGAsYHQ/s1600/1645118209407600-9.png)** 

\- Tap on **Creator**

 **[![](https://lh3.googleusercontent.com/-7ytJUoJbT1w/Yg6C_8lavMI/AAAAAAAAJN4/oi-FY4tVVNsL_mDMx8_3wUEadPQGI4ptQCNcBGAsYHQ/s1600/1645118203060840-10.png)](https://lh3.googleusercontent.com/-7ytJUoJbT1w/Yg6C_8lavMI/AAAAAAAAJN4/oi-FY4tVVNsL_mDMx8_3wUEadPQGI4ptQCNcBGAsYHQ/s1600/1645118203060840-10.png)** 

\- Enter your website url then tap on **Next**

 **[![](https://lh3.googleusercontent.com/-Bxi0nHdAkLo/Yg6C-bUhlMI/AAAAAAAAJN0/g9WRjbPWrhEwYu9SfrLpB6tdY8ILwU_VACNcBGAsYHQ/s1600/1645118196460813-11.png)](https://lh3.googleusercontent.com/-Bxi0nHdAkLo/Yg6C-bUhlMI/AAAAAAAAJN0/g9WRjbPWrhEwYu9SfrLpB6tdY8ILwU_VACNcBGAsYHQ/s1600/1645118196460813-11.png)** 

\- Enter your Business name then tap on **Complete**

 **[![](https://lh3.googleusercontent.com/--0QAUMstcJs/Yg6C8_YMlsI/AAAAAAAAJNw/sCUcXGQl4Zk_s37_IXz0VRKb8NtqfEH3gCNcBGAsYHQ/s1600/1645118190875466-12.png)](https://lh3.googleusercontent.com/--0QAUMstcJs/Yg6C8_YMlsI/AAAAAAAAJNw/sCUcXGQl4Zk_s37_IXz0VRKb8NtqfEH3gCNcBGAsYHQ/s1600/1645118190875466-12.png)** 

\- First if yiu have long videos select All videos else Short videos then just tap on **Upload Video.**

  

 [![](https://lh3.googleusercontent.com/-kXncxyCXNDs/Yg6C7Ql8rGI/AAAAAAAAJNs/vaMHzg8g2RATQ1fOeHIcKQBuSXTxXdQlgCNcBGAsYHQ/s1600/1645118184841528-13.png)](https://lh3.googleusercontent.com/-kXncxyCXNDs/Yg6C7Ql8rGI/AAAAAAAAJNs/vaMHzg8g2RATQ1fOeHIcKQBuSXTxXdQlgCNcBGAsYHQ/s1600/1645118184841528-13.png) 

  

\- Tap on Click to upload to select video from your storage then tap and select Video overlays, scroll down.

  

 [![](https://lh3.googleusercontent.com/-ofWWblSdDWA/Yg6C54LV56I/AAAAAAAAJNo/kzrjXXJRJm42YxCN_ie68FtrOE13gzwSwCNcBGAsYHQ/s1600/1645118178468568-14.png)](https://lh3.googleusercontent.com/-ofWWblSdDWA/Yg6C54LV56I/AAAAAAAAJNo/kzrjXXJRJm42YxCN_ie68FtrOE13gzwSwCNcBGAsYHQ/s1600/1645118178468568-14.png) 

  

\- Enter caption, Hashtags, etc then tap on **Create** 

  

 [![](https://lh3.googleusercontent.com/-wnsXkvRsw2k/Yg6C4HyTRlI/AAAAAAAAJNk/AWK3KGav3x09MMEHnbwKd2Pq8husU3jTACNcBGAsYHQ/s1600/1645118172009314-15.png)](https://lh3.googleusercontent.com/-wnsXkvRsw2k/Yg6C4HyTRlI/AAAAAAAAJNk/AWK3KGav3x09MMEHnbwKd2Pq8husU3jTACNcBGAsYHQ/s1600/1645118172009314-15.png) 

  

\- Your video is uploaded and processed, now tap on it.

  

 [![](https://lh3.googleusercontent.com/-u0ZDkW45_XA/Yg6C2hVq1jI/AAAAAAAAJNg/anm_8dO3BVwCKfp08PngfpoJQQwItG-xwCNcBGAsYHQ/s1600/1645118165317415-16.png)](https://lh3.googleusercontent.com/-u0ZDkW45_XA/Yg6C2hVq1jI/AAAAAAAAJNg/anm_8dO3BVwCKfp08PngfpoJQQwItG-xwCNcBGAsYHQ/s1600/1645118165317415-16.png) 

  

\- Tap on **</>**

 **[![](https://lh3.googleusercontent.com/-LG56oYk3DQQ/Yg6C06rTZVI/AAAAAAAAJNc/6-UVqAmDrsIZ7DrL4l4nGLaABceBj9YrgCNcBGAsYHQ/s1600/1645118160005128-17.png)](https://lh3.googleusercontent.com/-LG56oYk3DQQ/Yg6C06rTZVI/AAAAAAAAJNc/6-UVqAmDrsIZ7DrL4l4nGLaABceBj9YrgCNcBGAsYHQ/s1600/1645118160005128-17.png)** 

\- Tap on **Embed to web**

 **[![](https://lh3.googleusercontent.com/-g8-yCiSEwyI/Yg6CzhgkoII/AAAAAAAAJNY/TscsV3tGcEUq_OhrhtaQtkcL9yuPaSS4gCNcBGAsYHQ/s1600/1645118153805244-18.png)](https://lh3.googleusercontent.com/-g8-yCiSEwyI/Yg6CzhgkoII/AAAAAAAAJNY/TscsV3tGcEUq_OhrhtaQtkcL9yuPaSS4gCNcBGAsYHQ/s1600/1645118153805244-18.png)** 

\- Tap on **Copy code**

 **[![](https://lh3.googleusercontent.com/-2tYc4DBIc74/Yg6CyLE8_1I/AAAAAAAAJNU/q6mbVJXs8moVoB1mX7ewWHhH1ep57UBdgCNcBGAsYHQ/s1600/1645118148902280-19.png)](https://lh3.googleusercontent.com/-2tYc4DBIc74/Yg6CyLE8_1I/AAAAAAAAJNU/q6mbVJXs8moVoB1mX7ewWHhH1ep57UBdgCNcBGAsYHQ/s1600/1645118148902280-19.png)** 

\- Tap on **OK** and paste earlier copied code into HTML portion of your site.

  

 [![](https://lh3.googleusercontent.com/--M2HIkKTkRw/Yg6Cw3-rGDI/AAAAAAAAJNQ/5bC6h-HfOYMEwWIPtKqux1UXc88bhdLSwCNcBGAsYHQ/s1600/1645118142398573-20.png)](https://lh3.googleusercontent.com/--M2HIkKTkRw/Yg6Cw3-rGDI/AAAAAAAAJNQ/5bC6h-HfOYMEwWIPtKqux1UXc88bhdLSwCNcBGAsYHQ/s1600/1645118142398573-20.png) 

  

  

\- Tap on **≡**

 **[![](https://lh3.googleusercontent.com/-3Nuf_MQF8K0/Yg6CvSTbHkI/AAAAAAAAJNM/ORr_w_1LrngujcMVia_yW68_5weOqQC7gCNcBGAsYHQ/s1600/1645118133978638-21.png)](https://lh3.googleusercontent.com/-3Nuf_MQF8K0/Yg6CvSTbHkI/AAAAAAAAJNM/ORr_w_1LrngujcMVia_yW68_5weOqQC7gCNcBGAsYHQ/s1600/1645118133978638-21.png)** 

\- Tap on payment and add your bussines name, bank account and email to check earnings and payout.

  

That's it, you're good to go now onwards your short-form videos can get ranked on Google news and search engine.

  

Atlast, this are just highlighted features of Firework there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you're an publisher or creator and want to create short form videos to rank on Google news and search engine then you may use Firework.

  

Overall, Firework comes with light mode as default, it has well design with intuitive interface that ensures user friendly experience but in any project there is always space for improvement so let's wait and see will Firework get any major UI changes to make it even more better as of now it's awesome.

  

Moreover, it is worth to mention Firework is one of the best platform to create short form videos to monetize or rank them on Google news and search engine, yes indeed if you're searching for such platform then Firework has potential to become your new favorite choice.

  

Finally, this is Firework, a platform for publishers and creators to create short form video stories, are you an existing user of Firework? If yes do say your experience with Firework and mention which feature you like the most in our comment section below, see ya :)