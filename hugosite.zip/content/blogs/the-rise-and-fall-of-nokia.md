---
title: 'The rise and fall of Nokia.'
date: 2022-07-26T12:00:00.000+05:30
draft: false
url: /2022/07/the-rise-and-fall-of-nokia.html
tags: 
- Fall
- technology
- Lumia
- nokia
- rise
---

 [![](https://lh3.googleusercontent.com/-0TzI9EThbHE/YuBFZkWpoYI/AAAAAAAAMuI/ATSoDleFbC8tnhasvi8IODx-8ZAUYAMRwCNcBGAsYHQ/s1600/1658864973831843-0.png)](https://lh3.googleusercontent.com/-0TzI9EThbHE/YuBFZkWpoYI/AAAAAAAAMuI/ATSoDleFbC8tnhasvi8IODx-8ZAUYAMRwCNcBGAsYHQ/s1600/1658864973831843-0.png) 

  

On planet earth humans since ancient times wanted to communicate with each other from long distances to make that happen many human intellectuals found numerous ways at first humans used to travel by walk and meet fellow humans to talk with them but it's not easy as they can't always physically go to particular destination to communicate with fellow humans as there is no option they depended on it.

  

Eventually, humans able to express thier voice language in written form due to that they were able to write on any physical object to say or share information in beggining humans used to write on rocks with hard material and then on cloth using colours after that they found a way to get paper from tree that is better then rock or cloth etc to write so it is in continuous usage now.

  

 [![](https://lh3.googleusercontent.com/-JW8-Lvguc0k/YuESTt2802I/AAAAAAAAMvU/i-6WnkRcb0Y_sLrdXb6LT7QyTGMYTk0NACNcBGAsYHQ/s1600/1658917449331086-0.png)](https://lh3.googleusercontent.com/-JW8-Lvguc0k/YuESTt2802I/AAAAAAAAMvU/i-6WnkRcb0Y_sLrdXb6LT7QyTGMYTk0NACNcBGAsYHQ/s1600/1658917449331086-0.png) 

  

  

Humans, used to write information on cloth or paper then send it with fellow humans who taken this as mediator job then they started training birds to send information which is more convenient and comfortable but not everyone can train birds so they depended on fellow humans to send information by paying them with money after many centuries this written communication form is known as letters and humans also known as people in this modern era who work as mediator to send letters are called postmans.

  

Postmans, usually charge money from you to send letters to a particular destination in country or overseas if you send letter to long distance location then it can take alot of time like days or weeks based on travel method used by postmans but postmans are not trustworthy and take alot of time to send information including that people can't always write letters so they wanted best alternative to postmans.

  

Thankfully, many people for centuries tried to find ways to communicate with fellow people without letters and postmans in that process when mechanical era started in year 1450 people around the world invented alot of machines to simplify human life for instance trains with them people and postmans can travel faster to deliver letters but alot of mechanics and engineers worked hard to develop voice communicate machines by using them people can voice communicate in real time instantly in seconds or minutes.

  

 [![](https://lh3.googleusercontent.com/-Aqrazpq2vLw/YuESScCyNaI/AAAAAAAAMvQ/t77ECEwHkAwjv-gRAFBEeBUiv62PVGfUgCNcBGAsYHQ/s1600/1658917445551901-1.png)](https://lh3.googleusercontent.com/-Aqrazpq2vLw/YuESScCyNaI/AAAAAAAAMvQ/t77ECEwHkAwjv-gRAFBEeBUiv62PVGfUgCNcBGAsYHQ/s1600/1658917445551901-1.png) 

  

  

Innocenzo Manzetti a inventor first mooted the idea of speaking telegraph basically voice letter in year 1843 and then Antonio Meucci a french inventor credited as first to develop voice communication device in year 1876 after him Charles Bourseul wrote a memorandum of voice communicate device but he didn't made it later on many inventors worked to invent a working telephone and then on February 14, 1876 Alexander Graham Bell got patent for telephone a voice transmissible device to communicate with people over 6 miles.

  

 [![](https://lh3.googleusercontent.com/-T9mHQo9WVaM/YuESRU1WYAI/AAAAAAAAMvI/ds6tGgCtYTkWHDRJBHfZpObSW0N9Xt8WACNcBGAsYHQ/s1600/1658917441853309-2.png)](https://lh3.googleusercontent.com/-T9mHQo9WVaM/YuESRU1WYAI/AAAAAAAAMvI/ds6tGgCtYTkWHDRJBHfZpObSW0N9Xt8WACNcBGAsYHQ/s1600/1658917441853309-2.png) 

  

Telephone is big and expensive but eventually many inventors and companies around the world started making small size and affordable telephones to reach Telephone to everyone but the problem with telephone is it is wired and you can only communicate with people in short distances which is not enough as people wanted to communicate in long distances as there is demand for it alot of inventors and companies globally tried to make long distance support telephones.

  

 [![](https://lh3.googleusercontent.com/-qUGkTT1ErbY/YuESQkOu4oI/AAAAAAAAMvE/eL3OcNxLO8wqWWm8Kzw2oY_mX346wM1bgCNcBGAsYHQ/s1600/1658917437677177-3.png)](https://lh3.googleusercontent.com/-qUGkTT1ErbY/YuESQkOu4oI/AAAAAAAAMvE/eL3OcNxLO8wqWWm8Kzw2oY_mX346wM1bgCNcBGAsYHQ/s1600/1658917437677177-3.png) 

  

  

Fortunately, in year 1983 Motorola a American company build world's first small size wire-less handheld mobile phone named Motorola DynaTac 8000x which is better then telephones since then the era of wireless mobile phones begin but at first it's expensive yet has huge demand alot of telephone companies started making thier own custom mobile phones better then Motorola DynaTac 8000x.

  

The size and price of mobile phones keep on decreasing with increased features thanks to competition among mobile companies due to that we got modern keypad mobile phones but with mobile phones you can only call or message they lack features of computers.

  

 [![](https://lh3.googleusercontent.com/-sc_Nmka--yQ/YuESPjbLCNI/AAAAAAAAMvA/YXrC3eMfh_EmYg9TTUBbkt3YWVdO5jtFgCNcBGAsYHQ/s1600/1658917433556496-4.png)](https://lh3.googleusercontent.com/-sc_Nmka--yQ/YuESPjbLCNI/AAAAAAAAMvA/YXrC3eMfh_EmYg9TTUBbkt3YWVdO5jtFgCNcBGAsYHQ/s1600/1658917433556496-4.png) 

  

  

Computer is a mechanical device first invented by Charles Babbage during 1820s and 1830s later on people around the world invented various types of computers for different purposes eventually we got display computers with operating system basically a software build using several programming languages with them you can install more softwares that can do alot of real-life work electronically and digitally.

  

But, computers are big and expensive so most people unable to afford them even if they are able to buy yet they can't fit it in thier homes so only companies have and use them like IBM but later on many inventors and companies around the world started making thier own small size & affordable computers to sell commercially due to that by year 1970s we got personal computers.

  

PC aka personal computers are small in size and less expensive, better then computers with powerful hardware and operating system that occupy less space you can put PC on lap or small table and start using it in home or anywhere thus PCs are super comfortable but you can't hold and move them easily it takes time and they're not pocket friendly so many inventors and companies starting making much smaller PCs and eventually we got portable hand-held PCs.

  

Portable hand-held PC is pocket friendly first created by a company named Osborne after that many inventors and PC companies started making portable hand-held PCs but both PCs and portable hand-held PCs usually don't have sim card slot and support due to that you can't make telecom based direct calls and messages even though you can make Internet based calls and messages using world wide web digital platforms yet most people prefer and use sim card telecom network calls and messages as it's comfortable and  easy.

  

 [![](https://lh3.googleusercontent.com/-57dUpgqIi8Q/YuESOWKC1mI/AAAAAAAAMu8/tWwTW48qKu0Ic7MgYIEMfAwrIdPozjg6wCNcBGAsYHQ/s1600/1658917427106935-5.png)](https://lh3.googleusercontent.com/-57dUpgqIi8Q/YuESOWKC1mI/AAAAAAAAMu8/tWwTW48qKu0Ic7MgYIEMfAwrIdPozjg6wCNcBGAsYHQ/s1600/1658917427106935-5.png) 

  

  

There are number of companies who made different types of mobile phones with upgraded features using latest technologies due to that we got modern wireless mobile phones with operating systems like computers even though mobile phone hardware and operating systems is no match to PCs yet you can do some stuff of PC on mobile phones with small size KB aka kilo byte size softwares.

  

Anyhow, Nokia a finland company founded by Fredrik Idestam, Leo Mechelin, Eduard Polón on 12th May, 1865 started as pulp mill and associated with rubber and cables but since 1990s Nokia started making  and developing mobile phones and got world wide popularity due to that Nokia eventually from year 1998 for decade was largest worldwide vendor of mobile phones and smartphones.

  

 [![](https://lh3.googleusercontent.com/-ZQR46HTNkuY/YuESM7F89wI/AAAAAAAAMu4/_JV8mPf-sgIQzMxkEcTJjSnUtmDyRZyEQCNcBGAsYHQ/s1600/1658917422767640-6.png)](https://lh3.googleusercontent.com/-ZQR46HTNkuY/YuESM7F89wI/AAAAAAAAMu4/_JV8mPf-sgIQzMxkEcTJjSnUtmDyRZyEQCNcBGAsYHQ/s1600/1658917422767640-6.png) 

  

  

Nokia is top leading keypad mobile phone manufacturer with tagline connecting people well known for best quality keypad mobile phones around the world they made thousands of amazing keypad mobile phones in year 1990s out of them Nokia 3310 is called as indestructible and by year 2000s Nokia started making many cool keypad mobile phones with java and symbian operating systems and most of them are super successfull.

  

If you're from 1990s then you probably know Nokia and south korean mobile company Samsung used to mutually compete with each other in mobile market and with thier keypad mobile phones got huge fanbase and trusted customers but at the end alot of people used to prefer Nokia over Samsung keypad mobile phones.

  

In fact Nokia gained so much trust from people globally with it's premium and durable high quality keypad mobile phones majority of people used to go and buy Nokia keypad mobile phones without thinking much over other company keypad mobile phones but the downfall of Nokia started in year 2007 when Apple inc. entered in mobile market business.

  

 [![](https://lh3.googleusercontent.com/-qo1LZC4S6w0/YuESLoebN4I/AAAAAAAAMu0/znl_SY6-flYjWZRCwJgx_tenAlxCvHrTQCNcBGAsYHQ/s1600/1658917418301659-7.png)](https://lh3.googleusercontent.com/-qo1LZC4S6w0/YuESLoebN4I/AAAAAAAAMu0/znl_SY6-flYjWZRCwJgx_tenAlxCvHrTQCNcBGAsYHQ/s1600/1658917418301659-7.png) 

  

  

Apple inc. which used to make and sell PCs in 1990s later on in year 2005 they made world's first iPod to replace cassette music players after that on January 9, 2007 it's founder Steve jobs launched iPhone a revolutionary world's first multi-touch technology powerful and advanced software smartphone that can totally replace modern keypad mobile phones.

  

 [![](https://lh3.googleusercontent.com/-3pOoT-EUaD0/YuESKua8C0I/AAAAAAAAMuw/99eWYxjzmNEtCPSNSclCpo0f6gYfLiF-wCNcBGAsYHQ/s1600/1658917414623111-8.png)](https://lh3.googleusercontent.com/-3pOoT-EUaD0/YuESKua8C0I/AAAAAAAAMuw/99eWYxjzmNEtCPSNSclCpo0f6gYfLiF-wCNcBGAsYHQ/s1600/1658917414623111-8.png) 

  

  

iPhone 1st generation use a unnamed operating system as per Apple marketing literature it states iPhone 1st generation uses a Apple desktop operating system OS X but from iPhone 2nd generation Apple inc. named it's operating as iOS which has improvements and new features from then iPhone 1st generation operating system is considered as iOS 1.

  

The futuristic hardware and software technologies used on iPhone is way more powerful and advanced then keypad mobile operating systems due to that people wanted to buy them even though it's expensive so the demand for iPhone keep on rising meanwhile day by day the downfall of keypad mobile phones started due to that companies has no choice other then to make smartphones like iPhone.

  

 [![](https://lh3.googleusercontent.com/-Upj2s0fLdcw/YuESJi4B9EI/AAAAAAAAMus/wN29T3F3dXcuEem4HTCfloNXqo4GJ4pYwCNcBGAsYHQ/s1600/1658917410041235-9.png)](https://lh3.googleusercontent.com/-Upj2s0fLdcw/YuESJi4B9EI/AAAAAAAAMus/wN29T3F3dXcuEem4HTCfloNXqo4GJ4pYwCNcBGAsYHQ/s1600/1658917410041235-9.png) 

  

  

Most mobile companies especially Nokia and Samsung has potential and money to build top notch hardware smartphone but what they lack is modern operating system like iOS due to that they're unable to make a full fledged smartphone like iPhone so in order to survive in mobile market they either have to develop a operating system like iOS which is hard or bit modify and use keypad mobile phones operating systems on smartphones.

  

 [![](https://lh3.googleusercontent.com/--eoLHH3W89g/YuESIV7BJFI/AAAAAAAAMuo/VJvKvPYtkycfFxjZiOIuXJA4Beg1eQbUgCNcBGAsYHQ/s1600/1658917405420960-10.png)](https://lh3.googleusercontent.com/--eoLHH3W89g/YuESIV7BJFI/AAAAAAAAMuo/VJvKvPYtkycfFxjZiOIuXJA4Beg1eQbUgCNcBGAsYHQ/s1600/1658917405420960-10.png) 

  

  

Google, search engine giant in year 2005 purchased a operating system named Android from Andy Rubens then in year 2008 partnered with HTC a Taiwanese mobile company and released world's first Android operating system smartphone HTC Dream to compete with iPhone.

  

Android, is free and open source linux based operating system that has potential and capability to compete with iOS which anyone can build thier own version of Android via AOSP aka Android open source project and install on smartphones so with in few years almost all mobile companies started shipping smartphones with Android OS including Samsung but for whatever Nokia didn't used Android OS instead they they relyed on Java and mainly SymbianOS.

  

**[\+ Here's why, Symbian OS failed to beat Android OS on smartphones.](https://www.techtracker.in/2022/06/heres-why-symbian-os-failed-to-beat.html)**

  

**[\+ How to install Symbian OS apps on Android using EKA2L1 Emulator.](https://www.techtracker.in/2022/05/how-to-install-symbian-os-apps-on.html)**

  

 [![](https://lh3.googleusercontent.com/-8De_02wq7qI/YuESHWVSDiI/AAAAAAAAMuk/EqcNA7xN2SY1pj9ROYLYaN_wVR2hZainACNcBGAsYHQ/s1600/1658917398211376-11.png)](https://lh3.googleusercontent.com/-8De_02wq7qI/YuESHWVSDiI/AAAAAAAAMuk/EqcNA7xN2SY1pj9ROYLYaN_wVR2hZainACNcBGAsYHQ/s1600/1658917398211376-11.png) 

  

  

Especially, SymbianOS a operating system developed for PDAs aka personal digital assistants in year 1998 but later on Nokia further developed it to install on most Nokia smartphones over Android OS that poor decision eventually put Nokia out of league in mobile market as SymbianOS is not fully capable to compete with neither Android OS and iOS etc.

  

However, Nokia didn't leave SymbianOS they tried thier best to make SymbianOS better then Android OS but failed for alot of reasons foremost it is bit hard to develop apps for SymbianOS as Nokia didn't even provide proper guide for third party developers to build and create apps  while there are detailed guides to easily develop apps for Android OS so third party developers preffered and liked Android OS more then iOS for sure.

  

Meanwhile, Apple inc. encouraged even hired third party developers to create apps for iOS due to that iPhone always used to compete with Android OS in number of apps but at the end Android OS has more apps then iOS because Android OS is less expensive thus it has  72% + world wide share in case of iOS it's just 27% + as it's expensive and closed source operating system so no one can build and use on thier smartphones except Apple inc.

  

Even though, some third party developers build some apps and features to improve SymbianOS yet the user interface and user experience of Android OS and iOS is much better then SymbianOS so most people buyed Android OS and iOS powered smartphones due to that the sells of Nokia SymbianOS smartphones dropped heavily and eventually failed to beat Google's Android OS and Apple inc. iOS.

  

 [![](https://lh3.googleusercontent.com/-G6RE0K1vOAA/YuESFhiRX0I/AAAAAAAAMug/Zg2y7MKruz00E_Vl3S7H4xbGmo1B34TxQCNcBGAsYHQ/s1600/1658917391390596-12.png)](https://lh3.googleusercontent.com/-G6RE0K1vOAA/YuESFhiRX0I/AAAAAAAAMug/Zg2y7MKruz00E_Vl3S7H4xbGmo1B34TxQCNcBGAsYHQ/s1600/1658917391390596-12.png) 

  

  

The losses occured because of SymbianOS smartphones is huge yet Nokia stubbornly didn't use Android OS instead Nokia partnered with Microsoft and released Nokia Lumia smartphones powered by mobile version of popular desktop operating system Windows that recieved big attention and recognition from people around world.

  

Nokia Lumia series smartphones has top notch quality hardware and impressive Windows operating software so as usual nokia customers used to buy them over Android OS and iOS smartphones but at the end Nokia Lumia Windows smartphones got same fate of SymbianOS smartphones.

  

Windows, mobile operating system available on Nokia Lumia series smartphones is really cool and closed source like iOS that's fine but it doesn't got much third party developers support as there is no proper guides like Symbian OS and most third party developers highly focused on Android OS and iOS powered smartphones because of large userbase over Nokia Lumia Windows smartphones.

  

**[\+ The story of guy who installed Android OS on Windows phone.](https://www.techtracker.in/2022/03/the-story-of-guy-who-installed-android.html)**

  

Anyway, the price of Nokia Lumia smartphones is much higher then Android OS smartphones considering the quality of hardware it's understandable but software plays main role in smartphones which is insufficient in Nokia Lumia smartphones due to lack of required apps thus most people used to buy Android OS and iOS smartphones over half-baked Nokia Lumia windows operating system smartphones.

  

In few years Nokia Lumia smartphones struggled and eventually failed to beat Android OS and iOS smartphones that leaded to huge losses and put Nokia out of smartphone race in worldwide mobile market since then Nokia stopped making smartphones and selled it's mobile business to Microsoft and then focused on it's keypad mobile phones profitable business because of that Nokia is still in mobile market business globally.

  

 [![](https://lh3.googleusercontent.com/-7z8E6_KuIVo/YuESD0dtUOI/AAAAAAAAMuc/LvPKkoqlhqcSe0Ll6qfBRD-szfWpwrI3QCNcBGAsYHQ/s1600/1658917387791414-13.png)](https://lh3.googleusercontent.com/-7z8E6_KuIVo/YuESD0dtUOI/AAAAAAAAMuc/LvPKkoqlhqcSe0Ll6qfBRD-szfWpwrI3QCNcBGAsYHQ/s1600/1658917387791414-13.png) 

  

  

Luckily, Nokia ex-employees taking Nokia trademark rights found a company named HMD Global that released it's first Android OS smartphone Nokia 6 on 8 January, 2017 since then HMD global started manufacturing and shipping many Nokia smartphones with stock Android OS in partnership with Google's Android One program due to that new era of Nokia smartphones begin.

  

 [![](https://lh3.googleusercontent.com/-EZcYvVs6O-0/YuESC6z9pvI/AAAAAAAAMuY/TgYuPvaUkZEHp76NWVtqsLRBwnUAuEfIACNcBGAsYHQ/s1600/1658917383795018-14.png)](https://lh3.googleusercontent.com/-EZcYvVs6O-0/YuESC6z9pvI/AAAAAAAAMuY/TgYuPvaUkZEHp76NWVtqsLRBwnUAuEfIACNcBGAsYHQ/s1600/1658917383795018-14.png) 

  

  

Android one smartphones of Nokia is well applaused by customers because of regular software upgrades and updates and this time Nokia started making and selling smarphones in low, mid range and flagship ranges at less price but still Nokia unable to compete with china mobile companies like Xiaomi and Samsung M series as they provide much better smartphones then HMD global Nokia smartphones.

  

**[\+ The success story of Xiaomi.](https://www.techtracker.in/2022/07/the-success-story-of-xiaomi.html)**

  

Now, HMD Global is in losses even though there are able to sell some smartphones yet china mobile companies like Xiaomi and south korean mobile company Samsung dominating mobile market in developed and developing countries with it's feature rich low price smartphones so it's difficult to dodge them as they are selling Android OS smartphones way before HMD Global Nokia but let's wait and see is HMD Global do any miracles in near future to win against other mobile companies with it's Android powered smartphones.

  

Finally, this is rise and fall of Nokia, are you an existing user of Nokia Lumia or Android powered smartphones? If yes do say your experience and mention which one you like Nokia Lumia windows series or Android One smartphones in our comment section below, see ya :)