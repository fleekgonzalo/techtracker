---
title: 'SICO™ - A new battle royale game from indian developers on Android! '
date: 2021-03-12T20:33:00.000+05:30
draft: false
url: /2021/03/sico-new-battle-royale-game-from-indian.html
tags: 
- technology
- New
- Royale
- Developers
- game
- Battle
- Indian
- SICO
---

 [![SICO™ - A new battle royale game from indian developers on Android!](https://lh3.googleusercontent.com/-p9qTWsSDeig/YE93Jv_5SCI/AAAAAAAADio/wx0XF8nApb09wOnaMvn3oa0ltWpXbIsyACLcBGAsYHQ/s1600/1615820576073020-0.png "SICO™ - A new battle royale game from indian developers on Android!")](https://lh3.googleusercontent.com/-p9qTWsSDeig/YE93Jv_5SCI/AAAAAAAADio/wx0XF8nApb09wOnaMvn3oa0ltWpXbIsyACLcBGAsYHQ/s1600/1615820576073020-0.png) 

  

New battle royale games are on rage these days in india, every new week one new bat- tle royale game can be seen as Pub-G was banned and atma Nirbhar Bharat Program is inspiring and motivating many talented young developers to make amazing world class apps and games that can compete with global companies. 

  

**Yes**, After the ban of Pub-G due to many reasons and mainly because of security and data breach issues in India, we keen to see many new Battle Royale Games by indian developers and companies who are trying to compete other games.

  

In this new battle royale games, we found an interesting game named SICO : special insurgency counter operations developed by indie developers who just started game pre-registrations in play store giving alot of

information about the game to public. 

  

**SICO™** is a modern warfare shooting game that you can play with your friends with its multi-player feature you can enjoy intense action game in your hands that has loaded with high powered guns and there is many game modes that were included with alot of engaging maps with multiple characters to give full-fledged campaign. 

  

\- **App Info** - [Google Play](https://play.google.com/store/apps/details?id=com.indicarenasico.shooter) -  

  

 [![](https://lh3.googleusercontent.com/-qd9SEvtz8s8/YE93IG83fRI/AAAAAAAADik/evBObMnHGcQGjJg0l0mK4QWcCj3ZaTXZACLcBGAsYHQ/s1600/1615820567793184-1.png)](https://lh3.googleusercontent.com/-qd9SEvtz8s8/YE93IG83fRI/AAAAAAAADik/evBObMnHGcQGjJg0l0mK4QWcCj3ZaTXZACLcBGAsYHQ/s1600/1615820567793184-1.png) 

  

• **How to PRE-REGISTER or Download**  •

  

It is very easy to download **SICO™** on these platforms for free but as of now you can only **Pre-Register** for game because it is not released yet! 

  

\- [Google Play ](https://play.google.com/store/apps/details?id=com.indicarenasico.shooter)  

  

• **SICO™ Official Support** •

  

\- [Facebook](https://www.facebook.com/sicomobile/)

\- [Twitter](https://twitter.com/sicomobile?s=08)

\- [YouTube](https://youtu.be/RwseM-ZBdTQ)

\- [Discord](https://discord.gg/wFkp9wUz9F)

\- [Instagram](https://instagram.com/indicarena?igshid=srrkwzj48zvj)

\- [Linkedin](https://www.linkedin.com/company/indicarena)

  

Email : [infosicomobile@gmail.com](Mailto:infosicomobile@gmail.com)

**Website** : [sicomobile.com](http://sicomobile.com)  

  

• **SICO™ GamePlay Trailer •**

**\- **[YouTube](https://youtu.be/RwseM-ZBdTQ)

  

 [![](https://lh3.googleusercontent.com/-K03QfQOoOlQ/YFBDSDkPPzI/AAAAAAAADj0/b61puQwpvSs_PRJi1tf_diRtDBo3Q3w5wCLcBGAsYHQ/s1600/1615872831495868-0.png)](https://lh3.googleusercontent.com/-K03QfQOoOlQ/YFBDSDkPPzI/AAAAAAAADj0/b61puQwpvSs_PRJi1tf_diRtDBo3Q3w5wCLcBGAsYHQ/s1600/1615872831495868-0.png) 

  

 [![](https://lh3.googleusercontent.com/-uy3aXQCizXI/YFBDP0IK3YI/AAAAAAAADjs/c7Vk8bLz3PAI0vLfughx1jd_nQ4tHq5ugCLcBGAsYHQ/s1600/1615872822209011-1.png)](https://lh3.googleusercontent.com/-uy3aXQCizXI/YFBDP0IK3YI/AAAAAAAADjs/c7Vk8bLz3PAI0vLfughx1jd_nQ4tHq5ugCLcBGAsYHQ/s1600/1615872822209011-1.png) 

  

 [![](https://lh3.googleusercontent.com/-Tg4ThArERiw/YFBDNv8RTAI/AAAAAAAADjo/JmU2RIF0WOAhdkXfSBOzLHSzFz4N8WnLgCLcBGAsYHQ/s1600/1615872815889465-2.png)](https://lh3.googleusercontent.com/-Tg4ThArERiw/YFBDNv8RTAI/AAAAAAAADjo/JmU2RIF0WOAhdkXfSBOzLHSzFz4N8WnLgCLcBGAsYHQ/s1600/1615872815889465-2.png) 

  

 [![](https://lh3.googleusercontent.com/-RZN7ZD5RZ0w/YFBDLwZAXzI/AAAAAAAADjk/lNNnSYY6iZoGOgsYy7IWiqAEORPi1PgawCLcBGAsYHQ/s1600/1615872806723815-3.png)](https://lh3.googleusercontent.com/-RZN7ZD5RZ0w/YFBDLwZAXzI/AAAAAAAADjk/lNNnSYY6iZoGOgsYy7IWiqAEORPi1PgawCLcBGAsYHQ/s1600/1615872806723815-3.png) 

  

 [![](https://lh3.googleusercontent.com/-A6JnYAvjBUI/YFBDJiKN4CI/AAAAAAAADjg/o2EBcMoppck6L1hicyLeH7CEFbmVe5lxACLcBGAsYHQ/s1600/1615872797407080-4.png)](https://lh3.googleusercontent.com/-A6JnYAvjBUI/YFBDJiKN4CI/AAAAAAAADjg/o2EBcMoppck6L1hicyLeH7CEFbmVe5lxACLcBGAsYHQ/s1600/1615872797407080-4.png) 

  

 [![](https://lh3.googleusercontent.com/-bxanH6wEgMg/YFBDHCMEORI/AAAAAAAADjc/Pydl1aB7Os8kutQUGSqoM1p4qVNNJ-Y4QCLcBGAsYHQ/s1600/1615872790067505-5.png)](https://lh3.googleusercontent.com/-bxanH6wEgMg/YFBDHCMEORI/AAAAAAAADjc/Pydl1aB7Os8kutQUGSqoM1p4qVNNJ-Y4QCLcBGAsYHQ/s1600/1615872790067505-5.png) 

  

 [![](https://lh3.googleusercontent.com/-JlRitOX8MAA/YFBDFTlYMcI/AAAAAAAADjY/7K7KTqOlDicjJGTLwDNnxcNCLmOIxGepgCLcBGAsYHQ/s1600/1615872783479915-6.png)](https://lh3.googleusercontent.com/-JlRitOX8MAA/YFBDFTlYMcI/AAAAAAAADjY/7K7KTqOlDicjJGTLwDNnxcNCLmOIxGepgCLcBGAsYHQ/s1600/1615872783479915-6.png) 

  

 [![](https://lh3.googleusercontent.com/-YSCXlrXvE-I/YFBDD2wst2I/AAAAAAAADjU/YYB3Ett4Vwo797sp-Q2TgURiMzglf4aTACLcBGAsYHQ/s1600/1615872776334485-7.png)](https://lh3.googleusercontent.com/-YSCXlrXvE-I/YFBDD2wst2I/AAAAAAAADjU/YYB3Ett4Vwo797sp-Q2TgURiMzglf4aTACLcBGAsYHQ/s1600/1615872776334485-7.png) 

  

 [![](https://lh3.googleusercontent.com/-AIvwI5KfMBI/YFBDB_pM0CI/AAAAAAAADjQ/0Wy1fQRmJqw4hndXA-6zvr1uFv74Jqj-ACLcBGAsYHQ/s1600/1615872768818552-8.png)](https://lh3.googleusercontent.com/-AIvwI5KfMBI/YFBDB_pM0CI/AAAAAAAADjQ/0Wy1fQRmJqw4hndXA-6zvr1uFv74Jqj-ACLcBGAsYHQ/s1600/1615872768818552-8.png) 

  

 [![](https://lh3.googleusercontent.com/-K1vbRb1rNBw/YFBDANG8sLI/AAAAAAAADjM/sFO4wmLby5sj_5P-44ssAypFowY62bkNgCLcBGAsYHQ/s1600/1615872756430738-9.png)](https://lh3.googleusercontent.com/-K1vbRb1rNBw/YFBDANG8sLI/AAAAAAAADjM/sFO4wmLby5sj_5P-44ssAypFowY62bkNgCLcBGAsYHQ/s1600/1615872756430738-9.png) 

  

• **SICO™  Team •**

  

\- [About Us](https://indicarena.com/teams.html)

  

• **SICO™ : Donate • **

 **[![](https://lh3.googleusercontent.com/-dDGQSO-LEq8/YE93F_iRI-I/AAAAAAAADig/8JfJOHq0IpUbfpCAYc3_XA5SrKOVxRB7ACLcBGAsYHQ/s1600/1615820561066011-2.png)](https://lh3.googleusercontent.com/-dDGQSO-LEq8/YE93F_iRI-I/AAAAAAAADig/8JfJOHq0IpUbfpCAYc3_XA5SrKOVxRB7ACLcBGAsYHQ/s1600/1615820561066011-2.png)** 

Scan this QR code with any payment app ( by taking screenshot of this QR code ) or by copying this UPI address:   

##### indicarena@icici  

**PRATYUSH ANAND** is the banking name of Developers ( please don't panic while payment ) 

  

• **SICO™ Game Pre-Release Images •**  

 [![](https://lh3.googleusercontent.com/-oD_jVPwS-B4/YE93EOirNnI/AAAAAAAADic/r9hkIBsOfNICaHc6OD4Gt9pcwmV5pKdAQCLcBGAsYHQ/s1600/1615820554373113-3.png)](https://lh3.googleusercontent.com/-oD_jVPwS-B4/YE93EOirNnI/AAAAAAAADic/r9hkIBsOfNICaHc6OD4Gt9pcwmV5pKdAQCLcBGAsYHQ/s1600/1615820554373113-3.png) 

  

 [![](https://lh3.googleusercontent.com/-2M0hRbsco0s/YE93CoukfpI/AAAAAAAADiY/Hy1KPHmaLHYPTct-ymRHhxbKsXHrErCSwCLcBGAsYHQ/s1600/1615820547266617-4.png)](https://lh3.googleusercontent.com/-2M0hRbsco0s/YE93CoukfpI/AAAAAAAADiY/Hy1KPHmaLHYPTct-ymRHhxbKsXHrErCSwCLcBGAsYHQ/s1600/1615820547266617-4.png) 

  

 [![](https://lh3.googleusercontent.com/-jRj-MvtrlV4/YE93AzioTTI/AAAAAAAADiU/wSfe9QKuRUMozGviq6Zath2L49H1vBO9ACLcBGAsYHQ/s1600/1615820539856595-5.png)](https://lh3.googleusercontent.com/-jRj-MvtrlV4/YE93AzioTTI/AAAAAAAADiU/wSfe9QKuRUMozGviq6Zath2L49H1vBO9ACLcBGAsYHQ/s1600/1615820539856595-5.png) 

  

 [![](https://lh3.googleusercontent.com/-5PQ7Yj3q0Hw/YE92-zr6JVI/AAAAAAAADiM/nlT5f7wckvUbJ6MrgPWW8FjD_Ke8mOR6QCLcBGAsYHQ/s1600/1615820534669893-6.png)](https://lh3.googleusercontent.com/-5PQ7Yj3q0Hw/YE92-zr6JVI/AAAAAAAADiM/nlT5f7wckvUbJ6MrgPWW8FjD_Ke8mOR6QCLcBGAsYHQ/s1600/1615820534669893-6.png) 

  

 [![](https://lh3.googleusercontent.com/-gW3eQOJ0Y94/YE929pVGxdI/AAAAAAAADiE/TXaV4s9FxGo_w6ErZZTlTFE4nTaxR1HqACLcBGAsYHQ/s1600/1615820529809644-7.png)](https://lh3.googleusercontent.com/-gW3eQOJ0Y94/YE929pVGxdI/AAAAAAAADiE/TXaV4s9FxGo_w6ErZZTlTFE4nTaxR1HqACLcBGAsYHQ/s1600/1615820529809644-7.png) 

  

 [![](https://lh3.googleusercontent.com/-dOWOhUKHuF8/YE928QaV19I/AAAAAAAADiA/__HliojmvJUJ3zFSpXJFK5JotGxYcUbbQCLcBGAsYHQ/s1600/1615820524464828-8.png)](https://lh3.googleusercontent.com/-dOWOhUKHuF8/YE928QaV19I/AAAAAAAADiA/__HliojmvJUJ3zFSpXJFK5JotGxYcUbbQCLcBGAsYHQ/s1600/1615820524464828-8.png) 

  

**• ****SICO™ Developer Images • **

 **[![](https://lh3.googleusercontent.com/-KH42vBVK0j8/YE927Hcl03I/AAAAAAAADh8/l8mMqoE-IhsQiTLaGuL7c6yhCd03LWI2QCLcBGAsYHQ/s1600/1615820515712558-9.png)](https://lh3.googleusercontent.com/-KH42vBVK0j8/YE927Hcl03I/AAAAAAAADh8/l8mMqoE-IhsQiTLaGuL7c6yhCd03LWI2QCLcBGAsYHQ/s1600/1615820515712558-9.png)** 

 **[![](https://lh3.googleusercontent.com/-O_jrm6JDrdI/YE9249W6C_I/AAAAAAAADh0/g_4TnK23kfsVhJ8Uh5NnEm0609p-_SdNgCLcBGAsYHQ/s1600/1615820509174693-10.png)](https://lh3.googleusercontent.com/-O_jrm6JDrdI/YE9249W6C_I/AAAAAAAADh0/g_4TnK23kfsVhJ8Uh5NnEm0609p-_SdNgCLcBGAsYHQ/s1600/1615820509174693-10.png)** 

 [![](https://lh3.googleusercontent.com/-WjYjrjpCd_g/YE923BoXbvI/AAAAAAAADhw/oOIDml1TEa0WvcdTWAtbg4OnGXQccSwJgCLcBGAsYHQ/s1600/1615820501835803-11.png)](https://lh3.googleusercontent.com/-WjYjrjpCd_g/YE923BoXbvI/AAAAAAAADhw/oOIDml1TEa0WvcdTWAtbg4OnGXQccSwJgCLcBGAsYHQ/s1600/1615820501835803-11.png) 

  

 [![](https://lh3.googleusercontent.com/-loPOz8zUhGY/YE921VtGtII/AAAAAAAADhs/eIO-eJtPt6oP99l0YL-LFPx_DSvWLbEAgCLcBGAsYHQ/s1600/1615820490644275-12.png)](https://lh3.googleusercontent.com/-loPOz8zUhGY/YE921VtGtII/AAAAAAAADhs/eIO-eJtPt6oP99l0YL-LFPx_DSvWLbEAgCLcBGAsYHQ/s1600/1615820490644275-12.png) 

  

 [![](https://lh3.googleusercontent.com/-9wHHkhorG-A/YE92yaYpkeI/AAAAAAAADhg/vzN-5PqDKkIUovsQoPYYeoiBh5uPE_eYACLcBGAsYHQ/s1600/1615820483631552-13.png)](https://lh3.googleusercontent.com/-9wHHkhorG-A/YE92yaYpkeI/AAAAAAAADhg/vzN-5PqDKkIUovsQoPYYeoiBh5uPE_eYACLcBGAsYHQ/s1600/1615820483631552-13.png) 

  

 [![](https://lh3.googleusercontent.com/-bu32bhgQu8Q/YE92wvKHF2I/AAAAAAAADhc/TlYtll-lZJI_Tyx2PjIQXYSqerlIFIY5gCLcBGAsYHQ/s1600/1615820474118894-14.png)](https://lh3.googleusercontent.com/-bu32bhgQu8Q/YE92wvKHF2I/AAAAAAAADhc/TlYtll-lZJI_Tyx2PjIQXYSqerlIFIY5gCLcBGAsYHQ/s1600/1615820474118894-14.png) 

  

 [![](https://lh3.googleusercontent.com/-KjGdun5O0sY/YE92uXxAdcI/AAAAAAAADhY/-bORqTJRcGUq2JmGjk4DXa6-oDTYbDrowCLcBGAsYHQ/s1600/1615820457552708-15.png)](https://lh3.googleusercontent.com/-KjGdun5O0sY/YE92uXxAdcI/AAAAAAAADhY/-bORqTJRcGUq2JmGjk4DXa6-oDTYbDrowCLcBGAsYHQ/s1600/1615820457552708-15.png) 

  

  

**• ****SICO™ Maps • **

 **[![](https://lh3.googleusercontent.com/-FRrMI1uKgIo/YE92qRYItRI/AAAAAAAADhU/J8awKvm2cOcg38JqUCFopDj0rxhe1S5qgCLcBGAsYHQ/s1600/1615820452884807-16.png)](https://lh3.googleusercontent.com/-FRrMI1uKgIo/YE92qRYItRI/AAAAAAAADhU/J8awKvm2cOcg38JqUCFopDj0rxhe1S5qgCLcBGAsYHQ/s1600/1615820452884807-16.png)** 

 **[![](https://lh3.googleusercontent.com/-_mvZhztgse4/YE92pKzKwQI/AAAAAAAADhQ/nMkt75w0Yz0bGn0S8DWxLowAAuCurW6eQCLcBGAsYHQ/s1600/1615820447020646-17.png)](https://lh3.googleusercontent.com/-_mvZhztgse4/YE92pKzKwQI/AAAAAAAADhQ/nMkt75w0Yz0bGn0S8DWxLowAAuCurW6eQCLcBGAsYHQ/s1600/1615820447020646-17.png)** 

 [![](https://lh3.googleusercontent.com/-HPmEYZ0lN9k/YE92nh8vTWI/AAAAAAAADhM/OYWy9xGFg-42o5FmoO66ij1alZSu41ntwCLcBGAsYHQ/s1600/1615820443454119-18.png)](https://lh3.googleusercontent.com/-HPmEYZ0lN9k/YE92nh8vTWI/AAAAAAAADhM/OYWy9xGFg-42o5FmoO66ij1alZSu41ntwCLcBGAsYHQ/s1600/1615820443454119-18.png) 

  

 [![](https://lh3.googleusercontent.com/-0NNq4TZazG4/YE92mkEVBwI/AAAAAAAADhI/MQPEKkhrUyQIDi4qszkKD6jnuVKhz3DkACLcBGAsYHQ/s1600/1615820439382615-19.png)](https://lh3.googleusercontent.com/-0NNq4TZazG4/YE92mkEVBwI/AAAAAAAADhI/MQPEKkhrUyQIDi4qszkKD6jnuVKhz3DkACLcBGAsYHQ/s1600/1615820439382615-19.png) 

  

• **SICO™ Game Characters •**  

 **[![](https://lh3.googleusercontent.com/-GwBIDg5CtmE/YE92l8xWuAI/AAAAAAAADhE/feZ26DWbGnQo1fUZ4_JXZwgP6ZQsvQh2wCLcBGAsYHQ/s1600/1615820434370179-20.png)](https://lh3.googleusercontent.com/-GwBIDg5CtmE/YE92l8xWuAI/AAAAAAAADhE/feZ26DWbGnQo1fUZ4_JXZwgP6ZQsvQh2wCLcBGAsYHQ/s1600/1615820434370179-20.png)** 

 **[![](https://lh3.googleusercontent.com/-vEPd6a04lgA/YE92kY_l73I/AAAAAAAADhA/Gx942KhqRtgjpw5hFAF1cqZVedkl4SGMgCLcBGAsYHQ/s1600/1615820429242011-21.png)](https://lh3.googleusercontent.com/-vEPd6a04lgA/YE92kY_l73I/AAAAAAAADhA/Gx942KhqRtgjpw5hFAF1cqZVedkl4SGMgCLcBGAsYHQ/s1600/1615820429242011-21.png)** 

 **[![](https://lh3.googleusercontent.com/-2MkwZu7gyqk/YE92jJ2Wc0I/AAAAAAAADg4/PL7HbnGskRsFeTdW7gMeqMD_JuCtG17YQCLcBGAsYHQ/s1600/1615820368154815-22.png)](https://lh3.googleusercontent.com/-2MkwZu7gyqk/YE92jJ2Wc0I/AAAAAAAADg4/PL7HbnGskRsFeTdW7gMeqMD_JuCtG17YQCLcBGAsYHQ/s1600/1615820368154815-22.png)** 

 **[![](https://lh3.googleusercontent.com/-hKqqzbVPuwI/YE92T81S-MI/AAAAAAAADg0/8vd_c7AEm4QFEFXZV-0Ut0d9ngmT5bOjQCLcBGAsYHQ/s1600/1615820330486834-23.png)](https://lh3.googleusercontent.com/-hKqqzbVPuwI/YE92T81S-MI/AAAAAAAADg0/8vd_c7AEm4QFEFXZV-0Ut0d9ngmT5bOjQCLcBGAsYHQ/s1600/1615820330486834-23.png)** 

• **SICO™ Key features •**

**\- **Multiplayer Action Game / Modern Warfare Shooting Game / First Person Game / Sniper

  

\- You can customize your modes of playing either you want to play solo action game or a team play mode

  

\- There are multiple characters, and attachment system, etc.

  

\- Enjoy the 5 Match Modes in Modern Strike Online Game with Friends: Team Death Match, Free for all, Domination, Multiple Team Death Match, Gun Race. 

  

\- Modern Combat Online Game and Modern Warfare Shooter Game is Free for everyone!!!

  

\- In the Spectator Mode, you can watch your team mates engaged in live online FPS battles. 

  

\- Enjoy the Intense Shooting Action of “Modern Combat Online Game” in Squad vs Squad matches. 

  

\- Fight for yourself and your team survival in the classic mode of 100 players and enjoy the Modern Strike Online Game with Friends. 

  

\- Talk to your friends and plan strategies according to the situation in FPS Game (Action Game)

  

\- Engage in solo missions where you have to be the first person shooter and break the challenges. 

  

\- Play the epic missions and complete the challenges and tasks given to you in our Modern Combat Online Game. 

  

\- Enjoy the great graphics with intense sounds of Modern Warfare Shooting Game.

  

\- SICO™ comes with highly customizable controls so you can play our Modern Strike Online Game with Friends just like the way you want.

  

\- Enjoy the 5 Match Modes, Multiple Engaging Maps, and Multiple Characters with Attachment system in this Modern Combat Online Game (FPS Game)

  

**Overall**, this pre-release public images of SICO™ battle royale game looks fabulous & interesting and this images are super fine, based on all the images available out there

we can say the game will be impressive it increased alot of expectations. I hope the user interface and user experience will be good to compete other popular battle Royale game out there! 

  

**Moreover**, the game is made by Indic Arena who are young & aspiring Indie developers who want to make  an impact on gaming industry in India and this is thier big first serious project which they are continuously working to make it feel great, so we have to wait and see how SICO Battle Royale game will make an impact on the gamers especially who like to play multi-player and Battle Royale modes. 

  

**Finally**, this is the buzz and information about the game **SICO™** which is proudly made in india, do we raised your interest on this game, do you like the pre-release images, are you awaiting for the game like us?, if yes do mention your view and also share anything that you want to convey about **SICO™** game, we like to hear from you in our comment section below, see ya :)