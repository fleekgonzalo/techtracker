---
title: 'How to host your website with custom domain forever for free on WordPress!'
date: 2021-03-16T21:19:00.001+05:30
draft: false
url: /2021/03/how-to-host-your-website-forever-for.html
tags: 
- technology
- Infinityfree
- host
- Website
---

[![Infinityfree - How to host your website with custom domain forever for free on WordPress!](https://lh3.googleusercontent.com/-YClgI7ptHj4/YFRXu1LcviI/AAAAAAAADp4/hizG9TK4clQQGe_JKCpon2iP9-zpwllVACLcBGAsYHQ/s1600/1616140215362354-0.png "Infinityfree - How to host your website with custom domain forever for free on WordPress!")](https://lh3.googleusercontent.com/-YClgI7ptHj4/YFRXu1LcviI/AAAAAAAADp4/hizG9TK4clQQGe_JKCpon2iP9-zpwllVACLcBGAsYHQ/s1600/1616140215362354-0.png)

  

Do you want to host your website for free? If yes then infinityfree is a nice platform to full-fill the requirements it will provide you unlimited hosting for your website without forced ads and **99**% uptime, infinityfree is an established company with experience of 8 years in this hosting industry. 

  

**Infinityfree** provides fastest free hosting that was independently tested and found to be the fastest free hosting in the world with 99.9& uptime is their main priority, in infinityfree you will get unlimited hosting with unlimited disk space and bandwidth for free with no credit cards, time limits and no hidden fees and yes unlike some hosting providers infinityfree don't have forced ads which is good and infinityfree provide upto 25 free sub-domains to pick. 

  

  

 [![](https://lh3.googleusercontent.com/-lq114To5lm4/YFN18ZdLDLI/AAAAAAAADpg/ymfVfPfK_ww2CZLEYvX6WjvagcKJW5ncQCLcBGAsYHQ/s1600/1616082337984408-1.png)](https://lh3.googleusercontent.com/-lq114To5lm4/YFN18ZdLDLI/AAAAAAAADpg/ymfVfPfK_ww2CZLEYvX6WjvagcKJW5ncQCLcBGAsYHQ/s1600/1616082337984408-1.png) 

  

  

**Infinityfree** do provides softaculous script installer which will make it easy to install softwares unlike some hosting providers where you need to manually install them and yes this softaculous script installer can install **400+** applications in few clicks with most popular applications like joomla and Drupal, **WordPress**, MyBB, PrestaShop and phpBB etc.

  

• **Infinityfree official support • **

**\-** [Contact Us](https://infinityfree.net/contact/)

\- [Terms & Service](https://infinityfree.net/terms/)[](https://infinityfree.net/terms/)

\- [Privacy Policy](https://infinityfree.net/privacy/)

\- [Support Forum](https://forum.infinityfree.net/)

\- [Knowledge Base](https://support.infinityfree.net/)

  

• **Infinityfree Key features** •

  

\- Unlimted Disk Space

  

\- Unlimited Bandwidth

  

\- 400 MySQL Databases

  

\- PHP 5.4, 5.5, 5.6, 7.4

  

\- Full .**htaccess** Support

  

\- Full Sub-domain Names

  

\- Free SSL on all your domains

  

\- Free DNS Service

  

\- 1 FTP account

  

\- No email accounts

  

\- Limited Server Power

  

\- 50,000 daily hits. 

  

• **How to register in** [Infinityfree.com](http://www.Infinityfree.com)•

  

 [![](https://lh3.googleusercontent.com/-HLJkDWGOzu0/YFN1obuZvII/AAAAAAAADpU/2dPGHO155ZAvwOBhsWySC_NRvsOUoI2LACLcBGAsYHQ/s1600/1616082291131103-2.png)](https://lh3.googleusercontent.com/-HLJkDWGOzu0/YFN1obuZvII/AAAAAAAADpU/2dPGHO155ZAvwOBhsWySC_NRvsOUoI2LACLcBGAsYHQ/s1600/1616082291131103-2.png) 

  

\- Go to [infinityfree.com](http://www.infinityfree.com)

  

 [![](https://lh3.googleusercontent.com/-0MqKE2NElJs/YFN1cuSCLuI/AAAAAAAADpQ/Aio5e12aaMcEEhAK04V6TFzKzCjXM8hBQCLcBGAsYHQ/s1600/1616082114913848-3.png)](https://lh3.googleusercontent.com/-0MqKE2NElJs/YFN1cuSCLuI/AAAAAAAADpQ/Aio5e12aaMcEEhAK04V6TFzKzCjXM8hBQCLcBGAsYHQ/s1600/1616082114913848-3.png) 

  

\- **Scroll down**, until you find this option **Sign Up Now** and tap on it. 

  

 [![](https://lh3.googleusercontent.com/-CtXUmojh8LQ/YFN0wFGkkFI/AAAAAAAADpE/TlJptVKLg0YrVUJLzhoamu5obPk8EfE5ACLcBGAsYHQ/s1600/1616082094177572-4.png)](https://lh3.googleusercontent.com/-CtXUmojh8LQ/YFN0wFGkkFI/AAAAAAAADpE/TlJptVKLg0YrVUJLzhoamu5obPk8EfE5ACLcBGAsYHQ/s1600/1616082094177572-4.png) 

  

  

\- **Here**, you can tap on **Sign Up** if you don't have account, or you can tap on **Sign in**

 **[![](https://lh3.googleusercontent.com/-aeRHXPwlZ-g/YFN0rRt8pjI/AAAAAAAADo8/ixliYbo_IYgpWduAYM0snvWnj1V0aw0LQCLcBGAsYHQ/s1600/1616082035152987-5.png)](https://lh3.googleusercontent.com/-aeRHXPwlZ-g/YFN0rRt8pjI/AAAAAAAADo8/ixliYbo_IYgpWduAYM0snvWnj1V0aw0LQCLcBGAsYHQ/s1600/1616082035152987-5.png) 

￼- Once,** you login tap on **AGREE** to accept thier privacy policies. 

  

 [![](https://lh3.googleusercontent.com/-v3QsFOxHM0c/YFN0ckiCWTI/AAAAAAAADow/8geNcAtdeVczCItdOQ_rHc5enYRhwZSeQCLcBGAsYHQ/s1600/1616081997284743-6.png)](https://lh3.googleusercontent.com/-v3QsFOxHM0c/YFN0ckiCWTI/AAAAAAAADow/8geNcAtdeVczCItdOQ_rHc5enYRhwZSeQCLcBGAsYHQ/s1600/1616081997284743-6.png) 

  

**\-** After you **AGREE** privacy policies, then tap on **Create Account**. 

  

 [![](https://lh3.googleusercontent.com/-LHQKpSV3gO0/YFN0TB1XvbI/AAAAAAAADoo/D3H_MzllPrkaeBcb1kWmdsO2iTp5vMZJQCLcBGAsYHQ/s1600/1616081980965114-7.png)](https://lh3.googleusercontent.com/-LHQKpSV3gO0/YFN0TB1XvbI/AAAAAAAADoo/D3H_MzllPrkaeBcb1kWmdsO2iTp5vMZJQCLcBGAsYHQ/s1600/1616081980965114-7.png) 

  

**\- Now,** you can choose Sub-domain or custom domain, we choosed Sub-domain for demo purposes. 

  

\- choose any Sub-domain you like that was available or tap on custom domain to add your own and once you choosed or added own domain tap on **Search Domain. **

 **[![](https://lh3.googleusercontent.com/-wEvH-NThlKY/YFN0PFl35HI/AAAAAAAADog/b783YCLpOZEpFxwlT7DQpZWlqxa3wqyHQCLcBGAsYHQ/s1600/1616081950164882-8.png)](https://lh3.googleusercontent.com/-wEvH-NThlKY/YFN0PFl35HI/AAAAAAAADog/b783YCLpOZEpFxwlT7DQpZWlqxa3wqyHQCLcBGAsYHQ/s1600/1616081950164882-8.png)** 

\- **Then**, Enter your desired account label with your interested account **Username** and account **Password** and tap on **Create** **Account** by completing I'm not a robot captcha. 

  

 [![](https://lh3.googleusercontent.com/-jzRJz7AmZyE/YFN0Hb8DPRI/AAAAAAAADoc/Jn3T7mtuYooWThF8pM3IylzymfUTRRwWACLcBGAsYHQ/s1600/1616081921595396-9.png)](https://lh3.googleusercontent.com/-jzRJz7AmZyE/YFN0Hb8DPRI/AAAAAAAADoc/Jn3T7mtuYooWThF8pM3IylzymfUTRRwWACLcBGAsYHQ/s1600/1616081921595396-9.png) 

  

\- You successfully created account, check that in home URL of **infinityfree**, now tap on the username that was created now. 

  

 [![](https://lh3.googleusercontent.com/-GI9L92vfsLQ/YFN0ALXi9nI/AAAAAAAADoU/COJgh_E253o1KJHfArHJVqIVSi5putSMwCLcBGAsYHQ/s1600/1616081895280248-10.png)](https://lh3.googleusercontent.com/-GI9L92vfsLQ/YFN0ALXi9nI/AAAAAAAADoU/COJgh_E253o1KJHfArHJVqIVSi5putSMwCLcBGAsYHQ/s1600/1616081895280248-10.png) 

  

. 

\- Tap on **Control Panel**

 **[![](https://lh3.googleusercontent.com/-uQL0oLLByiY/YFNz5s4j4rI/AAAAAAAADoM/yxO8L0AtbT8Eb4goqjD10xoBwqjr1isSwCLcBGAsYHQ/s1600/1616081876465047-11.png)](https://lh3.googleusercontent.com/-uQL0oLLByiY/YFNz5s4j4rI/AAAAAAAADoM/yxO8L0AtbT8Eb4goqjD10xoBwqjr1isSwCLcBGAsYHQ/s1600/1616081876465047-11.png) 

￼-** You will be redirected to this page, tap on **I Approx** to access control panel. 

  

 [![](https://lh3.googleusercontent.com/-wbCFaG5UjGQ/YFNz0yP347I/AAAAAAAADoE/QwV9MS3MuDYQH8OmT2Z5_QRYFctUreztACLcBGAsYHQ/s1600/1616081836827011-12.png)](https://lh3.googleusercontent.com/-wbCFaG5UjGQ/YFNz0yP347I/AAAAAAAADoE/QwV9MS3MuDYQH8OmT2Z5_QRYFctUreztACLcBGAsYHQ/s1600/1616081836827011-12.png) 

  

\- In control panel, scroll down and find this option **Softaculous Apps Installer**. 

  

 [![](https://lh3.googleusercontent.com/-bO97PJtUasY/YFNzq4YOJtI/AAAAAAAADn8/sSO_q4LxjeEhg1yAqsr2Auvmm0EQmYHdACLcBGAsYHQ/s1600/1616081823946015-13.png)](https://lh3.googleusercontent.com/-bO97PJtUasY/YFNzq4YOJtI/AAAAAAAADn8/sSO_q4LxjeEhg1yAqsr2Auvmm0EQmYHdACLcBGAsYHQ/s1600/1616081823946015-13.png) 

  

\- There will be many popular top scripts available as most people like to choose and use WordPress we using same. 

  

\- Tap on **WordPress**

 **[![](https://lh3.googleusercontent.com/-e3ViqFUPFbY/YFNzn5KDNgI/AAAAAAAADn0/peURPWXGcYAS54ERdEyIjofKjIG4JrlDgCLcBGAsYHQ/s1600/1616081794810575-14.png)](https://lh3.googleusercontent.com/-e3ViqFUPFbY/YFNzn5KDNgI/AAAAAAAADn0/peURPWXGcYAS54ERdEyIjofKjIG4JrlDgCLcBGAsYHQ/s1600/1616081794810575-14.png)** 

  

\- Tap on **Install Now. **

 **[![](https://lh3.googleusercontent.com/-4UJtszK5X-4/YFNzgQ_auAI/AAAAAAAADnw/M-OniS00PjsfJf6hEyvud6xwTuGo2YBOACLcBGAsYHQ/s1600/1616081783781588-15.png)](https://lh3.googleusercontent.com/-4UJtszK5X-4/YFNzgQ_auAI/AAAAAAAADnw/M-OniS00PjsfJf6hEyvud6xwTuGo2YBOACLcBGAsYHQ/s1600/1616081783781588-15.png)** 

**\-** Give required details like **Site Name**, **Site** **Description** and scroll down to add more. 

**￼**

 **[![](https://lh3.googleusercontent.com/-COxyR4E_YvE/YFNzdvfl88I/AAAAAAAADno/1yo2d_JwjS8ItkIoCvWcZd708Vd9ggqqgCLcBGAsYHQ/s1600/1616081771593972-16.png)](https://lh3.googleusercontent.com/-COxyR4E_YvE/YFNzdvfl88I/AAAAAAAADno/1yo2d_JwjS8ItkIoCvWcZd708Vd9ggqqgCLcBGAsYHQ/s1600/1616081771593972-16.png)** 

**\- Again,** Give your interested Admin User- Name and Admin Password with Admin Email and keep them noted which you need to access WordPress panel and to recover username and password later. 

  

 [![](https://lh3.googleusercontent.com/-H3pF7yg9u1E/YFNzalHcS2I/AAAAAAAADnk/5dAZdG36G-8QOM_Fm0OyjCXRWZIv0Is1QCLcBGAsYHQ/s1600/1616081760095152-17.png)](https://lh3.googleusercontent.com/-H3pF7yg9u1E/YFNzalHcS2I/AAAAAAAADnk/5dAZdG36G-8QOM_Fm0OyjCXRWZIv0Is1QCLcBGAsYHQ/s1600/1616081760095152-17.png) 

  

\- **Scroll down,** Tap on Advanced Options and here you can remain it default or you can give your own directory name with the option to enable auto upgrade WordPress plugins or themes and more. 

  

 [![](https://lh3.googleusercontent.com/-6rCcgiSj900/YFNzX11fmMI/AAAAAAAADng/ESB-B7BSp4UsmZcB0JGgOd1lAZ4rCydZACLcBGAsYHQ/s1600/1616081723085916-18.png)](https://lh3.googleusercontent.com/-6rCcgiSj900/YFNzX11fmMI/AAAAAAAADng/ESB-B7BSp4UsmZcB0JGgOd1lAZ4rCydZACLcBGAsYHQ/s1600/1616081723085916-18.png) 

  

\- **Scroll down**, Select default WordPress theme or search for desired theme. 

  

 [![](https://lh3.googleusercontent.com/-oZsOja3VL8w/YFNzOoxFqhI/AAAAAAAADnc/xWkETiclPuQcBh6ug0Z7314s8FfEEXV_gCLcBGAsYHQ/s1600/1616081682700646-19.png)](https://lh3.googleusercontent.com/-oZsOja3VL8w/YFNzOoxFqhI/AAAAAAAADnc/xWkETiclPuQcBh6ug0Z7314s8FfEEXV_gCLcBGAsYHQ/s1600/1616081682700646-19.png) 

  

\- Scroll down, and tap on **Install**. 

  

  

\- It will start installing, it won't take more than 1 minute in most cases. 

  

 [![](https://lh3.googleusercontent.com/-vqZORw9iYCo/YFNzEnqECpI/AAAAAAAADnU/2JOM1q2spfYdBA-RjLi4CO9cC3Ra8O7LgCLcBGAsYHQ/s1600/1616081635180140-20.png)](https://lh3.googleusercontent.com/-vqZORw9iYCo/YFNzEnqECpI/AAAAAAAADnU/2JOM1q2spfYdBA-RjLi4CO9cC3Ra8O7LgCLcBGAsYHQ/s1600/1616081635180140-20.png) 

  

  

\- You will be notified like this upon the successfull software installation with website URL and Administrative URL which you need to use to **login**. 

  

• **How to login and use WordPress after software installed successfully •**

 **[![](https://lh3.googleusercontent.com/-_us_h7J3ljg/YFNy4mTjlrI/AAAAAAAADnI/2en0B3Pc0hYInayAtxfC3OKEnKiD2dLLQCLcBGAsYHQ/s1600/1616081606826135-21.png)](https://lh3.googleusercontent.com/-_us_h7J3ljg/YFNy4mTjlrI/AAAAAAAADnI/2en0B3Pc0hYInayAtxfC3OKEnKiD2dLLQCLcBGAsYHQ/s1600/1616081606826135-21.png)** 

**\-** Copy the administrative URL or enter your website URL website.com and at the end of URL put / and **wp-admin** which will redirect you to wp user panel where you can manage website. 

  

 [![](https://lh3.googleusercontent.com/--vMqL9KGgPU/YFNyxe-8enI/AAAAAAAADnE/Rf2S1lmHfY0SsMoWti7Hd6g8CcWKo4CgACLcBGAsYHQ/s1600/1616081578727434-22.png)](https://lh3.googleusercontent.com/--vMqL9KGgPU/YFNyxe-8enI/AAAAAAAADnE/Rf2S1lmHfY0SsMoWti7Hd6g8CcWKo4CgACLcBGAsYHQ/s1600/1616081578727434-22.png) 

  

  

\- Enter your WP Admin **USERNAME** and **Password** that you given at the time of WordPress installation. 

  

\- Tap on **Remember Me** if you want to login without re-entering details again. 

  

\- Tap on **Login**

  

 [![](https://lh3.googleusercontent.com/-9JGyZrs1Obs/YFNyqa2UxnI/AAAAAAAADnA/MtdLRp2Xq_MNPQJZnsBR2mVeRpjOiLDlQCLcBGAsYHQ/s1600/1616081499192915-23.png)](https://lh3.googleusercontent.com/-9JGyZrs1Obs/YFNyqa2UxnI/AAAAAAAADnA/MtdLRp2Xq_MNPQJZnsBR2mVeRpjOiLDlQCLcBGAsYHQ/s1600/1616081499192915-23.png) 

  

\- **Hurray**, Now your website is live on the WordPress where you can utilise 1000's of themes and plugins with the hosting of infinityfree forever for free. 

  

**Overall**, Infinityfree have easy to navigate user interface so that you can register or use the service in ease which gives it an clean experience for the users and vistors of the website, do you feel the same? 

  

**Moreover**, infinityfree is truly free hosting but you may notice ads on thier website because they are independent company who are relied on ads to be self-reliant and lprovide this features for free due to that they have to put ads on website which is **OK** in our opinion but they also provide thier premium services. 

  

**Check** : [Premium Services](https://infinityfree.net/premium/). 

  

**Finally**, the only problem that we seen in infinityfree was they only support 50,000 daily hits on the website which is major drawback in free plan other then that this is how you can utilise infinityfree to get unlimited hosting for website without any limits for free and get website or blog live on wordpress, what do you think about infinityfree is it good? Are you using it? If yes say your opinion in our comment section below, see ya :)