---
title: 'How to add contact form widget anywhere on blogger for free. '
date: 2021-12-14T23:41:00.001+05:30
draft: false
url: /2021/12/how-to-add-contact-form-widget-anywhere.html
tags: 
- How
- technology
- Blogger
- Contact Form
- Add
---

 [![](https://lh3.googleusercontent.com/-vZqwAx3yd_E/YbjeVai4f2I/AAAAAAAAH4I/U1cPeeiUk8IhmtJnicfGpNyKay5kd99VwCNcBGAsYHQ/s1600/1639505489773328-0.png)](https://lh3.googleusercontent.com/-vZqwAx3yd_E/YbjeVai4f2I/AAAAAAAAH4I/U1cPeeiUk8IhmtJnicfGpNyKay5kd99VwCNcBGAsYHQ/s1600/1639505489773328-0.png) 

  

Contact form is essential and important part of website, you can add it on page, article or somewhere on website layout so that your visitors can easily contact you even send files through it. now a days numerous bloggers using contact form instead of regular e-mail, as contact form have many benefits like it will reduce spam, collect feedback and many more.

  

However, some people don't know about contact forms, so they use regular emails to collect feedback, support requests and questions etc which will increase e-mails in inbox and make them feel like spam so due to that managing and replying to each and every email will become hard task and that can dissapoint thier visitors even give negative impact on sales, leads etc.

  

While, there are alot of plugins available for wordpress to add different types of contact forms, but for blogger there is no in-build plugins, so you have to depend on code to add contact form any where on blogger like either on specific page, article even on homepage but the issue here is if  you don't know coding then adding contact form on blogger is tough task.

  

 [![](https://lh3.googleusercontent.com/-WR0oy5nLi00/YbjeUbc3qxI/AAAAAAAAH4E/-EmnvJoRiZYDrHUCyexYvBroGx-IyLh1gCNcBGAsYHQ/s1600/1639505486720982-1.png)](https://lh3.googleusercontent.com/-WR0oy5nLi00/YbjeUbc3qxI/AAAAAAAAH4E/-EmnvJoRiZYDrHUCyexYvBroGx-IyLh1gCNcBGAsYHQ/s1600/1639505486720982-1.png) 

  

Eventhough, there is one contact form widget available on blogger which you can add from gadgets, but the problem with blogger contact form widget is it will send visitor's messages directly to your blogger email that is problematic including that pre-available contact form widget is very simple and don't give you any option to customize or add additional fields.

  

So, there is only two simple workarounds to add contact form on blogger, first one, is little hard task you have to make you own contact form widget, second one, you have to rely and add existing pre-made contact form widget codes created by developers that were publicly available on internet, it will ease the process and saves time.

  

But, on Internet we have many platforms where you can get contact form widget for blogger so you have to carefully select the best platform which is trusted and reputed by people so that you won't get any issues in future, including that the platform where you will get contact form widget code also should give customisation options with all possible security for user submissions.

  

In this scenario, we are glad to announce a best and reliable platform named elfsight where you will get 80+ widgets including contact form for free to add it on blogger, on elfsight you will get many contact form templates to select and edit according to your liking, once you finish setting up the contact form, you will get code which you can place on any HTML Editor, theme and website template etc.

  

Note : Elfsight free lite plan have some restrictions like you can only add one website, after that widget you created will only load 200 times on your website, so it will be useful for testing purpose and the elfsight free plan will work best for those who have low traffic and get below 200 contact submission in month, elfsight automatically reset 200 views limit every month, if you want to remove restrictions you can easily upgrade to paid plans on yearly basis, it's your choice.

  

**• How to register on elfsight and add contact form widget on blogger •**

 **[![](https://lh3.googleusercontent.com/-w5AGsLblgFw/YbjeT_3uH8I/AAAAAAAAH4A/CXksYUT2pvQA8oegAxQ0O4PFZy47kCEjQCNcBGAsYHQ/s1600/1639505483427948-2.png)](https://lh3.googleusercontent.com/-w5AGsLblgFw/YbjeT_3uH8I/AAAAAAAAH4A/CXksYUT2pvQA8oegAxQ0O4PFZy47kCEjQCNcBGAsYHQ/s1600/1639505483427948-2.png)** 

\- Go to [elfsight.com](http://elfsight.com) and tap on **≡**

 **[![](https://lh3.googleusercontent.com/-P_jp_LKwbbU/YbjeSycirsI/AAAAAAAAH38/27cvf4iTfgM4mbqyTACLpvP3fXG5-bKjQCNcBGAsYHQ/s1600/1639505480404231-3.png)](https://lh3.googleusercontent.com/-P_jp_LKwbbU/YbjeSycirsI/AAAAAAAAH38/27cvf4iTfgM4mbqyTACLpvP3fXG5-bKjQCNcBGAsYHQ/s1600/1639505480404231-3.png)** 

  

\- Tap on **Widgets**

  

 [![](https://lh3.googleusercontent.com/--ojRsAMi-UE/YbjeSNGna6I/AAAAAAAAH34/hxeArrvaa6QAes_WmfMWF5RpMOGKHTyIgCNcBGAsYHQ/s1600/1639505477061150-4.png)](https://lh3.googleusercontent.com/--ojRsAMi-UE/YbjeSNGna6I/AAAAAAAAH34/hxeArrvaa6QAes_WmfMWF5RpMOGKHTyIgCNcBGAsYHQ/s1600/1639505477061150-4.png) 

  

  

\- In search, Enter Contact Form and tap on Contact Form Widget available below.

  

 [![](https://lh3.googleusercontent.com/-6s73xbYuAao/YbjeRT_G_VI/AAAAAAAAH30/OkXElckulMYNWXaHiAI9SWdo-38t4mCWgCNcBGAsYHQ/s1600/1639505473752129-5.png)](https://lh3.googleusercontent.com/-6s73xbYuAao/YbjeRT_G_VI/AAAAAAAAH30/OkXElckulMYNWXaHiAI9SWdo-38t4mCWgCNcBGAsYHQ/s1600/1639505473752129-5.png) 

  

\- Tap on **Create widget**

 **[![](https://lh3.googleusercontent.com/-9wvxZhXCtGg/YbjeQo-ke-I/AAAAAAAAH3w/pBSP7wHG0eIpfM9rLGTQ4FuBM1Co38V-gCNcBGAsYHQ/s1600/1639505469382398-6.png)](https://lh3.googleusercontent.com/-9wvxZhXCtGg/YbjeQo-ke-I/AAAAAAAAH3w/pBSP7wHG0eIpfM9rLGTQ4FuBM1Co38V-gCNcBGAsYHQ/s1600/1639505469382398-6.png)** 

\- Tap on **Widget Settings >**

 **[![](https://lh3.googleusercontent.com/-xG-WoYwTaRA/YbjePVOx5-I/AAAAAAAAH3s/Mxs3ltzTvAcQvGFtV-CRd6xJXfasyXRJQCNcBGAsYHQ/s1600/1639505465984199-7.png)](https://lh3.googleusercontent.com/-xG-WoYwTaRA/YbjePVOx5-I/AAAAAAAAH3s/Mxs3ltzTvAcQvGFtV-CRd6xJXfasyXRJQCNcBGAsYHQ/s1600/1639505465984199-7.png)** 

\- Select contact form template and tap on **Continue with this template**  

 **[![](https://lh3.googleusercontent.com/-JaCNi4WDvio/YbjeOmYRVcI/AAAAAAAAH3o/m58SNKgBrDo_4BdF64Pr_C6qSQXDWNm4wCNcBGAsYHQ/s1600/1639505462958919-8.png)](https://lh3.googleusercontent.com/-JaCNi4WDvio/YbjeOmYRVcI/AAAAAAAAH3o/m58SNKgBrDo_4BdF64Pr_C6qSQXDWNm4wCNcBGAsYHQ/s1600/1639505462958919-8.png)** 

\- Here, you can do customisation and edit settings for contact form and scroll down.

  

 [![](https://lh3.googleusercontent.com/-MvEeUNHxeQI/YbjeN1Yg2qI/AAAAAAAAH3k/pArWSNmBe4YHRygRP-mxOTftjhlYdcq6gCNcBGAsYHQ/s1600/1639505459774453-9.png)](https://lh3.googleusercontent.com/-MvEeUNHxeQI/YbjeN1Yg2qI/AAAAAAAAH3k/pArWSNmBe4YHRygRP-mxOTftjhlYdcq6gCNcBGAsYHQ/s1600/1639505459774453-9.png) 

  

\- Tap on **JOIN TO INSTALL**

 **[![](https://lh3.googleusercontent.com/-Z04b3tU1dDo/YbjeNNY2cJI/AAAAAAAAH3g/_SIYFl9uNjoooN1FbBZ54jEsz09oiwfKACNcBGAsYHQ/s1600/1639505455447111-10.png)](https://lh3.googleusercontent.com/-Z04b3tU1dDo/YbjeNNY2cJI/AAAAAAAAH3g/_SIYFl9uNjoooN1FbBZ54jEsz09oiwfKACNcBGAsYHQ/s1600/1639505455447111-10.png)** 

\- Now, sign up with Email, Facebook or Google.

  

 [![](https://lh3.googleusercontent.com/-Vo80RKHxjGg/YbjeLx9_BdI/AAAAAAAAH3c/B19Vu9xPgFg0Mne5O0wAJjzeV8PZ7xalgCNcBGAsYHQ/s1600/1639505450994503-11.png)](https://lh3.googleusercontent.com/-Vo80RKHxjGg/YbjeLx9_BdI/AAAAAAAAH3c/B19Vu9xPgFg0Mne5O0wAJjzeV8PZ7xalgCNcBGAsYHQ/s1600/1639505450994503-11.png) 

  

\- Go to your email service provider and find mail from elfsight, you may find it in spam, check it and tap on **CONFIRM EMAIL**

 **[![](https://lh3.googleusercontent.com/-f_4V9avkCXE/YbjeK8ElMXI/AAAAAAAAH3Y/AhUdTmlg_boEzKIxDOMSagLJAC7u1lxXwCNcBGAsYHQ/s1600/1639505446807118-12.png)](https://lh3.googleusercontent.com/-f_4V9avkCXE/YbjeK8ElMXI/AAAAAAAAH3Y/AhUdTmlg_boEzKIxDOMSagLJAC7u1lxXwCNcBGAsYHQ/s1600/1639505446807118-12.png)** 

  

  

\- Tap on **Save** to create contact form.

  

 [![](https://lh3.googleusercontent.com/-RR_15Ghjm4Q/YbjeJlAEqaI/AAAAAAAAH3U/xLD0WO0IPMAV5aVt6k6Dzuuxa5FErxa8gCNcBGAsYHQ/s1600/1639505442978311-13.png)](https://lh3.googleusercontent.com/-RR_15Ghjm4Q/YbjeJlAEqaI/AAAAAAAAH3U/xLD0WO0IPMAV5aVt6k6Dzuuxa5FErxa8gCNcBGAsYHQ/s1600/1639505442978311-13.png) 

  

\- Select Lite plan if you want to use it for free else choose Enterprise, Pro, Basic according to your requirements.

  

 [![](https://lh3.googleusercontent.com/-xNwpNxcJy-0/YbjeI6gyacI/AAAAAAAAH3Q/oz0dEtFnbU0xxRsnCX5KGk2Lv_4uVopOQCNcBGAsYHQ/s1600/1639505439288562-14.png)](https://lh3.googleusercontent.com/-xNwpNxcJy-0/YbjeI6gyacI/AAAAAAAAH3Q/oz0dEtFnbU0xxRsnCX5KGk2Lv_4uVopOQCNcBGAsYHQ/s1600/1639505439288562-14.png) 

  

 [![](https://lh3.googleusercontent.com/-ePGuQmntdtg/YbjeH2rNw7I/AAAAAAAAH3M/y2DqQ00Ry909G8f6FHaTBgCba9lEIFc_gCNcBGAsYHQ/s1600/1639505435794634-15.png)](https://lh3.googleusercontent.com/-ePGuQmntdtg/YbjeH2rNw7I/AAAAAAAAH3M/y2DqQ00Ry909G8f6FHaTBgCba9lEIFc_gCNcBGAsYHQ/s1600/1639505435794634-15.png) 

  

\- There it is, Copy the code and go to your blogger layout and add **html / javascript** from gadgets in section where you want then tap on SAVE.

  

\- Get back to elfsight and tap on I have installed the code.

  

**• How to add elfsight contact form widget on blogger page or article •**

  

 [![](https://lh3.googleusercontent.com/-x7X7_JQubxU/YbjeG1YCM6I/AAAAAAAAH3I/jFh5Rpj1mmcJ4yeOEHLfsLPeEw_lccW3ACNcBGAsYHQ/s1600/1639505431682806-16.png)](https://lh3.googleusercontent.com/-x7X7_JQubxU/YbjeG1YCM6I/AAAAAAAAH3I/jFh5Rpj1mmcJ4yeOEHLfsLPeEw_lccW3ACNcBGAsYHQ/s1600/1639505431682806-16.png) 

  

  

\- Go to blogger and open blogger article or page or article where you want to add the contact form.

  

\- Paste elfsight contact form code that we copied earlier in article or page then select <> HTML view.

  

\- Tap on **Publish**

**WOOHOO**, you successfully added modern Contact Form on blogger for free.

  

Atlast, This are just highlighted key features of Elfsight there may be many hidden features inbuild that provides you external benefits to give you the ultimate usage experience, so if you want to easily add contact form on blogger then elfsight  can be a worthy choice.

  

Overall, On Elfsight free widgets including contact form a credit sticked at the end which is not necessary and impressive, except that elfsight give user friendly experience but elfsight have to improve little interms of thier user interface to make widget creation process simple and vibrant, let's wait and see many elfsight get major UI changes to improve.

  

 [![](https://lh3.googleusercontent.com/-yH7kJE0f3LI/YbjeF_B9XUI/AAAAAAAAH3E/tkroCPCtSEw1hNfql0-XMoiLitLA_L4DACNcBGAsYHQ/s1600/1639505421358862-17.png)](https://lh3.googleusercontent.com/-yH7kJE0f3LI/YbjeF_B9XUI/AAAAAAAAH3E/tkroCPCtSEw1hNfql0-XMoiLitLA_L4DACNcBGAsYHQ/s1600/1639505421358862-17.png) 

  

  

Moreover, after the creation of Contact form with elfsight, if any user send you information using Contact form, you can download all form submissions in .csv file format from elfsight itself then check all details of form submission offline, also you can create more widget, duplicate or edit existing widgets and check statistics.

  

Finally, this is how you can create contact form with elfsight and add it on blogger for free, so do you like it? Are you an existing user of Elfsight? If yes do say your experience and mention which widget and feature you the most in elfsight in our comment section below, see ya :)