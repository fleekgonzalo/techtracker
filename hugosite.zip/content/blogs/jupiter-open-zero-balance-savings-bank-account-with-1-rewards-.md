---
title: 'Jupiter - Open zero balance savings bank account with 1% rewards!'
date: 2021-10-09T23:00:00.000+05:30
draft: false
url: /2021/10/jupiter-open-zero-balance-savings-bank.html
tags: 
- technology
- Jupiter
- Savings Account
- Federal Bank
- Rewards
---

 [![](https://lh3.googleusercontent.com/-POwVsCIQCu4/YWHRrY5jhyI/AAAAAAAAG4c/apFhECOrp4wo4fvHvjiEzxR5UIfaOkfSwCLcBGAsYHQ/s1600/1633800585423975-0.png)](https://lh3.googleusercontent.com/-POwVsCIQCu4/YWHRrY5jhyI/AAAAAAAAG4c/apFhECOrp4wo4fvHvjiEzxR5UIfaOkfSwCLcBGAsYHQ/s1600/1633800585423975-0.png) 

  

We have numerous banks available while most banks need you to complete KYC in thier bank itself to open any kind of bank account but due to today's digital era and technology and mainly due to limitations of COVID-19 pandemic most banks either government owned or private using EKYC to verify person identity in india that takes less then few minutes if your phone number is connected to your Aaadhar Card.

  

Most people prefer to open bank account online there are millions of students want to open savings account for thier personal and shopping needs due to huge craze for zero balance savings account most banks already started online bank open facility in thier own apps and websites in india.

  

If you are planning to open bank account online then it is very important to choose bank wisely else you may face issue later because there are some banks which will provide zero balance savings account for name sake online but asks you to deposit minimum account balance & most banks ask you to upload documents which alot of people don't like including they restrict alot of features & don't provide physical debit card for free virtual which is surely another drawback for some people.

  

In this scenario, we have a workaround we found a bank named federal bank which is now providing free zero balance savings account with 1% rewards on all debit card and UPI payments to everyone who linked thier mobile number with Aadhaar card to do E-KYC by verifying OTP so you don't need to visit bank or upload documents everything will be done online smoothly on thier official app named Jupiter for free Including that you'll get free virtual debit card with no delivery fees as well, so are you interested in Jupiter? 

  

Jupiter is in a partnership with popular private sector bank named federal bank when compared to federal bank savings account, Jupiter saving account have more benefits and features which will amaze you but even though you will able to open bank account on Jupiter without physical kyc and uploading documents still you must do and complete video kyc within 1 year to become verified Jupiter user to unlock all features.

  

If you don't do video kyc on Jupiter, you will be termed as basic member so your Jupiter zero balance savings bank account will be valid only for 1 year with limited features after that it will expire but don't worry when we compared Jupiter with other banks, in Jupiter video kyc process is very quick and simple it will just take just 2 minutes to do video kyc to become full verified user and enjoy full features and awesomness of Jupiter in 24 hours.

  

Jupiter is currently in early access phase so you may able to find bugs and issues, but certainly Jupiter will be more amazing and better in the upcoming releases, even now Jupiter is near to perfection and we didn't found even single issue according to our personal usage experience, so do we got your attention on Jupiter? If yes let's know little more before we start Registering and start exploring Jupiter.

  

**• Jupiter Official Support •**

**\-** [Facebook](https://www.facebook.com/Jupiter-App-110524370493863)

\- [LinkedIn](https://in.linkedin.com/company/jupiter-money)

\- [Twitter](https://twitter.com/TheJupiterApp)

\- [YouTube](https://www.youtube.com/channel/UCVST4WhYtGRlyt1u9CDNNVQ)

**Website** **:** [Jupiter.money](https://www.Jupiter.money)

**Email :** [support@jupiter.money](mailto:support@jupiter.money)[](http://Support@jupiter.money)

**\- App Info** - [Google Play](https://play.google.com/store/apps/details?id=money.jupiter&utm_source=website&utm_medium=organic) -

**• How to download Jupiter •**

It is very easy to download Jupiter from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=money.jupiter&utm_source=website&utm_medium=organic)

**• How to register on Jupiter and do video kyc to become life time user •**

Note : Jupiter app do not allow to capture screen shots due to that we can't provide pictures so we will only able to guide you with text, kindly follow below instructions to open zero balance savings bank account on Jupiter absolutely for free.

  

\- Open Jupiter & Tap on **START**

\- Tap on **ALLOW** to give all app required permissions to proceed further.

  

\- Enter your mobile number and tap on

**Verify**.

  

\- Now, it will show you don't have a invite but don't worry just tap on **request invite**, then Jupiter will instantly give a special invite for you.

  

\- Then, Tap on **Continue**

\- Enter your Pan Card Number & Tap on **Continue**

  

\- Enter your Aaadhar Card Number & Tap on **Continue**

\- You will get OTP to your Aaadhar linked mobile number, go to your sms inbox and find the latest OTP recieved from Aaadhar and acknowledge it then enter the OTP in Jupiter app and tap on **Continue**.

  

\- Once done you will get basic member Jupiter zero balance savings account for free with validity of 1 year Instantly but if you want lifetime Jupiter account then you have to complete Jupiter video kyc.

  

**• How to do Video KYC on Jupiter • **

  

\- In home, Tap on **≡**

\- Below your name, Tap on **Basic Account**

\- Tap on **Know more**

  

\- It will ask you to do video kyc, just tap on **continue**

  

\- It will immediately try to connect with an video kyc agent within 2 minutes, just wait you will connected.

  

\- Before you connect with keep white paper, pen and pan card with you.

  

\- Once you connect with video kyc agent of Jupiter, follow the instructions to quickly Verify Jupiter Account and become life time user.

  

Hurray, you successfully learned how to register on Jupiter and do video kyc.

  

**• Jupiter key features with UI / UX Overview •**

\- Zero balance bank savings account with no hidden charges.

  

1% reward on all debit card and UI spends.

  

\- Your rewards will credited instantly and never expire.

  

\- Reddem with one tap.

  

\- Create pots and put as much as you want and withdraw any time, in Jupiter there is no restrictions and earn same interest on saved money as the rest of your account.

  

\- 100 % digital bank account.

  

\- Open bank account in just 3 minutes.

  

\- Jupiter is in partnership with RBI licensed bank named federal bank.

  

\- Free VISA physical debit card with no annual fees and no delivery fees.

  

\- Live chat support from 10 am to 9 pm.

  

\- Unlimited ATM withdrawals in federal bank and 5 transactions can be done in other bank ATMs for free, after that Jupiter will charge minimal transparent fees on ATM transactions and demand drafts.

  

\- 3.5% forex charge.

  

\- Money is insured up to ₹5,00,000.

  

\- Link all your bank accounts in Jupiter

  

\- You can add HDFC Bank, Kotak Mahindra Bank, ICICI Bank, SBI, Axis Bank, Yes Bank, Bank of Baroda, PNB, Canara Bank, and CitiBank which are supported and track balances in one screen on Jupiter.

  

\- Bank grade security with that is ISO and PCI complaint.

  

Atlast, This are just highlighted key features of Jupiter there may be many features in upcoming Jupiter releases, as Jupiter team said to expect advanced card controls, investments, bill payment, credit, and personalised advice in future that can provide you external benefits to give you the ultimate usage experience, so if you want the best digital bank to open zero balance savings account app that provide then Jupier can be worthy choice.

  

Jupiter simplified the process of opening bank account online making it is more convenient, simple and easy, due to that now you can easily open bank account online in few minutes for free without physical kyc and uploading documents, you just need need Aaadhar number and, Aadhar linked mobile number, pan card with you, that's it.

  

Overall, Jupiter is simple, clean, quick and fast due to that it is very easy to use that gives clean user friendly experience but we have to wait and see will Jupiter get any major UI improvements in future to make it even more better, as of now Jupiter user interface and user experience is very good with no objections from me.

  

Moreover, it is worth to mention Jupiter is one of the very few banks that provide you bank account without doing physical KYC, and uploading documents etc and Jupiter  is i believe the only bank which provides free debit card with no yearly fees and delivery charges including that Jupiter is the only bank that provide 1% returns on every debit card and UPI transactions, Simply amazing right?

  

Jupiter surely has more advantage to gain users over other banks which is major prospect Yes, Indeed so, if you are searching for bank to open bank account that is very easy to open and use with many features then we suggest you to prefer and choose Jupiter it is an smart choice that has potential to become your new favorite.  

  

Finally, This is Jupiter a neo bank that keeps pace with you, Jupiter is one of the best and easy to open zero balance bank saving account in India online for free but for 18+ only without uploading documents and physical kyc so, do you like it? are you an existing customer of Jupiter, if yes do say your experience and also mention why you like Jupiter in our comment section below, see ya :)