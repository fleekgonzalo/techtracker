---
title: 'Forkgram - best telegram fork with extra useful small features.'
date: 2022-02-14T22:07:00.001+05:30
draft: false
url: /2022/02/forkgram-best-telegram-fork-with-extra.html
tags: 
- Apps
- Forkgram
- Telegram
- Useful
- Client
---

 [![](https://lh3.googleusercontent.com/-v5JQsCJ0QDw/YgqFSjnZ5DI/AAAAAAAAJIk/wpda5dHJz-sJLjwWUhUjkqGqBc2gWHQvQCNcBGAsYHQ/s1600/1644856642658465-0.png)](https://lh3.googleusercontent.com/-v5JQsCJ0QDw/YgqFSjnZ5DI/AAAAAAAAJIk/wpda5dHJz-sJLjwWUhUjkqGqBc2gWHQvQCNcBGAsYHQ/s1600/1644856642658465-0.png) 

  

Telegram is amazing social messaging app founded by pavel durvov and nikoloi durov with awesome features that every user like, telegram has gone through alot of changes over the years, telegram strive to provide advanced new features timely and regularly, this is why large percentage of Whatsapp users and people around the globe started using telegram for it's best privacy and security oriented features for online anonymity.

  

However, there are some features missing on official telegram app that are required by few percentage users, this is why there are numerous Telegram clients created by developers to full-fill needs of users, while right now plus messenger is most popular telegram client for android with numerous useful and extra features, when it comes to iOS we have Nicegram which is best client with some additional features, so that you won't miss official telegram experience.

  

But, there is one underrated official telegram fork named  Forkgram which need some attention and recognition from people around the world  especially Telegram users, Forkgram is an open source Telegram client with some extra small useful features and changes that you won't get in other telegram forks, this is why Forkgram is pretty interesting.

  

Forkgram is publicly available open source app on Github since 2018 but for whatever reason it doesn't recieved enough required popularity, may be due to un-availabilty on playstore and app store, anyhow now we are going to show it's features, so that you will get better idea about Forkgram, so do you like it? are you interested in Forkgram? If yes let's know little more info before we explore more.

  

**• Forkgram official support •**

\- [Github](https://github.com/Forkgram)

**• How to download Forkgram •**

It is very easy to download Forkgram from these platforms for free.

  

\- [F-Droid](https://f-droid.org/en/packages/org.forkgram.messenger/) 

\- [Github](https://github.com/Forkgram/tdesktop) 

  

**• Forkgram key features with UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-2YixHSaePLs/YgqFQiTnSzI/AAAAAAAAJIg/XQVV6eUvPeUaTDJjJfUO1ukz9KP7UV4zACNcBGAsYHQ/s1600/1644856638878775-1.png)](https://lh3.googleusercontent.com/-2YixHSaePLs/YgqFQiTnSzI/AAAAAAAAJIg/XQVV6eUvPeUaTDJjJfUO1ukz9KP7UV4zACNcBGAsYHQ/s1600/1644856638878775-1.png)** 

  

\- Open Forkgram app then tap on **Start** **Messaging**.

  

 [![](https://lh3.googleusercontent.com/-YhmatWBD6SA/YgqFPX3P_GI/AAAAAAAAJIc/NfembNZop1cXm-oz3NrpQb35vMLkfXvgACNcBGAsYHQ/s1600/1644856634410957-2.png)](https://lh3.googleusercontent.com/-YhmatWBD6SA/YgqFPX3P_GI/AAAAAAAAJIc/NfembNZop1cXm-oz3NrpQb35vMLkfXvgACNcBGAsYHQ/s1600/1644856634410957-2.png) 

  

\- Login procedure is same of Telegram.

  

\- Enter your phone number and tap on ->

  

 [![](https://lh3.googleusercontent.com/-ak2MBQ3ED78/YgqFOU7HBHI/AAAAAAAAJIY/_xBHdvwrNR8jCfMLuED1yb6VoX760g2JwCNcBGAsYHQ/s1600/1644856630223930-3.png)](https://lh3.googleusercontent.com/-ak2MBQ3ED78/YgqFOU7HBHI/AAAAAAAAJIY/_xBHdvwrNR8jCfMLuED1yb6VoX760g2JwCNcBGAsYHQ/s1600/1644856630223930-3.png) 

  

\- On Forkgram you can add proxy from Login stage itself.

  

 [![](https://lh3.googleusercontent.com/-BiSf9FA7a78/YgqFNYBiC6I/AAAAAAAAJIU/CepGTss2mSkBsWOTAUnEDT71VvQmObw2gCNcBGAsYHQ/s1600/1644856626040091-4.png)](https://lh3.googleusercontent.com/-BiSf9FA7a78/YgqFNYBiC6I/AAAAAAAAJIU/CepGTss2mSkBsWOTAUnEDT71VvQmObw2gCNcBGAsYHQ/s1600/1644856626040091-4.png) 

  

\- Enter 5 digit OTP to login.

  

 [![](https://lh3.googleusercontent.com/-LiWp2zuYQTI/YgqFMc_F3tI/AAAAAAAAJIQ/E30rOP3OzFILz172Jppd1TMuJK8A_95dACNcBGAsYHQ/s1600/1644856622266428-5.png)](https://lh3.googleusercontent.com/-LiWp2zuYQTI/YgqFMc_F3tI/AAAAAAAAJIQ/E30rOP3OzFILz172Jppd1TMuJK8A_95dACNcBGAsYHQ/s1600/1644856622266428-5.png) 

  

\- Tap on ≡ then tap on **Settings**

 **[![](https://lh3.googleusercontent.com/-WIwY115BcAw/YgqFLdGu4gI/AAAAAAAAJIM/-uDpTaIyOt4N3-XUlMzBvGEDWY5WQfE2wCNcBGAsYHQ/s1600/1644856618261881-6.png)](https://lh3.googleusercontent.com/-WIwY115BcAw/YgqFLdGu4gI/AAAAAAAAJIM/-uDpTaIyOt4N3-XUlMzBvGEDWY5WQfE2wCNcBGAsYHQ/s1600/1644856618261881-6.png)** 

\- Tap on **Fork Client Settings**

 **[![](https://lh3.googleusercontent.com/-DPHM55eIsJk/YgqFKYQMP4I/AAAAAAAAJII/ttGcYPH96PcBgDXtIzI14SPS2NUHOiWLwCNcBGAsYHQ/s1600/1644856613941437-7.png)](https://lh3.googleusercontent.com/-DPHM55eIsJk/YgqFKYQMP4I/AAAAAAAAJII/ttGcYPH96PcBgDXtIzI14SPS2NUHOiWLwCNcBGAsYHQ/s1600/1644856613941437-7.png)** 

 **[![](https://lh3.googleusercontent.com/-iIrt3Yyija8/YgqFJbmM-YI/AAAAAAAAJIE/iig1Ya9CAtgNERzh0h-yaeZj9aw4fmxkwCNcBGAsYHQ/s1600/1644856606684606-8.png)](https://lh3.googleusercontent.com/-iIrt3Yyija8/YgqFJbmM-YI/AAAAAAAAJIE/iig1Ya9CAtgNERzh0h-yaeZj9aw4fmxkwCNcBGAsYHQ/s1600/1644856606684606-8.png)** 

\- There it is, Here we have extra features of which you can use for better experience.

  

Atlast, this are just highlighted features of

Forkgram there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best Telegram client with some useful extra features then Forkgram is on go choice.

  

Overall, Forkgram is fork of Telegram with only few changes, so you will get same feel good experience of Telegram which has light and dark mode with numerous themes and customization options, it has well designed intutive design that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will Forkgram get any major UI changes in future to make it even more better, as of now Forkgram is nice.

  

Moreover, it is definitely worth to mention Forkgram app file is available to install on Andriod and Windows, but we didn't find it for iOS, however there is one Github repo available for iOS which you may use to develop Forkgram app for iOS, I expect Forkgram official app for iOS may be available in future, remember there is no guarantee anyway.

  

Finally, this is Forkgram, a fork of Dklr/Telegram for Android and Telegram desktop application for Windows, with some extra useful features and changes which makes it easy to keep the fork up to date from official upstream, are you an existing user of Forkgram, what do you think about Forkgram, are you an existing user of Forkgram? If yes kindly do say your experience and mention which feature you like the most in our comment section below, see ya ;)