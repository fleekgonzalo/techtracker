---
title: 'What if india bans china mobiles and smartphones, will that work?'
date: 2022-09-07T12:00:00.000+05:30
draft: false
url: /2022/09/what-if-india-bans-china-mobiles-and.html
tags: 
- technology
- India ban
- Happen
- China Smartphones
- What
---

 [![](https://lh3.googleusercontent.com/-U7hSTsmzhpA/YxksCSkhd-I/AAAAAAAANj0/CkE8BCmRT0EnkmaORNiEnrfMkZKZxcQrQCNcBGAsYHQ/s1600/1662594053090786-0.png)](https://lh3.googleusercontent.com/-U7hSTsmzhpA/YxksCSkhd-I/AAAAAAAANj0/CkE8BCmRT0EnkmaORNiEnrfMkZKZxcQrQCNcBGAsYHQ/s1600/1662594053090786-0.png) 

  

India and china south asian countries since long time like centuries competing with each other in almost all arts mainly since industrial era occured in early 19th century when companies started setting up big and small factories for production of goods at rural and urban areas without caring much about earth environment due to that global pollution level increased but as we are mass producing goods because of that many countries economy pumped at the same time it leaded us to modern world of revolutionary technologies.  

  

Majority of countries in the world joined industrial revolution including India and china after Great Britain, England, France,  America and Germany etc even though both china and India used to be on par in terms of population and economy back in mid 19th century but china since it's 2nd industrial revolution started building alot of industries and factories even focused on promoting education because of that china in just few decades crossed india and many other countries except america in every sector that impact be seen now credit goes to communist party of china.

  

 [![](https://lh3.googleusercontent.com/-JSpGdHst55U/YxnEQwhC9kI/AAAAAAAANk4/nb4aKPJDhLI-HDKGkrwXAHBhBL_JeFY_gCNcBGAsYHQ/s1600/1662633022462808-0.png)](https://lh3.googleusercontent.com/-JSpGdHst55U/YxnEQwhC9kI/AAAAAAAANk4/nb4aKPJDhLI-HDKGkrwXAHBhBL_JeFY_gCNcBGAsYHQ/s1600/1662633022462808-0.png) 

  

Meanwhile, india which currency rupee used to be equal in value of America dollor in mid 19th century after Independence in year 1947 even after hundreds of billons looted by Britain in colonization rule that's pretty impressive but india didn't used it's funds well and made poor political and financial decisions because of that many wars occurred between neighbor countries like pakistan and china that negetively impacted India's economy immensely.

  

Especially, financial polices of India are incapable of improving economy as back in mid 19th century india for whatever reasons didn't setup industrial factories in large numbers they not even promoted education to the level of china because of that india both financial and education sectors suffered and stayed behind china that leaded them to stage of bankruptcy like venzuela and Sri Lanka now.

  

 [![](https://lh3.googleusercontent.com/-xMqqVCbJc1U/YxnEPu57zpI/AAAAAAAANk0/mxhxJ6vabvgxYTPa__S7UXWsKSwsn_nUgCNcBGAsYHQ/s1600/1662633018571800-1.png)](https://lh3.googleusercontent.com/-xMqqVCbJc1U/YxnEPu57zpI/AAAAAAAANk0/mxhxJ6vabvgxYTPa__S7UXWsKSwsn_nUgCNcBGAsYHQ/s1600/1662633018571800-1.png) 

  

  

The problem with india is being largest democratic state in the world after independence they have full freedom and authority to invite foreign companies to make business and establish companies which they did but only very few foriegn companies came to India because india terms and polices are lengthy completing and complying with them is bit hard which is why majority of foreign companies liked and preferred other democratic nations.

  

 [![](https://lh3.googleusercontent.com/-Pzolcq9pTv4/YxnEOsr9fCI/AAAAAAAANkw/AdJxkpPwNLIXIjO0b5WyVAKueljJjM0ZgCNcBGAsYHQ/s1600/1662633013402591-2.png)](https://lh3.googleusercontent.com/-Pzolcq9pTv4/YxnEOsr9fCI/AAAAAAAANkw/AdJxkpPwNLIXIjO0b5WyVAKueljJjM0ZgCNcBGAsYHQ/s1600/1662633013402591-2.png) 

  

In early year 1990s the financial situation of india is bad and the value of currency rupee is keep on decreasing due to lack of investments and exports if india don't stabilize value of rupee then it can become poor nation in the world at that time in year 1991 P.V Narsimha rao sworn as new prime minister of India who worked with financial minister Manmohan singh to solve financial crisis in that process they created new economic policies.

  

The new economic policies of 1991 are user friendly which devalued ruppee to attract foreign investments and eased way for foriegn entrepreneurs to establish companies and make business in india due to that in just few years alot of foreign companies with help from PV Narasimha Rao government established big and small companies that eventually not just fixed financial crisis and instability but also put india on top of world's biggest economy list after USA and China.

  

 [![](https://lh3.googleusercontent.com/-aNdXbUOHGs8/YxnENcN_FrI/AAAAAAAANks/OWgh4S5jflAWvPOqC47L9m_gQO1ornQCACNcBGAsYHQ/s1600/1662633008926397-3.png)](https://lh3.googleusercontent.com/-aNdXbUOHGs8/YxnENcN_FrI/AAAAAAAANks/OWgh4S5jflAWvPOqC47L9m_gQO1ornQCACNcBGAsYHQ/s1600/1662633008926397-3.png) 

  

Even though, india stock market crashed in year 1992 due to Harshad Mehta scam yet thanks to new economy policies it taken less time to make stock market get back to normal again including that government made many changes and reforms in indian stock exchange to improve security and fix loopholes which worked out very well.

  

 [![](https://lh3.googleusercontent.com/-f0w2U-PhPqo/YxnEMMdYfQI/AAAAAAAANko/wcYGH-lz6XYZRuCXCXoxz0ewe_RF5KUNACNcBGAsYHQ/s1600/1662633004248795-4.png)](https://lh3.googleusercontent.com/-f0w2U-PhPqo/YxnEMMdYfQI/AAAAAAAANko/wcYGH-lz6XYZRuCXCXoxz0ewe_RF5KUNACNcBGAsYHQ/s1600/1662633004248795-4.png) 

  

Fortunately, in early 20th century india shaped up and came to stage where it can compete with developed countries in terms of economy, national security and technologies thanks to prime minister atal bihari vajpayee who supported and conducted pokhran nuclear tests to make india global power and he also efficiently allocated and managed financial budgets to impove and upgrade all sectors of india.

  

 [![](https://lh3.googleusercontent.com/-0GUjsaExOaQ/YxnELCCklKI/AAAAAAAANkk/FxUTOaL9PHcSFOiRiUC4wv9yz96Va6SRQCNcBGAsYHQ/s1600/1662632998722252-5.png)](https://lh3.googleusercontent.com/-0GUjsaExOaQ/YxnELCCklKI/AAAAAAAANkk/FxUTOaL9PHcSFOiRiUC4wv9yz96Va6SRQCNcBGAsYHQ/s1600/1662632998722252-5.png) 

  

However, after year 2004 new government formed who didn't focused much on getting new india or foriegn companies and improving technologies to stand out in global competition race because of that india struggled and developments slowed down due to that India become least performing developing country in the world especially after year 2008 stock market crash that caused india to go much behind many countries mainy people republic of china.

  

Thankfully, we have many indian companies and conglomerates who totally make and produce goods in india itself known as desi goods which they usually sell in india but also exported to foriegn companies due to that india don't fully rely on foriegn companies for goods but because of poor decisions of government back in mid 19th century india is one of the highest importer of goods from many 

countries around the world out of them china is favourite choice.

  

 [![](https://lh3.googleusercontent.com/-WCNQBCCY4fg/YxnEJuOdCoI/AAAAAAAANkg/mrLqXIbSVU0E-2rrho21KKaDDVPm8bYmgCNcBGAsYHQ/s1600/1662632992905939-6.png)](https://lh3.googleusercontent.com/-WCNQBCCY4fg/YxnEJuOdCoI/AAAAAAAANkg/mrLqXIbSVU0E-2rrho21KKaDDVPm8bYmgCNcBGAsYHQ/s1600/1662632992905939-6.png) 

  

China, as said earlier is communist country so they believe in equality among all people beside thier financial standards including that they work together for the development of country which is why the ruling communist party of china back in mid 19th century massively setup alot of industries, factories and created world class infrastructure and technologies without relying on foreign companies due to that china is self reliant in all sectors so they are constantly working on to beat america from long time and become world super power #1 top biggest economy.

  

The major factor behind china such high economy growth is because of less imports and large number of exports thanks to low labour costs and china pre-available infrastructure they are able to make and manufacture goods fast and export or sell them at low rate globally.

  

Even though, india had several wars between china regarding borders yet as they export goods at low price then any other countries so for the benefit of Indian government and it's citizens since long time indian government importing all types of required goods in large numbers especially electronic products.

  

In sense, india is largest exporter of china goods mainly electronic products due to that you see or use atleast one china product knowingly or unknowingly as they occupied every corner of markets in india which put india in difficult state as highly relying on neighbor country with chances of war in future is not good but as there is no better option india regularly dealing and exporting goods from china even now.

  

 [![](https://lh3.googleusercontent.com/-jJdYQ3BhUe4/YxnEIGsaQvI/AAAAAAAANkc/oQ9im4Vv0v0alOb5bNaXnE027UzKAmzRgCNcBGAsYHQ/s1600/1662632988570477-7.png)](https://lh3.googleusercontent.com/-jJdYQ3BhUe4/YxnEIGsaQvI/AAAAAAAANkc/oQ9im4Vv0v0alOb5bNaXnE027UzKAmzRgCNcBGAsYHQ/s1600/1662632988570477-7.png) 

  

In year 2014, Narendra Modi former longest chief minister of state Gujarat sworn as prime minister of India who continously and constantly working on to de-neutralise previous governments bad political and financial decisions effects at that same time he planned to make connection between foriegn country healthier and launched revolutionary schemes and people benefit programs to improve life of citizens and make india powerful and advanced in all sectors.

  

 [![](https://lh3.googleusercontent.com/-OLlA-T4lu8I/YxnEHBQQjGI/AAAAAAAANkY/ibb0-UJKuR0FpZfkq8L1mUP1slhR-n5-QCNcBGAsYHQ/s1600/1662632983446652-8.png)](https://lh3.googleusercontent.com/-OLlA-T4lu8I/YxnEHBQQjGI/AAAAAAAANkY/ibb0-UJKuR0FpZfkq8L1mUP1slhR-n5-QCNcBGAsYHQ/s1600/1662632983446652-8.png) 

  

  

Narendra Modi government focused on promoting and developing indian companies and technologies to reduce reliance on foriegn companies to maximum level due to that indian companies like for instance reliance India's largest conglomerate with help and support of indian government build and introduced alot of technologies and products like Jio network as part of digital india campaign which are widely used in india that even put india in highest mobile data usage country in world.

  

But, even after 2014 in rule of Narendra Modi government, goods imports from china didn't stopped as in india there is no complete infrastructure and technologies to make certain goods and electronic products to fix this Narendra Modi launched Made in india to promote and make citizens buy indian products which worked out but due of lack of required infrastructure and technologies indian companies can't make all goods which is why deals and exports from china were going on uninterruptedly.

  

 [![](https://lh3.googleusercontent.com/-qSd9oPSudoU/YxnEFvfNJpI/AAAAAAAANkU/Wvrg54lusTIBuE7WsDkT6kCG4W4hH6gwwCNcBGAsYHQ/s1600/1662632978331216-9.png)](https://lh3.googleusercontent.com/-qSd9oPSudoU/YxnEFvfNJpI/AAAAAAAANkU/Wvrg54lusTIBuE7WsDkT6kCG4W4hH6gwwCNcBGAsYHQ/s1600/1662632978331216-9.png) 

  

The reliance and large number of imports from china companies for goods is slightly increasing india economy but that's not enough as china is highly benefiting from it which is why Narendra Modi launched Make in india program which provide user friendly terms and policies with required help from government to establish companies and make goods in india itself employing indian people thus we can get more profit and boost in economy.

  

Make in india is quite succesfull as alot of china and other foriegn country companies starting establishing companies and assemble plants to make goods and products over building and importing them from thier own country which boosted India's economy at the same time given employment to alot of people to make living out of it.

  

Now, we have many china and other foriegn companies who make or we can assemble imported parts of goods and electronic devices or electric machinery in india like Toys, TVs, Smartphones, Radios, speakers and many more then add make in india tag on product to sell them across India which people buy as they are most low price and for patriotic reasons.

  

 [![](https://lh3.googleusercontent.com/-Eyi8t4PZbNI/YxnEEf_mljI/AAAAAAAANkQ/Z7ujLaPswpwkP6118XOhEbrTYVgK0lJYQCNcBGAsYHQ/s1600/1662632973041073-10.png)](https://lh3.googleusercontent.com/-Eyi8t4PZbNI/YxnEEf_mljI/AAAAAAAANkQ/Z7ujLaPswpwkP6118XOhEbrTYVgK0lJYQCNcBGAsYHQ/s1600/1662632973041073-10.png) 

  

Smarphones from china companies sell like hot or cool cakes in india over other electronic devices as china companies provide feature rich smartphones at value for money low price possible over indian and other foriegn smartphones companies because china companies has complete infrastructure and take less profit margin thus it's possible for them.

  

In case, you don't know what exactly is smarphone then for you in simple smartphone is an revolutionary electronic device first launched by Apple inc. founder Steve Jobs in year 2007 with powerful closed source hardware and software named iPhone that has patented multi-touch display technology came into existence to replace keypad mobile phones.

  

Keypad mobiles phones sells gradually dropped little by little after entry of iPhone as people buying iPhone to level it go out of stock in few minutes mainly in USA and European countries even though it's very expensive due to that mobile companies around the world has no choice other then to manufacture smartphones like iPhone which they eventually did with open source hardware and softwares.

  

 [![](https://lh3.googleusercontent.com/-5TFJ2PtyPvo/YxnEDMraj7I/AAAAAAAANkM/j7eINOtRioEHE7OhSvhwolZ92aWkYfj5gCNcBGAsYHQ/s1600/1662632968299463-11.png)](https://lh3.googleusercontent.com/-5TFJ2PtyPvo/YxnEDMraj7I/AAAAAAAANkM/j7eINOtRioEHE7OhSvhwolZ92aWkYfj5gCNcBGAsYHQ/s1600/1662632968299463-11.png) 

  

China mobile companies also started making smartphones after iPhone and they used to sell them only in china but for commercial reasons or any other agenda in year 2014 they gone international in that process they begin importing budget smartphones targeting developing countries like India where they got huge recognition and sells for thumping and whopping success.

  

There are many mobile companies in india who sell keypad mobile phones and smartphones like Micromax, Karbonn, Celkon etc which used to import china smartphones then add thier company logo with extra added profit margin to sell in india which got huge profits but direct entry of china smartphones in india totally broke down india mobile companies as people stopped buying over priced indian mobile companies instead liked and totally preffered low price china smartphones.

  

The entry of china smartphones put indian mobile companies out of market but thanks to china smartphones digital usage in india increased drastically and many indian people who unable to afford expensive smartphones like students and workers started buying china smartphones for various purposes which helped indian government in numerous ways.

  

In fact, china smartphones played major role in success of digital india program but still indian government has responsibility to reduce reliance on china smartphones  and promote made in india mobiles and smartphones which they are doing mainly since year 2014 but due to lack of proper infrastructure building it can take decades so indian companies were not able to build full fledged smarphones in india itself.

  

The reason china able to make and export smartphones in large quantities at low price is mainly because of it's existing infrastructure build over the years mainly since mid 19th century at that time india government didn't go in way of china Instead busy in managing inner matters and tensions concerning the country.

  

Anyhow, now we are rapidly building proper infrastructure required by companies to make not just smartphones but also all other technologies and electronic products in india itself to make developed country but still as of now it may be not possible to make fully made in india smarphone that can cost billons of dollors which most indian companies can't afford and there is no full facilities as well.

  

 [![](https://lh3.googleusercontent.com/-YTkyrArWaT0/YxnECGIcqwI/AAAAAAAANkI/8NSt1hyUSecJrOT_-o2rv-j3c7g9GB6PACNcBGAsYHQ/s1600/1662632963735827-12.png)](https://lh3.googleusercontent.com/-YTkyrArWaT0/YxnECGIcqwI/AAAAAAAANkI/8NSt1hyUSecJrOT_-o2rv-j3c7g9GB6PACNcBGAsYHQ/s1600/1662632963735827-12.png) 

  

  

Recently, PM Narendra Modi as part of Azadi Ka Amrut Mahotsav announced vision @2047 digital india for providing complete digital facilities for urban and rural areas by that time indian mobile companies may build full true desi india smarphone with not even single imported technology or device parts etc which will definitely happen but right now china smartphones doing rounds around the world.

  

We have alot of india companies and conglomerates like Reliance who have billions of dollars to build complete full fledged smartphone in india itself but for that they have to invest billions of dollars to build proper smartphone manufacturing from scratch that most indian companies don't as it's super risky even if you they do yet they may unable to make smartphones at such low of china smartphones due to lack of experience or marketing plans etc so it can push them into bankruptcy.

  

Generally, almost all mobile companies including china ones use one or more imported parts or technologies on their smartphones even founder of multi-touch display technology smartphone Apple inc use few smartphone hardware parts from other companies then to assemble parts rely on China's company foxconn which is common so right now it is hard for indian companies to completely make thier own no import parts smartphones.

  

The problem with indian companies is they import almost all smartphones from foriegn or china mobile companies which is highly benefiting those countries then india that can be changed if Indian mobile companies try to reduce profit margins and build seperate units to make parts of smartphones one by one phasely so that india reliance on foreign companies will be reduced which is fruitful in future.

  

**[\+ Here's why, Karbonn Mobile India failed to beat china smartphones.](https://www.techtracker.in/2022/06/heres-why-karbonn-mobile-india-failed.html)**

**[\+ Here's why, Celkon Mobile India failed to beat china smartphones.](https://www.techtracker.in/2022/06/heres-why-celkon-mobile-india-failed-to.html)**

**[\+ Here's why, Micromax Mobile India failed to beat china smartphones.](https://www.techtracker.in/2022/06/heres-why-micromax-india-failed-to-beat.html)**

  

Anyhow, majority of india people don't care about imported parts instead they are concerned with less features over price indian smartphones so indian mobile companies at the moment simultaneously have to reduce thier profit margin even without profit have to make and sell feature rich value for money smartphones to compete with china mobile companies and gradually make people shift to indian smartphones with real quality and features not on paper attractions and gimmicks.

  

On 5 may, 2020 india and chinese troops engaged in skirmishes at line of actual control ( LAC ) sino indian border due to that tensions heated up between china and India and this incident caused many  indian people raised slogans to not use china products and smartphones even indian government for the country integrity and security reasons banned more then 100 china apps including PUBG which are suspected to cause databreach issues.

  

There are millions of china apps available out there on world wide of internet out of them very few number of apps are only banned by india not everyone as india is democracy so it's not against china developers or companies but banned because of country citizens privacy and security which is why you'll find china companies invest in india startups and vice versa is happening as well.

  

China companies developed world class apps and software which are popular and extensively used by people around the world including India so if this goes on this then india and it's developers go out of spotlight and revenue which is why indian government PM narendra modi to make india self reliant in all sectors especially in digital technology launched Aatma Nirbhaar Bharat programme to help and promote indian developers which is currently going on smoothly.

  

 [![](https://lh3.googleusercontent.com/-8Q3wl4Hccy8/YxnEAvTNTBI/AAAAAAAANkE/t11VQ4E5PH0Hcr1RJPq7gp6quzU39rLggCNcBGAsYHQ/s1600/1662632958319236-13.png)](https://lh3.googleusercontent.com/-8Q3wl4Hccy8/YxnEAvTNTBI/AAAAAAAANkE/t11VQ4E5PH0Hcr1RJPq7gp6quzU39rLggCNcBGAsYHQ/s1600/1662632958319236-13.png) 

  

If Indian government bans china smartphones as part of Aatma Nirbhaar Bharat programme which they usually won't do as they are financial experts on board who may don't suggest such step but if india right out ban china mobiles and smartphones etc in severe situations then indian mobile companies definitely have to struggle to satisfy and meet the price and features expectations of indian people.

  

Once, india government bans china smartphones then there will be chaos from large percentage of Indian people atleast in social media networks who even show displeasure on india government which can last until india mobile companies make smartphones to the price and level of china smartphones.

  

Indian mobile companies ethically must don't use china smartphones parts in thier smartphones if indian government ban them so they have to use smartphone parts from other companies like Samsung, LG, Sony etc which are priced higher then china ones so indian mobile companies in order to sell smartphones at low price like china have to reduce profit margin to 2 to 4% or 0% like china mobile company Xiaomi then only it will work else people will demand for china smartphones or use foriegn mobile company low cost smartphones like Samsung M series.

  

Luckily, Lava an indian mobile company was able to make low cost 5G smartphone named Agni which has features that can compete with china and other foriegn companies so if Lava can do then other indian mobile companies also able to make such smartphones like Micromax and Reliance etc if all indian companies not just mobile companies everyone invest in each other and jointly work together to make smartphones then they can unleash smarphones like iPhone at price of china smartphones in future.

  

**[\+ Here's why, Lava not failed yet it may beat china smartphones.](https://www.techtracker.in/2022/06/heres-why-lava-not-failed-yet-it-may.html)**  

  

Atlast, now the decision of banning china smartphones in india will be based on current economic and political conditions of indian government if they ban just china smartphones to simply promote india smartphones then other countries will see india as not true democratic values nation  especially america but if india government must have to ban china smartphones for any strong reason then that may won't work instantly but slowly as indian people after ban start buying Indian smartphones bit more which will directly benefit indian company and india goverment financially and economically for sure.

  

Finally, this is what will happen if indian government bans china smartphones, are you an existing user of china smartphones? If yes do will you buy indian smartphones if government bans china smartphones and  mention why do you like or prefer china smartphones over indian smarphones and vice versa in our comment section below, see ya :)