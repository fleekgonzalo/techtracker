---
title: '3 farm laws - India''s agriculture acts for the welfare of farmers.'
date: 2022-10-07T20:00:00.000+05:30
draft: false
url: /2022/10/3-farm-laws-indias-agriculture-acts-for.html
tags: 
- technology
- India
- Farmers welfare
- Agriculture acts
- 3 farm laws
---

 [![](https://lh3.googleusercontent.com/--Lo2Q9c7kGA/Yz3tR0EQOhI/AAAAAAAAOLw/EQGbhCt5XN0GnulD7HhlIvkHKfR7NG9BgCNcBGAsYHQ/s1600/1665002819346864-0.png)](https://lh3.googleusercontent.com/--Lo2Q9c7kGA/Yz3tR0EQOhI/AAAAAAAAOLw/EQGbhCt5XN0GnulD7HhlIvkHKfR7NG9BgCNcBGAsYHQ/s1600/1665002819346864-0.png) 

  

India that is actually known as bharat is renamed to india when britain colonized bharat where large percentage of people since ancient times used to cut forests and make them clean agricultural lands for daily livelihood by simultaneously working as warriors at the time for war to protect country who used to do organic farming with lakhs of quality different varieties of crops for all purposes for Instance once up on time there are more then 500+ rice crops in india but now it is in few numbers as they lost in time due to various reasons mainly because indian farmers day by day leaving agriculture to choose other jobs.

  

 [![](https://lh3.googleusercontent.com/-y1oYEgW5GZY/Y0kJrSVLBMI/AAAAAAAAOPE/Df7o5rk41Kwf22k2ZDAJCp8cQ9iw8FO2gCNcBGAsYHQ/s1600/1665730985316638-0.png)](https://lh3.googleusercontent.com/-y1oYEgW5GZY/Y0kJrSVLBMI/AAAAAAAAOPE/Df7o5rk41Kwf22k2ZDAJCp8cQ9iw8FO2gCNcBGAsYHQ/s1600/1665730985316638-0.png) 

  

When agriculture sector used to flourish in india despite floods from rivers thanks to skills of indian farmers and as they mostly depended and concentrated in field of agriculture to feed themselves and buy necessary goods through barter system but eventually india like any other country joined industrial revolution in that process alot of agriculture lands are used to build numerous industries and factories by both governments and bussiness mans due to that eventually rural areas become urban and people also got adapted to it.

  

Unfortunately, Industrial revolution in india done alot of changes in lifestyle of people as majority of them who don't own agricultural lands started working in factories to earn money including that most agriculture land owners also partnering with peasents or building 

industries and factories even leaving or selling agricultural lands for education or to get or maintain industrial jobs etc.

  

 [![](https://lh3.googleusercontent.com/-7F9H_iyBvB8/Y0kJqFMM4TI/AAAAAAAAOPA/F_YN70J2yXM_FQrIPPbuQgvaCjcPUDahQCNcBGAsYHQ/s1600/1665730981254626-1.png)](https://lh3.googleusercontent.com/-7F9H_iyBvB8/Y0kJqFMM4TI/AAAAAAAAOPA/F_YN70J2yXM_FQrIPPbuQgvaCjcPUDahQCNcBGAsYHQ/s1600/1665730981254626-1.png) 

  

The main reason why majority of people in india not showing interest in farming agriculture lands is because it's not much profitable including that it's difficult and hard as several factors involved like agriculture is depended on sufficient requirement of water at the same time need proper nature and climate if any nature calamities occur like no rains or  floods and pests etc then years of farmers hard work and investment will be wasted which is why farmers not just getting into loophole of unbearable loans but also doing suicides in large numbers including that farmers not allowing thier children to work in agricultural lands Instead diverting them to corporate company jobs.

  

There are several reasons why agriculture is not profitable in india out of them to name few back then when invaders started ruling parts of India for example : nawabs and britishers for hundreds of years they used to forcefully apply heavy taxes on agriculture lands with number of other atrocities in name of authority and laws like leasing or snatching agriculture lands from tribals etc but eventually thanks to fearless freedom fighters like subash chandra bose on August 15, 1947 india got indepedence and started creating own constitution that came into force on January 26, 1950 and adopted Sovereign Socialist Secular Democratic Republic to secure all indian citizens.

  

 [![](https://lh3.googleusercontent.com/-k7enRWTIHWc/Y0kJpE2WuMI/AAAAAAAAOO8/iqjd5d-wFxcXA-MGIY9jQC6A8vSKNaI_gCNcBGAsYHQ/s1600/1665730977216952-2.png)](https://lh3.googleusercontent.com/-k7enRWTIHWc/Y0kJpE2WuMI/AAAAAAAAOO8/iqjd5d-wFxcXA-MGIY9jQC6A8vSKNaI_gCNcBGAsYHQ/s1600/1665730977216952-2.png) 

  

Unfortunately, even after india got most awaited freedom to execute and make it's own laws freedom still the party that was elected right after independence to rule through voting procedure in democracy haven't done much for the benefit of farmers for decades due to that india farmers not only faced many hardships to get right price for thier crops yields but also unable to sell them including that farmers didn't even educated or provided necessary loans and advanced equipment or techniques by government like cold storages due to that indian farmers didn't upgraded and stayed behind farmers of number of developed countries like USA, china, brazil, russia and Israel etc. 

  

 [![](https://lh3.googleusercontent.com/-fktGwNjhbzw/Y0kJoCSjHVI/AAAAAAAAOO4/t-f8DiSSY241RYN6ibeFkktbTr4dkpw9ACNcBGAsYHQ/s1600/1665730973037302-3.png)](https://lh3.googleusercontent.com/-fktGwNjhbzw/Y0kJoCSjHVI/AAAAAAAAOO4/t-f8DiSSY241RYN6ibeFkktbTr4dkpw9ACNcBGAsYHQ/s1600/1665730973037302-3.png) 

  

  

Even though, india is world's one of the largest agriculture producing country thanks to some people who liked and preferred to continue in agriculture work even after numerous hurdles but majority of them use old equipment and methods to do farming in thier agricultural lands 

including that farmers mostly depend on mediators who take vegetables or fruits etc usually at less or government decided price then do marketing to sell them in local and international markets.  

  

 [![](https://lh3.googleusercontent.com/-_6_k4-kXmUQ/Y0kJnBxIVJI/AAAAAAAAOO0/awbJSGhsZfchY3XEo2aFmBTwJIKCoBvPACNcBGAsYHQ/s1600/1665730968796541-4.png)](https://lh3.googleusercontent.com/-_6_k4-kXmUQ/Y0kJnBxIVJI/AAAAAAAAOO0/awbJSGhsZfchY3XEo2aFmBTwJIKCoBvPACNcBGAsYHQ/s1600/1665730968796541-4.png) 

  

Majority of indian farmers don't have education and knowledge to aware about crops that are on demand with correct value in india and overseas market including that they always sell thier yields to mediators out of them few faulty ones even force or make farmers to sell all thier agriculture land yields at lowest price possible by doing gimmicks due to that farmers of all states in india since long time suffered mentally and financially.

  

Fortunately, many states in india under various schemes provide loans at minimal rates but that require them to put assets like lands or gold etc including that few chief ministers even promise to fully or half wipe farmer loans which they do some times but it's not enough as indian farmers not just take loans from farmers they depend on third party financiers as well which is why instead of making indian farmers to depend on loans governments have to provide necessary knowledge and facilities to make them stable professional bussiness mans for continous profits and ability to recover and handle losses easily.

  

 [![](https://lh3.googleusercontent.com/-xOdD8qyj0TI/Y0kJmP01LSI/AAAAAAAAOOw/nu75ccEEdeU99rqVfziuJpD5eW9ogzB5wCNcBGAsYHQ/s1600/1665730964143639-5.png)](https://lh3.googleusercontent.com/-xOdD8qyj0TI/Y0kJmP01LSI/AAAAAAAAOOw/nu75ccEEdeU99rqVfziuJpD5eW9ogzB5wCNcBGAsYHQ/s1600/1665730964143639-5.png) 

  

  

Especially, In times of natural calamities most farmers unable to save thier crops from nature calamities so only few of them somehow able to safeguard thier crops yields luckily or using technologies who sell thier agricultural yields at higher price possible as there is no competition due to that vegetables and fruits prices will become expensive suddenly.

  

 [![](https://lh3.googleusercontent.com/-pqdGP_OzMOs/Y0kJk9eAwvI/AAAAAAAAOOs/8Tx41kLrBuw9cw7j3jQHn9JqEHWV83dIQCNcBGAsYHQ/s1600/1665730959832825-6.png)](https://lh3.googleusercontent.com/-pqdGP_OzMOs/Y0kJk9eAwvI/AAAAAAAAOOs/8Tx41kLrBuw9cw7j3jQHn9JqEHWV83dIQCNcBGAsYHQ/s1600/1665730959832825-6.png) 

  

  

Thankfully, In order to protect and for the benefit of farmers in all sides in year 2020 on September 17 prime minister Narendra Modi government passed 3 new agriculture acts which in simple basically allow farmers to directly partner and sign contracts with companies to take lease of agriculture lands and advanced equipments for farming, make byproducts or sell thier own agricultural yields at desired price they want according to company requirements due to that dependence on mediators will be reduced to big extent thus farmers can sell thier agricultural yields at much higher profits to local or international companies.

  

3 new farm laws or agricultural acts of india are straight forward and clear which are accepted by almost all states and people in india but few states like punjab, tamilnadu and telengana were against new farm laws mainly because of political reasons where the formed government political party are different and not associated with ruling majority political party of the prime minister of country.

  

In case of Punjab and Telangana governments who are always against anything done by prime minister Narendra Modi which is why they in back end with thier political party activists done protests and rallies even though most people support 3 new farm laws including that instead of educating farmers regarding the benefits of 3 new farm laws they circulated mis-conceptions and information to confuse farmers and rage them to do protests and rallies against 3 new farm laws.

  

Punjab is first india state to go against 3 new farm laws as over there the current  ruling government is not associated with prime minister political party and against them since few decades which is why they some how got grip of punjab farmers by bribing farmer leaders or circulating alot of fake information like 3 farm laws will remove mediators and they only profit companies not farmers due to that punjab farmers in huge numbers done months of protests and rallies against 3 new farm laws even removed indian flag on Red fort.

  

It is fact there is an misconception and confusion among farmers mainly in punjab that 3 new farm laws totally remove mediators that's not true which is why indian government through numerous ways tried to clarify and educate punjab farmers regarding this but they didn't listen as over there punjab state government is moving them in that way they wanted as per observations of mine and wonderful reporters around the world.

  

Anyhow, on December 1 prime minister Narendra Modi repealed revolutionary 3 farm laws for protection of health and families of punjab farmers who are brainwashed by thier state governments for sure since then 3 farm laws didn't re-instated as if they do then punjab, Telangana and tamilnadu state governments will again rage up people and farmers protests and rallies to somehow create or increase negetivity on prime minister and his political party.

  

In this scenario considering all edges it is to better to hold repeal on 3 farm laws nation wide but just because of 3 state farmers not providing it's benefits to other state farmers and people is also not right which is why government have to find some way to release and reach 3 new farm laws to farmers silently thus one after one new farmers will start partnering with companies that will increase organic growth and expand to all over country.

  

In sense, prime minister Narendra Modi have to first launch 3 new farms with new name in thier strong majority states where people trust them completely for instance it is better to pass 3 new farm laws in gujarat state assembly as over there people know prime minister Narendra Modi always think of welfare of farmers and people once it is successfull in gujarat then other states will eventually start adoping 3 new farm laws including those who are now against it now.

  

If 3 new laws can't be launched in gujarat or any other ruling party strong majority areas for whatever reasons then it's better to start a digital campaign like connecting farmers with companies or setting up volunteer organization like farmers with companies something like that to educate farmers in every state to let them directly connect with companies not through direct agriculture laws and acts.

  

In my opinion, A government website or software should be developed and released with Integration of call or personal volunteer and legal support where both companies and farmers can connect through messages or calls to make deals if government can't officially do that as it resembles the idea of 3 farm laws then that can be implemented by companies like Reliance, Tata or small company under digital india campaign.

  

Atlast, 3 new farm laws of india were repealed to stop futher unethical political stunts and plans of opposition parties who are unable to see revolutionary new 3 farm laws as if they are implemented then it will get good name to prime minister Narendra Modi ruling party and increase support in people to win again and progress india agriculture to level of America which is why used illegal tricks and stopped them.

  

Finally, this are 3 new farm or agricultural acts of india developed and released purely and completely for the welfare of india farmers and development of indian agriculture to global level, are you an existing supporter of 3 new farm laws of india? If yes do say your opinion on why they repealed them and mention will 3 new farm laws can be passed again in our comment section below, see ya :)