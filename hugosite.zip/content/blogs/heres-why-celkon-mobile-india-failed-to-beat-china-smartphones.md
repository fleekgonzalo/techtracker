---
title: 'Here''s why, Celkon Mobile India failed to beat china smartphones.'
date: 2022-06-19T23:37:00.001+05:30
draft: false
url: /2022/06/heres-why-celkon-mobile-india-failed-to.html
tags: 
- Why
- technology
- Smartphones
- Celkon Mobile India
- china
---

 [![](https://lh3.googleusercontent.com/-NSEFYZ85qww/Yq9l8kxjuxI/AAAAAAAAL-M/BXq8pk7m8BUQNsTy8AiW0TVo28UtDGuvQCNcBGAsYHQ/s1600/1655662060821565-0.png)](https://lh3.googleusercontent.com/-NSEFYZ85qww/Yq9l8kxjuxI/AAAAAAAAL-M/BXq8pk7m8BUQNsTy8AiW0TVo28UtDGuvQCNcBGAsYHQ/s1600/1655662060821565-0.png) 

  

  

India, is playing it's role for the development of technologies from past few decades thankfully CEO's of top global companies are from india even Google and Microsoft set up thier R&D aka research and development centres in india but still unfortunately we don't have infrastructure to manufacture complete smartphones.

  

 [![](https://lh3.googleusercontent.com/-q0kb59cTG6M/Yq9rnFlW4cI/AAAAAAAAL-k/nVvBXhR2PJ0uME1lWFgiNojPtNrOvpzIgCNcBGAsYHQ/s1600/1655663511824865-0.png)](https://lh3.googleusercontent.com/-q0kb59cTG6M/Yq9rnFlW4cI/AAAAAAAAL-k/nVvBXhR2PJ0uME1lWFgiNojPtNrOvpzIgCNcBGAsYHQ/s1600/1655663511824865-0.png) 

  

  

Eventhough, we have many top leading tech companies and conglomerates in india like Reliance who have billions of dollars to setup thier own fully capable company like Apple to manufacture full smartphones yet as good infrastructure is only limited to some techy areas it is bit hard even if indian companies decided to setup infrastructure that costs billions of dollors to manufacture full smartphones yet the outcome can be risky as right now china smartphones conquered majority of mobile market in india due to thier well low priced quality products.

  

 [![](https://lh3.googleusercontent.com/-vhp50hrbgcc/Yq9rmG8v-gI/AAAAAAAAL-g/ckcalXVjXQwqIs_s1u42TgFDWfhVvv2FACNcBGAsYHQ/s1600/1655663508221364-1.png)](https://lh3.googleusercontent.com/-vhp50hrbgcc/Yq9rmG8v-gI/AAAAAAAAL-g/ckcalXVjXQwqIs_s1u42TgFDWfhVvv2FACNcBGAsYHQ/s1600/1655663508221364-1.png) 

  

However, indian government in year 2014 introduced made in india and make in india programmes to improvise and promote indian products from then the percentage of Indian people who buy indian products increased due to patriotic reasons but as we don't have competent enough indian mobile company that can tackle china companies due to that people have no choice other then buying low price feature rich china smartphones.  

  

But, thankfully as Indian people like to buy indian products even indian government want foriegn companies to manufacture in india they given several tax benefits and help to foreign companies to manufacture in india eventually many foriegn especially china companies set up assembly plants in india where imported mobile or other electronic products are assembled by indian people to release in indian market mobile market that will increase india's employment and economy.

  

Now a days, most smartphones and electronic products like LED TVs released in india comes with tagline make in india or assembled in india but still as we don't manufacture complete smartphone parts in india there is no market for it due to that indian companies import mobiles parts from foriegn countries mostly from china as they provide mobile parts at very low price to assemble in india.

  

Indian companies used to import keypad mobiles and smartphones from china then label thier company logo to release in india prior year 2014 but since most people got to know about this and make in india and made in india programmes are successful indian companies have no choice other then to assemble smartphone parts in india itself else no one will buy them.

  

Fortunately, we have number of Indian mobile companies like Micromax, Celkon, Micromax, itel, iBall, etc and all of them used to import china smartphones to release in india with added profit margin at high price but still indian people used to buy them as they don't have any choice thus india mobile companies used float in profits as thier smartphones are super successful but the entry of budget foriegn companies mainly from china put indian companies in tough situation so eventually they got out of competition with big loss.

  

In year 2014, many policies revamped and changed to make India a tech hub with that effect digital revolution started in inda a big thanks to goverment at that time USA mobile company Motorola released Moto E and G series smartphones at low price with amazing features on online shopping sites like Flipkart and Amazon from then people started buying and using them.

  

 [![](https://lh3.googleusercontent.com/-CgkQ3wmfxGo/Yq9rlKNGNqI/AAAAAAAAL-c/yU7On__eLtwiYSzwCB5jrRZbdAfKXs7dgCNcBGAsYHQ/s1600/1655663504532268-2.png)](https://lh3.googleusercontent.com/-CgkQ3wmfxGo/Yq9rlKNGNqI/AAAAAAAAL-c/yU7On__eLtwiYSzwCB5jrRZbdAfKXs7dgCNcBGAsYHQ/s1600/1655663504532268-2.png) 

  

  

Motorola smartphones selled like hot cakes in india thanks to flash sales and simultaneously china mobile companies started entering in india especially Xiaomi released Redmi Note 1 smartphone at low price with better features then Motorola or any smartphones on india shopping sites thus as china smartphones are value for money india people shifted to them.

  

 [![](https://lh3.googleusercontent.com/-3M7XObSsIyg/Yq9rkNC1-DI/AAAAAAAAL-Y/zEz9pyDKNxk_SxDHuBSJLh42b4I3ksxHACNcBGAsYHQ/s1600/1655663500809281-3.png)](https://lh3.googleusercontent.com/-3M7XObSsIyg/Yq9rkNC1-DI/AAAAAAAAL-Y/zEz9pyDKNxk_SxDHuBSJLh42b4I3ksxHACNcBGAsYHQ/s1600/1655663500809281-3.png) 

  

  

There are many china mobile companies entered in india out of them some didn't got success even though they got huge hype in beginnings but as Xiaomi don't spend money on advertising and they take very less profit margin like 2 to 4% thus they are able release low price budget smartphones with alot of features that kicked indian and foriegn smartphone makers out of league.

  

Each India mobile company has it's own decisions and reasons that leaded them to failure but the main one is they are highly depended on imported smartphones and they take high profit margins thus indian mobile company smartphones are costly which most people don't like to buy as they have much better low price smartphones from china and foriegn companies.

  

The problem with indian mobile companies is they take huge profit margin but still want to sell smartphones with old design and hardware but somehow they they are able to sell their basic oudated smartphones at large in retail market mostly to people who don't know much about smartphones but later on indian mobile retail market also got dominated by china mobile companies like Oppo and Vivo who provide much better share % to retail marketers to sell thier products.

  

While, reliance industries founded by Dhirubai Ambani released thier own low price keypad mobiles in 1990s for indian people that loosened the grip of foriegn expensive keypad mobiles companies like Nokia and samsung in india but later on due to whatever reason reliance didn't entered into smartphone business until year 2015 with LYF brand and recently Reliance partnership with Google made Jio smartphone both are unsuccessful.

  

In case of Celkon, a indian mobile company founded by Murali Retineni in year 2009 based at Hyderabad used to sell smartphones under two brands low and mid range series campus and high end series Millennials both are successful brands but they are not comparable to china smartphones thus no one really showing much interest or attention to Celkon smartphones.

  

Celkon like any other india mobile company has it's focus mainly on retail market where only they can sell keypad mobile and smartphones while online market is completely dominated by china and foriegn companies even if Celkon put smartphones in online market yet they won't be able to sell them as most people are concentrated on china smartphones.

  

Most people especially teens don't know about Celkon even though they are in profits just because of thier keypad mobiles sell in retail market while most Celkon smartphones released from past few years are pretty basic ones that don't have any potential to make buzz and win against china and foriegn smartphones.

  

Now a days china and foriegn mobile companies releasing 5G punch hole smartphones with 8GB RAM and 128GB storage mean while Celkon struck with 2GB GB and 16GB ROM 4G smartphones and they are struggling to sell them while other indian mobile company like Lava and Micromax etc atleast trying and releasing china level smartphones.

  

You many think India mobile companies  failed due to lack of advertising it's partly true but not for Celkon over the years they done alot of advertising campaigns for keypad mobiles and smartphones through numerous ways now they don't have any latest smartphone that meets the current specs of people even if they advertise thier old smartphones no one will buy them.

  

 [![](https://lh3.googleusercontent.com/-c8-LWDc0mho/Yq9rjKcvuRI/AAAAAAAAL-U/dUUiGDVqyuIfvxxQgvuZ5_qR7ijacfEpACNcBGAsYHQ/s1600/1655663496928508-4.png)](https://lh3.googleusercontent.com/-c8-LWDc0mho/Yq9rjKcvuRI/AAAAAAAAL-U/dUUiGDVqyuIfvxxQgvuZ5_qR7ijacfEpACNcBGAsYHQ/s1600/1655663496928508-4.png) 

  

It's been more then a decade since china and foriegn smartphones dominated the mobile market of India if this scenario go on like this then we may can't see 1 Indian company to manufacture smartphones in future so as indian companies are still in market they have to make plans to make smartphones that are capable enough to beat china smartphones then only people will buy them else seems like end is near like Microsoft Windows smartphones.

  

Finally, this is why Celkon Mobile India failed to beat chinese smartphones, are you an existing user of Celkon Mobiles, if yes do say your experience and mention why do you think Celkon smartphones failed in india in our comment section below, see ya :)