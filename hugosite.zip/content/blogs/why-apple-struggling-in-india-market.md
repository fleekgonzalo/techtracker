---
title: 'Why Apple Struggling In India Market ?'
date: 2020-03-02T23:19:00.001+05:30
draft: false
url: /2020/03/why-apple-struggling-in-india-market.html
tags: 
- Budget
- apple
- iOS
- XR
- Stores
- Retail
---

**  

[![](https://lh3.googleusercontent.com/-IdOWumUEePo/XoIavJ9zUwI/AAAAAAAABOA/gNP1-dOedVcRckXobmTW4xjMOBsJY0B2ACLcBGAsYHQ/s1600/IMG_20200111_105332_780-01.jpeg)](https://lh3.googleusercontent.com/-IdOWumUEePo/XoIavJ9zUwI/AAAAAAAABOA/gNP1-dOedVcRckXobmTW4xjMOBsJY0B2ACLcBGAsYHQ/s1600/IMG_20200111_105332_780-01.jpeg)

**

**

Tech** **Tracker** | Apple Inc, the glorious days of apple until the Steve jobs being CEO of the company with a lot of enthusiasm, innovation and trend setting accomplishments.

  

Then the need of CEO required due to death of Steve jobs then Tim Cook Became CEO and continued apple being the popular first choice in countries like USA and some European countries.

  

Apple primary focus on quality in depth and innovation where today innovation lacks quality excels as usual but apple have huge fanism due to thier great achievements in time of Steve jobs.

  

Apple, smartphones mainly excells in camera, gaming, stability and security to the users giving a closed portal with in build benefits for a better secured device that making a major role in buying apple smartphones.

  

\- Why Apple Struggling In India ?

  

\- Less Options

  

\- Less Features

  

\- Over Hyped 

  

\- Availability

  

\- Value

  

\- Price 

  

\- Repair Charge's

  

• Apple do have less options to choose unlike samsung or Nokia you won't be having a entry device or budget device primarily made for Indian market.

  

Example : Apple launched iPhone xr which said to be entry level device in view of apple with 720p display not even HD display that the price is 70,000rs which the entry level price market in india is 7,000rs with specs of minimum 1080p display.

  

Eventhough, apple gives best in it specs on paper specs shows different effect on Indian consumer where lack of experiencing apple devices become problem for various reasons.

  

India is one of the largest populated country where the salary of a person ideal is 10k per month with this ideal salary getting a 720p display phone in 70k is not value for money.

  

Indian consumers give high priority to value for money as apple give vibrant look with the carefully curved adverts to over hype thier below average specs in Indian market which doesn't work as Indian customer's choose smartphone after a lot of research and usage.

  

Repair charges one of the main reason apple takes the price of half of the phone to repair or replace parts and to buy the accessories then it is also the same scenario while budget phones are getting fast charging apple taken years and to get far lesser voltage which really won't workout in Indian markets.

  

Usability, india is android dominated smartphone country which android known for customization and free control to users while iPhone put firewall to features and usability.

  

To make India users to get used apple products, apple have to give products at lesser price, apple struggle with taxes and import charges making iPhone more costly than usual price.

  

No apple stores, apple does partner with Indian sim network which doesn't really succeed well still there is not even one official store available in india and yet apple struggling, apple knows india is future development hub with young ratio so apple doesn't want some other company to handle thier products so they doing research carefully to get open thier retail stores which gives a + point to thier gain in sells but until the price reduce their is very less possibility of reaching apple products to every Indian household.

  

The problem with apple in india

  

\- Quality - √ | Specs - × | Camera - √ |

  

\- Value - × | Repair Charges - × | Price - ×

  

This are some of the main reasons that apple struggling in india market the India mobile market have great potential once boomed it will chase for years for a brand like apple which have great reputation and value among Indians eveb though most people not interest and unable to afford for on paper no value product but apple need to promote thier quality at best they definitaley has to open retail stores for a better reach.

  

Finally, apple still maintains quality but innovation lacking which Steve jobs not even digest the fact that apple being ruined with no improvised timely and sticking to older golden structures set by Steve jobs, however lack of interest and effort in large hike making apple to struggle in india market unless apple think of releasing india centric devices its hard to cope up anywhere near future and Indian smart customers.