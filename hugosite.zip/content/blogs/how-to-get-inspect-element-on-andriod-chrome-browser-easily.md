---
title: 'How to get Inspect Element on Andriod chrome browser easily.'
date: 2022-01-24T21:31:00.002+05:30
draft: false
url: /2022/01/how-to-get-inspect-element-on-andriod.html
tags: 
- browser
- Chrome
- How
- Inspect element
- technology
---

 [![](https://lh3.googleusercontent.com/--9sCkU-wSQM/Ye7NOX34UQI/AAAAAAAAIwU/bMPH7dmCBpEHiNQ1ysu2M6dPmp1Hv4b-gCNcBGAsYHQ/s1600/1643040052168345-0.png)](https://lh3.googleusercontent.com/--9sCkU-wSQM/Ye7NOX34UQI/AAAAAAAAIwU/bMPH7dmCBpEHiNQ1ysu2M6dPmp1Hv4b-gCNcBGAsYHQ/s1600/1643040052168345-0.png) 

  

Inspect element is a tool available in PC browsers to check and debug website's code but on Android there is not even 1 browser has inspect element tool due to this drawback alot of people were unable to use Inspect element even the official Android chrome browser doesn't have a inspect element tool by default may be because of Android browser limitations, whatever Inspect element is widely used essential and necessary tool that should be thier on Andriod to.

  

This is why, we found one unofficial trick which will bring Inspect element tool atleast on official Andriod chrome browser, however this is basic Inspect element tool where you can only see code of website, you can't edit or modify to debug or test code extensively which is definitely dissapointing but atleast we are able to bring Inspect element to check code on Andriod chrome browser, isn't cool and suprising?

  

Inspect element which we are going to get on Andriod chrome browser is equipped with numerous features and plugins to test and debug website like Console, Elements, Network, Resources, Sources, Info, Snippets, Geo Location, Dom, Benchmark, Settings to get check almost all code on website in detailed manner.

  

However, Inspect element tool that we get on PC is more powerful then the one we are going get on Andriod chrome browser, but getting Inspect element on Andriod browser is impossible task before, thanks  to Eruda 2.4.1 inspect element tool script created by [eruda.liriliri.io](http://eruda.liriliri.io/)  it's now possible to get inspect element tool on Andriod chrome browser for any website, so are you ready to get Inspect Element? If yes let's begin.

**• How to get Inspect Element on Android chrome browser •**

 **[![](https://lh3.googleusercontent.com/-2AJ8k5Qo0vE/Ye7NNPbD4PI/AAAAAAAAIwQ/aTudlJ1C8JIV6kuay8Z9S7sCqaifHWNpQCNcBGAsYHQ/s1600/1643040047626535-1.png)](https://lh3.googleusercontent.com/-2AJ8k5Qo0vE/Ye7NNPbD4PI/AAAAAAAAIwQ/aTudlJ1C8JIV6kuay8Z9S7sCqaifHWNpQCNcBGAsYHQ/s1600/1643040047626535-1.png)** 

\- Open chrome app and search for the website or blog which you want to Inspect Element tap on **⋮**

  

 [![](https://lh3.googleusercontent.com/-UJLB5WUI5Dw/Ye7NL0tyERI/AAAAAAAAIwM/-ncqvxB1LqEpV9Du03lDu9Uo8wGExUHAACNcBGAsYHQ/s1600/1643040043044457-2.png)](https://lh3.googleusercontent.com/-UJLB5WUI5Dw/Ye7NL0tyERI/AAAAAAAAIwM/-ncqvxB1LqEpV9Du03lDu9Uo8wGExUHAACNcBGAsYHQ/s1600/1643040043044457-2.png) 

  

\- Tap on **⭐**

 **[![](https://lh3.googleusercontent.com/--g5o3LswQXs/Ye7NK76TuII/AAAAAAAAIwI/BPlqiG0erfg5J6oVoUKl8NBo2cvhPIlKwCNcBGAsYHQ/s1600/1643040038923154-3.png)](https://lh3.googleusercontent.com/--g5o3LswQXs/Ye7NK76TuII/AAAAAAAAIwI/BPlqiG0erfg5J6oVoUKl8NBo2cvhPIlKwCNcBGAsYHQ/s1600/1643040038923154-3.png)** 

\- Tap on **Edit**

 **[![](https://lh3.googleusercontent.com/-ZZawV8uGNxA/Ye7NJ64xAsI/AAAAAAAAIwE/UOJCzLFkq14m8IsiHKtr--gUKedAiTkrwCNcBGAsYHQ/s1600/1643040035188913-4.png)](https://lh3.googleusercontent.com/-ZZawV8uGNxA/Ye7NJ64xAsI/AAAAAAAAIwE/UOJCzLFkq14m8IsiHKtr--gUKedAiTkrwCNcBGAsYHQ/s1600/1643040035188913-4.png)** 

\- Enter Name : Inspect Element, URL : add this below script code and go back.

  

> javascript:(function () { var script = document.createElement('script'); script.src="//cdn.jsdelivr.net/npm/eruda"; document.body.appendChild(script); script.onload = function () { eruda.init() } })();

  

 [![](https://lh3.googleusercontent.com/-pCtdC2qaobs/Ye7NIzl-CVI/AAAAAAAAIwA/ywq2Gy_DmUMHezKYhDVANaaEzdI5XH3LQCNcBGAsYHQ/s1600/1643040030546785-5.png)](https://lh3.googleusercontent.com/-pCtdC2qaobs/Ye7NIzl-CVI/AAAAAAAAIwA/ywq2Gy_DmUMHezKYhDVANaaEzdI5XH3LQCNcBGAsYHQ/s1600/1643040030546785-5.png) 

  

\- In search, Enter **Inspect Element**

 **[![](https://lh3.googleusercontent.com/-edj350qpMa8/Ye7NHqyg7KI/AAAAAAAAIv8/cHw-wPy4fG4uvjpRlrJD-exdzxnju3mfwCNcBGAsYHQ/s1600/1643040026014462-6.png)](https://lh3.googleusercontent.com/-edj350qpMa8/Ye7NHqyg7KI/AAAAAAAAIv8/cHw-wPy4fG4uvjpRlrJD-exdzxnju3mfwCNcBGAsYHQ/s1600/1643040026014462-6.png)** 

\- Tap on Inspect Element bookmark that we added earlier.

  

 [![](https://lh3.googleusercontent.com/-Qcu2Dpr7lrw/Ye7NGQPOnWI/AAAAAAAAIv4/YmWsoCsZsxIGXdfvnxUKRQ2vxquzUeiOACNcBGAsYHQ/s1600/1643040021122198-7.png)](https://lh3.googleusercontent.com/-Qcu2Dpr7lrw/Ye7NGQPOnWI/AAAAAAAAIv4/YmWsoCsZsxIGXdfvnxUKRQ2vxquzUeiOACNcBGAsYHQ/s1600/1643040021122198-7.png) 

  

\- Tap on config / settings icon appeared at bottom right.

  

 [![](https://lh3.googleusercontent.com/-Z0ZTSbT_zmk/Ye7NFW7nhOI/AAAAAAAAIv0/mb3oUoBHGh8i6CWr6dMrZNPjAnvyfFZvwCNcBGAsYHQ/s1600/1643039984850117-8.png)](https://lh3.googleusercontent.com/-Z0ZTSbT_zmk/Ye7NFW7nhOI/AAAAAAAAIv0/mb3oUoBHGh8i6CWr6dMrZNPjAnvyfFZvwCNcBGAsYHQ/s1600/1643039984850117-8.png) 

  

\- Bingo, Inspect Element is live on your Android chrome browser.

  

Atlast, this are just highlighted features of Eruda Inspect Element script there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want the best script to enable Inspect Element tool on Andriod chrome browser then surely Eruda is perfect choice.

  

Overall, Eruda Inspect Element comes with dark mode by default with beautiful and  has well designed intuitive interface which ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will Eruda Inspect Element script get any major UI changes to make it even more better as of now Eruda is amazing.

  

Moreover, Eruda Inspect Element mobile console script that works on Google Andriod chrome browser is open source and you can check or contribute on Github, Yes indeed if you are searching for such Inpect Element tool then Eruda has potential to become your new favorite.

  

Finally, this is how you can get Inspect Element unofficially on Google's Android chrome browser easily using Eruda script which is working flawless, are you an existing user of this Inspect Element? If yes do say your experience and mention why you like and use this Eruda Inspect Element tool in our comment section below see ya :)