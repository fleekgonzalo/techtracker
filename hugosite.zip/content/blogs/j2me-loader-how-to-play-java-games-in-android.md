---
title: 'J2ME Loader - How To Play Java Games In Android ?'
date: 2020-03-15T22:45:00.001+05:30
draft: false
url: /2020/03/j2me-loader-how-to-play-java-games-in.html
tags: 
- J2ME
- Java
- Loader
- Android
- Emulator
---

**  

[![](https://lh3.googleusercontent.com/-GeqCGnDg6vA/XoIcsE-sqBI/AAAAAAAABQQ/onjjEyDkW5IysEyEBkBNSXo1AhWcRIdJwCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-13.jpeg)](https://lh3.googleusercontent.com/-GeqCGnDg6vA/XoIcsE-sqBI/AAAAAAAABQQ/onjjEyDkW5IysEyEBkBNSXo1AhWcRIdJwCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-13.jpeg)

**

**

J2ME** **Loader** is an android application available in playstore for android that gives ability to Play Java games in your android through the app so that you can play all the Java games available that you like can be played in android from now.

  

**J2ME - Java 2 Micro Edition**

  

It supports 2d and 3d games ( some 3d games not supported like mascot 3d games )

  

Emulator Have Virtual Keyboard

  

Individual Setting's For Each Application With Scaling Support 

  

\- J2ME Loader is an open source project you can view source in GitHub : [https://github.com/nikita36078/J2ME-Loader](https://github.com/nikita36078/J2ME-Loader)

  

You can donate the app with in app purchases as well.

  

**Check out in Playstore 👇**

  

https://play.google.com/store/apps/details?id=ru.playsoftware.j2meloader