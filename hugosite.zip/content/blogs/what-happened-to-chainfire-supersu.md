---
title: 'What happened to Chainfire SuperSu?'
date: 2022-09-22T20:00:00.000+05:30
draft: false
url: /2022/09/what-happened-to-chainfire-supersu.html
tags: 
- technology
- Chainfire
- Happened
- SuperSu root
- What
---

 [![](https://lh3.googleusercontent.com/-8Ik7GmAuM7g/YymfOU0EWGI/AAAAAAAAN5w/S_6morqfl4wQucWa88A_3j-npTJ3KiatgCNcBGAsYHQ/s1600/1663672118681224-0.png)](https://lh3.googleusercontent.com/-8Ik7GmAuM7g/YymfOU0EWGI/AAAAAAAAN5w/S_6morqfl4wQucWa88A_3j-npTJ3KiatgCNcBGAsYHQ/s1600/1663672118681224-0.png) 

  

  

  

There are numerous inventions which helped to make modern world out of them operating system based computers is one which allows you to install softwares developed using various programming languages that can do almost all tasks if programmed correctly which even allows you to easily get system administrator access in few clicks without any additional tools where you can find system files that you can delete or move even modify or change for customization of softwares.

  

In sense, computers are flexible which give access to system level files even though any mis-confinguration end up corrupting operating system and make it unusable that can be simply fixed by installing same software using cd or pen drive etc including that they have powerful hardware which is why computers are primarily used for developement of softwares available on various electronic devices like smartphones that we are widely using around the world.

  

Smartphones came in replacement of keypad mobile phones starting from Apple inc. iPhone in year 2007 on January 9 but eventually went to stage that now it is comparable and competing with PCs aka personal computers where you will get mobile operating systems that can install supported format softwares known as apps same as personal computers.

  

But, the in-build operating system available on smartphones are locked by manufacturer for instance Apple inc. in order to keep iPhone secure they locked it's operating system iOS and same thing done by search engine giant Google on it's FOSS aka free and open source operating system Android that has more then 78% world wide market share beating iOS that has only 20% and struggling to increase in developing countries like India.

  

Android powered smartphones are popular and less expensive then iPhones which is known for ultra customization and free ecosystem due to that large percentage of people like to use Android but in terms of security it is bit back ward when compared with iOS which is closed source and eco system that not even let you install third party apps which is why iPhone iOS known to have more security and privacy.

  

Anyhow, both iOS and Android lock and limit access to system files to keep your device in safe and secure but alot of people want to get access to system files for various purposes either to customize or modify software according to thier liking and preferences which is why third party developers around the mainly from XDA over the years created numerous rooting softwares for Android and iOS.

  

But, rooting smartphone operating system voids device warranty which is known as Jailbroke on iOS yet many people mainly geeks used to root smartphones as by doing that they can further customize softwares for instance Android is already known for customization but in order to extend that developer chain fire created SuperSU that can root almost all Android old operating system smartphones.

  

SuperSU is Android's top rooting software that can be installed right after unlocking bootloader through custom recoveries like CWM - CyanogenMod recovery or TWRP aka TeamWin recovery project etc which is way better then any other rooting software before year 2015 once you done rooting using SuperSU you can access system level files and also run all root apps.

  

The main speciality of SuperSU is beside providing access to run root apps as an system administrator like PC but also used to provide an one click permanently unroot device to restore device warranty including that SuperSu used to provide many more useful and interesting features that are necessary and required to utilise the full potential of rooting extensively.

  

Fortunately, majority of people few years back used to root via SuperSu as it's universal and stable rooting software that support long list of Android smartphones thanks to Chainfire who constantly worked to develop SuperSu to increas it's list of supported Android powered smartphones which is why SuperSU is considered as the best Android rooting software for sure.

  

If you never unlocked bootloader and rooted Android then it's very likely possible that you may be wondering why rooting Android when it already has customization with regular software upgrades and  security updates? you may be right now but few years back in Android 2.0 times software and hardware of smartphones is basic so in order to extend it's capabilities many people have to root via SuperSu.

  

Especially, A decade back Android user interface is not modern though acceptable at that time including that they used to have less storage space and memory like few hundred mega bytes not even 1 giga byte but by rooting it will provide facility via root apps to extend system storage and memory at the same push CPU and GPU  processor speed as well, cool isn't?

  

Anyhow, Chainfire in year 2017 left the development of SuperSU and selled it to CCMT who since then managing the development of SuperSu at first it was available on Google Play but later on removed may be due CCOPA complaince  including that same year Chainfire open sourced his su-hide root mitigation tool.

  

Thankfully, CCMT released SuperSu 2.8.2 update root support for Android 7.0 in 2017 but after that they are not active in development it's been more then 5 years there is no new SuperSu version seems like they stopped working on SuperSu may be because Google encrypting Android so much for security it has become very hard to root or for any personal reasons which is why alot of existing SuperSu shifting to other rooting softwares like Magisk.

  

Magisk is popular modern rooting software considered as replacement of SuperSu developed by Johnwu back in year 2016 which has alot of features and options like SuperSU with ability to install modules, root hide etc which is why now most people use Magisk but some people still like to depend and use SuperSu may be because of nostalgia reasons. 

  

Unfortunately, it is not possible to install SuperSU on latest versions of Android but in case you have Android software like Android 7.0 or even older then you can install SuperSU or may be you just want to check out how SuperSU look back in time isn't? for you we are going to explore and show you an old version of SuperSU? so do you like it? are you interested in SuperSu? If yes let's explore more.

  

**• SuperSU official support •**

\- [Facebook](https://www.facebook.com/SuperSU-1024576694301637/?ref=br_rs)

\- [Twitter](https://twitter.com/intent/follow?original_referer=https%253A%252F%252Fdownload.chainfire.eu%252F315%252F&ref_src=twsrc%255Etfw%257Ctwcamp%255Ebuttonembed%257Ctwterm%255Efollow%257Ctwgr%255EChainfireXDA&region=follow_link&screen_name=ChainfireXDA)

\- [Forums](http://forum.supersu.com/)

**Website : **[www.supersu.com](http://www.supersu.com)

**• How to download SuperSu •**

\- [XDA](https://forum.xda-developers.com/t/stable-2017-05-27-supersu-v2-82.3452703/)

**• SuperSU key features with UI / UX overview •**

 **[![](https://lh3.googleusercontent.com/-i6WZz_8B5L0/YymfNuO8KbI/AAAAAAAAN5s/PU3v5_wN4OUIW_0Ii92rSQ0TGyDEU9G4wCNcBGAsYHQ/s1600/1663672115719428-1.png)](https://lh3.googleusercontent.com/-i6WZz_8B5L0/YymfNuO8KbI/AAAAAAAAN5s/PU3v5_wN4OUIW_0Ii92rSQ0TGyDEU9G4wCNcBGAsYHQ/s1600/1663672115719428-1.png)** 

 **[![](https://lh3.googleusercontent.com/-jYSf_v-jDL0/YymfM9CYgJI/AAAAAAAAN5o/FEkqqwv7arU8Vw2taeKwBp-thVStH_xiACNcBGAsYHQ/s1600/1663672112795685-2.png)](https://lh3.googleusercontent.com/-jYSf_v-jDL0/YymfM9CYgJI/AAAAAAAAN5o/FEkqqwv7arU8Vw2taeKwBp-thVStH_xiACNcBGAsYHQ/s1600/1663672112795685-2.png)** 

 [![](https://lh3.googleusercontent.com/-JaJgcJY-SmY/YymfL1_OVwI/AAAAAAAAN5k/scuf7T8eJJsQhs6NDQifO8_1Y9wW4k3kwCNcBGAsYHQ/s1600/1663672109408002-3.png)](https://lh3.googleusercontent.com/-JaJgcJY-SmY/YymfL1_OVwI/AAAAAAAAN5k/scuf7T8eJJsQhs6NDQifO8_1Y9wW4k3kwCNcBGAsYHQ/s1600/1663672109408002-3.png) 

  

 [![](https://lh3.googleusercontent.com/-H54neejV7i4/YymfLIKE2oI/AAAAAAAAN5g/EojP8WjdNSgxSXwvBgNCp0ORjPdtqn1WACNcBGAsYHQ/s1600/1663672106050314-4.png)](https://lh3.googleusercontent.com/-H54neejV7i4/YymfLIKE2oI/AAAAAAAAN5g/EojP8WjdNSgxSXwvBgNCp0ORjPdtqn1WACNcBGAsYHQ/s1600/1663672106050314-4.png) 

  

 [![](https://lh3.googleusercontent.com/-XSg6FgHqDCA/YymfKeVd0gI/AAAAAAAAN5c/nGXT83QcGe0XE3Vq-YDAdH-TEIWZTjvEgCNcBGAsYHQ/s1600/1663672102577104-5.png)](https://lh3.googleusercontent.com/-XSg6FgHqDCA/YymfKeVd0gI/AAAAAAAAN5c/nGXT83QcGe0XE3Vq-YDAdH-TEIWZTjvEgCNcBGAsYHQ/s1600/1663672102577104-5.png) 

  

 [![](https://lh3.googleusercontent.com/-RBKB3QAVOv8/YymfJZlko9I/AAAAAAAAN5Y/kTUhACh9O1w7rD-UUR5PFlUDolqmFTN0QCNcBGAsYHQ/s1600/1663672098933251-6.png)](https://lh3.googleusercontent.com/-RBKB3QAVOv8/YymfJZlko9I/AAAAAAAAN5Y/kTUhACh9O1w7rD-UUR5PFlUDolqmFTN0QCNcBGAsYHQ/s1600/1663672098933251-6.png) 

  

 [![](https://lh3.googleusercontent.com/-0tQDY2Fj3XI/YymfIolRw_I/AAAAAAAAN5U/Pmxs18bLxuEcfBEQEJ43JWaBIi7jlVZHgCNcBGAsYHQ/s1600/1663672095423085-7.png)](https://lh3.googleusercontent.com/-0tQDY2Fj3XI/YymfIolRw_I/AAAAAAAAN5U/Pmxs18bLxuEcfBEQEJ43JWaBIi7jlVZHgCNcBGAsYHQ/s1600/1663672095423085-7.png) 

  

 [![](https://lh3.googleusercontent.com/-hZKFZqyUl7Y/YymfHlKaXtI/AAAAAAAAN5Q/bc4JaMRySN42-6zu3rtZdsnnkQX1Y_PGACNcBGAsYHQ/s1600/1663672092086970-8.png)](https://lh3.googleusercontent.com/-hZKFZqyUl7Y/YymfHlKaXtI/AAAAAAAAN5Q/bc4JaMRySN42-6zu3rtZdsnnkQX1Y_PGACNcBGAsYHQ/s1600/1663672092086970-8.png) 

  

 [![](https://lh3.googleusercontent.com/-Zjr6NqnT-9w/YymfG44kFnI/AAAAAAAAN5M/CKhH3iERPpYCTtghgMQIWGfUVnTMJ55lgCNcBGAsYHQ/s1600/1663672088513295-9.png)](https://lh3.googleusercontent.com/-Zjr6NqnT-9w/YymfG44kFnI/AAAAAAAAN5M/CKhH3iERPpYCTtghgMQIWGfUVnTMJ55lgCNcBGAsYHQ/s1600/1663672088513295-9.png) 

  

  

 [![](https://lh3.googleusercontent.com/-zTjweX_ZYfA/YymfF8yttSI/AAAAAAAAN5I/kfwZEezavnY1ssnoW4wdUjXmiUusnK2AQCNcBGAsYHQ/s1600/1663672084661331-10.png)](https://lh3.googleusercontent.com/-zTjweX_ZYfA/YymfF8yttSI/AAAAAAAAN5I/kfwZEezavnY1ssnoW4wdUjXmiUusnK2AQCNcBGAsYHQ/s1600/1663672084661331-10.png) 

  

 [![](https://lh3.googleusercontent.com/-oYNod5XAJaQ/YymfFOqOgVI/AAAAAAAAN5E/c3a6xHvsc00BXKYex2UFKpoWIVEy9LgMQCNcBGAsYHQ/s1600/1663672081232261-11.png)](https://lh3.googleusercontent.com/-oYNod5XAJaQ/YymfFOqOgVI/AAAAAAAAN5E/c3a6xHvsc00BXKYex2UFKpoWIVEy9LgMQCNcBGAsYHQ/s1600/1663672081232261-11.png) 

  

 [![](https://lh3.googleusercontent.com/-oZxqN3KZI6I/YymfEJgvKFI/AAAAAAAAN5A/zCryJknFkJUJKv0pTjPk5Vc0mF68jO9zwCNcBGAsYHQ/s1600/1663672076993757-12.png)](https://lh3.googleusercontent.com/-oZxqN3KZI6I/YymfEJgvKFI/AAAAAAAAN5A/zCryJknFkJUJKv0pTjPk5Vc0mF68jO9zwCNcBGAsYHQ/s1600/1663672076993757-12.png) 

  

Atlast, this are just highlighted features of SuperSU there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, anyway if you want one of the best rooting software for old Android operating systems then SuperSU is on go worthy choice for sure.

  

Overall, SuperSU comes with light mode by default, it has clean and simple interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will SuperSU get any major UI changes in future to make it even more better, as of now SuperSU is nice. 

  

Moreover, it is definitely worth to mention SuperSU is one of the very few rooting available out there on internet for Android powered smartphones before Magisk conquered new ones, yes indeed if you're searching for such Android rooting software then SuperSU has potential to become your new favourite.

  

Finally, this is what happened to SuperSU Android rooting software, are you an existing user of SuperSU? If yes do say your experience? and why you like SuperSu over Magisk and vice versa and mention which is your most used SuperSu version and features in our comment section below see ya :)