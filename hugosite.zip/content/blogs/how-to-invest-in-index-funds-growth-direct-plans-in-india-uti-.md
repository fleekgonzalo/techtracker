---
title: 'How To Invest In Index Funds Growth : Direct Plans in India [ UTI ]'
date: 2021-08-04T15:59:00.001+05:30
draft: false
url: /2021/08/how-to-invest-in-index-funds-growth.html
tags: 
- How
- technology
- Invest
- Index Funds
- Stocks
---

 [![](https://lh3.googleusercontent.com/-yGpzwwxgKOo/YQt9UH2J7KI/AAAAAAAAGHY/ILAZel8O-84zJBtWOWvlc1tDWwbeVjYQgCLcBGAsYHQ/s1600/1628142917153340-0.png)](https://lh3.googleusercontent.com/-yGpzwwxgKOo/YQt9UH2J7KI/AAAAAAAAGHY/ILAZel8O-84zJBtWOWvlc1tDWwbeVjYQgCLcBGAsYHQ/s1600/1628142917153340-0.png) 

  

[Stock Market](https://www.techtracker.in/2021/08/how-to-invest-in-index-funds-growth.html?m=1) investments are subject to market risks, it can make you billionaire in a day or even can bankrupt you due to this reason you need to have some knowledge on stock market before you start investing in stocks, derivatives etc, else you can get huge financial losses so, for those who do intraday or swing trading require advanced knowledge on stock market instruments & technical analysis, techniques like hedging to recover losses and mainly fundamental analysis is primarly required to study stock carefully before you invest to survive in the stock market.

  

As per stock market analysts & experts it is better & best choice to invest in Nifty 50 Index funds for long term due to it's strong fundementals which will attract investors, low volatility that can give price stability, large market capitalisation that won't give advantage to market big players to manipulate the price of share over Nifty Next 50, mid cap and low cap funds which have high volatility that will give big fluctuations of share price, low market capitalisation that will give advantage to market big players who can manipulate the price of share with large scale buying or selling whenever they want according to thier requirments and weak fundamentals which will make investors to stay away, so yes mid-cap and low can give you rapid big profits in short term but when they get into bearish mode it can give unbearable big losses to investors as well.

  

However, In stock market anything can happen you can't predict future so even you have investments in Index Funds that doesn't mean you will not get losses you will just have little more safety compared to mid cap and low cap funds for Example : if you invested in 5 to 10 nifty 50 shares after carefully checking & analysing each stock fundamentals, charts etc but in future the nifty 50 stocks that you invested can make you billionaire or even get you huge losses that won't even let you recover your capital, this is why stock market billionaire Warren Buffet says to protect your capital first. 

  

So, don't invest in stock market by taking loans or borrowing money, as per stock market principles only invest 10% of your total capital that you can afford to loss and always keep liquid cash in your bank or with you that you can utilise for various reasons or situations in future instead depending on stocks.

  

If you don't have risk appetite but you still insisting to invest in stock market then you can invest in mutual funds, the money you invested in mutual funds will be disbursed in numerous stocks analysed & monitored by expert fund managers to get profits for your investments but they take little fees or share on your profits for the work they done.

  

Eventhough, Mutual funds are little better  and safer due to expert fund managers yet it is only for those who don't have enough knowledge on stock market and can't select shares on thier own then mutual funds can be considered as a choice but there is no guarantee mutual funds can also get you losses due to human error in selecting stocks or in the times of bearish market etc.

  

In this scenario, we have better option over mutual funds named index funds, in Index funds we have numerous plans but Nifty 50 and Nifty Next 50 Index fund growth direct plans are popular choices among stock market investors these days, in index funds money you invested will be automatically distributed equally to all Nifty 50 or Nifty Next 50 shares due to very less work index fund managers take very minimal fees like 0.1 so that you will  gain maximum profits without the need of checking shares frequently which you will do when you invest manually or through mutual funds.

  

But, As per stock market governing authority sebi rules, we stating again stock market investments are subject to market risks which is moderately high, even in Nifty 50 & Nifty next 50 Index funds you may still get losses but there is very low chance for example : the money you invested in in Nifty 50 & Nifty Next 50 growth direct funds will be equally distributed to all shares so there is very low chance that all shares fall immensely, incase nifty 50 & Nifty next 50 shares fall immensely that they won't recover then the nation itself will fall to extreme situation like all banks will get bankrupt, economy and GDP will fall & all people will have no other choice other then to face the situation occured.

  

Yes, Index Funds are more safer & better then any other mode of investment mode available on stock market, through index funds you can become millionaire by taking full benefit of compounding but to get compounding benefit you need to invest for long term like you have to invest in index funds and forget for atleast 30 years to get profits and become millionaire or billionaire based upon your investment today but index funds are especially for those who insisting to get long term returns so it is not suitable for short terms investors as they won't get compounding benefit which is required for big profits. 

  

If you are a long term investor & you have patience to wait for atleast 25 to 30 years either for your personal benefit when you are in retirement or for you children or grand children benefit then index funds are for you but you shouldn't disturb and sell shares in middle of decided time frame which is 25 to 30 years to get money, so  kindly only invest minimal amount which you are affording to forget or losse, so that you won't think about it much and yeah as we earlier said only invest 10% of your total capital and always put liquid cash in bank or with yourself for personal usages. So are you interested in index funds ? If yes let's know little more info regarding index before we get started.

  

We have few platforms available to invest in Index funds like ICICI prudential funds, LIC India, Unit Trust of India While ICICI and LIC have high commission fees which is not good as they only distributing the investment equally to all index shares which is very easy so, UTI - Unit Trust of India is good platform to invest in Index funds with low commission fees and potential features as of now to get maximum returns in future. Let's know registering and investing proccess in Unit Trust Of India.

  

**• UTI - Unit Trust Of India Official Support •**

\- [Facebook](http://www.facebook.com/UTIMutualFund)

\- [LinkedIn](http://www.linkedin.com/company/uti-mf)

\- [YouTube](http://www.youtube.com/user/utimutualfunds)

\- [Twitter](https://twitter.com/utimutualfund)

\- [Instagram](https://www.instagram.com/utimutualfund/)

\- [WhatsApp](http://wa.me/917208081230/?text=hi)

  

**Contact Us** : 1800 266 1230

**Email** : [service@uti.co.in](http://service@uti.co.in)

  

**\- App Info** = [Google Play](https://app.appsflyer.com/com.utimutualfunds.utimutualfund?pid=web&c=website&af_dp=utimutualfunds%253A%252F%252F) / [App Store](https://app.appsflyer.com/id1077281815?pid=web&c=website)

  

• **How to download UTI - MF Mobile App •**

It is very easy to download UTI - Unit Trust Of India App from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.utimutualfunds.utimutualfund) / [App Store](https://app.appsflyer.com/id1077281815?pid=web&c=website)

  

• **How to Invest In Index Funds Growth Direct Plans using UTI MF Mobile App • **

 **[![](https://lh3.googleusercontent.com/-i0LAZZXWiCA/YQut6sECAAI/AAAAAAAAGI4/vtzEeVUEsbMiyCrI-VQiCWnH0qnXcnJBQCLcBGAsYHQ/s1600/1628155366404522-0.png)](https://lh3.googleusercontent.com/-i0LAZZXWiCA/YQut6sECAAI/AAAAAAAAGI4/vtzEeVUEsbMiyCrI-VQiCWnH0qnXcnJBQCLcBGAsYHQ/s1600/1628155366404522-0.png)** 

**\-** Open **UTI Mutual Funds App** and Tap on **Let's Begin.**

 [![](https://lh3.googleusercontent.com/-ipuQuY1UwIc/YQut5cCp7zI/AAAAAAAAGIw/uI1l4Zi2FM8RtyCv2u2yTZNie4a6NdakwCLcBGAsYHQ/s1600/1628155361973372-1.png)](https://lh3.googleusercontent.com/-ipuQuY1UwIc/YQut5cCp7zI/AAAAAAAAGIw/uI1l4Zi2FM8RtyCv2u2yTZNie4a6NdakwCLcBGAsYHQ/s1600/1628155361973372-1.png) 

  

**\-** Tap on **Invest Now**

  

 [![](https://lh3.googleusercontent.com/-rX0--fBtZ7o/YQut4To7RgI/AAAAAAAAGIs/m1YtFHZqJoUWkPiEbmwbXvlCyBctlS1ewCLcBGAsYHQ/s1600/1628155357982591-2.png)](https://lh3.googleusercontent.com/-rX0--fBtZ7o/YQut4To7RgI/AAAAAAAAGIs/m1YtFHZqJoUWkPiEbmwbXvlCyBctlS1ewCLcBGAsYHQ/s1600/1628155357982591-2.png) 

  

\- Enter your PAN card number & Tap on **Validate**

 **[![](https://lh3.googleusercontent.com/-uZciO0ktOgA/YQut3eMvrFI/AAAAAAAAGIo/TBlUWoZ3wpg5-TTYRUvlWf7b3d7NXASkwCLcBGAsYHQ/s1600/1628155353662953-3.png)](https://lh3.googleusercontent.com/-uZciO0ktOgA/YQut3eMvrFI/AAAAAAAAGIo/TBlUWoZ3wpg5-TTYRUvlWf7b3d7NXASkwCLcBGAsYHQ/s1600/1628155353662953-3.png)** 

**\-** Tap on **Continue**

 **[![](https://lh3.googleusercontent.com/-LQhKmNOHOdQ/YQut2Be9e4I/AAAAAAAAGIk/fXVAafkdbMw-p6JVhTU0NrpA4w8sX_WwgCLcBGAsYHQ/s1600/1628155349526833-4.png)](https://lh3.googleusercontent.com/-LQhKmNOHOdQ/YQut2Be9e4I/AAAAAAAAGIk/fXVAafkdbMw-p6JVhTU0NrpA4w8sX_WwgCLcBGAsYHQ/s1600/1628155349526833-4.png)** 

**\-** You will be primary holder of your funds but you can also add additional holders if you want,

  

\- In correspondence address, enter your Email ID, Mobile Number, Date of Birth & Tap on **Procced**.

  

 [![](https://lh3.googleusercontent.com/-BER08SM8BIE/YQut1LwbJdI/AAAAAAAAGIg/HVuHKt28bNUunmnbHCH-4DK2icAmP4lyACLcBGAsYHQ/s1600/1628155345170304-5.png)](https://lh3.googleusercontent.com/-BER08SM8BIE/YQut1LwbJdI/AAAAAAAAGIg/HVuHKt28bNUunmnbHCH-4DK2icAmP4lyACLcBGAsYHQ/s1600/1628155345170304-5.png) 

  

**\-** Fill, select and choose the details and options given in FATCA Details and scroll down below.

  

 [![](https://lh3.googleusercontent.com/-uhjFoxecCA8/YQut0MfjGdI/AAAAAAAAGIc/OUyQCJuDNDovPLF87U0GP9p2FGP4LWG8wCLcBGAsYHQ/s1600/1628155340847541-6.png)](https://lh3.googleusercontent.com/-uhjFoxecCA8/YQut0MfjGdI/AAAAAAAAGIc/OUyQCJuDNDovPLF87U0GP9p2FGP4LWG8wCLcBGAsYHQ/s1600/1628155340847541-6.png) 

  

\- Fill below FATCA details & Tap on **Submit**

 **[![](https://lh3.googleusercontent.com/-m3BolhclHBI/YQutzC4N8dI/AAAAAAAAGIU/p5nOzPd8tZk8_8qOoW5mtY3Zoa6glAOQgCLcBGAsYHQ/s1600/1628155336681038-7.png)](https://lh3.googleusercontent.com/-m3BolhclHBI/YQutzC4N8dI/AAAAAAAAGIU/p5nOzPd8tZk8_8qOoW5mtY3Zoa6glAOQgCLcBGAsYHQ/s1600/1628155336681038-7.png)** 

\- **Kindly Choose These Below Details - **

\- **INVESTMENT TYPE** :  • Direct -

  

\- **SELECT SCHEME CATEGORY** :  EQUITY -

  

\- **SELECT SCHEME NAME** : UTI NIFY INDEX FUND OR UTI NIFTY NEXT 50 INDEX FUND

  

**Note** : Nifty Next 50 may have high volatility but it has the potential to grow as Nifty Next 50 are best performing stocks after Nifty 50 so they can enter anytime in Nifty 50 list in future, so if you have more risk appetite and young then investing in Nifty Next 50 can be a nice choice or try to invest 5% in Nifty 50 & 5% in Nifty Next 50 of your total capital to be in more safe side, while as per stock market experts Nifty 50 can give upto 16% returns on long term & Nifty Next 50 can give upto 19 to 21% on long term, so do some research on nifty 50 and nifty next 50 before investing!

  

\- **SELECT PLAN / OPTION** : DIRECT GROWTH PLAN GROWTH.

  

\- **INVESTMENT AMOUNT** : Minimum SIP amount is 500rs, you can modify it to.

  

**\- SIP START DATE  :** Select **Frequency** : Monthly, Quarterly or Annually.

  

\- **SIP CYCLE DATE & SIP CYCLE MONTH** : Choose according to your convenience & scroll down.

  

 [![](https://lh3.googleusercontent.com/--C3uXoUdBvI/YQutx6ZHecI/AAAAAAAAGIQ/8k59E8V3TCQ10Nc8xTSHf-OdmFZgVxwuwCLcBGAsYHQ/s1600/1628155332076617-8.png)](https://lh3.googleusercontent.com/--C3uXoUdBvI/YQutx6ZHecI/AAAAAAAAGIQ/8k59E8V3TCQ10Nc8xTSHf-OdmFZgVxwuwCLcBGAsYHQ/s1600/1628155332076617-8.png) 

  

  

\- SIP END DATE : Select **UNTIL  CANCELLED**

  

\- Select **SIP END MONTH & SIP END YEAR** according to your  convenience.

  

\- check **✓** I agree to the terms & Tap on Submit to **Proceed** further.

  

**Note** : According to stock market experts it is always better and best to invest in SIP mode over lumsum, as in SIP mode the money you invested will be automatically averaged according to market conditions and prices so SIP mode is good mode for lumsum investors to, If you don't want to invest in SIP mode then for lum sum investors there is option in UTI MF Mobile app. Do check it out.

  

  

 [![](https://lh3.googleusercontent.com/-j2pBBO1880M/YQutwwG0zMI/AAAAAAAAGIM/lrkNyATAB4IZVpLA2vQUKqbZcs_A6if4wCLcBGAsYHQ/s1600/1628155327665206-9.png)](https://lh3.googleusercontent.com/-j2pBBO1880M/YQutwwG0zMI/AAAAAAAAGIM/lrkNyATAB4IZVpLA2vQUKqbZcs_A6if4wCLcBGAsYHQ/s1600/1628155327665206-9.png) 

  

\- Add Nominee details & Tap on **Proceed**

 **[![](https://lh3.googleusercontent.com/-07ljO83dcsA/YQutviBWiBI/AAAAAAAAGII/t9Oq1Q9Wlrk3sGmDWqyrh_trFcRPt9_jACLcBGAsYHQ/s1600/1628155323245329-10.png)](https://lh3.googleusercontent.com/-07ljO83dcsA/YQutviBWiBI/AAAAAAAAGII/t9Oq1Q9Wlrk3sGmDWqyrh_trFcRPt9_jACLcBGAsYHQ/s1600/1628155323245329-10.png)** 

**\-** Now, it's time to add your bank details : enter your bank details carefully, enter your IFSC and search it.

  

\- Select Your Bank Account Type, Enter your Bank Account Number, Bank Name, double check your details to make sure it's correct or not then tap on **Submit**

 **[![](https://lh3.googleusercontent.com/-9E8i0paw8TA/YQutujuJfnI/AAAAAAAAGIE/rYjWlaIpG2ExBsgq51RdMc_y40cnV6gPQCLcBGAsYHQ/s1600/1628155318728240-11.png)](https://lh3.googleusercontent.com/-9E8i0paw8TA/YQutujuJfnI/AAAAAAAAGIE/rYjWlaIpG2ExBsgq51RdMc_y40cnV6gPQCLcBGAsYHQ/s1600/1628155318728240-11.png) 

\-** Your successfully registered for INDEX Funds In SIP mode, Now to make it work you have copy your URN number and Add it your bank account bill pay section. And yeah you can also make another purchase.

**• How to add URN Number on your bank account for automatic payments •**

 **[![](https://lh3.googleusercontent.com/-EaIL4kA4sAM/YQu9nIXpJlI/AAAAAAAAGJo/RoYIf6bvJfkqPbmSusoLdogzijyfQMiFACLcBGAsYHQ/s1600/1628159383474868-0.png)](https://lh3.googleusercontent.com/-EaIL4kA4sAM/YQu9nIXpJlI/AAAAAAAAGJo/RoYIf6bvJfkqPbmSusoLdogzijyfQMiFACLcBGAsYHQ/s1600/1628159383474868-0.png)** 

\- First copy the URN number that we got after we done transaction, you can find URN Number in your sms or email, after copying URN number Go to your official bank account app or website and find **Pay Bills** options & tap on it 

 **[![](https://lh3.googleusercontent.com/-Z16dcuzfAX8/YQu9lvAwYSI/AAAAAAAAGJk/gXmyyydLGHoW50H0KlG71nLU621bFUjGQCLcBGAsYHQ/s1600/1628159379274614-1.png)](https://lh3.googleusercontent.com/-Z16dcuzfAX8/YQu9lvAwYSI/AAAAAAAAGJk/gXmyyydLGHoW50H0KlG71nLU621bFUjGQCLcBGAsYHQ/s1600/1628159379274614-1.png)** 

**\-** Tap on **Mutual Fund**

  

 [![](https://lh3.googleusercontent.com/-ipiurs6tXcc/YQu9koilzPI/AAAAAAAAGJg/OowSjFiFzDA57cADMlq8h9V7xOnCVhkqgCLcBGAsYHQ/s1600/1628159374620586-2.png)](https://lh3.googleusercontent.com/-ipiurs6tXcc/YQu9koilzPI/AAAAAAAAGJg/OowSjFiFzDA57cADMlq8h9V7xOnCVhkqgCLcBGAsYHQ/s1600/1628159374620586-2.png) 

  

\- Search or find **UTI Mutual Fund**

 **[![](https://lh3.googleusercontent.com/-CpNkd6cGNnI/YQu9jYm1eiI/AAAAAAAAGJc/4R3x7qg1tUguqLSQOhJvv3vUaLp1FKD6QCLcBGAsYHQ/s1600/1628159370387569-3.png)](https://lh3.googleusercontent.com/-CpNkd6cGNnI/YQu9jYm1eiI/AAAAAAAAGJc/4R3x7qg1tUguqLSQOhJvv3vUaLp1FKD6QCLcBGAsYHQ/s1600/1628159370387569-3.png)** 

\- Enter or Copy paste your URN No. and enter biller nickname ( optional ) then tap on **ADD BILLER**

 **[![](https://lh3.googleusercontent.com/-5i-zlSelsFY/YQu9iUXWWXI/AAAAAAAAGJY/LIUpWWZ1jVEYFwfUJvd1MO56abN7gOHiwCLcBGAsYHQ/s1600/1628159366490311-4.png)](https://lh3.googleusercontent.com/-5i-zlSelsFY/YQu9iUXWWXI/AAAAAAAAGJY/LIUpWWZ1jVEYFwfUJvd1MO56abN7gOHiwCLcBGAsYHQ/s1600/1628159366490311-4.png)** 

\- Your URN Number will be added, you will get successfull confirmation message to your mobile number and email, from now your SIP plan will start working and money will deducted every month from your bank account and will be invested in Index funds on UTI - Unit Trust of India, YAY!

  

**• How to login on UTI MF Mobile App to access more features  •**

  

 [![](https://lh3.googleusercontent.com/-KmfDM97yBw8/YQuttlJntOI/AAAAAAAAGIA/xd5-UF_u-94OuEzUnsW5n8D5HSn9RvTywCLcBGAsYHQ/s1600/1628155314247749-12.png)](https://lh3.googleusercontent.com/-KmfDM97yBw8/YQuttlJntOI/AAAAAAAAGIA/xd5-UF_u-94OuEzUnsW5n8D5HSn9RvTywCLcBGAsYHQ/s1600/1628155314247749-12.png) 

  

\- Go to UTI MF Mobile App, **Home** & Tap on **Login**

  

 [![](https://lh3.googleusercontent.com/-klqLioafAwg/YQutsSJY34I/AAAAAAAAGH8/PWquoujHvYk7zjz1enD3B8jBNLwo9WlnQCLcBGAsYHQ/s1600/1628155309821870-13.png)](https://lh3.googleusercontent.com/-klqLioafAwg/YQutsSJY34I/AAAAAAAAGH8/PWquoujHvYk7zjz1enD3B8jBNLwo9WlnQCLcBGAsYHQ/s1600/1628155309821870-13.png) 

  

\- Tap on **Generate Id**

 **[![](https://lh3.googleusercontent.com/-smPRbPxf-2c/YQutrU858zI/AAAAAAAAGH4/SeoUUmsaj5AU23isG8B_a1X90qGcq7VzQCLcBGAsYHQ/s1600/1628155305501086-14.png)](https://lh3.googleusercontent.com/-smPRbPxf-2c/YQutrU858zI/AAAAAAAAGH4/SeoUUmsaj5AU23isG8B_a1X90qGcq7VzQCLcBGAsYHQ/s1600/1628155305501086-14.png)** 

**\-** Enter your Pan Card, wait to get folio number go to  : [utimf.com/portal/signup](http://utimf.com/portal/signup)

  

 [![](https://lh3.googleusercontent.com/-KZx0vdW576s/YQutqJ_4JkI/AAAAAAAAGH0/X7hFUyPut-Q6cs6A_0Wi6VGlyGiMmQHKQCLcBGAsYHQ/s1600/1628155301064912-15.png)](https://lh3.googleusercontent.com/-KZx0vdW576s/YQutqJ_4JkI/AAAAAAAAGH0/X7hFUyPut-Q6cs6A_0Wi6VGlyGiMmQHKQCLcBGAsYHQ/s1600/1628155301064912-15.png) 

  

\- Enter your Pan Card Number, and Tap on **Get OTP \***

 [![](https://lh3.googleusercontent.com/-WqvB9hSEEJI/YQutpL09gPI/AAAAAAAAGHw/s9pfcXAYXRQDujK_m-mHVaw7e30wPiAhwCLcBGAsYHQ/s1600/1628155296485959-16.png)](https://lh3.googleusercontent.com/-WqvB9hSEEJI/YQutpL09gPI/AAAAAAAAGHw/s9pfcXAYXRQDujK_m-mHVaw7e30wPiAhwCLcBGAsYHQ/s1600/1628155296485959-16.png) 

  

\- OTP will sent to your registered mobile number and email check it then enter the OTP here & Tap on **Sign in**

  

 [![](https://lh3.googleusercontent.com/-XjDudiB_OYc/YQutn006GbI/AAAAAAAAGHs/3McgOsqBaAgdWWzXEq416eTGUMnyrZtkwCLcBGAsYHQ/s1600/1628155291697006-17.png)](https://lh3.googleusercontent.com/-XjDudiB_OYc/YQutn006GbI/AAAAAAAAGHs/3McgOsqBaAgdWWzXEq416eTGUMnyrZtkwCLcBGAsYHQ/s1600/1628155291697006-17.png) 

  

\- Here you will get Folio Number : Copy it and get back to UTI MF Mobile app.

  

 [![](https://lh3.googleusercontent.com/-GLfuSejkIPg/YQutmnaA1HI/AAAAAAAAGHo/pTTJmyUiS_Yj7pqBoVV0KLPU3ctEkkv8gCLcBGAsYHQ/s1600/1628155287400320-18.png)](https://lh3.googleusercontent.com/-GLfuSejkIPg/YQutmnaA1HI/AAAAAAAAGHo/pTTJmyUiS_Yj7pqBoVV0KLPU3ctEkkv8gCLcBGAsYHQ/s1600/1628155287400320-18.png) 

  

\- Re-enter your Pan number, Folio number, then tap on **Validate**

 **[![](https://lh3.googleusercontent.com/-5EnHlYTpYY4/YQutloWM1-I/AAAAAAAAGHk/1UexFzch004nMT_HZiSf3do886ep2ODYgCLcBGAsYHQ/s1600/1628155282977324-19.png)](https://lh3.googleusercontent.com/-5EnHlYTpYY4/YQutloWM1-I/AAAAAAAAGHk/1UexFzch004nMT_HZiSf3do886ep2ODYgCLcBGAsYHQ/s1600/1628155282977324-19.png)** 

**\-** Enter your Pan Card number as user name, re-enter user name, enter password according to rules then tap on **Set**

  

 [![](https://lh3.googleusercontent.com/-g2uwS0asvDU/YQutkTG_5kI/AAAAAAAAGHg/u-mAcof3WHcrr47NNAR13WSX0erApWQlwCLcBGAsYHQ/s1600/1628155275550664-20.png)](https://lh3.googleusercontent.com/-g2uwS0asvDU/YQutkTG_5kI/AAAAAAAAGHg/u-mAcof3WHcrr47NNAR13WSX0erApWQlwCLcBGAsYHQ/s1600/1628155275550664-20.png) 

  

\- Enter your Pan Card Number in user name field & Enter password then tap on **Submit.**

 **[![](https://lh3.googleusercontent.com/-BBnS1rwPICk/YQu9hfxmxeI/AAAAAAAAGJU/qQTmDxjDBiwUY1SMwi8pAE_rD2NF1JQfACLcBGAsYHQ/s1600/1628159349765306-5.png)](https://lh3.googleusercontent.com/-BBnS1rwPICk/YQu9hfxmxeI/AAAAAAAAGJU/qQTmDxjDBiwUY1SMwi8pAE_rD2NF1JQfACLcBGAsYHQ/s1600/1628159349765306-5.png)** 

\- Your are in UTI MF Mobile App, Tap on Transact where you can invest in SIP or lumsum mode in numerous equity funds like Debt Category Funds, Equity Category Funds, Hybrid Category Funds, Overnight & Liquid Funds,  Solution Based Funds, ETFs.

  

**CONGRATULATIONS**, You successfully registered and learned how to invest in index funds using UTI MF Mobile App.

  

**• UTI MF Mobile App Key Features With UI / UX Overview •**

\- It promotes 100% paperless transactions. 

  

  

\- You can easily sign up and sign in into your account using PAN card or folio number.

  

  

\- Explore and know the details of various UTI mutual funds and check the fund-related latest and historic data, including NAVs.

  

  

\- The One Click Investment is a NIFTY tool that allows you to purchase/sell units with click of a button.

  

  

\- The e-Smart features allow you to make payment for all your transactions with a single click without the hassles of accessing internet banking or entering debit card details.

  

  

\- The easy-to-use calculators allows you to plan your investments, including setting a goal, purchasing an SIP. You can also email the results to yourself for posterity.

  

  

\- The factsheet gives easy access to fund details and quarterly performance to all investors.

  

  

\- uSAVE allows you to make smart investment decisions and grow your savings through investment in liquid funds. It also allows you to instantly Redeem up to Rs. 50,000 into your bank account through IMPS. 

  

  

\- You can mark and save your transactions as favourite for easy and quick reference in the future.

  

  

\- The Learn and invest sections is specially crafted to give you the best information content and be a master at investment and make smarter decisions. The information can also be saved and shared through social media.

  

Atlast, Remember if you are in between 20 to 25 years age Index funds can be very useful for your financial growth as you have more future over retired citizens to wait and get long terms returns, so if you are young & want to invest then kindly research on your own before you invest in Index Funds, as here we provided gathered information from stock market experts with included opinions of our own.

  

Overall, UTI MF Mobile App is quick and fast Equity funds investing app packed with useful and potential features for investors, it is very easy to use due to its simple user interface which gives you clean and optimized user experience but we have to wait and see will UTI MF Mobile App get any major UI changes in future to make it even more better, as of now UTI MF Mobile App have perfect user interface and user experience that you may like to use for sure.   

  

Moreover, it is worth to mention Warren Buffett said Mutual funds can't beat index funds in terms of profits and even challenged Mutual funds companies with 1 million dollars winner price money for mutual fund companies who get more profits then index funds but none of the mutual fund companies were able to beat index funds interms of profits in long term till now, Interesting right!

  

  

Finally**, **This is UTI - Unit Trust Of India, one of the best portal to invest in equity funds with low commission fee for index growth direct funds available right now, so, do you like it? If yes? Are you an existing user of UTI? If you are an existing user of UTI do say your experience with UTI & mention which features you like the most in it in our comment section below, see ya :)