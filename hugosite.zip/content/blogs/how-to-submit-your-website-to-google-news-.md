---
title: 'How to submit your website to Google News ! '
date: 2021-01-19T12:31:00.000+05:30
draft: false
url: /2021/01/how-to-submit-your-website-to-google.html
tags: 
- technology
- Google News
- publisher
- traffic
- content
---

 [![How to submit your website to Google News !](https://lh3.googleusercontent.com/-FB2wh06KL8s/YAWgWGPTzpI/AAAAAAAAC00/QtIFWqpgiBUrj9hDCXKtpQixwDaACbFKACLcBGAsYHQ/s1600/1610981457592288-0.png "How to submit your website to Google News !")](https://lh3.googleusercontent.com/-FB2wh06KL8s/YAWgWGPTzpI/AAAAAAAAC00/QtIFWqpgiBUrj9hDCXKtpQixwDaACbFKACLcBGAsYHQ/s1600/1610981457592288-0.png) 

  

Google have presence on every platform and it is popularly known for their Google search engine which will get 90% internet internet traffic worldwide. 

  

Google index and rank million of websites and billions of articles daily based on the search engine optimization and content. 

  

In the same way google news fetch alot of articles from blogs and websites based on it's popularity, content and traffic. 

  

**Yes**, google will put your article using their  algorithm based on your article popularity you don't need to submit your website for that google will do it automatically. 

  

**However**, it is always better to get verified in google publisher center which enable more chance of getting your article listed on google news with alot of advantages that we will mention later on. 

  

When it comes to advantages by getting approval from Google News you will get your seperate website catalogue. 

  

Including that you can build followers by sharing your publication URL which will build audience for your site like Facebook or Instagram in Google News. 

  

Which will extend your reach to more people that will get you more traffic & brand identity which will help your site. 

  

Now, let's know how to submit website to Google News.

  

It is very easy to submit your website or blog in google publisher center which will get you a google news catalogue for your website. 

  

To submit your website or blog in google publisher console you need to go - [here](https://publishercenter.google.com/)

  

 [![](https://lh3.googleusercontent.com/-361RacN0I3E/YAXSwKHRarI/AAAAAAAAC1w/8UyCCpSI64ofX-YBLTuH8yfzt_7ERlKJwCLcBGAsYHQ/s1600/1610994364523732-0.png)](https://lh3.googleusercontent.com/-361RacN0I3E/YAXSwKHRarI/AAAAAAAAC1w/8UyCCpSI64ofX-YBLTuH8yfzt_7ERlKJwCLcBGAsYHQ/s1600/1610994364523732-0.png) 

  

  

This is our publisher center you can see our website is **LIVE** because our website was approved by google news. 

  

But, if you just registered you need give your website Information to google and submit for review. 

  

 [![](https://lh3.googleusercontent.com/-uFQLi9MDK7o/YAXSvNEW20I/AAAAAAAAC1s/CTfvhkDZ4tY6GtSjxA5hXA0eHKSB1IP0QCLcBGAsYHQ/s1600/1610994360056102-1.png)](https://lh3.googleusercontent.com/-uFQLi9MDK7o/YAXSvNEW20I/AAAAAAAAC1s/CTfvhkDZ4tY6GtSjxA5hXA0eHKSB1IP0QCLcBGAsYHQ/s1600/1610994360056102-1.png) 

  

  

**Once**, you login with your gmail It is best to login with your AdSense email which will easy up the process. 

  

**Now**, Tap on \[ + **Add Publication** \]

  

 [![](https://lh3.googleusercontent.com/-nLAS6n1v63c/YAXSt3gJOqI/AAAAAAAAC1o/IlKFDGDuNj0f6umIz1c_p6h6w5t4u_e9gCLcBGAsYHQ/s1600/1610994356856067-2.png)](https://lh3.googleusercontent.com/-nLAS6n1v63c/YAXSt3gJOqI/AAAAAAAAC1o/IlKFDGDuNj0f6umIz1c_p6h6w5t4u_e9gCLcBGAsYHQ/s1600/1610994356856067-2.png) 

  

You will get this pop-up on your browser then enter your publication name & save the new publication. 

  

**Now**, you created new publication but you have to submit more information that we stated below to submit for review. 

  

 [![](https://lh3.googleusercontent.com/-TnQCMupGL3Y/YAXStBI-22I/AAAAAAAAC1k/C2Rn7iePDX4_qOrXUUHHWuL3XP1ozsW4gCLcBGAsYHQ/s1600/1610994352762928-3.png)](https://lh3.googleusercontent.com/-TnQCMupGL3Y/YAXStBI-22I/AAAAAAAAC1k/C2Rn7iePDX4_qOrXUUHHWuL3XP1ozsW4gCLcBGAsYHQ/s1600/1610994352762928-3.png) 

  

\- Enter your publication name ( required ) 

\- Description ( required ) 

\- Category ( required ) 

\- Primary language ( required ) 

\- \[ √ \] Allow automatic translation \[ i \]

  

In _general_ - **basic information** - you have to fill all the required fields. 

  

  

 [![](https://lh3.googleusercontent.com/-1mTjSWbD-W0/YAXSsORfgUI/AAAAAAAAC1g/e9KImQ-K7AwJsg8Iqf8q4uh0j_-SW1NbQCLcBGAsYHQ/s1600/1610994348617282-4.png)](https://lh3.googleusercontent.com/-1mTjSWbD-W0/YAXSsORfgUI/AAAAAAAAC1g/e9KImQ-K7AwJsg8Iqf8q4uh0j_-SW1NbQCLcBGAsYHQ/s1600/1610994348617282-4.png) 

  

\- In **Website Property URL**\- you have to Enter your Website **URL** or else you can

alternatively you can verify it with your search console if your login email is already registered in search console. 

  

 [![](https://lh3.googleusercontent.com/-dot_QAko9mY/YAXSrEAFwrI/AAAAAAAAC1c/4gE2q42nYgIwSslP3MgQw2FrBeDm8FCFACLcBGAsYHQ/s1600/1610994345151649-5.png)](https://lh3.googleusercontent.com/-dot_QAko9mY/YAXSrEAFwrI/AAAAAAAAC1c/4gE2q42nYgIwSslP3MgQw2FrBeDm8FCFACLcBGAsYHQ/s1600/1610994345151649-5.png) 

  

**\- To add a location**, you must first set a primary language and verify your website property URL

  

 [![](https://lh3.googleusercontent.com/-MyhdDF2PPSI/YAXSqAGHjvI/AAAAAAAAC1Y/K2CJUfell9A8vxCNHQjMvSvTKhLGDPppgCLcBGAsYHQ/s1600/1610994341305328-6.png)](https://lh3.googleusercontent.com/-MyhdDF2PPSI/YAXSqAGHjvI/AAAAAAAAC1Y/K2CJUfell9A8vxCNHQjMvSvTKhLGDPppgCLcBGAsYHQ/s1600/1610994341305328-6.png) 

  

 [![](https://lh3.googleusercontent.com/-plMNpev3cGI/YAXSpaxnyxI/AAAAAAAAC1U/Qs_2I5OHb2kFX1keSyYJjr3SdifLIP_6ACLcBGAsYHQ/s1600/1610994337787866-7.png)](https://lh3.googleusercontent.com/-plMNpev3cGI/YAXSpaxnyxI/AAAAAAAAC1U/Qs_2I5OHb2kFX1keSyYJjr3SdifLIP_6ACLcBGAsYHQ/s1600/1610994337787866-7.png) 

  

  

**In contacts**, you have give your alternative gmail to let Google inform about technical issues and more. 

  

 [![](https://lh3.googleusercontent.com/-HlWJ2bZ9n7Q/YAXSoQoeLXI/AAAAAAAAC1Q/atRi5ljZL2EVb9hHOVthudfMSfGomF6GwCLcBGAsYHQ/s1600/1610994334258137-8.png)](https://lh3.googleusercontent.com/-HlWJ2bZ9n7Q/YAXSoQoeLXI/AAAAAAAAC1Q/atRi5ljZL2EVb9hHOVthudfMSfGomF6GwCLcBGAsYHQ/s1600/1610994334258137-8.png) 

  

**In distribution**, you have choose either you want your articles distributed to world or Allow or Block specific countries. 

  

 [![](https://lh3.googleusercontent.com/-92As9yEYutk/YAXSnXrZ20I/AAAAAAAAC1M/92jrg_0nA5o8YZB9uJG4HMzWcluhitUrwCLcBGAsYHQ/s1600/1610994330176775-9.png)](https://lh3.googleusercontent.com/-92As9yEYutk/YAXSnXrZ20I/AAAAAAAAC1M/92jrg_0nA5o8YZB9uJG4HMzWcluhitUrwCLcBGAsYHQ/s1600/1610994330176775-9.png) 

  

**In tracking**, you have give your google an- lytics tracking ID which will monitor your google news traffic. 

  

you can easy find in your Google Analytics console or in your blogger settings if you submitted to the ID already. 

  

Enter your Google Analytics tracking ID & press on **SAVE** and tap on **Next**

 **[![](https://lh3.googleusercontent.com/-pxh9_yYMXeY/YAXSmXLBVbI/AAAAAAAAC1I/f_URpHCtu6ATIRxxR6fuBgA_ixAwNSFYACLcBGAsYHQ/s1600/1610994325673045-10.png)](https://lh3.googleusercontent.com/-pxh9_yYMXeY/YAXSmXLBVbI/AAAAAAAAC1I/f_URpHCtu6ATIRxxR6fuBgA_ixAwNSFYACLcBGAsYHQ/s1600/1610994325673045-10.png)** 

**In content**, _sections_**, **tap on + new section and add your website feed. 

  

 [![](https://lh3.googleusercontent.com/-GcMvVpAg-5I/YAXSldFGj0I/AAAAAAAAC1E/TsCWD0Maf1IOb-cryFk7lHGuz211nDYRACLcBGAsYHQ/s1600/1610994321218699-11.png)](https://lh3.googleusercontent.com/-GcMvVpAg-5I/YAXSldFGj0I/AAAAAAAAC1E/TsCWD0Maf1IOb-cryFk7lHGuz211nDYRACLcBGAsYHQ/s1600/1610994321218699-11.png) 

  

• Section title \[ required \]

  

• RSS or Atom Feed URL

  

**\- WordPress feed format -**

[www.techtracker.in/feed](http://www.techtracker.in/feed) 

**\[** Replace with your website URL **\]**  

**\- Blogger feed format -**

  

[www.techtracker.in/feeds/posts/default](http://www.techtracker.in/feeds/posts/default)  

**\[** Replace with your website URL **\]**  

  

• \[ √ \] Anyone

  

\- Feed options - Generate article directly from feed. 

  

\- In rendering preference - use amp ( rec- ommeded )  or use feed content. 

  

**In video**, you can submit your YouTube channel **URL**. 

  

In **web location** or **personal feed** is user specific and not much popular if you have knowledge on them then do try it. 

  

If you are a beginner we don't suggest or recommend to use AMP and mainly if you use blogger platform. 

  

 [![](https://lh3.googleusercontent.com/-fRo9kwDPfFw/YAXSkM9zfVI/AAAAAAAAC1A/bspYgnLQ7_YKkoW6wzfArt6blB62v3rOQCLcBGAsYHQ/s1600/1610994315863503-12.png)](https://lh3.googleusercontent.com/-fRo9kwDPfFw/YAXSkM9zfVI/AAAAAAAAC1A/bspYgnLQ7_YKkoW6wzfArt6blB62v3rOQCLcBGAsYHQ/s1600/1610994315863503-12.png) 

  

In content labels, Add your site-wide label either it's blog, user generated or opinion. 

  

 [![](https://lh3.googleusercontent.com/-gN1jg4-VnrE/YAZo1J5_8aI/AAAAAAAAC2k/tqaKQewrrpA6UfE_wIzeYDSSc272Ib-5wCLcBGAsYHQ/s1600/1611032780305876-0.png)](https://lh3.googleusercontent.com/-gN1jg4-VnrE/YAZo1J5_8aI/AAAAAAAAC2k/tqaKQewrrpA6UfE_wIzeYDSSc272Ib-5wCLcBGAsYHQ/s1600/1611032780305876-0.png) 

  

In **verify URL ownership**, All content that associated with Google News must be from verified URL 

￼

 [![](https://lh3.googleusercontent.com/-Ho6lXan6yTY/YAZoy5rV9mI/AAAAAAAAC2g/Ocxj0Q3Nvu8dOaIJiSGl41JnGmHVEiAtgCLcBGAsYHQ/s1600/1611032772748463-1.png)](https://lh3.googleusercontent.com/-Ho6lXan6yTY/YAZoy5rV9mI/AAAAAAAAC2g/Ocxj0Q3Nvu8dOaIJiSGl41JnGmHVEiAtgCLcBGAsYHQ/s1600/1611032772748463-1.png) 

  

Tap on **\+ New content source**, you will get this pop-up then enter you website source.

  

After that tap on **Add** and press on **Next**

  

 **[![](https://lh3.googleusercontent.com/-WzVInMR9HQ0/YAZoxHIHUwI/AAAAAAAAC2c/DStts08ZnSIF7m5sWsDx3-qGYNZF7rG3ACLcBGAsYHQ/s1600/1611032768673298-2.png)](https://lh3.googleusercontent.com/-WzVInMR9HQ0/YAZoxHIHUwI/AAAAAAAAC2c/DStts08ZnSIF7m5sWsDx3-qGYNZF7rG3ACLcBGAsYHQ/s1600/1611032768673298-2.png)** 

In _Images,_ **Square Logo -** Add a square logo to represent your publication. 

  

\- **File format** - Recommend PNG, but JPG is also supported. 

  

\- **Dimensions** - Recommend 1000 by 1000 px but required 512 to 512 px. 

  

 [![](https://lh3.googleusercontent.com/-Dsbn5si-VSM/YAZowEZKMzI/AAAAAAAAC2Y/x-fzP5m-8SIuEbAPI8yiJd4FNvQ1sKm6QCLcBGAsYHQ/s1600/1611032764791265-3.png)](https://lh3.googleusercontent.com/-Dsbn5si-VSM/YAZowEZKMzI/AAAAAAAAC2Y/x-fzP5m-8SIuEbAPI8yiJd4FNvQ1sKm6QCLcBGAsYHQ/s1600/1611032764791265-3.png) 

  

In **wide logo**, you have add light theme wide logo and add theme wide logo by following all guidelines and press **Next**

 **[![](https://lh3.googleusercontent.com/-XJuh6zQMu04/YAZovBYGfLI/AAAAAAAAC2U/khM-yInPHS4aS-dKfH8YNpdcnbGNkznNgCLcBGAsYHQ/s1600/1611032756026082-4.png)](https://lh3.googleusercontent.com/-XJuh6zQMu04/YAZovBYGfLI/AAAAAAAAC2U/khM-yInPHS4aS-dKfH8YNpdcnbGNkznNgCLcBGAsYHQ/s1600/1611032756026082-4.png)** 

In **Ads**, don't change anything if you are a complete beginner just change if you have knowledge on it and then press **Next**

 **[![](https://lh3.googleusercontent.com/-N5ngKODM_e8/YAaDx6KImvI/AAAAAAAAC3E/palHEEtW-kIg-rnefeskdqv2RFRKgVW_wCLcBGAsYHQ/s1600/1611039682435908-0.png)](https://lh3.googleusercontent.com/-N5ngKODM_e8/YAaDx6KImvI/AAAAAAAAC3E/palHEEtW-kIg-rnefeskdqv2RFRKgVW_wCLcBGAsYHQ/s1600/1611039682435908-0.png)** 

In _Advanced,_ **Access groups** \- restrict sections of your publication in Google News app to specific people such as authorised testers. Once you create a group assign it to a section on Content tab by tapping on + **New access group** and then press on **Next** 

  

 [![](https://lh3.googleusercontent.com/-N2IZexKF4t4/YAaDwfAtdrI/AAAAAAAAC3A/yrF7BYhI1z8-2_JqXjZZ6MCbUGK8XOn1QCLcBGAsYHQ/s1600/1611039673722861-1.png)](https://lh3.googleusercontent.com/-N2IZexKF4t4/YAaDwfAtdrI/AAAAAAAAC3A/yrF7BYhI1z8-2_JqXjZZ6MCbUGK8XOn1QCLcBGAsYHQ/s1600/1611039673722861-1.png) 

  

In _Review and Publish_, you can see all the issues that you can review, edit and fix them to submit your website to Google News. 

  

You can follow your publication which will be saved in your favorites. 

  

After fixing issues and re-checking your details then press on **Save** and preview and submit your website to Google news. 

  

Note : It will take upto **2 weeks** to get approval from Google News but if your website have consistent and quality content your website will be approved in less time. 

  

**Finally**, Google News is good platform to reach more people it has good features and seperate catalogue to build followers which will help you to grow you website, do you have any questions comment down below in our comment we will try to answer as soon as we can, see ya :-)