---
title: 'Pub G shut down all the servers making game completely inaccessible in India !'
date: 2020-10-30T20:40:00.001+05:30
draft: false
url: /2020/10/pub-g-shut-down-all-servers-making-game.html
tags: 
- servers
- technology
- India
- game
- Pubg
- shut down
---

 [![](https://lh3.googleusercontent.com/-kfjw3zLVoqs/X5ws-iGVtiI/AAAAAAAACBc/NLU_5fa0l0o2P4_PCevoJLUsZ0FzbY9dQCLcBGAsYHQ/s1600/1604070645510245-0.png)](https://lh3.googleusercontent.com/-kfjw3zLVoqs/X5ws-iGVtiI/AAAAAAAACBc/NLU_5fa0l0o2P4_PCevoJLUsZ0FzbY9dQCLcBGAsYHQ/s1600/1604070645510245-0.png) 

  

While faug is ramping up to release thier new game alternative to pub g in november, pub g have found no way to return back to India.

  

Previously, on sept 2nd information technology and electronics of India banned pubg including other 58 apps that may have privacy and data threat issues.

  

Pub G was one of them the popularity that this game got in India is humongous.

  

While pub g fans waiting for the game to return today pub g states it terminates all the services complying India it regulations starting oct 30.

  

Pub G offically announced in thier socia media handles facebook, discord and in game itself.

  

 [![](https://lh3.googleusercontent.com/-iV3OZEF5Djc/X5wwGhCOdDI/AAAAAAAACBw/bfhn267dA4c5QzBYjd7vQYm1td1Aw-GDwCLcBGAsYHQ/s1600/1604071446828072-0.png)](https://lh3.googleusercontent.com/-iV3OZEF5Djc/X5wwGhCOdDI/AAAAAAAACBw/bfhn267dA4c5QzBYjd7vQYm1td1Aw-GDwCLcBGAsYHQ/s1600/1604071446828072-0.png) 

  

 [![](https://lh3.googleusercontent.com/-uZbVSKLfZMQ/X5wwF7CtlJI/AAAAAAAACBs/izbsF71zDrEytL2DA-c8eLUOeUS4P0iHwCLcBGAsYHQ/s1600/1604071443373386-1.png)](https://lh3.googleusercontent.com/-uZbVSKLfZMQ/X5wwF7CtlJI/AAAAAAAACBs/izbsF71zDrEytL2DA-c8eLUOeUS4P0iHwCLcBGAsYHQ/s1600/1604071443373386-1.png) 

  

 [![](https://lh3.googleusercontent.com/-3uUt9-RzUC0/X5wwFBP5iUI/AAAAAAAACBo/AhLRyVrd6sQHJNU-bTCUcjDzq_Br-irZACLcBGAsYHQ/s1600/1604071439920996-2.png)](https://lh3.googleusercontent.com/-3uUt9-RzUC0/X5wwFBP5iUI/AAAAAAAACBo/AhLRyVrd6sQHJNU-bTCUcjDzq_Br-irZACLcBGAsYHQ/s1600/1604071439920996-2.png) 

                          

  

  

In spite of ban, these seems working for India to grow itself in scenario of tik tok which still not made return got many alternatives same may goes for pub g.

  

Faug is already on the way to appear in november even if pub g returns it takes alot of time setting up new servers and refreshed and redesigned game for India users like they done for china.

  

Pub G not only faced ban in India even in china to where china banned it for violence content which pub g redesigned game and renamed to it game of peace to come back in china.

  

**Eventhough**, government may not have plans to unban games made by china that made pub G korea to cut partenership with tencent.

  

However, if pub g won't return to India there are alernatives like free fire, sky high, free fall, cod, etc.

  

**Finally**, do you think pub g will return, are you waiting for pub g, do you think faug can be pub g competitor do mention your thoughts below in our comment section, see ya :-)