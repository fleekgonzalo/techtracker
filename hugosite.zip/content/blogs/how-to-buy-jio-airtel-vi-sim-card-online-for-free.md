---
title: 'How to buy Jio, Airtel, Vi sim card online for free.'
date: 2021-11-14T22:14:00.001+05:30
draft: false
url: /2021/11/how-to-buy-jio-airtel-vi-vodafone-idea.html
tags: 
- How
- Jio
- technology
- Airtel
- Vi
---

 [![](https://lh3.googleusercontent.com/-fFEN-sL3_-Q/YZE8-lfO-yI/AAAAAAAAHSo/NrfXKTn-6hsT6Vx2xYmgtrgPv5bSai06ACLcBGAsYHQ/s1600/1636908275895587-0.png)](https://lh3.googleusercontent.com/-fFEN-sL3_-Q/YZE8-lfO-yI/AAAAAAAAHSo/NrfXKTn-6hsT6Vx2xYmgtrgPv5bSai06ACLcBGAsYHQ/s1600/1636908275895587-0.png) 

  

In 20th century, we just need little sim card to connect with world either to call, sms or use internet services, we can do all by just recharging it with required packs based on the network provider which could cost you few bucks as in india from 2017 due to jio call and data packs become very cheaper that millions of people started buying Jio sim cards by standing in big lines infront of jio digital stores.

  

Prior to 2017 in india sim card providers like airtel, idea and vodafone used to put high price for recharge packs which are not even value for money so people with poor financial conditions were unable to use call and internet services extensively but when reliance jio network entered in scene all other existing network providers almost went to bankruptcy state so they don't have any choice other then to follow the path of Jio to sustain in market.

  

In india, few years back in order to get sim card of any network company you need to visit thier official local branch or partnered stores physically for verification but due to digitalization & COVID-19 pandemic most network providers started online portal to purchase thier sim cards and even waived delivery charges for mutual benefit.

  

However, alot of people were unaware of this online portals due to that they usually visit stores to get sim card so they miss the comfort and convenience of online shopping, but incase if you are planning to purchase sim card then you are at right place we will now show you how to buy sim cards of Jio, VI, Airtel, from official online portals for free with our detailed step by step instructions below, so let's begin. ain't you exicited?

**• How to buy Jio sim card online •**

 **[![](https://lh3.googleusercontent.com/-kaeoq70h1iU/YZE886d-X7I/AAAAAAAAHSk/2ybl3Y4HF2Yv55Ldtj_2ezUhuppDL1YZwCLcBGAsYHQ/s1600/1636908267953944-1.png)](https://lh3.googleusercontent.com/-kaeoq70h1iU/YZE886d-X7I/AAAAAAAAHSk/2ybl3Y4HF2Yv55Ldtj_2ezUhuppDL1YZwCLcBGAsYHQ/s1600/1636908267953944-1.png)** 

\- Go to [www.jio.com/en-in/jio-home-delivery-book-appointment.html](http://www.jio.com/en-in/jio-home-delivery-book-appointment.html)

  

\- Enter your full name, mobile number and tap on **Generate OTP**

 **[![](https://lh3.googleusercontent.com/-ulm14zMVa8o/YZE87IuOfzI/AAAAAAAAHSg/REmsQYBr8CgXZn1r8AMSXeJRdrhNlWBtwCLcBGAsYHQ/s1600/1636908263953165-2.png)](https://lh3.googleusercontent.com/-ulm14zMVa8o/YZE87IuOfzI/AAAAAAAAHSg/REmsQYBr8CgXZn1r8AMSXeJRdrhNlWBtwCLcBGAsYHQ/s1600/1636908263953165-2.png)** 

\- You will receive a 6 digit OTP to your mobile number, go to sms inbox and find the OTP received from Jio, then enter it here and tap on **Validate**.

  

 [![](https://lh3.googleusercontent.com/-axjOAmycr-E/YZE85xu53eI/AAAAAAAAHSc/fMZbSVTL02oNrgAFEkonAi_ZpgSSrDShgCLcBGAsYHQ/s1600/1636908256905691-3.png)](https://lh3.googleusercontent.com/-axjOAmycr-E/YZE85xu53eI/AAAAAAAAHSc/fMZbSVTL02oNrgAFEkonAi_ZpgSSrDShgCLcBGAsYHQ/s1600/1636908256905691-3.png) 

  

\- Select Prepaid / Postpaid

  

\- Select Port to jio / New Connection

  

\- Enter Locality / Address, PIN code, Flat / house number and tap on submit new Jio SIM request.

  

YAY, you successfully applied for new Jio SIM card connection for free.

  

**• How to buy Airtel sim card online •**

 **[![](https://lh3.googleusercontent.com/-tLPKRLfYfz0/YZE84M6HYgI/AAAAAAAAHSY/k3gWE4PZp8APAPoj4O-FyXdGhQkdmrr9wCLcBGAsYHQ/s1600/1636908250880753-4.png)](https://lh3.googleusercontent.com/-tLPKRLfYfz0/YZE84M6HYgI/AAAAAAAAHSY/k3gWE4PZp8APAPoj4O-FyXdGhQkdmrr9wCLcBGAsYHQ/s1600/1636908250880753-4.png)** 

\- Go to [www.airtel.in/prepaid-4g-sim/](http://www.airtel.in/prepaid-4g-sim/)

  

\- Select Your Pack, Enter Name, Mobile Number and scroll down.

  

 [![](https://lh3.googleusercontent.com/-bLdue9_m2aY/YZE82rVtgvI/AAAAAAAAHSU/6TZZ3PAokUUqDwN-f7LzJaFcOLZe0DIAgCLcBGAsYHQ/s1600/1636908245153453-5.png)](https://lh3.googleusercontent.com/-bLdue9_m2aY/YZE82rVtgvI/AAAAAAAAHSU/6TZZ3PAokUUqDwN-f7LzJaFcOLZe0DIAgCLcBGAsYHQ/s1600/1636908245153453-5.png) 

  

\- Select : Yes if you want to port number else tap on No, I want a new connection.

  

\- Select City, Location, House / Flat no. ( Optional )

  

\- Enter pincode and tap on **SUBMIT**

That's it, You successfully applied for Airtel sim card for free.

  

**• How to buy VI sim card online •**

  

 [![](https://lh3.googleusercontent.com/-Duipy8_JuFs/YZE81AFZZuI/AAAAAAAAHSQ/f5MNC8R0yPIAagIoCtbKS0eehvx1cLUSQCLcBGAsYHQ/s1600/1636908239249794-6.png)](https://lh3.googleusercontent.com/-Duipy8_JuFs/YZE81AFZZuI/AAAAAAAAHSQ/f5MNC8R0yPIAagIoCtbKS0eehvx1cLUSQCLcBGAsYHQ/s1600/1636908239249794-6.png) 

  

  

\- Select postpaid plan or prepaid packs to start then scroll down.

  

 [![](https://lh3.googleusercontent.com/-CczlvTeUuFU/YZE8ziD0uGI/AAAAAAAAHSM/rqfIUHx7VoUWon-TZVWXQk-7RtCdxdNEgCLcBGAsYHQ/s1600/1636908234040382-7.png)](https://lh3.googleusercontent.com/-CczlvTeUuFU/YZE8ziD0uGI/AAAAAAAAHSM/rqfIUHx7VoUWon-TZVWXQk-7RtCdxdNEgCLcBGAsYHQ/s1600/1636908234040382-7.png) 

  

\- In contact details Enter your delivery pincode and mobile number.

  

 [![](https://lh3.googleusercontent.com/-N6dg0Ov8EKQ/YZE8yUmR2BI/AAAAAAAAHSI/5EE3sqy2ABs8DC-FSdi6MzhkwM_l0_KPgCLcBGAsYHQ/s1600/1636908229200094-8.png)](https://lh3.googleusercontent.com/-N6dg0Ov8EKQ/YZE8yUmR2BI/AAAAAAAAHSI/5EE3sqy2ABs8DC-FSdi6MzhkwM_l0_KPgCLcBGAsYHQ/s1600/1636908229200094-8.png) 

  

\- In select a number, select either I want number of my choice or I will use my existing number based on your interest.

  

 [![](https://lh3.googleusercontent.com/-G5xY_B0S7-8/YZE8xO_MwhI/AAAAAAAAHSE/k5JTJ85QNWoC4SJcvHFd8M065ZBpbQA8wCLcBGAsYHQ/s1600/1636908223138132-9.png)](https://lh3.googleusercontent.com/-G5xY_B0S7-8/YZE8xO_MwhI/AAAAAAAAHSE/k5JTJ85QNWoC4SJcvHFd8M065ZBpbQA8wCLcBGAsYHQ/s1600/1636908223138132-9.png) 

  

\- In delivery details, Enter full name, Enter street / building name or tal on or detect my current location, Enter flat / house no then tap on **proceed to checkout **

Done, you successfully applied for VI number online for free.

  

Atlast, This is how you can buy sim cards of Jio, Airtel and VI from official online portals for free, keep in mind it is always safe and best to buy from official sources and try to not buy from unofficial sources, you don't have to pay any delivery charges to get your sim card to home atleast in jio so do also check with other networks.

  

Overall, the process to buy sim cards from official portals of Jio, Airtel and VI are very easy and simple to use due to its clean and user friendly interface which gives you Intuitive user experience but we have to wait and see they may make any major UI changes in future to make it even more better, as of now they are pretty ease to  use for sure.

  

Moreover, it is very important to mention right now Vi - Vodafone / Idea is the only network provider which will provide you an option to choose your own mobile number of your choice for free, and you can even buy premium numbers by paying certain amount based on the number in online portal itself, but kindly choose sim card based on your interest and requirements.

  

Finally, this is how you can buy sim cards of Jio, Airtel, Vi online for free, so do you like it? have you buyed your sim card from these official online portals? If yes kindly mention which network company provided you best online sim buy experience in our comment section below, see ya :)