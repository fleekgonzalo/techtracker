---
title: 'How to upload files to Google Drive using Telegram bot for free.'
date: 2021-11-27T23:37:00.001+05:30
draft: false
url: /2021/11/how-to-upload-files-to-google-drive.html
tags: 
- How
- technology
- Telegram
- Upload
- Google Drive
---

 [![](https://lh3.googleusercontent.com/-WmnHf50N3YU/YaJzwre2_zI/AAAAAAAAHlI/31D0aW9lW-85ZUTZl5kOT5Agphj9K00_QCLcBGAsYHQ/s1600/1638036409908071-0.png)](https://lh3.googleusercontent.com/-WmnHf50N3YU/YaJzwre2_zI/AAAAAAAAHlI/31D0aW9lW-85ZUTZl5kOT5Agphj9K00_QCLcBGAsYHQ/s1600/1638036409908071-0.png) 

  

If you use telegram then most probably you know there are alot of bots available to use developed by talented developers for various purposes, with telegram bots you can fast track your work, like you can remotely upload files to telegram by just sending download link to telegram bots  even upload your telegram files to cloud storage backup platforms like Google's Drive, Mega etc and many more.

  

[How to upload files from Telegram to MEGA cloud storage for free.](https://www.techtracker.in/2021/11/how-to-upload-files-from-telegram-to.html?m=1)

  

If you want to remotely upload files to Google Drive then in Telegram we have few bots available that do work, however each bot have its own features so it's upto you to decide which bot would work best according to your requirements, but here we like to present you the best Google's Drive upload bot named Google Drive X that has all features to amaze you.

  

Google Drive X telegram bot with user name @GdriveXbot developed by Bot X updates can upload your 5 telegram files to Google Drive under free plan with max file size of 50GB, @GdriveXbot can easy upload files to Google Drive with download link including that @GdriveXbot have /fast feature which will download slow links with multiple connections to improve speed and many more useful features which we will show below.

  

Note : it is our responsibility to say you this [@GdriveXbot](http://t.me/GdriveXbot) is not official bot of Telegram which means @GdriveXbot is created by third party developers by using telegram public API which means you can't trust that bot even it states and ensure you security and privacy, so use [@GdriveXbot](http://t.me/GdriveXbot) at your own risk we are not responsible for any personal or financial losses occurred by using that bot, we just demonstrated it for educational and knowledge purposes.

  

**• How to upload files to Google drive using [@GdriveXbot](http://t.me/GdriveXbot) for free • **

 **[![](https://lh3.googleusercontent.com/-1yUK3mzv9mo/YaJzuctMSrI/AAAAAAAAHlE/eo-aaKO4apohwSwOkJ5eslaBU7G-1qaJgCLcBGAsYHQ/s1600/1638036396299016-1.png)](https://lh3.googleusercontent.com/-1yUK3mzv9mo/YaJzuctMSrI/AAAAAAAAHlE/eo-aaKO4apohwSwOkJ5eslaBU7G-1qaJgCLcBGAsYHQ/s1600/1638036396299016-1.png)** 

\- Open @GdriveXbot and tap on **START**

  

 [![](https://lh3.googleusercontent.com/-j4UsUeDV9UM/YaJzq0lMyfI/AAAAAAAAHlA/AXuUCS6Syd8tOP5LUO9vmuayTei-nDTNgCLcBGAsYHQ/s1600/1638036382045790-2.png)](https://lh3.googleusercontent.com/-j4UsUeDV9UM/YaJzq0lMyfI/AAAAAAAAHlA/AXuUCS6Syd8tOP5LUO9vmuayTei-nDTNgCLcBGAsYHQ/s1600/1638036382045790-2.png) 

  

\- Enter and send **/start** command.

  

 [![](https://lh3.googleusercontent.com/-P84bLZQ69xI/YaJzmwSFGtI/AAAAAAAAHk4/ZJnQeSFXkm0vdLo_N5TrShBc-SmL-q2iACLcBGAsYHQ/s1600/1638036360717436-3.png)](https://lh3.googleusercontent.com/-P84bLZQ69xI/YaJzmwSFGtI/AAAAAAAAHk4/ZJnQeSFXkm0vdLo_N5TrShBc-SmL-q2iACLcBGAsYHQ/s1600/1638036360717436-3.png) 

  

\- Enter and send **/login** command, it will ask you to authenticate with your Google account, tap on **Authorization url.**

  

 [![](https://lh3.googleusercontent.com/-I6Ou9Lx04GE/YaJziJJONZI/AAAAAAAAHk0/Tu1fyOZyyzQOMAdPCv4HPY-Qx5NJqJPVQCLcBGAsYHQ/s1600/1638036340128666-4.png)](https://lh3.googleusercontent.com/-I6Ou9Lx04GE/YaJziJJONZI/AAAAAAAAHk0/Tu1fyOZyyzQOMAdPCv4HPY-Qx5NJqJPVQCLcBGAsYHQ/s1600/1638036340128666-4.png) 

  

\- Select your Google account and tap on Continue to give access to @GDriveXbot.

  

 [![](https://lh3.googleusercontent.com/-Adcfl_yMpWI/YaJzc7eOSBI/AAAAAAAAHks/2FZJaxgifnUnTPAKWXQdQx7-tGKMaPU9ACLcBGAsYHQ/s1600/1638036329177391-5.png)](https://lh3.googleusercontent.com/-Adcfl_yMpWI/YaJzc7eOSBI/AAAAAAAAHks/2FZJaxgifnUnTPAKWXQdQx7-tGKMaPU9ACLcBGAsYHQ/s1600/1638036329177391-5.png) 

  

\- Here you will code, just copy it and get back to @GdriveXbot.

  

 [![](https://lh3.googleusercontent.com/-TRFEXx0eNZ0/YaJzaMPGFbI/AAAAAAAAHko/o4otD9I6d-AYLPlk_bcsVFcQyyZLENTUwCLcBGAsYHQ/s1600/1638036289272167-6.png)](https://lh3.googleusercontent.com/-TRFEXx0eNZ0/YaJzaMPGFbI/AAAAAAAAHko/o4otD9I6d-AYLPlk_bcsVFcQyyZLENTUwCLcBGAsYHQ/s1600/1638036289272167-6.png) 

  

\- Just paste and send the code that you copied earlier, you'll will get authentication registered successfully response in return.

  

 [![](https://lh3.googleusercontent.com/-jAOgroc7pMw/YaJzQDyToGI/AAAAAAAAHkc/d9jv6qaMMk0dgGKNT0EHaAW5Ap83Gg-QQCLcBGAsYHQ/s1600/1638036240045241-7.png)](https://lh3.googleusercontent.com/-jAOgroc7pMw/YaJzQDyToGI/AAAAAAAAHkc/d9jv6qaMMk0dgGKNT0EHaAW5Ap83Gg-QQCLcBGAsYHQ/s1600/1638036240045241-7.png) 

  

\- It's time to send your download link, send or forward telegram file to @GdriveXbot.  

  

\- It will download and upload your files to your Google Drive for free.

  

\- Once, @GdriveXbot upload your files to Google drive it will give Rename Delete & Download options, you can use them.

  

 [![](https://lh3.googleusercontent.com/-Et14ssKn1wE/YaJzDw8BSpI/AAAAAAAAHkY/Yrg7TNrMLP8ncpRI1WRVQkG0hO1-fBp9gCLcBGAsYHQ/s1600/1638036233306065-8.png)](https://lh3.googleusercontent.com/-Et14ssKn1wE/YaJzDw8BSpI/AAAAAAAAHkY/Yrg7TNrMLP8ncpRI1WRVQkG0hO1-fBp9gCLcBGAsYHQ/s1600/1638036233306065-8.png) 

  

 [![](https://lh3.googleusercontent.com/-Wx7SRD7DQkY/YaJzCOOplJI/AAAAAAAAHkU/oksWVsLe95Uw6iv0n9NXRB1ukOjVyd9qwCLcBGAsYHQ/s1600/1638036226254772-9.png)](https://lh3.googleusercontent.com/-Wx7SRD7DQkY/YaJzCOOplJI/AAAAAAAAHkU/oksWVsLe95Uw6iv0n9NXRB1ukOjVyd9qwCLcBGAsYHQ/s1600/1638036226254772-9.png) 

  

Yahoo, you successfully uploaded files to Google drive using @GdrjveXbot for free.

  

**• Google Drive X bot all features list •**

 **[![](https://lh3.googleusercontent.com/-FHQpyNesTEI/YaJzAcCzZeI/AAAAAAAAHkM/6QxJayeEg0IYHeq83W8DFk4UL-OVQABCQCLcBGAsYHQ/s1600/1638036183775926-10.png)](https://lh3.googleusercontent.com/-FHQpyNesTEI/YaJzAcCzZeI/AAAAAAAAHkM/6QxJayeEg0IYHeq83W8DFk4UL-OVQABCQCLcBGAsYHQ/s1600/1638036183775926-10.png)** 

\- All options and features of @GdriveXbot.

  

**• @GdriveXbot /Plan prices, features and payment details • **

 **[![](https://lh3.googleusercontent.com/-u6y86WZ5fTc/YaJy106X-mI/AAAAAAAAHkA/PPZlBsUUocUk_j6_8o53cUz0Cve1k1jwgCLcBGAsYHQ/s1600/1638036175704522-11.png)](https://lh3.googleusercontent.com/-u6y86WZ5fTc/YaJy106X-mI/AAAAAAAAHkA/PPZlBsUUocUk_j6_8o53cUz0Cve1k1jwgCLcBGAsYHQ/s1600/1638036175704522-11.png)** 

**\-** Free plan

  

 [![](https://lh3.googleusercontent.com/-hOtICxaIYWY/YaJyzQAM9uI/AAAAAAAAHj4/yYd0_Qm2fQov1GWFlKC8L-T4MeELKFVmACLcBGAsYHQ/s1600/1638036167553496-12.png)](https://lh3.googleusercontent.com/-hOtICxaIYWY/YaJyzQAM9uI/AAAAAAAAHj4/yYd0_Qm2fQov1GWFlKC8L-T4MeELKFVmACLcBGAsYHQ/s1600/1638036167553496-12.png) 

  

\- Basic plan

  

 [![](https://lh3.googleusercontent.com/-DvdCtKQ4IbE/YaJyxudsOlI/AAAAAAAAHjw/J0cBllcIXnMlQucjFn8wN5XdGzgXb4bMQCLcBGAsYHQ/s1600/1638036159513101-13.png)](https://lh3.googleusercontent.com/-DvdCtKQ4IbE/YaJyxudsOlI/AAAAAAAAHjw/J0cBllcIXnMlQucjFn8wN5XdGzgXb4bMQCLcBGAsYHQ/s1600/1638036159513101-13.png) 

  

\- Standard plan.

  

 [![](https://lh3.googleusercontent.com/-NtT0xwI9zmI/YaJyv6o1YzI/AAAAAAAAHjs/0O_64JsRpsM4Zq2WQ1kwV1Hag1C9HfhYQCLcBGAsYHQ/s1600/1638036152863354-14.png)](https://lh3.googleusercontent.com/-NtT0xwI9zmI/YaJyv6o1YzI/AAAAAAAAHjs/0O_64JsRpsM4Zq2WQ1kwV1Hag1C9HfhYQCLcBGAsYHQ/s1600/1638036152863354-14.png) 

  

• Premium plan

  

 [![](https://lh3.googleusercontent.com/-n603HgbEKQY/YaJytiB_R4I/AAAAAAAAHjo/6jFyfNk1Ax4aiw-lH6_WRaqyuJIwniOVQCLcBGAsYHQ/s1600/1638036145577733-15.png)](https://lh3.googleusercontent.com/-n603HgbEKQY/YaJytiB_R4I/AAAAAAAAHjo/6jFyfNk1Ax4aiw-lH6_WRaqyuJIwniOVQCLcBGAsYHQ/s1600/1638036145577733-15.png) 

  

• Payment options

  

These are the available plans on Google Drive X bot, 

  

**• Google Drive X bot key features with UI / UX Overview •**

  

 [![](https://lh3.googleusercontent.com/-ogEtSxcV23E/YaJyr781aYI/AAAAAAAAHjk/YDev7-Uf8wUlOvE5QyS-TWj1xb3a2oDtwCLcBGAsYHQ/s1600/1638036138533307-16.png)](https://lh3.googleusercontent.com/-ogEtSxcV23E/YaJyr781aYI/AAAAAAAAHjk/YDev7-Uf8wUlOvE5QyS-TWj1xb3a2oDtwCLcBGAsYHQ/s1600/1638036138533307-16.png) 

  

 [![](https://lh3.googleusercontent.com/-JNlhaFuFUM8/YaJyqZoxQYI/AAAAAAAAHjg/uTGQu5oWbdIiNgOrZUkVOdDXJencVTEcACLcBGAsYHQ/s1600/1638036131492838-17.png)](https://lh3.googleusercontent.com/-JNlhaFuFUM8/YaJyqZoxQYI/AAAAAAAAHjg/uTGQu5oWbdIiNgOrZUkVOdDXJencVTEcACLcBGAsYHQ/s1600/1638036131492838-17.png) 

  

\- In /myfiles, you can create new folders on authenticated Google Drive.  

  

 [![](https://lh3.googleusercontent.com/-ojcSDDbpHMQ/YaJyog54sgI/AAAAAAAAHjc/nAE7BuU1TGQmeIEs2KMdKwXzZ9fxIiyvwCLcBGAsYHQ/s1600/1638036125151976-18.png)](https://lh3.googleusercontent.com/-ojcSDDbpHMQ/YaJyog54sgI/AAAAAAAAHjc/nAE7BuU1TGQmeIEs2KMdKwXzZ9fxIiyvwCLcBGAsYHQ/s1600/1638036125151976-18.png) 

  

\- In storage, you will get Google Drive storage details.

  

 [![](https://lh3.googleusercontent.com/-JWZDv-rYdEE/YaJym1-Q_2I/AAAAAAAAHjY/noVBwm_zkecFmZSofdLrMYbfvCSqRWfoACLcBGAsYHQ/s1600/1638036120268600-19.png)](https://lh3.googleusercontent.com/-JWZDv-rYdEE/YaJym1-Q_2I/AAAAAAAAHjY/noVBwm_zkecFmZSofdLrMYbfvCSqRWfoACLcBGAsYHQ/s1600/1638036120268600-19.png) 

  

\- In drive, You can use Team drive to upload files over your Google drive.

  

 [![](https://lh3.googleusercontent.com/-P3KdcDiZ0cw/YaJyl-mt8aI/AAAAAAAAHjU/X7CDI8hb4G4bfxmTq06yUAdS9Ky91_oiQCLcBGAsYHQ/s1600/1638036115687595-20.png)](https://lh3.googleusercontent.com/-P3KdcDiZ0cw/YaJyl-mt8aI/AAAAAAAAHjU/X7CDI8hb4G4bfxmTq06yUAdS9Ky91_oiQCLcBGAsYHQ/s1600/1638036115687595-20.png) 

  

\- In fast, you can download slow links with multiple connections to improve speed.

  

 [![](https://lh3.googleusercontent.com/-U0Dx57xlt24/YaJykvooLII/AAAAAAAAHjQ/-iXHvkBDzCMDMb3vdZo2zIdNjrG8MX7FgCLcBGAsYHQ/s1600/1638036111004742-21.png)](https://lh3.googleusercontent.com/-U0Dx57xlt24/YaJykvooLII/AAAAAAAAHjQ/-iXHvkBDzCMDMb3vdZo2zIdNjrG8MX7FgCLcBGAsYHQ/s1600/1638036111004742-21.png) 

  

\- In search, you can search files on your Google drive with file name.

  

 [![](https://lh3.googleusercontent.com/-PO5vBzF2x04/YaJyjVgHLXI/AAAAAAAAHjM/KPIVW9Xqzc8qMSNglmPGLC67Xa7U8ED-wCLcBGAsYHQ/s1600/1638036106420598-22.png)](https://lh3.googleusercontent.com/-PO5vBzF2x04/YaJyjVgHLXI/AAAAAAAAHjM/KPIVW9Xqzc8qMSNglmPGLC67Xa7U8ED-wCLcBGAsYHQ/s1600/1638036106420598-22.png) 

  

\- In /starred you can find starred files of your Google drive.

  

 [![](https://lh3.googleusercontent.com/-L94Lb-acX4s/YaJyiSXjRAI/AAAAAAAAHjI/Pp0llbj0FcQap5FOZ6mvK8CBzkNoZ0sqgCLcBGAsYHQ/s1600/1638036100835630-23.png)](https://lh3.googleusercontent.com/-L94Lb-acX4s/YaJyiSXjRAI/AAAAAAAAHjI/Pp0llbj0FcQap5FOZ6mvK8CBzkNoZ0sqgCLcBGAsYHQ/s1600/1638036100835630-23.png) 

  

\- In /trash, you can delete all trash files on your Google drive permanently.

  

 [![](https://lh3.googleusercontent.com/-wyMYyLdogAA/YaJyhIZR-AI/AAAAAAAAHjE/X1IoXzopSU8uYAGf_Qii4tcx2H_3r0mZQCLcBGAsYHQ/s1600/1638036087133701-24.png)](https://lh3.googleusercontent.com/-wyMYyLdogAA/YaJyhIZR-AI/AAAAAAAAHjE/X1IoXzopSU8uYAGf_Qii4tcx2H_3r0mZQCLcBGAsYHQ/s1600/1638036087133701-24.png) 

  

\- In /settings, you can set timezone and recieve bot updates ON or OFF.

  

Yay, you successfully explored all features of @GdriveXbot on Telegram.

  

Atlast, This are just highlighted key features of @GdriveXbot there may be many hidden features inbuild that provides you external benefits to give you the ultimate usage experience, so if you want a best bot to upload files to Google Drive then @GdriveXbot can be a worthy choice.

  

Overall, @GdriveXbot is simply fabulous bot, it is very easy to use due to its clean and user friendly interface which gives you Intuitive user experience but we have to wait and see will @GdriveXbot get any major UI changes in future to make it even more better, as of now @GdriveXbot can provide assuring feel for sure. 

  

Moreover, it is worth to mention Google Drive X bot is one of the very few bots on Telegram which can remotely upload files to Google Drive, it does offer many plans like basic, standard and premium to give extra features that work for ever user, Yes indeed incase if you're searching for such bot then Google Drive X can become your new favorite.

  

Finally, This is @GdriveXbot, a telegram bot where you can remotely upload your files to Google Drive, so do you like it? Are you an existing user of @GdriveXbot If yes do share your experience and mention why you like it in our comment section below, see ya :