---
title: 'Future Of Electric Vehicles'
date: 2019-12-22T23:07:00.001+05:30
draft: false
url: /2019/12/future-of-electric-vehicles.html
tags: 
- technology
- ElectricVehicles
- Future
- Environment
- Pollution
- Bikes
---

_

  

[![](https://lh3.googleusercontent.com/-90vYMKOoEAc/Xg_90cnf0HI/AAAAAAAAAgU/V6hr5cbwotop-caS-13sq1Uuc3XC2VmGwCLcBGAsYHQ/s1600/IMG_20200104_081605_870.jpg)](https://lh3.googleusercontent.com/-90vYMKOoEAc/Xg_90cnf0HI/AAAAAAAAAgU/V6hr5cbwotop-caS-13sq1Uuc3XC2VmGwCLcBGAsYHQ/s1600/IMG_20200104_081605_870.jpg)

  












_

Hi, Welcome..,

  

If you are the one who likes the environment alot and want to protect from unnecessary things, then the first things that spoil the beauty of Nature and fresh air is pollution from vehicle smoke while there are no major alternatives before other than petrol vehicles with 2stroke 4stroke etc do the manufactures ever taught of pollution that damage public health if we see the history none of them are really interested in that for a biodiversity product,

  

The major pollution percentage are mostly from vehicles around the world releasing this gases in oxygen and polluting air, even the trees are cutdown for furniture's for houses etc and spoiling natures protection for money or fashion has become comman now a days. We however can't complain that much as the natural resources are for living beings in the world, but here the problem occurs using natural resources like water or tress at a limit rather than the people become complete money minded cutting trees as many as they needed other than in limit this way the oxygen levels are decreasing day by day.

  

As we have know, even water got polluted from industrial garbages, while that's a different story.

  

When there is taking you have to give else there will be less, likely the forest are becoming towns, rural areas are becoming techy day by day not even air being pollution even frequencies from radio towers are damaging birds brain.. As this is not scientifically proven yet but there is a lot of hype regarding this are going on.

  

Here, let's get into point tress are cut down more than needed making money out of it and most of the money makers from natural resources are not even in a campaign or even plants implanted at a minimum scale, that total issue the public complaining to the governments, what even governments can even do if there is no individual responsibility, there's a quotation that plant a tree and that tree saves you.

  

The less oxygen level and continuous release of external polluted gases like carbon dioxide, nitrogen that made people to wear masks even recently oxygen cylinders released to reduce pollution level in Delhi.

  

The effect of pollution on earth is more severe than the public actual care of.. People celebrate with crackers in festivals and many more well they enjoy very much releasing pollution to air, I don't know the people ever planted a plant that happily. So government has to do something regarding this and made a order to environment free crackers based on natural resources rather than chemical.

  

You'll know later, why the topic regarding environment pollution, to know the importance of electric vehicles you must know the effect and the consequences that are happening and damages that are happened already by air pollution released through vehicle or any other while vehicles are most continous pollution junction's.

  

To solve or overcome governments are trying hard educating people and saying the importance of trees through advertisements cleansing rivers and changing the vehicles like bs4 engines to other less pollution releaser engines while organising programmes like swatch bharat etc. the major failure of controlling pollution was in India recent years got an improvement, before the government really doesn't concentrated and now it was become a major threat likely the more requirement of electric vehicles are needed in india.

  

If it was a advancement of electric vehicles in other counties as a part automobile development for India it was urgency as the situation improving day by day these years is a good sign however the requirement is compulsory.

  

Now after the above points. You can easily understand electric vehicles are the future the companies are already worked on them and few companies released the vehicles into market while some of the them are not fully not released to every market around the world, and some are country specific.

  

The vehicles like cars, bikes, ecycles are making a good sales and developments and manufactures have a good support from government and people even recieving a lot of postive feedback from around the world.

  

[![](https://lh3.googleusercontent.com/-QBrtJlMvxX0/Xg_90wOo5eI/AAAAAAAAAgc/MHtTC2570LQXZySN7ITG5MiKfJjEKpagACLcBGAsYHQ/s1600/tesla-1738969__480.webp)](https://lh3.googleusercontent.com/-QBrtJlMvxX0/Xg_90wOo5eI/AAAAAAAAAgc/MHtTC2570LQXZySN7ITG5MiKfJjEKpagACLcBGAsYHQ/s1600/tesla-1738969__480.webp)

  

The companies like Tesla already released Tesla cars and added and improving the cars in united states availability as of now.

  

Ecycles and electric bikes are releasing in India from Indian based companies with good offers to make people buy.

  

[![](https://lh3.googleusercontent.com/-Ws84K7cYp6o/Xg_92dRybJI/AAAAAAAAAgk/DIaLPtWv9RMtMqKnlM1BghDuFZHHyutNQCLcBGAsYHQ/s1600/IMG_20200104_081541_180.jpg)](https://lh3.googleusercontent.com/-Ws84K7cYp6o/Xg_92dRybJI/AAAAAAAAAgk/DIaLPtWv9RMtMqKnlM1BghDuFZHHyutNQCLcBGAsYHQ/s1600/IMG_20200104_081541_180.jpg)

  

As electric bikes offer noise and air pollution free it was the primary considerable thing should be for everyone. The more features like AI will improve vehicles alot in upcoming years.

  

AI Features Cars Selfless Cars Are Making Sound Now A Days the Future of Both Will be A Good Combination and Most Prefferable one.

  

As I step towards complete environment free vehicles are primary goal for governments and organizations even from major.

  

In simply even the environment free electric vehicles are seen less but there are the future and using them or purchasing them over other bikes if you have possibility is a good decision being a part to save your earth from pollution is our and your responsibility.

  

Conclusion ; the bad effect of pollution was severe on humankind and planet in such way people need oxygen cylinders to walk on road, controlling them is should be priority else consequences are very high. Electric vehicles are environment free lets try to use them if have possibility over other, and save the earth from pollution even planting a small tree could save a bird life so be environment consciousness respect and love nature.

  

Keep Supporting : TechTracker.In