---
title: 'IND Money - Invest In US Stocks From India [ 0% Commission ]'
date: 2021-08-08T17:56:00.000+05:30
draft: false
url: /2021/08/ind-money-invest-in-us-stocks-from_30.html
tags: 
- US technology
- IND Money
- 0% commission
- Stocks
---

   
[![](https://lh3.googleusercontent.com/--C2XCNzaW88/YREMrh-pQ7I/AAAAAAAAGS0/O6SxU9bfx6AWnIazcaJcn2weyYGjKFSUgCLcBGAsYHQ/w320-h180/1628507301021588-0.png)](https://lh3.googleusercontent.com/--C2XCNzaW88/YREMrh-pQ7I/AAAAAAAAGS0/O6SxU9bfx6AWnIazcaJcn2weyYGjKFSUgCLcBGAsYHQ/s1600/1628507301021588-0.png)  
In India, there are many stock trading apps but you can only invest in india stocks due to the limitation traders who are interested to invest in overseas stocks were not able to do in indian stock trading platforms, so if you are a trader and want to invest in US stocks from india then we need to depend on a stock trading platform which have the facility to invest in US stocks legally.  
  
However, We have very few stock trading platforms available in india that has the  facility for indian traders to invest in US stocks through thier platform so you have to select the best stock exchange platform which will let you invest in US stocks easily with commission fees and packed with essential features else you may face issues later.  
  
In this scenario, we have a workaround we found one of the best stock trading platform named IND Money that have facility for indian traders to invest in US stocks with 0% commission fee which is truly remarkable that can give you splendid US stocks investment experience on the go, so are you interested IND Money? If yes let's know little more info about IND Money to start investments in US stocks from india.  
**• IND Money Official Support •**  
\- [Facebook](https://www.facebook.com/indmoney)

\- [LinkedIn](https://in.linkedin.com/company/indmoney)

\- [YouTube](https://www.youtube.com/channel/UCm7xZ9sbqhuARuDDcckh8Jg)

\- [Twitter](https://twitter.com/INDmoneyApp)

\- [Instagram](https://www.instagram.com/indmoneyapp/)

  
**Email** : [support@indwealth.in](mailto:support@indwealth.in)  
**Website** : [indmoney.com](http://indmoney.com/)  
**\- App Info = **[Google Play](https://play.google.com/store/apps/details?id=in.indwealth)** / **[App Store](https://itunes.apple.com/in/app/indwealth/id1450178837?mt=8)

  

• **How to download IND Money •**

  

It is very easy to download IND Money from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=in.indwealth)** / **[App Store](https://itunes.apple.com/in/app/indwealth/id1450178837?mt=8)

**• How to register on IND Money and do KYC from India •**  
[![](https://lh3.googleusercontent.com/-906FxhRsWsc/YREMpMoemaI/AAAAAAAAGSw/qD96ok0WVOsYGtmFDn_p9SuF2100mhGQACLcBGAsYHQ/s1600/1628507294217605-1.png)](https://lh3.googleusercontent.com/-906FxhRsWsc/YREMpMoemaI/AAAAAAAAGSw/qD96ok0WVOsYGtmFDn_p9SuF2100mhGQACLcBGAsYHQ/s1600/1628507294217605-1.png)**\- **Open **IND Super Money App**  
[![](https://lh3.googleusercontent.com/-UzHCXrIAOpI/YREMnTldS_I/AAAAAAAAGSs/Edmk27ie1ekr8CL8vRdNduWX6vs2503pACLcBGAsYHQ/s1600/1628507284916242-2.png)](https://lh3.googleusercontent.com/-UzHCXrIAOpI/YREMnTldS_I/AAAAAAAAGSs/Edmk27ie1ekr8CL8vRdNduWX6vs2503pACLcBGAsYHQ/s1600/1628507284916242-2.png)**\- **Tap on **Get started**  
  
[![](https://lh3.googleusercontent.com/-RaVyqzMUN3g/YREMlJ10JcI/AAAAAAAAGSo/rBFTvmFvsgQeUrr8IGh6Ae5S7vnNW2pYACLcBGAsYHQ/s1600/1628507277016845-3.png)](https://lh3.googleusercontent.com/-RaVyqzMUN3g/YREMlJ10JcI/AAAAAAAAGSo/rBFTvmFvsgQeUrr8IGh6Ae5S7vnNW2pYACLcBGAsYHQ/s1600/1628507277016845-3.png)  
\- Enter your mobile number & Tap on **Continue**.  
  
[![](https://lh3.googleusercontent.com/-m2xCK9RSjIo/YREMjGqnRWI/AAAAAAAAGSk/lRQhpJDOt-0aEh5AsHPRg9q_9BJ_OF76wCLcBGAsYHQ/s1600/1628507269827732-4.png)](https://lh3.googleusercontent.com/-m2xCK9RSjIo/YREMjGqnRWI/AAAAAAAAGSk/lRQhpJDOt-0aEh5AsHPRg9q_9BJ_OF76wCLcBGAsYHQ/s1600/1628507269827732-4.png)  
\- You will get 6 digit OTP from Ind Money to your mobile number, check your sms inbox and find it then acknowledge OTP and enter it here.  
  
\- OTP will be automatically detected if you enabled required permissions.  
  
[![](https://lh3.googleusercontent.com/-PJBpN9m_ZJ4/YREMhQYnD4I/AAAAAAAAGSg/CMA6EVsfbFAGwjci3XEbiBK76Ot5R_SBQCLcBGAsYHQ/s1600/1628507261489857-5.png)](https://lh3.googleusercontent.com/-PJBpN9m_ZJ4/YREMhQYnD4I/AAAAAAAAGSg/CMA6EVsfbFAGwjci3XEbiBK76Ot5R_SBQCLcBGAsYHQ/s1600/1628507261489857-5.png)  
\- Enter First name, Last name, Email Address then tap on **Submit.**  
[![](https://lh3.googleusercontent.com/-iGznL-BcUI4/YREMfP39KHI/AAAAAAAAGSc/3lLebesoQ7Qg3F9tWx5g7NWi7RizPkplACLcBGAsYHQ/s1600/1628507110352959-6.png)](https://lh3.googleusercontent.com/-iGznL-BcUI4/YREMfP39KHI/AAAAAAAAGSc/3lLebesoQ7Qg3F9tWx5g7NWi7RizPkplACLcBGAsYHQ/s1600/1628507110352959-6.png)**\- **if you are especially here to invest in US stocks to speed up the process **Tap** on Auto track now & Tap on I'll do it later,   
  
[![](https://lh3.googleusercontent.com/-h6NB2HxJFkc/YREL5dOYRgI/AAAAAAAAGSQ/w09U66EI9Hwf8s_GhUqtjfhZfGn_evKWwCLcBGAsYHQ/s1600/1628507087544905-7.png)](https://lh3.googleusercontent.com/-h6NB2HxJFkc/YREL5dOYRgI/AAAAAAAAGSQ/w09U66EI9Hwf8s_GhUqtjfhZfGn_evKWwCLcBGAsYHQ/s1600/1628507087544905-7.png)  
\- Tap on **Auto track now**  
[![](https://lh3.googleusercontent.com/-vAcusbgdriY/YRELzuQNBqI/AAAAAAAAGSI/1-xLDS4MthUjW9_Youv8v3gKcS4rA7PHACLcBGAsYHQ/s1600/1628507068602408-8.png)](https://lh3.googleusercontent.com/-vAcusbgdriY/YRELzuQNBqI/AAAAAAAAGSI/1-xLDS4MthUjW9_Youv8v3gKcS4rA7PHACLcBGAsYHQ/s1600/1628507068602408-8.png)**\- **Tap on** I Agree**  
[![](https://lh3.googleusercontent.com/-EYE2dnypNK8/YRELu1RDhJI/AAAAAAAAGSA/SkCVtbXUtrAO-_9lGFrXPR8syRODGsOEwCLcBGAsYHQ/s1600/1628507039239436-9.png)](https://lh3.googleusercontent.com/-EYE2dnypNK8/YRELu1RDhJI/AAAAAAAAGSA/SkCVtbXUtrAO-_9lGFrXPR8syRODGsOEwCLcBGAsYHQ/s1600/1628507039239436-9.png)**\- **Tap on **I'll do this later**  
[![](https://lh3.googleusercontent.com/-SYj0TFUO8Hk/YRELnkaos3I/AAAAAAAAGR4/T9FhLj4SDwgJ1asrxHJRhnJneQpzqub7QCLcBGAsYHQ/s1600/1628507017545608-10.png)](https://lh3.googleusercontent.com/-SYj0TFUO8Hk/YRELnkaos3I/AAAAAAAAGR4/T9FhLj4SDwgJ1asrxHJRhnJneQpzqub7QCLcBGAsYHQ/s1600/1628507017545608-10.png)**\- **Tap on **Miss Auto Tracking**  
[![](https://lh3.googleusercontent.com/-PRRD51Ksixo/YRELiD-X1UI/AAAAAAAAGRw/5o5wdObt-t8s8iaD1L8Wde-s1BzD2f9fwCLcBGAsYHQ/s1600/1628507006859998-11.png)](https://lh3.googleusercontent.com/-PRRD51Ksixo/YRELiD-X1UI/AAAAAAAAGRw/5o5wdObt-t8s8iaD1L8Wde-s1BzD2f9fwCLcBGAsYHQ/s1600/1628507006859998-11.png)**\- **Tap on** I Agree**  
[![](https://lh3.googleusercontent.com/-2fmOm7N4O4o/YRELfgOS5mI/AAAAAAAAGRo/vlv5hsS46rkLyV0ajCjjey8ZYPVxifW4gCLcBGAsYHQ/s1600/1628506997384578-12.png)](https://lh3.googleusercontent.com/-2fmOm7N4O4o/YRELfgOS5mI/AAAAAAAAGRo/vlv5hsS46rkLyV0ajCjjey8ZYPVxifW4gCLcBGAsYHQ/s1600/1628506997384578-12.png)**\- **Tap on **Enable** & Add your fingerprint for additional security.  
  
[![](https://lh3.googleusercontent.com/-0VRXYNuKsw4/YRELdJhyVtI/AAAAAAAAGRk/M_FaUYIyjcUQkMecLoeAvKMBiLwjC2H9wCLcBGAsYHQ/s1600/1628506982086600-13.png)](https://lh3.googleusercontent.com/-0VRXYNuKsw4/YRELdJhyVtI/AAAAAAAAGRk/M_FaUYIyjcUQkMecLoeAvKMBiLwjC2H9wCLcBGAsYHQ/s1600/1628506982086600-13.png)  
\- Tap on **Member**  
  
[![](https://lh3.googleusercontent.com/-soU6rXaH6bg/YRELZcLSBgI/AAAAAAAAGRc/cy1abILKSHMqkJbgASoubVdZEQFrQyXWgCLcBGAsYHQ/s1600/1628506964866477-14.png)](https://lh3.googleusercontent.com/-soU6rXaH6bg/YRELZcLSBgI/AAAAAAAAGRc/cy1abILKSHMqkJbgASoubVdZEQFrQyXWgCLcBGAsYHQ/s1600/1628506964866477-14.png)  
\- Tap on **Verify Your Profile**  
  
[![](https://lh3.googleusercontent.com/-c8x-IuML1H0/YRELVB_ajKI/AAAAAAAAGRU/I-bdZJJtgPcby-jx6K3fLGDHzAv9eT-BgCLcBGAsYHQ/s1600/1628506947434670-15.png)](https://lh3.googleusercontent.com/-c8x-IuML1H0/YRELVB_ajKI/AAAAAAAAGRU/I-bdZJJtgPcby-jx6K3fLGDHzAv9eT-BgCLcBGAsYHQ/s1600/1628506947434670-15.png)  
\- Enter your **Pan Card Number** then Tap on **Submit**.  
  
[![](https://lh3.googleusercontent.com/-zS3JjuTRHMU/YRELQkGFvSI/AAAAAAAAGRI/iXYVjLEa5UMMEbG89RGMfmY1qTCQZJlKwCLcBGAsYHQ/s1600/1628506939219308-16.png)](https://lh3.googleusercontent.com/-zS3JjuTRHMU/YRELQkGFvSI/AAAAAAAAGRI/iXYVjLEa5UMMEbG89RGMfmY1qTCQZJlKwCLcBGAsYHQ/s1600/1628506939219308-16.png)\- You are already KYC verified, Tap on **Continue.**  
[![](https://lh3.googleusercontent.com/-dvkaHUOoo0Q/YRELOuGAEII/AAAAAAAAGRE/ruWLPINmxMkh5IxZWTn7teRpu7H1nuPYgCLcBGAsYHQ/s1600/1628506929882353-17.png)](https://lh3.googleusercontent.com/-dvkaHUOoo0Q/YRELOuGAEII/AAAAAAAAGRE/ruWLPINmxMkh5IxZWTn7teRpu7H1nuPYgCLcBGAsYHQ/s1600/1628506929882353-17.png)\- Re-enter your Pan Card Number, Select : Gender, Enter Name, DOB as per pan then tap on **Continue**  
  
[![](https://lh3.googleusercontent.com/-Fq80FXLXCko/YRELMGg9iqI/AAAAAAAAGRA/7iCI4QyI4kAcgPemeHXMFxDnHQuR5d4ewCLcBGAsYHQ/s1600/1628506909946341-18.png)](https://lh3.googleusercontent.com/-Fq80FXLXCko/YRELMGg9iqI/AAAAAAAAGRA/7iCI4QyI4kAcgPemeHXMFxDnHQuR5d4ewCLcBGAsYHQ/s1600/1628506909946341-18.png)  
\- Select resident status, Country of Birth, Citizenship Information, then tap on **Continue**  
[![](https://lh3.googleusercontent.com/-pCbdXgzap5s/YRELHbwA9RI/AAAAAAAAGQ8/iP1p9cGhoRESA_VDJUiAKHMG6OGOHC0iACLcBGAsYHQ/s1600/1628506897858477-19.png)](https://lh3.googleusercontent.com/-pCbdXgzap5s/YRELHbwA9RI/AAAAAAAAGQ8/iP1p9cGhoRESA_VDJUiAKHMG6OGOHC0iACLcBGAsYHQ/s1600/1628506897858477-19.png)**\- **Tap on **Draw Signature **then draw your signature and tap on Submit.  
  
[![](https://lh3.googleusercontent.com/-YwoCIOes0SQ/YRELEZpAmCI/AAAAAAAAGQ0/K6ah4LQLs3sMoD18Iw9LSKF5O_LyB1SQgCLcBGAsYHQ/s1600/1628506885847539-20.png)](https://lh3.googleusercontent.com/-YwoCIOes0SQ/YRELEZpAmCI/AAAAAAAAGQ0/K6ah4LQLs3sMoD18Iw9LSKF5O_LyB1SQgCLcBGAsYHQ/s1600/1628506885847539-20.png)  
**\- **It's time to add Bank Account Details, select account type, enter Bank Account Number, re-enter Bank Account Number, then tap on **Submit**  
[![](https://lh3.googleusercontent.com/-_YGWYXd_XZc/YRELBJLKBYI/AAAAAAAAGQs/mIp7A_qmleMpuQ2Ovks4MTF40pWZLWwtACLcBGAsYHQ/s1600/1628506857721181-21.png)](https://lh3.googleusercontent.com/-_YGWYXd_XZc/YRELBJLKBYI/AAAAAAAAGQs/mIp7A_qmleMpuQ2Ovks4MTF40pWZLWwtACLcBGAsYHQ/s1600/1628506857721181-21.png)\- Tap on **NEXT**  
[![](https://lh3.googleusercontent.com/-4fyOhBTCYV0/YREK6DFh98I/AAAAAAAAGQg/1GqecsXs_VstkxsQnearKQIqYwmwkQZYgCLcBGAsYHQ/s1600/1628506845964897-22.png)](https://lh3.googleusercontent.com/-4fyOhBTCYV0/YREK6DFh98I/AAAAAAAAGQg/1GqecsXs_VstkxsQnearKQIqYwmwkQZYgCLcBGAsYHQ/s1600/1628506845964897-22.png)  
**\- Q1/3 : **Select option according to you.  
  
[![](https://lh3.googleusercontent.com/-Pfy5pMIk_lY/YREK3WkPnlI/AAAAAAAAGQY/6Le7Gk3re3ALhWad3TwsM-J3lsRWymoOACLcBGAsYHQ/s1600/1628506829552865-23.png)](https://lh3.googleusercontent.com/-Pfy5pMIk_lY/YREK3WkPnlI/AAAAAAAAGQY/6Le7Gk3re3ALhWad3TwsM-J3lsRWymoOACLcBGAsYHQ/s1600/1628506829552865-23.png)  
\- **Q2/3** : Select option according to you.  
  
[![](https://lh3.googleusercontent.com/-k_Go2DpD908/YREKzN9iNXI/AAAAAAAAGQM/kTXx8E5kRXwy_C-WEN135sylyvcCo5KgQCLcBGAsYHQ/s1600/1628506820564265-24.png)](https://lh3.googleusercontent.com/-k_Go2DpD908/YREKzN9iNXI/AAAAAAAAGQM/kTXx8E5kRXwy_C-WEN135sylyvcCo5KgQCLcBGAsYHQ/s1600/1628506820564265-24.png)  
\- **Q3/3** : Select according to you.  
  
[![](https://lh3.googleusercontent.com/-G_VJIOyFcGQ/YREKw5RkX3I/AAAAAAAAGQI/ILU8-A-HsGgpGlPU9RR5ZSkkQiGRBRetQCLcBGAsYHQ/s1600/1628506815205127-25.png)](https://lh3.googleusercontent.com/-G_VJIOyFcGQ/YREKw5RkX3I/AAAAAAAAGQI/ILU8-A-HsGgpGlPU9RR5ZSkkQiGRBRetQCLcBGAsYHQ/s1600/1628506815205127-25.png)  
\- It will show your risk profile based upon your selections, then tap on **I Agree**  
[![](https://lh3.googleusercontent.com/-9r89C6pO1P0/YREKvlPG9zI/AAAAAAAAGQE/FTCrBK3JCHUf8s09xnYAcQgKlgWbxu7_QCLcBGAsYHQ/s1600/1628506806092988-26.png)](https://lh3.googleusercontent.com/-9r89C6pO1P0/YREKvlPG9zI/AAAAAAAAGQE/FTCrBK3JCHUf8s09xnYAcQgKlgWbxu7_QCLcBGAsYHQ/s1600/1628506806092988-26.png)**\- **select your term preference, then tap on **Continue**  
[![](https://lh3.googleusercontent.com/-pxvLnrtN_DU/YREKtQtg94I/AAAAAAAAGQA/kuCMm6lP8nwAfS0dpZ0ssAE4nPcCx1GlwCLcBGAsYHQ/s1600/1628506799082604-27.png)](https://lh3.googleusercontent.com/-pxvLnrtN_DU/YREKtQtg94I/AAAAAAAAGQA/kuCMm6lP8nwAfS0dpZ0ssAE4nPcCx1GlwCLcBGAsYHQ/s1600/1628506799082604-27.png)**\- **Enter your Email ID & Tap on **Continue**  
[![](https://lh3.googleusercontent.com/-33jXzKkWL-E/YREKrphAtwI/AAAAAAAAGP8/i5QDcJ_wyvcfM9I9uq3_hFWNQWrD0C-KgCLcBGAsYHQ/s1600/1628506792517579-28.png)](https://lh3.googleusercontent.com/-33jXzKkWL-E/YREKrphAtwI/AAAAAAAAGP8/i5QDcJ_wyvcfM9I9uq3_hFWNQWrD0C-KgCLcBGAsYHQ/s1600/1628506792517579-28.png)**\- **6 digit OTP code will sent to your email, go to your email service provider and find the verification email from Ind Money,   
  
\- Once found, Acknowledge OTP and enter it here then tap on Verify Email.  
  
[![](https://lh3.googleusercontent.com/-jNuxaJMZtek/YREKp6V8LII/AAAAAAAAGP0/upPzdOcCEP0oEWfBN49j24Szl07ZTyocACLcBGAsYHQ/s1600/1628506776374009-29.png)](https://lh3.googleusercontent.com/-jNuxaJMZtek/YREKp6V8LII/AAAAAAAAGP0/upPzdOcCEP0oEWfBN49j24Szl07ZTyocACLcBGAsYHQ/s1600/1628506776374009-29.png)  
\- Your Profile is under verification, wait until it's get verified to begin investing in US stocks.  
  
Congratulations, You successfully registered and completed KYC on IND Money.  
  
**• How to invest in US stocks through IND Money from india •**  
  
[![](https://lh3.googleusercontent.com/-iv4pfmf0klM/YREKlwccikI/AAAAAAAAGPs/-jhKboM82Hgf-RaOse_OnKBvJXyCn2c3QCLcBGAsYHQ/s1600/1628506768594677-30.png)](https://lh3.googleusercontent.com/-iv4pfmf0klM/YREKlwccikI/AAAAAAAAGPs/-jhKboM82Hgf-RaOse_OnKBvJXyCn2c3QCLcBGAsYHQ/s1600/1628506768594677-30.png)  
  
\- You got 42rs worth of ind coins for just registering and completing KYC Profile, but to invest in US stocks scroll down.  
  
[![](https://lh3.googleusercontent.com/-7kdFxwOxFAg/YREKj8_iLtI/AAAAAAAAGPo/UtITcVIQALw7dgp69atDN0ZoGPPDsQVPgCLcBGAsYHQ/s1600/1628506761125401-31.png)](https://lh3.googleusercontent.com/-7kdFxwOxFAg/YREKj8_iLtI/AAAAAAAAGPo/UtITcVIQALw7dgp69atDN0ZoGPPDsQVPgCLcBGAsYHQ/s1600/1628506761125401-31.png)  
\- Tap on **US Stocks**  
[![](https://lh3.googleusercontent.com/-T0fEaCRZEeA/YREKhgKGZeI/AAAAAAAAGPg/zFgv4tlYcnINsq8ule8B5JySDfFqYRYhACLcBGAsYHQ/s1600/1628506750461516-32.png)](https://lh3.googleusercontent.com/-T0fEaCRZEeA/YREKhgKGZeI/AAAAAAAAGPg/zFgv4tlYcnINsq8ule8B5JySDfFqYRYhACLcBGAsYHQ/s1600/1628506750461516-32.png)\- Tap on **Create Free Account**  
[![](https://lh3.googleusercontent.com/-Up5Bpm_yeMM/YREKfcOaSrI/AAAAAAAAGPY/Id4EwQ-WzOwDCu-pds5bo-4wGwiv8MOugCLcBGAsYHQ/s1600/1628506735618736-33.png)](https://lh3.googleusercontent.com/-Up5Bpm_yeMM/YREKfcOaSrI/AAAAAAAAGPY/Id4EwQ-WzOwDCu-pds5bo-4wGwiv8MOugCLcBGAsYHQ/s1600/1628506735618736-33.png)\- Upload PAN Card Image & Tap on **Upload**  
[![](https://lh3.googleusercontent.com/-j0GQ-oYBZd8/YREKbgDWQBI/AAAAAAAAGPU/Ob-0_R11nJATOR-8ZdwecS3rwBnKlhk_ACLcBGAsYHQ/s1600/1628506722725676-34.png)](https://lh3.googleusercontent.com/-j0GQ-oYBZd8/YREKbgDWQBI/AAAAAAAAGPU/Ob-0_R11nJATOR-8ZdwecS3rwBnKlhk_ACLcBGAsYHQ/s1600/1628506722725676-34.png)**\- **Select Employment Status, ✓ check box to agree terms and tap on **Continue**  
[![](https://lh3.googleusercontent.com/-DjvEsh3Usxw/YREKYnhGqQI/AAAAAAAAGPQ/AniPH_4pcgQHwYa-4qm8P8KP319jhYNuACLcBGAsYHQ/s1600/1628506715631445-35.png)](https://lh3.googleusercontent.com/-DjvEsh3Usxw/YREKYnhGqQI/AAAAAAAAGPQ/AniPH_4pcgQHwYa-4qm8P8KP319jhYNuACLcBGAsYHQ/s1600/1628506715631445-35.png)**\- **✓ check box to agree to all data and account opening agreements with Drive Wealth and tap on **Continue**  
[![](https://lh3.googleusercontent.com/-m_NTsn3_7gw/YREKWt4ZNtI/AAAAAAAAGPM/U2UaLPNlBEofzOYkxBmgjg2TnksLaR6OACLcBGAsYHQ/s1600/1628506705623645-36.png)](https://lh3.googleusercontent.com/-m_NTsn3_7gw/YREKWt4ZNtI/AAAAAAAAGPM/U2UaLPNlBEofzOYkxBmgjg2TnksLaR6OACLcBGAsYHQ/s1600/1628506705623645-36.png)**\- YAY, **Your US stock account has been created successfully, Tap on Explore US stocks.  
  
[![](https://lh3.googleusercontent.com/-c-jDM3UF-f8/YREKUBEuM7I/AAAAAAAAGPE/YvA5nmITLlQYDVN6UuKw-KfNsAavLF7MQCLcBGAsYHQ/s1600/1628506697030681-37.png)](https://lh3.googleusercontent.com/-c-jDM3UF-f8/YREKUBEuM7I/AAAAAAAAGPE/YvA5nmITLlQYDVN6UuKw-KfNsAavLF7MQCLcBGAsYHQ/s1600/1628506697030681-37.png)  
\- Tap on **Add Funds**  
[![](https://lh3.googleusercontent.com/-25j9t_vv6f0/YREKSI7An6I/AAAAAAAAGO8/pfeOwquyoW0DglAakABqigkq-mqHuuWxQCLcBGAsYHQ/s1600/1628506689676170-38.png)](https://lh3.googleusercontent.com/-25j9t_vv6f0/YREKSI7An6I/AAAAAAAAGO8/pfeOwquyoW0DglAakABqigkq-mqHuuWxQCLcBGAsYHQ/s1600/1628506689676170-38.png)  
\- Tap on **Continue**  
[![](https://lh3.googleusercontent.com/-MKYYkvVH-FU/YREKQGF8l_I/AAAAAAAAGO4/9ZhxdUGawGk7W2UB714QCofu2B-xBwpowCLcBGAsYHQ/s1600/1628506683529163-39.png)](https://lh3.googleusercontent.com/-MKYYkvVH-FU/YREKQGF8l_I/AAAAAAAAGO4/9ZhxdUGawGk7W2UB714QCofu2B-xBwpowCLcBGAsYHQ/s1600/1628506683529163-39.png)**\- **Done, Ticket to transfer money has been generated, you will get a email from IND money with the details of DriveWealth bank details. So go to your Email service provider and find latest email from IND Money.  
  
[![](https://lh3.googleusercontent.com/-BTDH-5H6qpw/YREKOgOefgI/AAAAAAAAGO0/uWAOYEeKyR8qxMcfuERTlhIh5vWedbkZwCLcBGAsYHQ/s1600/1628506675586681-40.png)](https://lh3.googleusercontent.com/-BTDH-5H6qpw/YREKOgOefgI/AAAAAAAAGO0/uWAOYEeKyR8qxMcfuERTlhIh5vWedbkZwCLcBGAsYHQ/s1600/1628506675586681-40.png)  
\- **Note** : All DriveWealth bank account details, so that you can do overseas bank transfer from your bank account.  
  
**Woo hoo**, You successfully opened US stocks account through IND money and generated a ticket to transfer money.  
  
• **How To Send Money to DriveWealth from your bank account •**  
[![](https://lh3.googleusercontent.com/--nQHXOGBORI/YREKMqke1XI/AAAAAAAAGOw/pgSmwPhPQEkYj5iOtkoiiXavl-jG5ermQCLcBGAsYHQ/s1600/1628506668351117-41.png)](https://lh3.googleusercontent.com/--nQHXOGBORI/YREKMqke1XI/AAAAAAAAGOw/pgSmwPhPQEkYj5iOtkoiiXavl-jG5ermQCLcBGAsYHQ/s1600/1628506668351117-41.png)\- Go to your bank account app and find Overseas Transfer option then tap on it.  
  
[![](https://lh3.googleusercontent.com/-_FgAGzv8z0A/YREKK7Gj7oI/AAAAAAAAGOo/3gb_fcXs5gsPWwb7lDOoPyPH9cSBEVpHwCLcBGAsYHQ/s1600/1628506662720263-42.png)](https://lh3.googleusercontent.com/-_FgAGzv8z0A/YREKK7Gj7oI/AAAAAAAAGOo/3gb_fcXs5gsPWwb7lDOoPyPH9cSBEVpHwCLcBGAsYHQ/s1600/1628506662720263-42.png)  
\- Remember : Few banks only support add payee option in app only over online.  
  
\- Tap on **ADD PAYEE NOW**  
[![](https://lh3.googleusercontent.com/-tXS6jwoufbc/YREKJXrZDlI/AAAAAAAAGOk/w5NQ8qN8TBQKWh_GUSqe4rsQutWAWRL5gCLcBGAsYHQ/s1600/1628506657327619-43.png)](https://lh3.googleusercontent.com/-tXS6jwoufbc/YREKJXrZDlI/AAAAAAAAGOk/w5NQ8qN8TBQKWh_GUSqe4rsQutWAWRL5gCLcBGAsYHQ/s1600/1628506657327619-43.png)**\- **Search country : United States then tap on it.  
  
[![](https://lh3.googleusercontent.com/-uybgNLilfGk/YREKIOxW2QI/AAAAAAAAGOg/Pt6RK9ws_Z8ZXMfdtCGgiSEx2-hyaWmfQCLcBGAsYHQ/s1600/1628506650992625-44.png)](https://lh3.googleusercontent.com/-uybgNLilfGk/YREKIOxW2QI/AAAAAAAAGOg/Pt6RK9ws_Z8ZXMfdtCGgiSEx2-hyaWmfQCLcBGAsYHQ/s1600/1628506650992625-44.png)  
\- SELECT CURRENCY : **USD**  
**NOTE** : Some banks provide Zero transfer fee, if your bank provide zero transfer fee then it is a good benefit, if your bank do not provide zero transfer fee then you have to pay upto 5 to 7$ to send money overseas including that GST is applicable.  
  
[![](https://lh3.googleusercontent.com/-iYe3xv6r1_E/YREKGRZgEJI/AAAAAAAAGOY/aZty4CrIQwIpp7xsFYQWeOdXpKJBQlyMgCLcBGAsYHQ/s1600/1628506642819363-45.png)](https://lh3.googleusercontent.com/-iYe3xv6r1_E/YREKGRZgEJI/AAAAAAAAGOY/aZty4CrIQwIpp7xsFYQWeOdXpKJBQlyMgCLcBGAsYHQ/s1600/1628506642819363-45.png)  
\- Tap on Other banks in United States  
\- Enter SWIFT Code : **SVBKUS6S **  
\- Tap on **NEXT**  
[![](https://lh3.googleusercontent.com/-ZQrV0JW3qGU/YREKEePfT7I/AAAAAAAAGOU/EFpgCcecn5MA6XY7R4bUKuRd4ZVQxpD0ACLcBGAsYHQ/s1600/1628506636721139-46.png)](https://lh3.googleusercontent.com/-ZQrV0JW3qGU/YREKEePfT7I/AAAAAAAAGOU/EFpgCcecn5MA6XY7R4bUKuRd4ZVQxpD0ACLcBGAsYHQ/s1600/1628506636721139-46.png)**\- ENTER ACCOUNT DETAILS - **  
  
Enter Account No : **3303325711**  
**\- ENTER PERSONAL DETAILS -**  
Enter Payee's full name : **DriveWealth LLC**  
**\- Enter Payee's Address -**  
97 Main Street, Second Floor, Chatham, NJ  
  
  
[![](https://lh3.googleusercontent.com/-kDl7h1ZIDUk/YREKC6eb6zI/AAAAAAAAGOQ/HlmCMnu0RjogAtPTTkiCWxCNXIaSoOK1gCLcBGAsYHQ/s1600/1628506626771610-47.png)](https://lh3.googleusercontent.com/-kDl7h1ZIDUk/YREKC6eb6zI/AAAAAAAAGOQ/HlmCMnu0RjogAtPTTkiCWxCNXIaSoOK1gCLcBGAsYHQ/s1600/1628506626771610-47.png)  
Note : As per RBI regulations mandate, you can't transfer money to overseas through app, so tap on Go to **INTERNET BANKING** to transfer money through online.  
  
[![](https://lh3.googleusercontent.com/-O5Ddo2b929Q/YREKAVwedHI/AAAAAAAAGOM/JtzVfsp9Vx47fscskFsmKHjed1gWJq4lwCLcBGAsYHQ/s1600/1628506612221863-48.png)](https://lh3.googleusercontent.com/-O5Ddo2b929Q/YREKAVwedHI/AAAAAAAAGOM/JtzVfsp9Vx47fscskFsmKHjed1gWJq4lwCLcBGAsYHQ/s1600/1628506612221863-48.png)  
\- Enter your bank username, password and tap on **LOG IN**  
[![](https://lh3.googleusercontent.com/-LkLMEpgP6qM/YREJ8_cLlBI/AAAAAAAAGOI/PNW5FpdIxsYhjCG0f0csZby48ud7nweGwCLcBGAsYHQ/s1600/1628506604044847-49.png)](https://lh3.googleusercontent.com/-LkLMEpgP6qM/YREJ8_cLlBI/AAAAAAAAGOI/PNW5FpdIxsYhjCG0f0csZby48ud7nweGwCLcBGAsYHQ/s1600/1628506604044847-49.png)[![](https://lh3.googleusercontent.com/-BegXQtQOzmQ/YREJ6m_KAKI/AAAAAAAAGOE/YfrUWkVd_0ANK3lk4TBdVVtGhd1znvh_wCLcBGAsYHQ/s1600/1628506595317927-50.png)](https://lh3.googleusercontent.com/-BegXQtQOzmQ/YREJ6m_KAKI/AAAAAAAAGOE/YfrUWkVd_0ANK3lk4TBdVVtGhd1znvh_wCLcBGAsYHQ/s1600/1628506595317927-50.png)**\- **Tap on **Overseas Transfer**  
[![](https://lh3.googleusercontent.com/-Bbtpwznotpo/YREJ4rp9QwI/AAAAAAAAGOA/s_zGVV-3MqksQ3YUMmKwMy0Bxf1k8b-JgCLcBGAsYHQ/s1600/1628506572613386-51.png)](https://lh3.googleusercontent.com/-Bbtpwznotpo/YREJ4rp9QwI/AAAAAAAAGOA/s_zGVV-3MqksQ3YUMmKwMy0Bxf1k8b-JgCLcBGAsYHQ/s1600/1628506572613386-51.png)\- Select Country : **United States**  
\- Enter Sending Amount In INR  
\- Tap on **Start a transfer**  
  
[![](https://lh3.googleusercontent.com/-AtAbMaAQzB8/YREJy6n9C8I/AAAAAAAAGN4/Fu1vkh0wyJsMxZvn13n61AdbOqMjye7UwCLcBGAsYHQ/s1600/1628506559131249-52.png)](https://lh3.googleusercontent.com/-AtAbMaAQzB8/YREJy6n9C8I/AAAAAAAAGN4/Fu1vkh0wyJsMxZvn13n61AdbOqMjye7UwCLcBGAsYHQ/s1600/1628506559131249-52.png)  
\- 6 digit OTP is sent to your mobile number : go to your sms inbox and find sms from your bank and acknowledge OTP then enter it here.  
  
\- Tap on **SUBMIT**  
[![](https://lh3.googleusercontent.com/-7VruiJgR1K4/YREJvqz-CjI/AAAAAAAAGNw/xEslRKdyeDEaLvS5Bk0TUIlo7ihh8PmMwCLcBGAsYHQ/s1600/1628506543355888-53.png)](https://lh3.googleusercontent.com/-7VruiJgR1K4/YREJvqz-CjI/AAAAAAAAGNw/xEslRKdyeDEaLvS5Bk0TUIlo7ihh8PmMwCLcBGAsYHQ/s1600/1628506543355888-53.png)**\- **Tap on **Select a payee**  
[![](https://lh3.googleusercontent.com/-UlmkvG-G8i4/YREJrscaHRI/AAAAAAAAGNs/XbYapRRP9mEukAPF_nNk4Has_XfaYLCWgCLcBGAsYHQ/s1600/1628506531068212-54.png)](https://lh3.googleusercontent.com/-UlmkvG-G8i4/YREJrscaHRI/AAAAAAAAGNs/XbYapRRP9mEukAPF_nNk4Has_XfaYLCWgCLcBGAsYHQ/s1600/1628506531068212-54.png)**\- **Tap on **DriveWealth LLC** to add this payee which you earlier added through banking app.  
  
[![](https://lh3.googleusercontent.com/-l1bEHPlx2TE/YREJoXYOV1I/AAAAAAAAGNk/kjTTqPMUD2ArnjnN4gxf9wlVnbhbGEDRQCLcBGAsYHQ/s1600/1628506509622733-55.png)](https://lh3.googleusercontent.com/-l1bEHPlx2TE/YREJoXYOV1I/AAAAAAAAGNk/kjTTqPMUD2ArnjnN4gxf9wlVnbhbGEDRQCLcBGAsYHQ/s1600/1628506509622733-55.png)  
\- Once payee added, scroll down.  
  
[![](https://lh3.googleusercontent.com/-9b3CT8POuiA/YREJjMuD3tI/AAAAAAAAGNg/T_Zu6EyHMR0eHfNur4D2vA2PCW8QKHkBgCLcBGAsYHQ/s1600/1628506476495025-56.png)](https://lh3.googleusercontent.com/-9b3CT8POuiA/YREJjMuD3tI/AAAAAAAAGNg/T_Zu6EyHMR0eHfNur4D2vA2PCW8QKHkBgCLcBGAsYHQ/s1600/1628506476495025-56.png)  
\- Select Purpose of Transfer From India & add additional details if you want then tap on **NEXT** and send it.  
  
\- Once, you successfully transfer money from your bank account to DriveWealth bank account, it will take upto 1 to 3 days to reflect in your IND money US Stocks account.  
  
\- You can send as low as 0.75 paisa to DriveWealth bank account and it will be reflected to your US stocks account in IND money but the issue is some banks don't allow low money transfer like they put minimum 10$ threshold and even if your bank account allows sending minimal amount it will put extra burden of GST.  
  
**• How to invest in US stocks through IND money •**  
[![](https://lh3.googleusercontent.com/-HjjbKu0gRL4/YREJa25DhwI/AAAAAAAAGNY/ruQAB_Y2nvsqq5ZeI1eKi3c90UBCoNbsQCLcBGAsYHQ/s1600/1628506442736856-57.png)](https://lh3.googleusercontent.com/-HjjbKu0gRL4/YREJa25DhwI/AAAAAAAAGNY/ruQAB_Y2nvsqq5ZeI1eKi3c90UBCoNbsQCLcBGAsYHQ/s1600/1628506442736856-57.png)**\- **Once, your profile is verified & the money you sent is transferred to DriveWealth then Tap on **US stocks +**  
[![](https://lh3.googleusercontent.com/-5G5ShHUlLcQ/YREJSUki-CI/AAAAAAAAGNM/3cZoNMXCh4Yhi0S2wNcY6Tr22wbepv0LwCLcBGAsYHQ/s1600/1628506409994510-58.png)](https://lh3.googleusercontent.com/-5G5ShHUlLcQ/YREJSUki-CI/AAAAAAAAGNM/3cZoNMXCh4Yhi0S2wNcY6Tr22wbepv0LwCLcBGAsYHQ/s1600/1628506409994510-58.png)**\- **If money is reflected in your IND money US Socks Account, search or choose the desired stock to buy it.  
  
[![](https://lh3.googleusercontent.com/-4gQjhX1dO_g/YREJKG1Wj1I/AAAAAAAAGNI/Py_qZTTrCUIczj_hlXMB196n3lTKr5wIACLcBGAsYHQ/s1600/1628506383518794-59.png)](https://lh3.googleusercontent.com/-4gQjhX1dO_g/YREJKG1Wj1I/AAAAAAAAGNI/Py_qZTTrCUIczj_hlXMB196n3lTKr5wIACLcBGAsYHQ/s1600/1628506383518794-59.png)  
\- Here, we selected Google for demo purposes, You can buy stocks, check stocks charts and additional details.  
  
\- Tap on **BUY**  
  
[![](https://lh3.googleusercontent.com/-jBW7-HDdTis/YREJDqxND0I/AAAAAAAAGNE/kNSANe7Hry4J0-B2Up79hrLOd8fva0KpQCLcBGAsYHQ/s1600/1628506363421192-60.png)](https://lh3.googleusercontent.com/-jBW7-HDdTis/YREJDqxND0I/AAAAAAAAGNE/kNSANe7Hry4J0-B2Up79hrLOd8fva0KpQCLcBGAsYHQ/s1600/1628506363421192-60.png)  
\- You can buy stock in shares, or invest in particular amount then tap on **Place Buy Order** to get stock in your portfolio.  
  
[![](https://lh3.googleusercontent.com/-4ylNXLQCG1M/YREI-uycuHI/AAAAAAAAGM8/Z54P7w1r07ICwnxVJLoy-2zryDSiAnDyQCLcBGAsYHQ/s1600/1628506333999519-61.png)](https://lh3.googleusercontent.com/-4ylNXLQCG1M/YREI-uycuHI/AAAAAAAAGM8/Z54P7w1r07ICwnxVJLoy-2zryDSiAnDyQCLcBGAsYHQ/s1600/1628506333999519-61.png)  
\- Incase, if you want to withdraw money, go back to IND Money home and Tap on **Member**  
  
[![](https://lh3.googleusercontent.com/-Ucecua5YKMM/YREI3GP1qgI/AAAAAAAAGM0/IJLagRK3zGImPqQa1zAwQoeYa--VwbyPACLcBGAsYHQ/s1600/1628506307483671-62.png)](https://lh3.googleusercontent.com/-Ucecua5YKMM/YREI3GP1qgI/AAAAAAAAGM0/IJLagRK3zGImPqQa1zAwQoeYa--VwbyPACLcBGAsYHQ/s1600/1628506307483671-62.png)  
\- **Scroll down**  
[![](https://lh3.googleusercontent.com/-TN7s0Qh9f6s/YREIwpHME3I/AAAAAAAAGMs/R_tZSxlzLQk6Vle-yVH1EyOHLL5ZHiC3QCLcBGAsYHQ/s1600/1628506283760705-63.png)](https://lh3.googleusercontent.com/-TN7s0Qh9f6s/YREIwpHME3I/AAAAAAAAGMs/R_tZSxlzLQk6Vle-yVH1EyOHLL5ZHiC3QCLcBGAsYHQ/s1600/1628506283760705-63.png)\- Tap on **US stocks account**  
  
[![](https://lh3.googleusercontent.com/-7H8jH5KF68I/YREIqmIghhI/AAAAAAAAGMo/AXLHVNV9_LYA11Tppof14hikahZDjy87wCLcBGAsYHQ/s1600/1628506248203428-64.png)](https://lh3.googleusercontent.com/-7H8jH5KF68I/YREIqmIghhI/AAAAAAAAGMo/AXLHVNV9_LYA11Tppof14hikahZDjy87wCLcBGAsYHQ/s1600/1628506248203428-64.png)  
\- Tap on **Withdraw**  
  
[![](https://lh3.googleusercontent.com/-m32n2tdcXhs/YREIh0n9P9I/AAAAAAAAGMk/m0eDd6Iq4KsDOVHa060U5kQ5ogaxuvGuQCLcBGAsYHQ/s1600/1628506202922504-65.png)](https://lh3.googleusercontent.com/-m32n2tdcXhs/YREIh0n9P9I/AAAAAAAAGMk/m0eDd6Iq4KsDOVHa060U5kQ5ogaxuvGuQCLcBGAsYHQ/s1600/1628506202922504-65.png)  
\- Enter Withdrawal Amount then tap on **Proceed to Withdraw**  
That's it, You successfully learned to invest in US stocks & Withdraw Money on IND Money.  
**• IND Money Key Features With UI/UX Overview •**  
**\- **Mutual funds: Invest & Track your mutual fund portfolio performance (Zero Cost)   
  
\- US stocks: Invest in US stock from India  
  
\- India Stock market : Track your Indian stocks across DMAT a/c’s for FREE. Invest at Zero brokerage (coming soon)   
  
\- Book Fixed deposits (FDs) and get better returns.  
  
\- Financial & retirement planning tool    
  
\- Become a premium Gold member : Get personalised investment advisory and financial planning services. Add family member accounts and manage your money across PAN numbers.   
  
\- INDmoney has the state of the art security standards with  
Strict data security policies & encryption  
  
  
Atlast, This are just highlighted key features of IND Money here may be many hidden features inbuild that provides you external benefits to give the ultimate usage experience, IND Money is one of the best and easy stock trading platform to invest in US stocks from India, so if you want to invest in US stocks then US stocks is definitely a worthy choice.  
  
Overall, IND Money is quick and fast stock trading and mutual fund investment platform it is very easy to use due to its simple user interface which gives you clean and good user experience but we have to wait and see will IND Money get any major UI changes in future to make it even more better, as of now IND Money have perfect user interface and user experience that you may like to use for sure. 

  
Moreover, it is worth to mention again IND Money is one of the very few stock trading platform that have facility to invest in US stocks from india, Yes indeed so, if you are searching for a stock trading platform to invest in US stocks then we suggest you to prefer and choose IND Money it is an excellent choice that has potential to become your new favorite.

  

Finally, This is IND Money,  A stock trading platform to invest in US stocks from india with 0% commission fees so, IND Money is SEBI Registered Investment Advisor, so do you like it? If yes? Are you an existing user of IND Money? If you are an existing user of IND Money do say your experience with IND money & mention why you like IND money in our comment section below, see ya :)   
  

  

  

===