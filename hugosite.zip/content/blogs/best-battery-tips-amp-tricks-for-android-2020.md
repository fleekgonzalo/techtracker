---
title: 'Best Battery Tips &amp; Tricks For Android - 2020'
date: 2020-03-27T23:37:00.001+05:30
draft: false
url: /2020/03/best-battery-tips-tricks-for-android.html
tags: 
- Battery
- Lithium
- Tips_Tricks
- Android
- Kernel
---

  

[![](https://lh3.googleusercontent.com/-YtrGiIzYlac/XoIeRVRLvfI/AAAAAAAABTI/NI1Krc-0G243mMDcgFLV2xp_-BTKpNdsACLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-24.jpeg)](https://lh3.googleusercontent.com/-YtrGiIzYlac/XoIeRVRLvfI/AAAAAAAABTI/NI1Krc-0G243mMDcgFLV2xp_-BTKpNdsACLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-24.jpeg)

  

Battery of smartphones getting bigger day by day and even getting chargers that can charge phone in less than 30min so what about old smartphones and you are heavy user then these battery tips definitely useful.

  

\- Battery Saving Tips / Tricks -

  

• Put the apps in hibernating mode so that the apps will not use external resources that do effect your battery getting drained you can easily do that installing greenify app •

  

• if you are using battery in normal mode then enable batter saver or super battery saver in samsung •

  

• if you are using any unauthorized app or game that may be using uneccessary permissions check carefully and remove them uninstall if possible •

  

• don't charge the battery to 100% charge it to 95& or above 80% to get good battery time • 

  

• if you are not using the device turn off the internet and put the device in airplane mode so that you can save battery in needy times • 

  

• Use Dark wallpaper in amoled displays so you can save a little battery • 

  

• You can try LSpeed magisk module or app - root required that can save your battery and extend battery time • 

  

• You can even turn on data saver as it will limit the data recover that can reduce load so that the little battery time can be extented • 

  

\- This is our small tips and tricks for battery that can be useful - 

  

•