---
title: 'FnO Play - No AMC charges & No fees On Non-Profitable Trades In India.'
date: 2021-07-19T23:19:00.001+05:30
draft: false
url: /2021/07/fno-play-no-amc-charges-no-fees-on-non.html
tags: 
- Apps
- Mobile Trading
- FnO Play
- AMC
- Stocks
---

 [![](https://lh3.googleusercontent.com/-qFVabf9W35o/YPW7IchxkcI/AAAAAAAAF54/ud9sKMyrC68GDXBT72ebqhzSgda8nnYXQCLcBGAsYHQ/s1600/1626716916256268-0.png)](https://lh3.googleusercontent.com/-qFVabf9W35o/YPW7IchxkcI/AAAAAAAAF54/ud9sKMyrC68GDXBT72ebqhzSgda8nnYXQCLcBGAsYHQ/s1600/1626716916256268-0.png) 

We have numerous mobile trading apps available out there on internet like upstox, zerodha, but most trading apps charge you monthly fee for using thier platform which is sometimes feels little costly if user don't trade or use thier trading platform so, even if the user want to close his demat trading account user must have to pay AMC fees else his demat account will remain open and amc charges will continue until user pay annual maintenance charges. 

  

However, To fix AMC charges problem We have very few trading platforms available in india like Grow but all trading platforms will charge fees for every order beside the outcome of trade either it's in profit or loss which is fine for experts but for newbies who just entered into stock market trading probably not ok with it.

  

In this scenario, we have a workaround, we found a trading platform which doesn't have annual maintenance charges or brokerage fees for non profitable stocks  named FnO Play that will make your daily trading experience simple & amazing as it is definitely helpful for newbies who just started thier trading journey, So do we got your attention? Do you like to automate tasks on your device? If yes let's know little more info before we start saving AMC charges and brokerage charges on Non-Profitable stocks using FnO Play.  

  

**• FnO Play Official Support •**

**\-** [Facebook](https://www.facebook.com/FnOApp/)

\- [Twitter](https://t.me/FnOApps)

\- [YouTube](https://youtube.com/channel/UCzKOdRu_vzr1TzYSl3qsoRw)

\- [Instagram](https://instagram.com/fnoapp?utm_medium=copy_link)

  

**Website** : [www.fno.com](http://www.fno.com)

**Email** : [team@fno.com](http://team@fno.com)

**\- App Info -** [Google Play](https://play.google.com/store/apps/details?id=com.fnoplay) / [App Store](https://apps.apple.com/in/app/fno-play/id1533626293)

**• How to download FnO Play •**

It is very easy to install FnO Play using these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.fnoplay) / [App Store](https://apps.apple.com/in/app/fno-play/id1533626293)

  

• **How to register and open trading demat account on FnO Play for free •**

 **[![](https://lh3.googleusercontent.com/-GYyXQ_D7f5c/YPW687tH4fI/AAAAAAAAF50/lgyI7qgEEG4YctpXkbUKkI6i24p7a9wGACLcBGAsYHQ/s1600/1626716735321371-1.png)](https://lh3.googleusercontent.com/-GYyXQ_D7f5c/YPW687tH4fI/AAAAAAAAF50/lgyI7qgEEG4YctpXkbUKkI6i24p7a9wGACLcBGAsYHQ/s1600/1626716735321371-1.png)** 

**\- Open FnO Play** Mobile Trading App.

  

 [![](https://lh3.googleusercontent.com/-AbaJsyUgTEc/YPW6JgatvsI/AAAAAAAAF5s/XZaezfdXSZYGM0xK4xYRH4FK8KKecgAigCLcBGAsYHQ/s1600/1626716553822683-2.png)](https://lh3.googleusercontent.com/-AbaJsyUgTEc/YPW6JgatvsI/AAAAAAAAF5s/XZaezfdXSZYGM0xK4xYRH4FK8KKecgAigCLcBGAsYHQ/s1600/1626716553822683-2.png) 

  

\- Tap 6 times on next

  

 [![](https://lh3.googleusercontent.com/-yn5OAKVb1iM/YPW5iJkQhBI/AAAAAAAAF5c/qcny9cPEsmMW_o5Z6CvuzWwauAiwBCtjQCLcBGAsYHQ/s1600/1626716533821711-3.png)](https://lh3.googleusercontent.com/-yn5OAKVb1iM/YPW5iJkQhBI/AAAAAAAAF5c/qcny9cPEsmMW_o5Z6CvuzWwauAiwBCtjQCLcBGAsYHQ/s1600/1626716533821711-3.png) 

  

\- Tap on **GET STARTED**

  

 [![](https://lh3.googleusercontent.com/-Kmt2MsCQXlc/YPW5dZwwRyI/AAAAAAAAF5Y/3UX9GJQ2rX8dnQRAEuPNRBlDr1SLSnnDQCLcBGAsYHQ/s1600/1626716519404721-4.png)](https://lh3.googleusercontent.com/-Kmt2MsCQXlc/YPW5dZwwRyI/AAAAAAAAF5Y/3UX9GJQ2rX8dnQRAEuPNRBlDr1SLSnnDQCLcBGAsYHQ/s1600/1626716519404721-4.png) 

  

\- Tap on **OPEN TRADING ACCOUNT**

 **[![](https://lh3.googleusercontent.com/-MpGSIVbrT-0/YPW5ZACP3vI/AAAAAAAAF5U/Etv7LfTjYfAAFSqWYCveDhWSy8Q-a_kFQCLcBGAsYHQ/s1600/1626716510369118-5.png)](https://lh3.googleusercontent.com/-MpGSIVbrT-0/YPW5ZACP3vI/AAAAAAAAF5U/Etv7LfTjYfAAFSqWYCveDhWSy8Q-a_kFQCLcBGAsYHQ/s1600/1626716510369118-5.png)** 

**\-** Enter Mobile No. Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-ATaR6ytomqU/YPW5XLj7WmI/AAAAAAAAF5Q/TCNqhT9HbuAvGuqItdlxySvgsJMMkUcDACLcBGAsYHQ/s1600/1626716417229417-6.png)](https://lh3.googleusercontent.com/-ATaR6ytomqU/YPW5XLj7WmI/AAAAAAAAF5Q/TCNqhT9HbuAvGuqItdlxySvgsJMMkUcDACLcBGAsYHQ/s1600/1626716417229417-6.png)** 

**\-** Enter the verification code that you received from FnO Play to your mobile number via SMS 

  

 [![](https://lh3.googleusercontent.com/-6MBGYCNxyF0/YPW4_yj8rnI/AAAAAAAAF48/YlOoAJUYjOQW-LHWHFqGtDLns19oqeWBACLcBGAsYHQ/s1600/1626716404247554-7.png)](https://lh3.googleusercontent.com/-6MBGYCNxyF0/YPW4_yj8rnI/AAAAAAAAF48/YlOoAJUYjOQW-LHWHFqGtDLns19oqeWBACLcBGAsYHQ/s1600/1626716404247554-7.png) 

  

\- Create 4 Digit Login PIN & Tap on **CREATE**

 **[![](https://lh3.googleusercontent.com/-asJncyMyDYM/YPW48HBEsjI/AAAAAAAAF40/0Jb7DDlUnGgWGmoskmP8hx5XACNuKs3hACLcBGAsYHQ/s1600/1626716389942032-8.png)](https://lh3.googleusercontent.com/-asJncyMyDYM/YPW48HBEsjI/AAAAAAAAF40/0Jb7DDlUnGgWGmoskmP8hx5XACNuKs3hACLcBGAsYHQ/s1600/1626716389942032-8.png)** 

**\-** Re-Enter PIN & Tap on **CONFIRM**

  

 [![](https://lh3.googleusercontent.com/-ua6nG_ROFAs/YPW45CpRapI/AAAAAAAAF4s/LuMqZP_bshQtTt6Z7AhoCtySvBAVQwXDACLcBGAsYHQ/s1600/1626716383877541-9.png)](https://lh3.googleusercontent.com/-ua6nG_ROFAs/YPW45CpRapI/AAAAAAAAF4s/LuMqZP_bshQtTt6Z7AhoCtySvBAVQwXDACLcBGAsYHQ/s1600/1626716383877541-9.png) 

  

\- Select your DATE OF BIRTH & Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-mGjCw3sQsu4/YPW434qllqI/AAAAAAAAF4o/IY290ixCbMQYkaKgQW2CpRf4AyICCrcJQCLcBGAsYHQ/s1600/1626716373641503-10.png)](https://lh3.googleusercontent.com/-mGjCw3sQsu4/YPW434qllqI/AAAAAAAAF4o/IY290ixCbMQYkaKgQW2CpRf4AyICCrcJQCLcBGAsYHQ/s1600/1626716373641503-10.png)** 

**\-** Enter your FIRST NAME, LAST NAME & Tap on **DONE**

 **[![](https://lh3.googleusercontent.com/-4EySxQqHvyg/YPW40WHBBUI/AAAAAAAAF4k/FCoReyIDRyg80gR7vpWJW_MtSIUCtZZugCLcBGAsYHQ/s1600/1626716361239482-11.png)](https://lh3.googleusercontent.com/-4EySxQqHvyg/YPW40WHBBUI/AAAAAAAAF4k/FCoReyIDRyg80gR7vpWJW_MtSIUCtZZugCLcBGAsYHQ/s1600/1626716361239482-11.png)** 

**\-** Enter your Email & Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-MzkPmHH8mo4/YPW4x4Zob0I/AAAAAAAAF4g/z4YQrjsIdPMwqVZ3-HHu9l_gU8TTXBFMQCLcBGAsYHQ/s1600/1626716353309596-12.png)](https://lh3.googleusercontent.com/-MzkPmHH8mo4/YPW4x4Zob0I/AAAAAAAAF4g/z4YQrjsIdPMwqVZ3-HHu9l_gU8TTXBFMQCLcBGAsYHQ/s1600/1626716353309596-12.png)** 

**\-** Enter your PAN CARD NUMBER & Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-SgVh9k874s8/YPW4v69-lbI/AAAAAAAAF4c/dsRER2Hhzt4EemqpCnptMJTDOvPK0TPqACLcBGAsYHQ/s1600/1626716344642375-13.png)](https://lh3.googleusercontent.com/-SgVh9k874s8/YPW4v69-lbI/AAAAAAAAF4c/dsRER2Hhzt4EemqpCnptMJTDOvPK0TPqACLcBGAsYHQ/s1600/1626716344642375-13.png)** 

**\-** Enter FATHER'S NAME, MOTHER'S NAME & Tap on **NEXT**

  

 [![](https://lh3.googleusercontent.com/-55GTJdthELk/YPW4tptxkBI/AAAAAAAAF4U/Ib0iYmUxpfcF6wkErw7GEWZc7kaUxkW4ACLcBGAsYHQ/s1600/1626716335992321-14.png)](https://lh3.googleusercontent.com/-55GTJdthELk/YPW4tptxkBI/AAAAAAAAF4U/Ib0iYmUxpfcF6wkErw7GEWZc7kaUxkW4ACLcBGAsYHQ/s1600/1626716335992321-14.png) 

  

\- Select all details & Tap on **NEXT** 

  

 [![](https://lh3.googleusercontent.com/-bs91befTiGw/YPW4rqB8BDI/AAAAAAAAF4Q/sKFvepACnag9fYrkZQfKunnsKor3KSgnACLcBGAsYHQ/s1600/1626716310485925-15.png)](https://lh3.googleusercontent.com/-bs91befTiGw/YPW4rqB8BDI/AAAAAAAAF4Q/sKFvepACnag9fYrkZQfKunnsKor3KSgnACLcBGAsYHQ/s1600/1626716310485925-15.png) 

  

\- Enter Permanent Address, PIN CODE & Tap on **NEXT**

  

 [![](https://lh3.googleusercontent.com/-tkAmbMwYAzQ/YPW4k8E7e5I/AAAAAAAAF4I/Plg2KJcHUs40HgDo96FnSi7GWSpWsUqowCLcBGAsYHQ/s1600/1626716293592183-16.png)](https://lh3.googleusercontent.com/-tkAmbMwYAzQ/YPW4k8E7e5I/AAAAAAAAF4I/Plg2KJcHUs40HgDo96FnSi7GWSpWsUqowCLcBGAsYHQ/s1600/1626716293592183-16.png) 

  

  

\- Enter BANK ACCOUNT NUMBER, IFSC CODE & Tap on **DONE**

  

 [![](https://lh3.googleusercontent.com/-_9C6yZgWHIM/YPW4gyoSWqI/AAAAAAAAF4A/BKmUmVwwhOo57KxbQcL0G9lJxCOumOulwCLcBGAsYHQ/s1600/1626716285393214-17.png)](https://lh3.googleusercontent.com/-_9C6yZgWHIM/YPW4gyoSWqI/AAAAAAAAF4A/BKmUmVwwhOo57KxbQcL0G9lJxCOumOulwCLcBGAsYHQ/s1600/1626716285393214-17.png) 

  

\- Tap on **NEXT**, 

  

Note : 10% of profit will be charged as brokerage for Future & Options, Currencies & Commodities segments.

  

 [![](https://lh3.googleusercontent.com/-Zr3EuN6y19E/YPW4errGuxI/AAAAAAAAF38/tAKNw2GY9GQh8d4o5zVzT8qlW4ULKAzJgCLcBGAsYHQ/s1600/1626716265808449-18.png)](https://lh3.googleusercontent.com/-Zr3EuN6y19E/YPW4errGuxI/AAAAAAAAF38/tAKNw2GY9GQh8d4o5zVzT8qlW4ULKAzJgCLcBGAsYHQ/s1600/1626716265808449-18.png) 

  

\- Upload all the required documents and Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-kYQ0D0v1RzI/YPW4aPKvkuI/AAAAAAAAF34/nCK0dIeiRgQBoh0mPb4McDU-f6PmDpmGgCLcBGAsYHQ/s1600/1626716252574747-19.png)](https://lh3.googleusercontent.com/-kYQ0D0v1RzI/YPW4aPKvkuI/AAAAAAAAF34/nCK0dIeiRgQBoh0mPb4McDU-f6PmDpmGgCLcBGAsYHQ/s1600/1626716252574747-19.png)** 

**\-** Upload ADDRESS PROOF & Tap on NEXT

  

 [![](https://lh3.googleusercontent.com/-5EpQzc0Dv20/YPW4Wv6WVdI/AAAAAAAAF30/4gkna9V4XKMCyI_0LBHX-lp-XyIqlrIqQCLcBGAsYHQ/s1600/1626716238758079-20.png)](https://lh3.googleusercontent.com/-5EpQzc0Dv20/YPW4Wv6WVdI/AAAAAAAAF30/4gkna9V4XKMCyI_0LBHX-lp-XyIqlrIqQCLcBGAsYHQ/s1600/1626716238758079-20.png) 

  

\- Once, all documents uploaded, Tap on **NEXT.**

 **[![](https://lh3.googleusercontent.com/-Z6q8IUjz8B8/YPW4Tfns59I/AAAAAAAAF3w/6euh3e25T98vWKu4Oaskhb6gZniEb3ImQCLcBGAsYHQ/s1600/1626716069470777-21.png)](https://lh3.googleusercontent.com/-Z6q8IUjz8B8/YPW4Tfns59I/AAAAAAAAF3w/6euh3e25T98vWKu4Oaskhb6gZniEb3ImQCLcBGAsYHQ/s1600/1626716069470777-21.png)** 

**\-** Tap on **REVIEW NOW** to E-SIGN.

  

 [![](https://lh3.googleusercontent.com/-8AT7Nijzz3U/YPW3o6g1b6I/AAAAAAAAF3k/JdsW_VHxYQUZ9fs2TD7BuZVDRJmkv9UTACLcBGAsYHQ/s1600/1626716019293078-22.png)](https://lh3.googleusercontent.com/-8AT7Nijzz3U/YPW3o6g1b6I/AAAAAAAAF3k/JdsW_VHxYQUZ9fs2TD7BuZVDRJmkv9UTACLcBGAsYHQ/s1600/1626716019293078-22.png) 

  

  

\- Tap on **Proceed**

 **[![](https://lh3.googleusercontent.com/-CfKPUHqXenU/YPW3cbQup6I/AAAAAAAAF3U/D6E168c1Nwk0a8yG-mDg8xq-Obk3ugJMQCLcBGAsYHQ/s1600/1626715999242349-23.png)](https://lh3.googleusercontent.com/-CfKPUHqXenU/YPW3cbQup6I/AAAAAAAAF3U/D6E168c1Nwk0a8yG-mDg8xq-Obk3ugJMQCLcBGAsYHQ/s1600/1626715999242349-23.png)** 

  

\- Enter OTP you received to your mobile number from FnO Play & Tap on **Procced**.

  

 [![](https://lh3.googleusercontent.com/-lq4EXORngZY/YPW3XbCbk4I/AAAAAAAAF3Q/mfJj6vsjs6sv14wB2xjFjgn_ha0b1iPWACLcBGAsYHQ/s1600/1626715989178978-24.png)](https://lh3.googleusercontent.com/-lq4EXORngZY/YPW3XbCbk4I/AAAAAAAAF3Q/mfJj6vsjs6sv14wB2xjFjgn_ha0b1iPWACLcBGAsYHQ/s1600/1626715989178978-24.png) 

  

  

\- It's time for E-SIGN, Do it & Tap on **Procced**.

  

 [![](https://lh3.googleusercontent.com/-W_iHXs6i0AQ/YPW3U81hmBI/AAAAAAAAF3M/AEF0p8SLpdAyxWuD9Pyaq9eghOylyHP0ACLcBGAsYHQ/s1600/1626715971577441-25.png)](https://lh3.googleusercontent.com/-W_iHXs6i0AQ/YPW3U81hmBI/AAAAAAAAF3M/AEF0p8SLpdAyxWuD9Pyaq9eghOylyHP0ACLcBGAsYHQ/s1600/1626715971577441-25.png) 

  

\- Check the box & **Tap on Sign Document**

 **[![](https://lh3.googleusercontent.com/-Jijg5SGuNFw/YPW3QYZIRWI/AAAAAAAAF3I/PKwe-4L8qsk8mqDbj7INDqEeZC9JeY_HQCLcBGAsYHQ/s1600/1626715962272004-26.png)](https://lh3.googleusercontent.com/-Jijg5SGuNFw/YPW3QYZIRWI/AAAAAAAAF3I/PKwe-4L8qsk8mqDbj7INDqEeZC9JeY_HQCLcBGAsYHQ/s1600/1626715962272004-26.png)** 

**\-** Tap on **OK**

  

 [![](https://lh3.googleusercontent.com/-qNe4BbKMwOo/YPW3OSKKwtI/AAAAAAAAF3E/Vb3UkmwmPCQI8ke8m2di-cjN3KM26UZfwCLcBGAsYHQ/s1600/1626715953130686-27.png)](https://lh3.googleusercontent.com/-qNe4BbKMwOo/YPW3OSKKwtI/AAAAAAAAF3E/Vb3UkmwmPCQI8ke8m2di-cjN3KM26UZfwCLcBGAsYHQ/s1600/1626715953130686-27.png) 

  

**Congratulations**, Your trading account will be activated in 2 bussines days.

  

 [![](https://lh3.googleusercontent.com/-qUTEisL51-o/YPW3L4vNKBI/AAAAAAAAF3A/eHxhWou6Wb4XUT482zSPCspTgfz2XaKkwCLcBGAsYHQ/s1600/1626715738146457-28.png)](https://lh3.googleusercontent.com/-qUTEisL51-o/YPW3L4vNKBI/AAAAAAAAF3A/eHxhWou6Wb4XUT482zSPCspTgfz2XaKkwCLcBGAsYHQ/s1600/1626715738146457-28.png) 

  

\- Once, activated you can trade on stocks, currencies and commodities easily, if you do first trade you will get 100rs but kindly use our Refferal link to get it including that you can get 200rs for every Refferal.

  

Atlast, This are just highlighted key features of FnO Play there may be many hidden features inbuild that provides you external benefits to give the ultimate usage experience, FnO Play is one of the  best and simple trading platform available on Android & iOS So if you want easy to use mobile trading platform then FnO is  is definitely worthy choice.  

  

Overall, FnO Play is quick and fast trading platform it is very easy to use due to its simple user interface which gives you clean user experience but the only issue is you can only use it horizontally which is a drawback as user may feel uncomfortable at times but let's wait and see may FnO Play get any major UI changes in future to make it even more better, as of now FnO Play have optimised user interface and user experience that you may like to use for sure.   

  

Moreover, it is worth to mention FnO Play Research is one of the very few trading platform that do not charge brokerage fees on Non-Profit trades, so it has more advantage to gain users over other which is surely a major prospect but the problem is they charge 10% profit on trade so only continue if you are fine with it, Yes, Indeed so, if you are searching for such trading platform then we suggest you to choose FnO Play it is an excellent choice that has potential to become your new favorite.  

  

Finally**, **This is FnO Play, one of the best and simple trading app that doesn't have AMC charges and no brokerage fees on trades in loss, do you like it? If yes? Are you an existing user of FnO Play? If you are an existing user of FnO Play do say your experience with FnO Play & mention which features you like the most in it in our comment section below, see ya :)