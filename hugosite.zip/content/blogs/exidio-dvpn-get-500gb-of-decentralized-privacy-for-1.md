---
title: 'Exidio dVPN - Get 500GB of decentralized privacy for $1.'
date: 2022-03-05T12:00:00.001+05:30
draft: false
url: /2022/03/exidio-dvpn-get-500gb-of-decentralized.html
tags: 
- Apps
- Exidio dVPN
- Privacy
- $1
- decentralized VPN
---

 [![](https://lh3.googleusercontent.com/-mbI9xLRGmv0/YiQ5NBRe6qI/AAAAAAAAJdY/uvK6gbXZMYMgUhghjEEQ5k9Y62NUevAYwCNcBGAsYHQ/s1600/1646541104847005-0.png)](https://lh3.googleusercontent.com/-mbI9xLRGmv0/YiQ5NBRe6qI/AAAAAAAAJdY/uvK6gbXZMYMgUhghjEEQ5k9Y62NUevAYwCNcBGAsYHQ/s1600/1646541104847005-0.png) 

  

  

  

VPN aka Virtual private network is a peer to peer technology used by people around the world to protect privacy and security of browsing data online on internet, VPN's are generally provided by companies inform of apps and softwares which people have to choose and connect to tunnel user traffic through servers provided by VPN.

  

From ages, people believed that VPN's provide privacy and transparency as they cover as layer to protect users from cyber attacks and from being tracked and spyed  by ISP's, but people eventually learned that all VPN providers use centralised servers from different locations around the world to offer services, while some companies completely own those servers and other take them for lease.

  

Centralised servers provided by VPN platforms that people connect are not at all secure and provide privacy as they're owned by single company, which means VPN providers can check and track your online data through servers when they insist or required by law enforcement agencies including that as VPN's use centralised servers they are primarily targeted by hackers to easy exploit and steal personal data of users like you.

  

So, people who want better security and privacy of thier online presense switched to proxies especially Tor - the onion router which is created by american military but as Tor use three types of relays to encrypt traffic which reduces your internet speed including that when you traffic leaves the onion network it will be in exit node which law enforcements can abuse and monitor but locating the souce of traffic is difficult to trace and determine.

  

That's why, Tor is mainly used by normal people who want best privacy and security and incase of hackers and criminals they connect to Tor to do illegal activities and to access darknet and for anonymity and safety to escape from law enforcements, which is why people who don't like to use and usually stay away from Tor.

  

However, if you don't like to use VPN and want a better alternative to Tor then dVPN aka decentralised VPN is right choice, not everyone aware of dVPN which is stil new to world but eventually dVPN will be used widely in future, dVPN is upgrade of VPN which instead of using centralised servers provided by companies use de-centralised servers aka nodes provided by individuals around the world to encrypt online data of users data through blockchain technology and web3.0 infrastructure.

  

dVPN is like VPN over Tor so you will not only get security and privacy but also best internet speed at same time, we right now has only few dVPN platforms out there on internet out of them Sentinel dVPN build by Exidio provide truly de-centralised and  best experience but it's not free.

  

You heard that right, most dVPN platforms don't provide free services as they don't integrate advertisements like VPN's do including that dVPN's use nodes aka de-centralised servers hosted by individuals people like you so they are providing thier internet bandwidth to encrypt your online presence which is why dVPN's aren't free.

  

Sentinel lite, a dVPN app build by Exidio used to provide dVPN servers fo free from past few years but day before yesterday it removed all nodes except remaining two of them which are not working and when rised complaints on Sentinel support on Telegram, the free node provider said that he won't use Sentinel lite, so kindly switch to main platform " Exidio dVPN which is open source and the main contributer to Sentinel dVPN client.

  

Exidio dVPN is paid app by Exidio and Solar Labs, but don't worry dVPN's are super cheap like you can get 500GB of private and secure bandwidth for just 1$  atleast on Exidio dVPN, but you have to buy Exidio dVPN nodes using dVPN tokens instead through fiat currency which is very expensive and not worthy and to get dVPN tokens you have 5 apps, so do you like it? are you interested in Exidio dVPN? If yes let's know little more info before we ramp on to explore more to get started..

  

Note : remember, before we continue further the method which we are going to provide below to add Sentinel dVPN points on Exidio dVPN is best and easy one, but it is little complicated and lengthty to, it's not for lazy peeps and don't forget you have to use this method at your own risk we aren't responsible for any losses, kindly follow each and every step correctly else your funds will be lost, let's begin!

  

**• Exidio dVPN official support •**

\- [Telegram](https://t.me/sentinel_co)

  

**Email :** [support@exidio.co](mailto:support@exidio.co)

**Website** : [Exidio.co](http://Exidio.co)

  

 [![](https://lh3.googleusercontent.com/-CdpweKsE9OU/YiRXZWeFpUI/AAAAAAAAJgw/DfzqbxXMjrQPx2a_cJ_ZIdIvhe4fKrp_QCNcBGAsYHQ/s1600/1646548835358587-0.png)](https://lh3.googleusercontent.com/-CdpweKsE9OU/YiRXZWeFpUI/AAAAAAAAJgw/DfzqbxXMjrQPx2a_cJ_ZIdIvhe4fKrp_QCNcBGAsYHQ/s1600/1646548835358587-0.png) 

  

**• How to download Exidio dVPN •**

It is very easy to download Exidio dVPN from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=co.exidio.dvpn)

  

 [![](https://lh3.googleusercontent.com/-CPa_hhXDFSU/YiRXYvqlMHI/AAAAAAAAJgs/THN7yhjF4hILJqfeZTaYtOYL88oNdAbMACNcBGAsYHQ/s1600/1646548831548236-1.png)](https://lh3.googleusercontent.com/-CPa_hhXDFSU/YiRXYvqlMHI/AAAAAAAAJgs/THN7yhjF4hILJqfeZTaYtOYL88oNdAbMACNcBGAsYHQ/s1600/1646548831548236-1.png) 

  

**• How to download Crypto.com •**

It is very easy to download Crypto.com from these platforms for free.

  

\- [Google Play](https://crypto.onelink.me/veNW) / [App Store](https://play.google.com/store/apps/details?id=com.crypto.exchange)[](https://play.google.com/store/apps/details?id=com.crypto.exchange)

  

 [![](https://lh3.googleusercontent.com/-5et5QWWRaXs/YiRXXqirguI/AAAAAAAAJgo/dPmYWkWsfv84omd14YZURot5E4XOaa2owCNcBGAsYHQ/s1600/1646548828322463-2.png)](https://lh3.googleusercontent.com/-5et5QWWRaXs/YiRXXqirguI/AAAAAAAAJgo/dPmYWkWsfv84omd14YZURot5E4XOaa2owCNcBGAsYHQ/s1600/1646548828322463-2.png) 

  

**• How to download Kepler wallet •**

It is very easy to download Kepler wallet from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.chainapsis.keplr) / [App Store](https://apps.apple.com/us/app/keplr-wallet/id1567851089)

  

 [![](https://lh3.googleusercontent.com/-XZ-8ebg-ZIY/YiRXWwcRPuI/AAAAAAAAJgk/f2x39V92H3QZrc8Q4FOs_vHoNEKiPdZawCNcBGAsYHQ/s1600/1646548824841007-3.png)](https://lh3.googleusercontent.com/-XZ-8ebg-ZIY/YiRXWwcRPuI/AAAAAAAAJgk/f2x39V92H3QZrc8Q4FOs_vHoNEKiPdZawCNcBGAsYHQ/s1600/1646548824841007-3.png) 

  

**• How to download Cosmostation •**

It is very easy to download Cosmostation from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=wannabit.io.cosmostaion)

**• How to get 500GB of decentralised privacy on Exidio dVPN for 1$ with key features and UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-0K-UjE7hXtU/YiRXV5QjSEI/AAAAAAAAJgg/q3vycduYWXA2JOA7ZM_aOprmzIeRHd4jwCNcBGAsYHQ/s1600/1646548820954422-4.png)](https://lh3.googleusercontent.com/-0K-UjE7hXtU/YiRXV5QjSEI/AAAAAAAAJgg/q3vycduYWXA2JOA7ZM_aOprmzIeRHd4jwCNcBGAsYHQ/s1600/1646548820954422-4.png)** 

\- Open Kepler then tap on **Create a new wallet**

 **[![](https://lh3.googleusercontent.com/-_5xaZjaX18g/YiRXVHCax1I/AAAAAAAAJgY/XURBcyRKUAIFt-6yvQvWnoLF_qw-jr9nQCNcBGAsYHQ/s1600/1646548817464529-5.png)](https://lh3.googleusercontent.com/-_5xaZjaX18g/YiRXVHCax1I/AAAAAAAAJgY/XURBcyRKUAIFt-6yvQvWnoLF_qw-jr9nQCNcBGAsYHQ/s1600/1646548817464529-5.png)** 

\- Don't and never sign in with Google.

  

\- Tap on **Create new mnemonic** and copy and backup phrases somewhere safe and secure as need them in future and also set wallet nickname and password.

  

 [![](https://lh3.googleusercontent.com/-DJFGRfsPBLA/YiRXUDumc_I/AAAAAAAAJgU/tRxp0Bd96aAMtFdeuwvOX-b_jcqILHPogCNcBGAsYHQ/s1600/1646548813368547-6.png)](https://lh3.googleusercontent.com/-DJFGRfsPBLA/YiRXUDumc_I/AAAAAAAAJgU/tRxp0Bd96aAMtFdeuwvOX-b_jcqILHPogCNcBGAsYHQ/s1600/1646548813368547-6.png) 

  

\- Enable or disable Biometric, then tap on **Done** and Instantly you'll be Kepler wallet.

  

 [![](https://lh3.googleusercontent.com/-eWE-SLcc5rE/YiRXTH1S4II/AAAAAAAAJgM/6shLnnsPEUgeqWn5uuUEmnrlS_Irly_OACNcBGAsYHQ/s1600/1646548808599453-7.png)](https://lh3.googleusercontent.com/-eWE-SLcc5rE/YiRXTH1S4II/AAAAAAAAJgM/6shLnnsPEUgeqWn5uuUEmnrlS_Irly_OACNcBGAsYHQ/s1600/1646548808599453-7.png) 

  

\- Now open crypto.com app and tap on **Invited? Add Refferal code.**  

 **[![](https://lh3.googleusercontent.com/-2bOpqyoTt6g/YiRXRw8XrOI/AAAAAAAAJgI/PW_W4iM9Xn8il64_Tdf6cpKVcLfZFttygCNcBGAsYHQ/s1600/1646548804716702-8.png)](https://lh3.googleusercontent.com/-2bOpqyoTt6g/YiRXRw8XrOI/AAAAAAAAJgI/PW_W4iM9Xn8il64_Tdf6cpKVcLfZFttygCNcBGAsYHQ/s1600/1646548804716702-8.png)** 

\- Once, refferal code is added then tap on **Create New Account.**

 [![](https://lh3.googleusercontent.com/-2Mi4d6tyRIw/YiRXQ7eXAYI/AAAAAAAAJgA/G071ZaHtYVcMOJoFoh5UqKOUhA-ta1qlACNcBGAsYHQ/s1600/1646548800894125-9.png)](https://lh3.googleusercontent.com/-2Mi4d6tyRIw/YiRXQ7eXAYI/AAAAAAAAJgA/G071ZaHtYVcMOJoFoh5UqKOUhA-ta1qlACNcBGAsYHQ/s1600/1646548800894125-9.png) 

  

\- Enter this Refferal code : ×× and enter Your Email Address then tap on **Create New Account.**

 **[![](https://lh3.googleusercontent.com/-vp5iR0fnymI/YiRXP8MktwI/AAAAAAAAJf8/hmQK7gPxtxc8Z6i2kef2Xf497pi9qmVqwCNcBGAsYHQ/s1600/1646548797313067-10.png)](https://lh3.googleusercontent.com/-vp5iR0fnymI/YiRXP8MktwI/AAAAAAAAJf8/hmQK7gPxtxc8Z6i2kef2Xf497pi9qmVqwCNcBGAsYHQ/s1600/1646548797313067-10.png)** 

\- Tap on Open Mail to check your email for a confirmation link from Crypto.com.

  

 [![](https://lh3.googleusercontent.com/-mLBjyJd91zo/YiRXPBjC2AI/AAAAAAAAJf0/jaQyQEIiu5QbcDPudvlMkLugis2jbhE6QCNcBGAsYHQ/s1600/1646548793171274-11.png)](https://lh3.googleusercontent.com/-mLBjyJd91zo/YiRXPBjC2AI/AAAAAAAAJf0/jaQyQEIiu5QbcDPudvlMkLugis2jbhE6QCNcBGAsYHQ/s1600/1646548793171274-11.png) 

  

\- Find this mail, then tap on **LOG IN** instantly you will be redirected to app.

  

\- Once you're on app, crypto.com like any other crypto exchange, you have to submit documents and other details required.

  

\- When you complete setup and verified on crypto.com, just buy 21$ of CRO tokens as minimum withdraw is 20$ to be safe.

  

  

 [![](https://lh3.googleusercontent.com/-z-o2JzkQd-k/YiRXOIfceNI/AAAAAAAAJfw/XTV63vpoYEcHnmIbLr9ez4YUR51gpVNVQCNcBGAsYHQ/s1600/1646548768212504-12.png)](https://lh3.googleusercontent.com/-z-o2JzkQd-k/YiRXOIfceNI/AAAAAAAAJfw/XTV63vpoYEcHnmIbLr9ez4YUR51gpVNVQCNcBGAsYHQ/s1600/1646548768212504-12.png) 

  

  

\- We are going to use CRO tokens to buy sentinel dVPN as CRO transaction fee is very low and fast, so are you ready?

  

 [![](https://lh3.googleusercontent.com/-lgYq-8_ftCE/YiRXH7scJKI/AAAAAAAAJfs/cEdiboOzWxg7StDjLnPfXB-mYMxMwDj1ACNcBGAsYHQ/s1600/1646548764205996-13.png)](https://lh3.googleusercontent.com/-lgYq-8_ftCE/YiRXH7scJKI/AAAAAAAAJfs/cEdiboOzWxg7StDjLnPfXB-mYMxMwDj1ACNcBGAsYHQ/s1600/1646548764205996-13.png) 

  

  

\- Now, open Kepler wallet then tap on **\>> Cosmos Hub**

 **[![](https://lh3.googleusercontent.com/-equsr4ZgFI8/YiRXGvjpbjI/AAAAAAAAJfk/H_LwVW8x_ScBX931OYpJgYdjESl7fV5kACNcBGAsYHQ/s1600/1646548760005027-14.png)](https://lh3.googleusercontent.com/-equsr4ZgFI8/YiRXGvjpbjI/AAAAAAAAJfk/H_LwVW8x_ScBX931OYpJgYdjESl7fV5kACNcBGAsYHQ/s1600/1646548760005027-14.png)** 

\- Tap on **Osmosis**

 **[![](https://lh3.googleusercontent.com/-KtDoKiZ2CZY/YiRXFjN0IZI/AAAAAAAAJfg/qEM7bLBffbIx7klpVJaRZRVd1Pe5ep8lgCNcBGAsYHQ/s1600/1646548755615690-15.png)](https://lh3.googleusercontent.com/-KtDoKiZ2CZY/YiRXFjN0IZI/AAAAAAAAJfg/qEM7bLBffbIx7klpVJaRZRVd1Pe5ep8lgCNcBGAsYHQ/s1600/1646548755615690-15.png)** 

  

\- Tap on your wallet name to copy your osmosis address then simply go to your crypto.com app and withdraw CRX tokens to your osmosis address.

  

 [![](https://lh3.googleusercontent.com/-xCD_5qst2hY/YiRXEsF3gSI/AAAAAAAAJfc/oz_0gAhlMP44gPu_9IbLoQQbeVh01Da1ACNcBGAsYHQ/s1600/1646548751481687-16.png)](https://lh3.googleusercontent.com/-xCD_5qst2hY/YiRXEsF3gSI/AAAAAAAAJfc/oz_0gAhlMP44gPu_9IbLoQQbeVh01Da1ACNcBGAsYHQ/s1600/1646548751481687-16.png) 

  

  

\- Open Kepler again then tap on 🌎

  

 [![](https://lh3.googleusercontent.com/-VNgFisy4l-8/YiRXDT5iJaI/AAAAAAAAJfY/ge2dhURXkrwrB93oS8LJS0J0VZIX5p-HgCNcBGAsYHQ/s1600/1646548747385813-17.png)](https://lh3.googleusercontent.com/-VNgFisy4l-8/YiRXDT5iJaI/AAAAAAAAJfY/ge2dhURXkrwrB93oS8LJS0J0VZIX5p-HgCNcBGAsYHQ/s1600/1646548747385813-17.png) 

  

  

\- Tap on **Osmosis --->**

 **[![](https://lh3.googleusercontent.com/-W4nDA0SEqGY/YiRXCV0PKLI/AAAAAAAAJfU/RciAfITCBq4v_YxdtuwSMGN5-NZCYZ1rQCNcBGAsYHQ/s1600/1646548743064838-18.png)](https://lh3.googleusercontent.com/-W4nDA0SEqGY/YiRXCV0PKLI/AAAAAAAAJfU/RciAfITCBq4v_YxdtuwSMGN5-NZCYZ1rQCNcBGAsYHQ/s1600/1646548743064838-18.png)** 

\- Tap on ≡ then tap on **Assets**

 **[![](https://lh3.googleusercontent.com/-FUtq0rut_9M/YiRXBYc6rzI/AAAAAAAAJfQ/Qv5RXm4TAjETm52jDqvqB04Xxt2L-8S_QCNcBGAsYHQ/s1600/1646548738796355-19.png)](https://lh3.googleusercontent.com/-FUtq0rut_9M/YiRXBYc6rzI/AAAAAAAAJfQ/Qv5RXm4TAjETm52jDqvqB04Xxt2L-8S_QCNcBGAsYHQ/s1600/1646548738796355-19.png)** 

\- Find Crypto.org - CRO  then tap on **Deposit**

 **[![](https://lh3.googleusercontent.com/-PGJ9NX4KCXg/YiRXAUvogII/AAAAAAAAJfM/ImMcvyUaDXQtTk_9IGfhkVsOvSHBr_VuACNcBGAsYHQ/s1600/1646548734539098-20.png)](https://lh3.googleusercontent.com/-PGJ9NX4KCXg/YiRXAUvogII/AAAAAAAAJfM/ImMcvyUaDXQtTk_9IGfhkVsOvSHBr_VuACNcBGAsYHQ/s1600/1646548734539098-20.png)** 

\- Tap on MAX then tap on **Deposit**  

 **[![](https://lh3.googleusercontent.com/-tR9dCee12oo/YiRW_W4WdXI/AAAAAAAAJfI/vsiQh6B_YCwXvlFuaMwX3xbFZ4uVtxymQCNcBGAsYHQ/s1600/1646548730308701-21.png)](https://lh3.googleusercontent.com/-tR9dCee12oo/YiRW_W4WdXI/AAAAAAAAJfI/vsiQh6B_YCwXvlFuaMwX3xbFZ4uVtxymQCNcBGAsYHQ/s1600/1646548730308701-21.png)** 

\- Tap on **Approve**

 **[![](https://lh3.googleusercontent.com/-9nLvKeit31A/YiRW-AYuyOI/AAAAAAAAJfE/h9nhtFuon7YV_9GbhATpDSfHFUETOh_HgCNcBGAsYHQ/s1600/1646548725915624-22.png)](https://lh3.googleusercontent.com/-9nLvKeit31A/YiRW-AYuyOI/AAAAAAAAJfE/h9nhtFuon7YV_9GbhATpDSfHFUETOh_HgCNcBGAsYHQ/s1600/1646548725915624-22.png)** 

\- if successful, you will get transaction details on [finder.terra.money](https://finder.terra.money/columbus-5/tx/842075734F288FCC20F9833D5D1A7ED0A6F10FD35906BB78FAA1F1A7B5DB71C9).

  

 [![](https://lh3.googleusercontent.com/-IS86omnXtn0/YiRW9CoO0_I/AAAAAAAAJfA/-BV9KxmCg7AKcAuEqIwOi-Z5OtbotoeywCNcBGAsYHQ/s1600/1646548721771712-23.png)](https://lh3.googleusercontent.com/-IS86omnXtn0/YiRW9CoO0_I/AAAAAAAAJfA/-BV9KxmCg7AKcAuEqIwOi-Z5OtbotoeywCNcBGAsYHQ/s1600/1646548721771712-23.png) 

  

\- Go to Osmosis, from select - CRO and enter 3 or 2 and To - DVPN you will get around 180 DVPN tokens which will get you upto 500GB Exidio dVPN.

  

\- Set slippage to default then tap on **Swap**

  

\- Hold on, you can stake remaining CRO on osmosis to earn annual interest or swap CRO token to any token you like, experts suggest stable coins like UST or EEUR.

  

\- Anyhow you can also swap remaining CRO to Sentinel dVPN tokens in future to top-up Exidio dVPN, it's up to you.

  

 **[![](https://lh3.googleusercontent.com/-cQXr-kHacys/YiRW8AwVMBI/AAAAAAAAJe8/maLgDHOsHP4PfSQuX0cfXSIdROamd0-JQCNcBGAsYHQ/s1600/1646548717379553-24.png)](https://lh3.googleusercontent.com/-cQXr-kHacys/YiRW8AwVMBI/AAAAAAAAJe8/maLgDHOsHP4PfSQuX0cfXSIdROamd0-JQCNcBGAsYHQ/s1600/1646548717379553-24.png)** 

\- Tap on **Approve**

 **[![](https://lh3.googleusercontent.com/-VX_5rXXO5rM/YiRW61DqxiI/AAAAAAAAJe4/vTX2cXD9rHIO4cjT944a5CjmEtFxY1ntwCNcBGAsYHQ/s1600/1646548712912981-25.png)](https://lh3.googleusercontent.com/-VX_5rXXO5rM/YiRW61DqxiI/AAAAAAAAJe4/vTX2cXD9rHIO4cjT944a5CjmEtFxY1ntwCNcBGAsYHQ/s1600/1646548712912981-25.png)** 

\- if successful you will get transaction details on [www.mintscan.io](https://www.mintscan.io/osmosis/txs/99FFE03232D180430CFFCB1B02E8C4AFA056B7F3BC8DE081FC37190443206CF0)

  

 [![](https://lh3.googleusercontent.com/-YP6uze5Qmqc/YiRW5iLi-UI/AAAAAAAAJe0/ya6ZPYs8SaYidJ8_xQaKbZ-rW5qFUe3OQCNcBGAsYHQ/s1600/1646548708076965-26.png)](https://lh3.googleusercontent.com/-YP6uze5Qmqc/YiRW5iLi-UI/AAAAAAAAJe0/ya6ZPYs8SaYidJ8_xQaKbZ-rW5qFUe3OQCNcBGAsYHQ/s1600/1646548708076965-26.png) 

  

\- Again, go to Osmosis assets page and find Sentinel - DVPN then tap on **Deposit**

 **[![](https://lh3.googleusercontent.com/-eAOYbpsWFII/YiRW4kn7dcI/AAAAAAAAJes/vp8xdGHcJvsWLIQb9-vXn3dQog5yob1PgCNcBGAsYHQ/s1600/1646548703625216-27.png)](https://lh3.googleusercontent.com/-eAOYbpsWFII/YiRW4kn7dcI/AAAAAAAAJes/vp8xdGHcJvsWLIQb9-vXn3dQog5yob1PgCNcBGAsYHQ/s1600/1646548703625216-27.png)** 

\- Tap on MAX then tap on **Deposit**

 **[![](https://lh3.googleusercontent.com/-D_TedjuO0MI/YiRW3dw7qcI/AAAAAAAAJeo/wusLK7Ac2PEmnX4YrE7Yk9RApsWoslRuACNcBGAsYHQ/s1600/1646548699517478-28.png)](https://lh3.googleusercontent.com/-D_TedjuO0MI/YiRW3dw7qcI/AAAAAAAAJeo/wusLK7Ac2PEmnX4YrE7Yk9RApsWoslRuACNcBGAsYHQ/s1600/1646548699517478-28.png)** 

\- Tap on **Approve**

 **[![](https://lh3.googleusercontent.com/--fNH7PFIEfA/YiRW2b4MoMI/AAAAAAAAJek/Qt0UIRl4-J8922sUrZ9YyazvVrpI1UuBQCNcBGAsYHQ/s1600/1646548694789723-29.png)](https://lh3.googleusercontent.com/--fNH7PFIEfA/YiRW2b4MoMI/AAAAAAAAJek/Qt0UIRl4-J8922sUrZ9YyazvVrpI1UuBQCNcBGAsYHQ/s1600/1646548694789723-29.png)** 

  

\- if successful, you will get transaction details on [www.mintscan.io](https://www.mintscan.io/osmosis/txs/A1A830C096D5F08F98314B2D66154B843BE07A2C481EFAC557F18EE8A0404BD1)

  

\- Wait, you now send Sentinel dVPN tokens to Sentinel dVPN wallet of Osmosis which you have have transfer on Exidio dVPN.

  

 [![](https://lh3.googleusercontent.com/-wGNJJqDsuIo/YiRW1VNJHkI/AAAAAAAAJeg/5raK6UvDql887lbHnIuh07JjAI1gBrxCQCNcBGAsYHQ/s1600/1646548690921593-30.png)](https://lh3.googleusercontent.com/-wGNJJqDsuIo/YiRW1VNJHkI/AAAAAAAAJeg/5raK6UvDql887lbHnIuh07JjAI1gBrxCQCNcBGAsYHQ/s1600/1646548690921593-30.png) 

  

\- Open Cosmostation then tap on **START**

  

 [![](https://lh3.googleusercontent.com/-e_-npwGYT8w/YiRW0a4ls9I/AAAAAAAAJec/Vmy_KhjE00gps6K1krYLqgv53bk_EPzPQCNcBGAsYHQ/s1600/1646548686763774-31.png)](https://lh3.googleusercontent.com/-e_-npwGYT8w/YiRW0a4ls9I/AAAAAAAAJec/Vmy_KhjE00gps6K1krYLqgv53bk_EPzPQCNcBGAsYHQ/s1600/1646548686763774-31.png) 

  

\- Find and select **Sentinel**

  

 [![](https://lh3.googleusercontent.com/-QAHYDvl0Rcw/YiRWzWqSUpI/AAAAAAAAJeY/kue4rg6S6BUFENFRWM3Ev-70D5CXTQtQwCNcBGAsYHQ/s1600/1646548682733013-32.png)](https://lh3.googleusercontent.com/-QAHYDvl0Rcw/YiRWzWqSUpI/AAAAAAAAJeY/kue4rg6S6BUFENFRWM3Ev-70D5CXTQtQwCNcBGAsYHQ/s1600/1646548682733013-32.png) 

  

\- Tap on **Mnemonic** and enter your Kepler wallet backup phrases that I said earlier to backup somewhere safe and secure then tap on **START**

 **[![](https://lh3.googleusercontent.com/-uZyMUuMWgLI/YiRWyREnrAI/AAAAAAAAJeU/NW0uNkARX04eF6oquv3VcIR_8rrcANUDgCNcBGAsYHQ/s1600/1646548678579720-33.png)](https://lh3.googleusercontent.com/-uZyMUuMWgLI/YiRWyREnrAI/AAAAAAAAJeU/NW0uNkARX04eF6oquv3VcIR_8rrcANUDgCNcBGAsYHQ/s1600/1646548678579720-33.png)** 

\- Select **Sentinel dVPN wallet**.

  

\- it's time now you need Exidio dVPN address to receive tokens from Osmosis Sentinel dVPN wallet via Cosmostation.

  

 [![](https://lh3.googleusercontent.com/-aKoExUj2syA/YiRWxJOv0HI/AAAAAAAAJeQ/K4EXlC0VXLYeycEfCKPxxcBO7DxH7T54ACNcBGAsYHQ/s1600/1646548673942472-34.png)](https://lh3.googleusercontent.com/-aKoExUj2syA/YiRWxJOv0HI/AAAAAAAAJeQ/K4EXlC0VXLYeycEfCKPxxcBO7DxH7T54ACNcBGAsYHQ/s1600/1646548673942472-34.png) 

  

\- Open Exidio dVPN then tap on **CREATE AN ACCOUNT**

 **[![](https://lh3.googleusercontent.com/-MkwbaEfANKA/YiRWwBu3jTI/AAAAAAAAJeM/1yfa5XwCe9sriXJZby44G2cicu3XyNNNwCNcBGAsYHQ/s1600/1646548669680716-35.png)](https://lh3.googleusercontent.com/-MkwbaEfANKA/YiRWwBu3jTI/AAAAAAAAJeM/1yfa5XwCe9sriXJZby44G2cicu3XyNNNwCNcBGAsYHQ/s1600/1646548669680716-35.png)** 

**\-** Copy and keep Exidio dVPN backup phrases somewhere safe and secure to recover in any condition.

  

\- ✓ box to agree terms and conditions then tap on **CREATE AN ACCOUNT**

 **[![](https://lh3.googleusercontent.com/-E7BEOH-aEKc/YiRWu_VAMtI/AAAAAAAAJeI/2Uy5BIlSNnIpmDye2VFhlhCnawS30B5YACNcBGAsYHQ/s1600/1646548665232783-36.png)](https://lh3.googleusercontent.com/-E7BEOH-aEKc/YiRWu_VAMtI/AAAAAAAAJeI/2Uy5BIlSNnIpmDye2VFhlhCnawS30B5YACNcBGAsYHQ/s1600/1646548665232783-36.png)** 

\- You're in Exidio dVPN, tap on **My Account**

 **[![](https://lh3.googleusercontent.com/-fSUjZbdOz9o/YiRWt0WCcGI/AAAAAAAAJeE/AiAaDcSlKcUxjqJin6i6kYF0wq_tMZrowCNcBGAsYHQ/s1600/1646548661020410-37.png)](https://lh3.googleusercontent.com/-fSUjZbdOz9o/YiRWt0WCcGI/AAAAAAAAJeE/AiAaDcSlKcUxjqJin6i6kYF0wq_tMZrowCNcBGAsYHQ/s1600/1646548661020410-37.png)** 

\- Here, you see my Exidio wallet address, tap on Copy and go back to cosmostation.

  

 [![](https://lh3.googleusercontent.com/-PntzZKZustY/YiRWsz6Ii4I/AAAAAAAAJeA/qeizbhp4cFAdu1hxjcQnXPGpJ_muSZRdwCNcBGAsYHQ/s1600/1646548656614540-38.png)](https://lh3.googleusercontent.com/-PntzZKZustY/YiRWsz6Ii4I/AAAAAAAAJeA/qeizbhp4cFAdu1hxjcQnXPGpJ_muSZRdwCNcBGAsYHQ/s1600/1646548656614540-38.png) 

  

\- On Cosmostation, tap on **ASSETS**

 **[![](https://lh3.googleusercontent.com/-jC1DpnTFvZI/YiRWrpE2otI/AAAAAAAAJd8/VtNk1BMQ0BcPLU4a2bhG5iBG_4irKwAAACNcBGAsYHQ/s1600/1646548652421689-39.png)](https://lh3.googleusercontent.com/-jC1DpnTFvZI/YiRWrpE2otI/AAAAAAAAJd8/VtNk1BMQ0BcPLU4a2bhG5iBG_4irKwAAACNcBGAsYHQ/s1600/1646548652421689-39.png)** 

\- Tap on **DVPN >**

 **[![](https://lh3.googleusercontent.com/-cP3VnOFOno4/YiRWqn013GI/AAAAAAAAJd4/yRkZmWF5894zoRoG61jB5fA3ck4IXA-bQCNcBGAsYHQ/s1600/1646548648279605-40.png)](https://lh3.googleusercontent.com/-cP3VnOFOno4/YiRWqn013GI/AAAAAAAAJd4/yRkZmWF5894zoRoG61jB5fA3ck4IXA-bQCNcBGAsYHQ/s1600/1646548648279605-40.png)** 

\- Tap on IBC Send and paste your Exidio wallet address to send tokens.

  

\- Don't use Send option, it won't work and funds will be lost.

  

 [![](https://lh3.googleusercontent.com/-dX_xgaLHjH4/YiRWpoA2hfI/AAAAAAAAJd0/PIRKdWYuYycJqrOuYn0CFp-jy49zp11KQCNcBGAsYHQ/s1600/1646548644088770-41.png)](https://lh3.googleusercontent.com/-dX_xgaLHjH4/YiRWpoA2hfI/AAAAAAAAJd0/PIRKdWYuYycJqrOuYn0CFp-jy49zp11KQCNcBGAsYHQ/s1600/1646548644088770-41.png) 

  

\- Open Exidio dVPN, In My Account check either you received dVPN accounds or not.

  

\- if received, tap on **All nodes**

 **[![](https://lh3.googleusercontent.com/-5zd6ylElq3I/YiRWotpD6qI/AAAAAAAAJdw/Z5EURGz5MbkW8pYZ3rKGi0nlqrqzel8-QCNcBGAsYHQ/s1600/1646548639560720-42.png)](https://lh3.googleusercontent.com/-5zd6ylElq3I/YiRWotpD6qI/AAAAAAAAJdw/Z5EURGz5MbkW8pYZ3rKGi0nlqrqzel8-QCNcBGAsYHQ/s1600/1646548639560720-42.png)** 

\- Select any continent you like.

  

 [![](https://lh3.googleusercontent.com/-QaQ4cxQ6lNo/YiRWnQ6mNMI/AAAAAAAAJds/kz5A-4Jv3TorFwvLmoNDlRlHPDxg0eKDACNcBGAsYHQ/s1600/1646548634994005-43.png)](https://lh3.googleusercontent.com/-QaQ4cxQ6lNo/YiRWnQ6mNMI/AAAAAAAAJds/kz5A-4Jv3TorFwvLmoNDlRlHPDxg0eKDACNcBGAsYHQ/s1600/1646548634994005-43.png) 

  

\- Choose which country node you want.

  

 [![](https://lh3.googleusercontent.com/-5vPv_tfzYKQ/YiRWmfn2TpI/AAAAAAAAJdo/YqmH7IhtdxAqLgHpnin_2n0-7tD2AYOcACNcBGAsYHQ/s1600/1646548630240592-44.png)](https://lh3.googleusercontent.com/-5vPv_tfzYKQ/YiRWmfn2TpI/AAAAAAAAJdo/YqmH7IhtdxAqLgHpnin_2n0-7tD2AYOcACNcBGAsYHQ/s1600/1646548630240592-44.png) 

  

\- Here, I selected Amsterdam.

  

\- Tap on **Connect now**

 **[![](https://lh3.googleusercontent.com/-cLwqN88iGB4/YiRWlPAWlKI/AAAAAAAAJdk/HWqKi1rt8OQLzoj6d07cQkDn8syWx-uzQCNcBGAsYHQ/s1600/1646548626114594-45.png)](https://lh3.googleusercontent.com/-cLwqN88iGB4/YiRWlPAWlKI/AAAAAAAAJdk/HWqKi1rt8OQLzoj6d07cQkDn8syWx-uzQCNcBGAsYHQ/s1600/1646548626114594-45.png)** 

\- You probably got 180 dVPN tokens, just tap on + until it reaches 180.

  

\- Tap on **SUBSCRIBE** to get 500GB and tap on Connect again to turn on Node and get decentrailised dVPN experience.

  

 [![](https://lh3.googleusercontent.com/-ud-wQE9KfhE/YiRWkPxnk0I/AAAAAAAAJdg/cSkYQCbKF9QPlZkLoPaLjP_pdFW98czDgCNcBGAsYHQ/s1600/1646548620598057-46.png)](https://lh3.googleusercontent.com/-ud-wQE9KfhE/YiRWkPxnk0I/AAAAAAAAJdg/cSkYQCbKF9QPlZkLoPaLjP_pdFW98czDgCNcBGAsYHQ/s1600/1646548620598057-46.png) 

  

\- You can use your preffered Default DNS Server included with dVPN, cool right?

  

Bingo, you successfully added Sentinel dVPN tokens on Exidio dVPN app.

  

Atlast, this are just highlighted features of Exidio dVPN, Crypto.com, Kepler wallet, Cosmostation and osmosis, there are many features hidden features in-build that give the ultimate usage experience which you have to explore based on requirements to get external benefits.

  

Overall, Crypto.com is simple but has bugs so can't login, while cosmostation, Kepler has alot of logs bugs and they have to add more features and improve user interface so much as of now they look pretty basic and boring, in case of Osmosis and Exidio they both look amazing with modern user interface and we didn't found bugs that ensures user-friendly experience.

  

 [![](https://lh3.googleusercontent.com/-R0-AyQzEqEs/YiRiIbRXsKI/AAAAAAAAJhI/PbIvS6uu5F0FB89iaqrabWWMOwK6ytMHACNcBGAsYHQ/s1600/1646551582514259-0.png)](https://lh3.googleusercontent.com/-R0-AyQzEqEs/YiRiIbRXsKI/AAAAAAAAJhI/PbIvS6uu5F0FB89iaqrabWWMOwK6ytMHACNcBGAsYHQ/s1600/1646551582514259-0.png) 

  

Moreover, it is worth to mention don't buy through Exidio in-app top-up which is very expensive and not worthy at all, as you get only 0.500MB for $1.99, the reason is they have to pay vat, chargeback risks, google playstore fees and developer salaries etc, so if you're not lazy buy and transfer the dVPN tokens using this method.

  

Finally, this is how you can get 500GB of decentrailised privacy and security for 1$ on Exidio dVPN, are you an existing user of Exidio or Sentinel dVPN? If yes have you ever tried this method to load Sentinel dVPN tokens on Exidio dVPN app? If yes do say your experience and say us this method worked for you or not, including that mention why you like Exidio dVPN in our comment section below, see ya :)