---
title: 'Here''s why, Micromax Mobile India failed to beat china smartphones.'
date: 2022-06-27T12:00:00.004+05:30
draft: false
url: /2022/06/heres-why-micromax-india-failed-to-beat.html
tags: 
- Failed
- technology
- India
- China Smartphones
- Micromax
---

 [![](https://lh3.googleusercontent.com/-EVSkCQIC0Uc/YrobMnjqXxI/AAAAAAAAMHY/aZt9xdshamITyrVyfPPdDf3RBtR-4KrXQCNcBGAsYHQ/s1600/1656363822472155-0.png)](https://lh3.googleusercontent.com/-EVSkCQIC0Uc/YrobMnjqXxI/AAAAAAAAMHY/aZt9xdshamITyrVyfPPdDf3RBtR-4KrXQCNcBGAsYHQ/s1600/1656363822472155-0.png) 

  

  

In ancient times, people used to send messages through letters using birds or postmans but later in early 18th century industrial revolution started since then the usage and market for machinery increased and people also started migrating to urban areas for industrial jobs which made them adopt to industrial lifestyle that changed and progressed world immensely due to that high demand and requirement for voice transmissible has been device started.

  

 [![](https://lh3.googleusercontent.com/-YTzpG_NAHGI/YromSisqSTI/AAAAAAAAMH0/HPXO_EkG-7QGkl30KgEUZNFkH81XaLjnwCNcBGAsYHQ/s1600/1656366662606896-0.png)](https://lh3.googleusercontent.com/-YTzpG_NAHGI/YromSisqSTI/AAAAAAAAMH0/HPXO_EkG-7QGkl30KgEUZNFkH81XaLjnwCNcBGAsYHQ/s1600/1656366662606896-0.png) 

  

Scientists around the world always wanted to invent voice transmissible device to replace letters and telegraph but most of them are unsuccessful yet scientists didn't give up they keep on doing research to make voice transmissible device and then a scientist named Alexander Graham Bell invented first patented voice transmissible device named Telephone in year 1876.  

  

 [![](https://lh3.googleusercontent.com/-amyoM3AVkDI/YromRpjK3vI/AAAAAAAAMHw/od0CcvRk_gUuwDYklPGOkzRhogwsZzhCwCNcBGAsYHQ/s1600/1656366658003404-1.png)](https://lh3.googleusercontent.com/-amyoM3AVkDI/YromRpjK3vI/AAAAAAAAMHw/od0CcvRk_gUuwDYklPGOkzRhogwsZzhCwCNcBGAsYHQ/s1600/1656366658003404-1.png) 

  

Telephone is revolutionary invention that will let you voice communicate with any one but the early telephones are big and expensive thus they are not user friendly due to that not everyone can afford them it's common for any potential product but later on after few decades size and price of telephone decreased thanks to modern scientists and never ending competiton among industrial companies.

  

Companies around the world used to buy telephone patent rights to manufacture thier own telephones with better features according to latest requirements of people adapting to latest technologies thus telephones worked and survived for more then century but later on in 19th century many people wanted alternative to telephone which is more convenient and easy to use.

  

 [![](https://lh3.googleusercontent.com/-ueefqJi5gyg/YromQTHxE7I/AAAAAAAAMHs/wxlLObjI5sEugepuMTY2goWjOVK4pdAWACNcBGAsYHQ/s1600/1656366654385217-2.png)](https://lh3.googleusercontent.com/-ueefqJi5gyg/YromQTHxE7I/AAAAAAAAMHs/wxlLObjI5sEugepuMTY2goWjOVK4pdAWACNcBGAsYHQ/s1600/1656366654385217-2.png) 

  

  

However, we didn't got any alternatives to telephone until year 1983 when first handheld mobile phone Motorola DynaTAC 8000X released by US company Motorola that don't need lines or cords instead it will make long distance communication calls wirelessly from then numerous companies started making thier own mobile phones due to that mobile phones evolved just like telephones thus after few years we got better and feature rich mobile phones.

  

From year 1990, the era and rise of user friendly mobile phones begin but they can only make or receive calls thus many people were unsatisfied as computers at the time are more capable then mobile phones even though computers can't do calls any how after a decade in 20th century companies started releasing mobile phones with better features like integrating camera and java software to Install softwares like computers.

  

 [![](https://lh3.googleusercontent.com/-4xz5JTfs4Kc/YromPcqGynI/AAAAAAAAMHo/vY0uKMWyjUwoRgqmmh9kAPNmJ_-l3pzkQCNcBGAsYHQ/s1600/1656366650379885-3.png)](https://lh3.googleusercontent.com/-4xz5JTfs4Kc/YromPcqGynI/AAAAAAAAMHo/vY0uKMWyjUwoRgqmmh9kAPNmJ_-l3pzkQCNcBGAsYHQ/s1600/1656366650379885-3.png) 

  

  

In 20th century, many amazing companies like Samsung and Nokia released super high quality mobile phones with upgraded features thus people around the world purchased atleast one mobile phone for personal or business purposes then in year 2007 Steve Jobs founder of Apple Inc. launched revolutionary multi-touch big screen powerful hardware and software smartphone named iPhone that has super cool features and better then all existing keypad mobile phones.

  

The entry of futuristic smartphones in mobile market reduced sells of keypad phones heavily but smartphones are bit expensive especially iPhones thus not every one can afford them due to financial reasons mainly in india people are not aware of iPhones as there is no online shopping platforms or Apple stores in year 2007 thus only very few people used to buy imported Apple iPhones luckily.

  

In india, people got thier hands on keypad mobile phones lately when compared to developed countries like united states yet thankfully many indian people used to buy keypad mobile phones from companies like Nokia and Samsung even though they're are expensive to full fill thier needs but there are some indian people who were unable to afford expensive mobile phones and for them Indian company reliance manufactured and released affordable keypad mobiles phones.

  

 [![](https://lh3.googleusercontent.com/-Yx7Hlabapyg/YrqqbtQwVbI/AAAAAAAAMJE/09pLi7Ds004MeRe7ytum-DxQfbjICFt7wCNcBGAsYHQ/s1600/1656400490369682-0.png)](https://lh3.googleusercontent.com/-Yx7Hlabapyg/YrqqbtQwVbI/AAAAAAAAMJE/09pLi7Ds004MeRe7ytum-DxQfbjICFt7wCNcBGAsYHQ/s1600/1656400490369682-0.png) 

  

Reliance keypad mobile phones are pretty successfull but for whatever reason they didn't entered into smartphone industry until 2015 with LYF and now with JioPhone Next due to that we didn't got an alternative to iPhone in india but fortunately search engine giant Google partnered with few mobile companies like HTC and with in year released thier own Android powered smartphones.

  

**[\+ The success story of Reliance Jio.](https://www.techtracker.in/2022/06/the-success-story-of-reliance-jio.html)**

  

 [![](https://lh3.googleusercontent.com/-xsHSwD6g2pw/YromOuGV_jI/AAAAAAAAMHk/Qkbd_UBu7Y89aVubJx3lI2Sx8yYuEYd6wCNcBGAsYHQ/s1600/1656366647093767-4.png)](https://lh3.googleusercontent.com/-xsHSwD6g2pw/YromOuGV_jI/AAAAAAAAMHk/Qkbd_UBu7Y89aVubJx3lI2Sx8yYuEYd6wCNcBGAsYHQ/s1600/1656366647093767-4.png) 

  

  

Android is a mobile operating system developed by Andy Rubens in year 2005 Google purchased it from him and started installing it on thier smartphones and then Google intelligently made Android an open source project aka AOSP thus any one can use or build thier own version of Android to install on thier smartphones for free.

  

 [![](https://lh3.googleusercontent.com/-0Y-TuhFNVnQ/YromN6RjVdI/AAAAAAAAMHg/0Buz8PkzVegprI9uZyjTRjQLHYQjxMvvQCNcBGAsYHQ/s1600/1656366643076850-5.png)](https://lh3.googleusercontent.com/-0Y-TuhFNVnQ/YromN6RjVdI/AAAAAAAAMHg/0Buz8PkzVegprI9uZyjTRjQLHYQjxMvvQCNcBGAsYHQ/s1600/1656366643076850-5.png) 

  

  

While, Apple's iPhone iOS is closed source mobile operating systems thus no one can use it other then themselves due to that iPhones are expensive but incase of Android any developer or company can build and install thier own version of Android with custom features on smartphones thus Android powered smartphones available at 1/10 price of iPhones that's why most people around the world like to buy Android powered smartphones over iPhones.

  

But, in india even Android powered smartphones are bit expensive as average salary of Indian per annum is very low compared to developed nations like USA and UK yet many people used to buy Android smartphones but there are some people especially students were unable to buy costly Android powered smartphones from foriegn and indian companies as well.

  

Yes, we do have many indian companies like Micromax, Karbonn, Celkon etc who previously used to sell feature keypad mobile phones but since smartphones are very popular around the world they made deals with china mobile companies then imported non branded smartphones to india after that they used to simply add thier brand logo and custom software to sell in india mobile market that method give them immense success and fortune as most india people used to buy bit low priced smartphones from indian companies over foriegn mobiles.

  

 [![](https://lh3.googleusercontent.com/-EihBHstcqyg/YrqC0TKwhtI/AAAAAAAAMIo/oTqPEAuUJ4sQYHwTJWx5ho_SuIpJuU5dwCNcBGAsYHQ/s1600/1656390350054217-0.png)](https://lh3.googleusercontent.com/-EihBHstcqyg/YrqC0TKwhtI/AAAAAAAAMIo/oTqPEAuUJ4sQYHwTJWx5ho_SuIpJuU5dwCNcBGAsYHQ/s1600/1656390350054217-0.png) 

  

  

There are several reasons why indian mobile companies import smartphones from china but the main one was china mobile companies has best infrastructure and network of mobile companies who make all smartphone parts thus china mobile companies can make and provide smartphones at very low price compared to other country mobile companies.

  

 [![](https://lh3.googleusercontent.com/-1m4TPZQSW6Y/YrqCzrERp1I/AAAAAAAAMIk/GKoOGvx2uxYIyJDEaSChM0pjIoeqKkotgCNcBGAsYHQ/s1600/1656390345930981-1.png)](https://lh3.googleusercontent.com/-1m4TPZQSW6Y/YrqCzrERp1I/AAAAAAAAMIk/GKoOGvx2uxYIyJDEaSChM0pjIoeqKkotgCNcBGAsYHQ/s1600/1656390345930981-1.png) 

  

  

Mean while in india we have companies that are listed in fortune 500 companies but still they are not setting up proper infrastructure and full smartphone manufacturing plants as even if they setup them by taking huge risk still they may can't make smartphones at such price of china smartphones as indian employment cost per day is much higher then china including that it's hard for indian mobile company to beat china mobile overnight thus it's definitely long time battle between china and India mobile companies for sure.

  

 [![](https://lh3.googleusercontent.com/-5r2c7Ryo6xM/YrqCyU3z_OI/AAAAAAAAMIg/UjGNonuzaFMznWwLeE-RWcoRtLmnLpw5wCNcBGAsYHQ/s1600/1656390342099856-2.png)](https://lh3.googleusercontent.com/-5r2c7Ryo6xM/YrqCyU3z_OI/AAAAAAAAMIg/UjGNonuzaFMznWwLeE-RWcoRtLmnLpw5wCNcBGAsYHQ/s1600/1656390342099856-2.png) 

  

  

I hope any indian company that has potential should setup infrastructure and mobile parts manufacturing plants in india by taking inspiration from make in india and Aatma Nirbhaar Bharat as a developing nation we can't depend on china or any other foriegin company to make smartphones that negatively impact future of India which is why it's right time for indian companies to atleast try to make full smartphone in india even though it's hard at present yet it will surely lead to fruitful days in future.

  

 [![](https://lh3.googleusercontent.com/-tBLhsQT4254/YrqCxrjCIQI/AAAAAAAAMIc/_mW7VAr7zowr8hOiBgMN3P2nswYmlEeuQCNcBGAsYHQ/s1600/1656390337654551-3.png)](https://lh3.googleusercontent.com/-tBLhsQT4254/YrqCxrjCIQI/AAAAAAAAMIc/_mW7VAr7zowr8hOiBgMN3P2nswYmlEeuQCNcBGAsYHQ/s1600/1656390337654551-3.png) 

  

  

India mobile companies used to sell thier smartphones very well simultaneous with keypad mobiles by partnering with retail stores like Reliance Digital and Big C etc but the only problem with indian mobile companies is they used to Import basic smartphones from china companies and then they used to overprice them with extra big profit margin that eventually leaded them to hardships and failure.

  

 [![](https://lh3.googleusercontent.com/-iHzIc98bY5A/YrqCwci52DI/AAAAAAAAMIY/yO1_wO8iAOYARgbgybPL8mAGJycagZpPwCNcBGAsYHQ/s1600/1656390333526944-4.png)](https://lh3.googleusercontent.com/-iHzIc98bY5A/YrqCwci52DI/AAAAAAAAMIY/yO1_wO8iAOYARgbgybPL8mAGJycagZpPwCNcBGAsYHQ/s1600/1656390333526944-4.png) 

  

In year 2014, Motorola a US based company and china mobile companies like Xiaomi released thier feature rich low price quality smartphones in india thus existing india mobile companies struggled and failed to rise above them as they didn't have even one potential smartphone thus the survival itself become become big challenge to indian mobile companies.

  

 [![](https://lh3.googleusercontent.com/-ICm1JEzf3-k/YrqCvQ58RkI/AAAAAAAAMIU/ossBSLl0mMgCkVJ8zi045nvDaz6_VEcFgCNcBGAsYHQ/s1600/1656390329703813-5.png)](https://lh3.googleusercontent.com/-ICm1JEzf3-k/YrqCvQ58RkI/AAAAAAAAMIU/ossBSLl0mMgCkVJ8zi045nvDaz6_VEcFgCNcBGAsYHQ/s1600/1656390329703813-5.png) 

  

  

Fortunately, most indian mobile companies survived and they are in profits just because of thier keypad mobile phones and basic smartphones sells in retail market but actually indian mobile companies failed as even today most indian mobile companies don't have one capable smartphone that has capability to beat china smartphones except Lava.

  

 [![](https://lh3.googleusercontent.com/-XDg90WRhdbQ/YrqCucxZERI/AAAAAAAAMIQ/9a5MZsBG9PkIcFlo1HgLsn04qLWOiZAEACNcBGAsYHQ/s1600/1656390325836518-6.png)](https://lh3.googleusercontent.com/-XDg90WRhdbQ/YrqCucxZERI/AAAAAAAAMIQ/9a5MZsBG9PkIcFlo1HgLsn04qLWOiZAEACNcBGAsYHQ/s1600/1656390325836518-6.png) 

  

  

Online market of India is completely dominated by foriegn and china mobile companies even if indian mobile company enter in online market with thier basic china imported smartphones yet people usually don't buy them as foriegn and china smartphones are better value for money and indian mobile companies know that which is why they somehow sell thier basic smartphones in retail market.

  

 [![](https://lh3.googleusercontent.com/-nGC8XfsXvLM/YrqCtVxBHfI/AAAAAAAAMIM/RKCCNV-jGs0kJ2O5yT6OM9B1R4TbASNlgCNcBGAsYHQ/s1600/1656390321063631-7.png)](https://lh3.googleusercontent.com/-nGC8XfsXvLM/YrqCtVxBHfI/AAAAAAAAMIM/RKCCNV-jGs0kJ2O5yT6OM9B1R4TbASNlgCNcBGAsYHQ/s1600/1656390321063631-7.png) 

  

  

Retail market was once dominated by Nokia and Samsung even indian mobile companies has share in it who used to partner with retail dealers and pay them little commission when they sells their products and most of this retail dealers gimmick and over hype smartphone features to sell thier smartphones to people who don't know about how to select smartphones that's how indian mobile companies are still in profits.

  

Anyhow, almost all indian mobile companies failed and each indian mobile company has it's own reasons and decisions that driven them to failure out of them the common main issue with indian mobile companies is they didn't even trying to beat china and other country smartphones.

  

In case of Micromax, a indian IT software company established in year 29 March, 2000 founded by Rahul Sharma headquartered in Gurugram, Hariyana entered in mobile handset business in year 2008 and by 2010 it has become of the largest feature phone manufacturer in india and now Micromax is 10th largest smartphone vendor in world.

  

Micromax stayed calm for many years even after china smartphones rampage in india back in year 2014 Micromax like always they completely dependent on feature mobile phones even now keypad mobiles are there major market but thankfully in year 2020 onwards Micromax re-entered in indian mobile market with highly hyped Micromax IN Note series.

  

 [![](https://lh3.googleusercontent.com/-dxfUB4iteug/YrqCsHosdSI/AAAAAAAAMII/jGnQh-wLg20TMk24uRnPdi9fRW2-ugj8wCNcBGAsYHQ/s1600/1656390317389128-8.png)](https://lh3.googleusercontent.com/-dxfUB4iteug/YrqCsHosdSI/AAAAAAAAMII/jGnQh-wLg20TMk24uRnPdi9fRW2-ugj8wCNcBGAsYHQ/s1600/1656390317389128-8.png) 

  

  

Micromax IN series as stated by CEO is mostly made in india product using thier own machinery and clarified that it's not an imported one that has many powerful features at affordable rate just like china smartphones but later on it was proved that china smartphones are better then  Micromax IN smartphone in almost all aspects in device review and tests.

  

It's undoubtedly a good comeback from Micromax with smartphones that are comparable to china smartphones with alot of features on paper better then other indian mobile companies like Karbonn and Celkon for sure but in reality Micromax won't work as expected in long run when you get an issue with your product you will have to go to service center and they won't care about you much so you will eventually understand that china smartphones are better interms of quality and service.

  

If you're an indian then definitely there will be huge spark in you to buy and support indian smartphones that's understandable but indian mobile company smartphones including Micromax didn't won race against china smartphones as people are still preffering china smartphones over India smartphones as china smartphones offering better features and they are more value for money then india smartphones.

  

China smartphones provide much faster upgrades and updates if you select the right one while on indian smartphones especially on Micromax you very likely find hardware and software defects and many people confirmed it so before buying an indian smartphone brand don't get confused by good reviews as marketing agencies do fake comments to sale thier unworthy smartphones instead search for the issues that india smartphone have then you will find reality to decide either to buy or not.

  

The fact is Micromax lag behind china smartphones even being 10th largest smartphone vendor while small china companies are making best smartphones you can ever get as they are focusing on quality instead of profit margin so it's better if Micromax reduce profit margin and make better smartphones instead taking high profits and providing mediocre hardware and software with no upgrades that's not impressive at all.

  

Most people when they buy smartphones don't check about customer service and service centers availability and quality to be honest Micromax has one of the worst customer service and service center in india you can check for yourself they don't even provide proper customer service number even when you contact them they will disconnect your call number of times and reat you like you're not even thier product customer.

  

**[\+ Why you shouldn't buy Micromax Canvas Laptabs?](https://www.techtracker.in/2022/04/why-you-shouldnt-buy-micromax-canvas.html)**

  

While, china mobile company provide in app e- warranty with sometimes extended warranty and full list of service centers with exclusive support app where you can simply go and submit your smartphone if your device comes under warranty and do you know most people are very tired of bad Micromax service quality which is why existing Micromax users choose china or europe smartphones.

  

Now a days, Micromax releasing on paper vibrant feature smartphones one after one but still you can analyse majority of people especially geeks are not buying Micromax smartphones and the reason is  very simple china smartphones are highly suggested by true legit reviewers then fake influencers paid by Micromax.  

  

If Micromax smartphones really has potential and genuinely has good hardware and software then there is no need of advertisements they automatically get organic sells like OnePlus and Poco but Micromax not getting it as people are more smart they know Micromax is just masking the bad and showing the good which is why most people not buying Micromax smartphones.

  

Even, there are no top influencer you'll find on social media network who personally use and recommend Micromax smartphones instead they either suggest you to go for Poco or recommend you buy Pixel or iPhone if you don't want china smartphone have you ever seen top influencer who strongly use or said to buy Micromax smartphones in replacement of china smartphones, unlikely isn't?

  

 [![](https://lh3.googleusercontent.com/-QoUJTEMaOYE/YrqCrSidE2I/AAAAAAAAMIE/HTGFi8en7p4S8yvJZ3YWVqzwRCHBHyD3wCNcBGAsYHQ/s1600/1656390313008960-9.png)](https://lh3.googleusercontent.com/-QoUJTEMaOYE/YrqCrSidE2I/AAAAAAAAMIE/HTGFi8en7p4S8yvJZ3YWVqzwRCHBHyD3wCNcBGAsYHQ/s1600/1656390313008960-9.png) 

  

World's 10th largest smartphone vendor " and two decade old company " Micromax " struggling to beat Lava a indian company who already released a 5G smartphone named Agni 5G that has potential to beat china smartphones and Micromax being such largest company with R&D aka research and development centres set in place going to launch 5G smartphone after Lava, no one question why late isn't? 

  

[**\+ Here's why, Lava not failed yet it may beat china smartphones.**](https://www.techtracker.in/2022/06/heres-why-lava-not-failed-yet-it-may.html)

  

Anyway, Micromax must understand thier smartphones getting sells just because of feature mobile phones and smartphone sells in retail markets even that was already dominated by china mobile companies like oppo and vivo many more china mobile companies are entering into retail market including Xiaomi even dealers themselves buying smartphones from online market to sell in retail market, so Micromax shouldn't completely depend on retail market definitely not good for future of India.

  

The future of Indian mobile companies is definitely in hands of Micromax they have potential to make smartphones that are better then china smartphones so kindly form new plans and strategies mainly provide real life quality smartphones not on paper specs then not only indians everyone in the world will buy your smartphones just like they are now buying china smartphone worldwide.

  

Finally, this is how Micromax failed to beat china smartphones, are you an existing user of Micromax ? If yes do say your experience with Micromax smartphones and mention why do you like or hate Micromax smartphones in our comment section below, see ya :)