---
title: 'How To Add Custom Domain In Blogger'
date: 2019-12-27T15:53:00.001+05:30
draft: false
url: /2019/12/how-to-add-custom-domain-in-blogger.html
tags: 
- technology
- Website
- Blogger
- Domain
---

  

[![](https://lh3.googleusercontent.com/-eZupS18X89s/Xg-gRRNrKMI/AAAAAAAAAf0/9p3wJmNVQ30wi2ceaMcO0y75DC45cNwLgCLcBGAsYHQ/s1600/IMG_20200104_014103_304.jpg)](https://lh3.googleusercontent.com/-eZupS18X89s/Xg-gRRNrKMI/AAAAAAAAAf0/9p3wJmNVQ30wi2ceaMcO0y75DC45cNwLgCLcBGAsYHQ/s1600/IMG_20200104_014103_304.jpg)

  

Hi, if you want to add a custom domain to your blogger .blogspot.com follow the below instructions if you still got an issue comment down below will reply to it.

  

Blogger gives you an easy access to website creation and setup no need of hosting etc and blogspot.com sub domain of blogger is enough to adsense approval but still if you have a custom domain either .in or .com gives you more fast approval and for professional usage.

  

So. First go to your blogger and sign up or sign in google account and get into blogger panel then in menu create a blogger and put you desired website name and done.

  

After creating your blogger now you will have a web address with you desired name like example.blospot.com one you got it then go to your basic setting and then add tap on third party url and input your custom domain and press ok then you'll get the below following error.

  

Now to fix this copy the above given codes and login to your custom domain control panel and go to manage dns and add the above two records including a records that you will get on tapping the setting instructions.

  

After adding them carefully come back to blogger and press ok by adding you custom domain url again then now it will be added and you can redirect from .blogspot.com to your custom domain whichever it is.

  

And use all the blogger features, hassle free.

  

Keep Supporting : TechTracker.in