---
title: 'How to add modern sitemap on blogger in 2021 for free.'
date: 2021-12-13T22:07:00.019+05:30
draft: false
url: /2021/12/how-to-add-modern-sitemap-on-blogger-in.html
tags: 
- How
- technology
- Blogger
- Modern sitemap
- Embed
---

 [![](https://lh3.googleusercontent.com/-wGwxEGWG9vU/Ybd2thh2yNI/AAAAAAAAH20/Q3sDR0N2KT8-JtxtB5dgrQ9QWocP6PIcQCNcBGAsYHQ/s1600/1639413427651828-0.png)](https://lh3.googleusercontent.com/-wGwxEGWG9vU/Ybd2thh2yNI/AAAAAAAAH20/Q3sDR0N2KT8-JtxtB5dgrQ9QWocP6PIcQCNcBGAsYHQ/s1600/1639413427651828-0.png) 

  

There are two types of Sitemap formats available for bloggers, first one is HTML sitemap which is essential and required for Google to crawl on your website and second modern sitemap which also use HTML but you have embed this site-map on your blogger page, once you do that it will automatically show all your posts and lables in one place in simplified manner.

  

However, many bloggers don't know about modern site-map format, so they only use HTML sitemap which is good but adding a

modern site-map on blogger page have so many benefits, once you add modern site map on blogger, visitors whoever checking your website will get easy and convenient way to access your posts using site-map which gives in simple experience that will increase views on articles, in return you're able to increase traffic and ad revenue.

  

There are numerous sitemaps available on internet for blogger, while some sitemaps are not impressive, so to make this task easier for you we are glad to show you an simple yet modern site-map that works on all websites either in desktop or mobile mode, the site-map that we are going to feature will show all your website or blog posts and labels in clean format that can amaze you for sure.

  

Note : I didn't write or own this site-map code, I just found it some where on internet and I don't know the real owner of this site-map because many websites copy and paste site-map codes each other, so if you're real owner of this site-map do contact us and we will give proper credits.

  

**• How to download Sitemap code •**

it is very easy to download Sitemap code from these platforms for free.

  

\- [Bit.ly](http://bit.ly/sitemap-blogger)

  

**• How to add Sitemap on Blogger page •**

 **[![](https://lh3.googleusercontent.com/--dGUpRGAn0E/Ybd2s3GOPYI/AAAAAAAAH2w/D3KfIwb5uWAR5JAFOHjfz8-YIy0NTaVtwCNcBGAsYHQ/s1600/1639413419227054-1.png)](https://lh3.googleusercontent.com/--dGUpRGAn0E/Ybd2s3GOPYI/AAAAAAAAH2w/D3KfIwb5uWAR5JAFOHjfz8-YIy0NTaVtwCNcBGAsYHQ/s1600/1639413419227054-1.png)** 

  

  

\- Go to blogger and create and open sitemap page.

  

\- Select HTML view then copy and paste sitemap code available in download file given earlier and **publish it.**

  

Done, you successfully added modern sitemap on your blogger website.

  

Atlast, On internet you will find alot of sitemaps where you have to edit and add your blog or website URL but this sitemap that we provided above doesn't require any type of edits, it will auto fetch posts and labels using javascript technique which will ease the process for you.

  

 [![](https://lh3.googleusercontent.com/-M4Uua-cDWA8/Ybd2q5T9hHI/AAAAAAAAH2s/c0uZK9SPHXEayleL8frVam3nQSYJZqLyQCNcBGAsYHQ/s1600/1639413410813058-2.png)](https://lh3.googleusercontent.com/-M4Uua-cDWA8/Ybd2q5T9hHI/AAAAAAAAH2s/c0uZK9SPHXEayleL8frVam3nQSYJZqLyQCNcBGAsYHQ/s1600/1639413410813058-2.png) 

  

Overall, this site-map user interface is pretty impressive with default white background, which also highlight latest posts with " New " text and all posts were fitted well in vertical blocks, it is simple, easy to use and provides fast smoother user experience without lags or issues, including that you can edit or tweak the sitemap if you know little coding.

Moreover, it is worth to mention the above provided Sitemap will only work on Google blogger platform, don't waste your time by adding it on wordpress, it will not work and I believe for wordpress there are plugins or some other way to add a Sitemap like this, do some research before doing any thing.

  

Finally, this is modern site-map which you can add on your blogger page, are you an existing user of this site-map? If yes do you like it? have you found any issues? kindly say do you find this site-map useful? if yes say your user experience in our comment section below, see ya :)