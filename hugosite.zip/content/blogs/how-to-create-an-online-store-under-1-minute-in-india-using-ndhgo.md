---
title: 'How to create an online store under 1 minute in india using NDHGO.'
date: 2022-02-01T23:42:00.001+05:30
draft: false
url: /2022/02/how-to-create-online-store-under-1.html
tags: 
- How
- technology
- India
- NDHGO
- Online Store
---

 [![](https://lh3.googleusercontent.com/-1wk8qK4R9Ow/Yfl4IiICQaI/AAAAAAAAI8g/HKqP-qkti_Y9PDj3ub_IHSYoSpPMJxy9QCNcBGAsYHQ/s1600/1643739166396843-0.png)](https://lh3.googleusercontent.com/-1wk8qK4R9Ow/Yfl4IiICQaI/AAAAAAAAI8g/HKqP-qkti_Y9PDj3ub_IHSYoSpPMJxy9QCNcBGAsYHQ/s1600/1643739166396843-0.png) 

  

In india, online stores are not popular, most of the businesses run through offline stores, but when covid-19 pandemic expanded to india, bussines owners has no choice other then to create online store to get profits and recover losses occurred due to lock downs, mainly small bussines owners who run local stores has severely effected due to co-vid and they also shown interest to start online stores.

  

Online stores are very common in developed countries like united states and united kingdom but in india majority of business owners don't know how to create online stores, so india bussines owners out of necessity and emergency of online store they started hiring freelancers to create and setup online store.

  

In order to create online store for your business you need to have custom domain and hosting with best online store theme, and to setup all these you must have some knowledge on how online stores work, so if you're unable to setup online store for bussines by yourself then you have to hire freelancers which can cost extra money.

  

Usually, small business owners don't show interest to start online store as they have to pay for custom domain and hosting every year, and they have hire free lancers, this is pretty big investment for them and the success of online store is based on numerous factors, how ever there are many platforms available in india where you can create a online store for free.

  

Even though, only after co-vid pandemic online stores are created in large scale but online stores do existed in india, how ever only few bussines owners able to reap benefits of online store, now every one small and large bussines owners can setup an online store in india under 5 minutes for free using online store creating platforms.

  

We have many amazing online store creating apps and websites available in india and they gone through alot of improvements and updates to satisfy every bussines owners in times of co-vid, if you're searching for best platform to create online store then you're at right spot we will now show you how to create an online store under 1 minute using NDHGO app, so are you ready? If yes let's know little more about it before we register and explore more.

  

**• NDHGO official support •**

\- [Facebook](https://www.facebook.com/ndhgo)

\- [Twitter](https://twitter.com/ndhgoapp)

\- [YouTube](https://www.youtube.com/channel/UCT3nAFipmYhTdCNEyWJX79A)

\- [LinkedIn](https://in.linkedin.com/company/nextdoorhub)

\- [Instagram](https://www.instagram.com/ndhgo/)

**Email :** [mail@ndhgo.com](mailto:mail@ndhgo.com)

**Website :** [ndhgo.com](http://ndhgo.com)

**• How to download NDHGO •**

  

It is very easy to download NDHGO from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.nextdoorhub) / [App store](https://apps.apple.com/in/app/ndhgo/id1438955605)

  

**• How to create an online store in india under 1 minute using NDHGO •**

  

 [![](https://lh3.googleusercontent.com/-Sib-vpu6wok/Yfl4HlaoqPI/AAAAAAAAI8Y/zc8tFdYKIJwXXgKSYmlF_FAOTZf_xyXEwCNcBGAsYHQ/s1600/1643739162667580-1.png)](https://lh3.googleusercontent.com/-Sib-vpu6wok/Yfl4HlaoqPI/AAAAAAAAI8Y/zc8tFdYKIJwXXgKSYmlF_FAOTZf_xyXEwCNcBGAsYHQ/s1600/1643739162667580-1.png) 

  

\- Open NDHGO app

  

 [![](https://lh3.googleusercontent.com/-D8OYD392Rcw/Yfl4G6CgswI/AAAAAAAAI8U/hGPPpeXqG5gRLS3WQcQopTB2xsiNRkaVACNcBGAsYHQ/s1600/1643739158687246-2.png)](https://lh3.googleusercontent.com/-D8OYD392Rcw/Yfl4G6CgswI/AAAAAAAAI8U/hGPPpeXqG5gRLS3WQcQopTB2xsiNRkaVACNcBGAsYHQ/s1600/1643739158687246-2.png) 

  

  

\- Tap on **I'm a Seller**

 **[![](https://lh3.googleusercontent.com/-IF7i2SMmJ_M/Yfl4FlvR1oI/AAAAAAAAI8Q/JX4O4HMyfB0SA-dUExahomuV5aL7JcbCQCNcBGAsYHQ/s1600/1643739154449526-3.png)](https://lh3.googleusercontent.com/-IF7i2SMmJ_M/Yfl4FlvR1oI/AAAAAAAAI8Q/JX4O4HMyfB0SA-dUExahomuV5aL7JcbCQCNcBGAsYHQ/s1600/1643739154449526-3.png)** 

\- Tap on **Start Selling Now**

  

 [![](https://lh3.googleusercontent.com/-a3OZqLwswuU/Yfl4EvmJTFI/AAAAAAAAI8M/oPNwtLILFqUkT-ZgqNJ8ZtJlMDOzXzLBwCNcBGAsYHQ/s1600/1643739150333434-4.png)](https://lh3.googleusercontent.com/-a3OZqLwswuU/Yfl4EvmJTFI/AAAAAAAAI8M/oPNwtLILFqUkT-ZgqNJ8ZtJlMDOzXzLBwCNcBGAsYHQ/s1600/1643739150333434-4.png) 

  

\- Enter your phone number and tap on **Next**

 **[![](https://lh3.googleusercontent.com/-OknpHMZmbTY/Yfl4Di9gEFI/AAAAAAAAI8I/njAGskptzyEISm1Ns3pksGlmxrNTNoqrgCNcBGAsYHQ/s1600/1643739146259052-5.png)](https://lh3.googleusercontent.com/-OknpHMZmbTY/Yfl4Di9gEFI/AAAAAAAAI8I/njAGskptzyEISm1Ns3pksGlmxrNTNoqrgCNcBGAsYHQ/s1600/1643739146259052-5.png)**   

\- You will receive 4 digital OTP to your mobile number, check it and enter here then tap on **Verify**

 **[![](https://lh3.googleusercontent.com/-vMePKjpJsUY/Yfl4CkuMd6I/AAAAAAAAI8E/x-RBf2QxOooUi1K4KOa3tfKcNTQls148ACNcBGAsYHQ/s1600/1643739141960738-6.png)](https://lh3.googleusercontent.com/-vMePKjpJsUY/Yfl4CkuMd6I/AAAAAAAAI8E/x-RBf2QxOooUi1K4KOa3tfKcNTQls148ACNcBGAsYHQ/s1600/1643739141960738-6.png)** 

\- Enter your Full name, Email then tap on **Register**

 **[![](https://lh3.googleusercontent.com/-qt8lnaI74l4/Yfl4BuSxroI/AAAAAAAAI8A/bg8LkBc_SoclirKPFWeob-SNmZprQzk6gCNcBGAsYHQ/s1600/1643739137752329-7.png)](https://lh3.googleusercontent.com/-qt8lnaI74l4/Yfl4BuSxroI/AAAAAAAAI8A/bg8LkBc_SoclirKPFWeob-SNmZprQzk6gCNcBGAsYHQ/s1600/1643739137752329-7.png)** 

\- Select your business type then tap on **Continue**

 **[![](https://lh3.googleusercontent.com/-zsPVV9CIbWs/Yfl4AseB78I/AAAAAAAAI78/kYulrLNXrpgGrP0UjFy2EKrR3txO4SOVACNcBGAsYHQ/s1600/1643739133717871-8.png)](https://lh3.googleusercontent.com/-zsPVV9CIbWs/Yfl4AseB78I/AAAAAAAAI78/kYulrLNXrpgGrP0UjFy2EKrR3txO4SOVACNcBGAsYHQ/s1600/1643739133717871-8.png)** 

\- Upload store logo, Enter store name, Choose store address then tap on **Create store now.**

 **[![](https://lh3.googleusercontent.com/-THx5DmWXoC8/Yfl3_eOGEtI/AAAAAAAAI74/EwpOsVtHPmI9srMBlqadFwQM7-bIOTFBwCNcBGAsYHQ/s1600/1643739129650801-9.png)](https://lh3.googleusercontent.com/-THx5DmWXoC8/Yfl3_eOGEtI/AAAAAAAAI74/EwpOsVtHPmI9srMBlqadFwQM7-bIOTFBwCNcBGAsYHQ/s1600/1643739129650801-9.png)** 

\- Congratulations, your store is successfully created.

  

\-  tap on **Go to Seller Panel**

 **[![](https://lh3.googleusercontent.com/-Xyb2lEmQy6w/Yfl3-cslTpI/AAAAAAAAI70/Zuo7JuBlHXATg10hTqDE7HqYzCVC1Rg3ACNcBGAsYHQ/s1600/1643739125196576-10.png)](https://lh3.googleusercontent.com/-Xyb2lEmQy6w/Yfl3-cslTpI/AAAAAAAAI70/Zuo7JuBlHXATg10hTqDE7HqYzCVC1Rg3ACNcBGAsYHQ/s1600/1643739125196576-10.png)** 

\- In home, tap on **COMPLETE NOW**

 **[![](https://lh3.googleusercontent.com/-fJ2oL5ep6oI/Yfl39RyFGDI/AAAAAAAAI7w/U2dquu1cIkIjzlH5SYYhRg4JiHEyrT7eACNcBGAsYHQ/s1600/1643739120888513-11.png)](https://lh3.googleusercontent.com/-fJ2oL5ep6oI/Yfl39RyFGDI/AAAAAAAAI7w/U2dquu1cIkIjzlH5SYYhRg4JiHEyrT7eACNcBGAsYHQ/s1600/1643739120888513-11.png)** 

  

\- Now, add product, link your bank account, and share your online store.

  

\- once done, Go back.

  

 [![](https://lh3.googleusercontent.com/-71-XODQbT_I/Yfl38BA6BUI/AAAAAAAAI7s/p9dyKoJEzf0JLccYzu7aR93Fi5U74RnjgCNcBGAsYHQ/s1600/1643739116496429-12.png)](https://lh3.googleusercontent.com/-71-XODQbT_I/Yfl38BA6BUI/AAAAAAAAI7s/p9dyKoJEzf0JLccYzu7aR93Fi5U74RnjgCNcBGAsYHQ/s1600/1643739116496429-12.png) 

  

\- In POS, you can create links and request payments.

  

 [![](https://lh3.googleusercontent.com/-TqKpKBM89hQ/Yfl37A6DGkI/AAAAAAAAI7o/wRMxkz9TjpIeoQcKAgnhzAJbZIpITfJuACNcBGAsYHQ/s1600/1643739112293803-13.png)](https://lh3.googleusercontent.com/-TqKpKBM89hQ/Yfl37A6DGkI/AAAAAAAAI7o/wRMxkz9TjpIeoQcKAgnhzAJbZIpITfJuACNcBGAsYHQ/s1600/1643739112293803-13.png) 

 

\- In order, you can check pending orders.

  

 [![](https://lh3.googleusercontent.com/-rQMy7c-W7ew/Yfl36NZax5I/AAAAAAAAI7k/8XACPNqWliYCIqFifOsIohPRCb1V-TcTACNcBGAsYHQ/s1600/1643739107969985-14.png)](https://lh3.googleusercontent.com/-rQMy7c-W7ew/Yfl36NZax5I/AAAAAAAAI7k/8XACPNqWliYCIqFifOsIohPRCb1V-TcTACNcBGAsYHQ/s1600/1643739107969985-14.png) 

  

\- In Poduct, you can add products to your online store.

  

 [![](https://lh3.googleusercontent.com/-Nw0Ga6v98GA/Yfl344mdq-I/AAAAAAAAI7g/pkb90Lx7B_ECMTV9gAK6KBDhsK7TudH-gCNcBGAsYHQ/s1600/1643739072540656-15.png)](https://lh3.googleusercontent.com/-Nw0Ga6v98GA/Yfl344mdq-I/AAAAAAAAI7g/pkb90Lx7B_ECMTV9gAK6KBDhsK7TudH-gCNcBGAsYHQ/s1600/1643739072540656-15.png) 

  

\- In store, yoy can edit your online store website, payment and deliver settings and many more.

  

Atlast, this are just highlighted features of NDHGO there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best app to create online store in india then NDHGO is worthy choice.

  

Overall, NDHGO comes with light mode by default, it has well designed intuitive interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will NDHGO get any major UI changes in future to make it even more better, as of now NDHGO is nice.

  

Moreover, it is definitely worth to mention NDHGO is mobile ready and comes with 24 hr customer support for your business, and according to google play NDHGO is India's rising app to create online store easily for free, yes Indeed if you're searching for such app then NDHGO has potential to become your new favorite, 

  

Finally, this is how NDHGO enables your large and small business go online in less then minute, are you an existing user of NDHGO? If yes do say your experience with NDHGO and mention which feature you like the most in our comment section below, see ya :)