---
title: 'How to add lazyload images script on blogger easily.  '
date: 2023-03-27T12:00:00.000+05:30
draft: false
url: /2023/04/how-to-add-lazyload-images-script-on.html
tags: 
- How
- technology
- Blogger
- Lazyload images
- Add
---

 [![](https://lh3.googleusercontent.com/-Mp8Yx3lFNak/ZEQYiKW_YkI/AAAAAAAAQ58/EJOccpxA7FMBR8WbHJh7OjMwqPKkzIrQwCNcBGAsYHQ/s1600/1682184325077080-0.png)](https://lh3.googleusercontent.com/-Mp8Yx3lFNak/ZEQYiKW_YkI/AAAAAAAAQ58/EJOccpxA7FMBR8WbHJh7OjMwqPKkzIrQwCNcBGAsYHQ/s1600/1682184325077080-0.png) 

  

CMS aka content management system as you may know there are numerous cms  platforms to publish digital content on world wide web of internet out of them WordPress by Automatic Inc. and Blogger by Google are most popular and widely used cms platforms around the world though WordPress is more powerful and advanced than Blogger thanks to feature rich dashboard and plugins but at the end both are super useful and compete edge to edge interms of userbase globally.

  

Blogger do have pretty useful and impressive dashboard with widgets which are more or less equivalent to plugins but they are simple and basic not to the level of WordPress including that blogger only supports HTML, CSS, JavaScript on theme basically template though nowadays they are not enough yet with just them you can do many cool and valuable things which is why a lot of people who want to create basic websites or blogs choose Blogger so that they can manage and maintain whatever digital stuff easily on go.

  

Meanwhile, WordPress comes with thousands of modern plugins and themes including that support more programming languages than blogger like for instance PHP and SQL with them you can create and manage custom heavy database and resources packed websites and blogs efficiently as possible like digital content hosting platforms and community forums etc that's why large percentage of geeks and companies use WordPress to show and reach their digital products or services to people worldwide effectively.

  

Anyhow, if you maintain a website or blog then you may probably already know that  size of website or blog depends on code you have on your theme and uploaded resources like media especially images and videos the more size your website will be in return it takes more Internet data and time to load on browser which is why many people choose less size themes as it increases speed and reduces load time of content on website or blog so that visitors will be able to see things quickly.

  

Especially, the speed of website and blog matters as the faster it is the better will be seo aka search engine optimization that increase chances of content ranking on search engines like Google and Microsoft Bing etc which is why most cms platforms including WordPress and Blogger not only let you edit and remove code of themes but also provide facility to make or add  your own custom themes though it reduce size but it's not everything in order to really speed up it's important to reduce size of resources mainly images and videos.

  

Most people except some beginners before uploading media on cms platforms compress and reduce size of them but sometimes for whatever reasons it's not up to mark which is why to reduce further a lot of them use media compressor or optimizer plugins which are good but thing is to get best seo many people want to further increase speed of website or blog for that we can use lazyload images or videos plugins they delay load of original images or videos by using a different low size image until users scroll down to it's position which increases speed as well as saves data of visitors immensely.

  

There are many lazyload plugins to install for WordPress they techically defer off screen images and videos which all you can simply search and get them but when it comes to Blogger it don't have any default catalog for plugins or scripts Instead you have to find and try number of  different lazyload images scripts created by third party developers online which are not available and compatible for videos as working is not guaranteed you have to test each one of them on your own carefully.

  

Recently, we tried number of lazyload scripts out of them most didn't work on our templates and found issues like no images but luckily we found one amazing working lazyload script which worked on our template flawlessly so if you already tried some scripts I recommend you to try the one we tried as well who know it may work for you, so do you like it? are you interested? If yes let's explore more.

**• How to download Lazyload script •**

\- [Google Drive](https://drive.google.com/file/d/18toSGjr2GF3TutNjErwIaOfLQDMFh_-o/view)

  

**• How to add Lazyload images script on Blogger •**

 **[![](https://lh3.googleusercontent.com/-G08yhjQUAbM/ZERD6vXdU3I/AAAAAAAAQ6Y/-bsglb34AJErd3R-DRFAtOIX9_6U7drsACNcBGAsYHQ/s1600/1682195431314107-0.png)](https://lh3.googleusercontent.com/-G08yhjQUAbM/ZERD6vXdU3I/AAAAAAAAQ6Y/-bsglb34AJErd3R-DRFAtOIX9_6U7drsACNcBGAsYHQ/s1600/1682195431314107-0.png)** 

\- Go to your Blogger dashboard then tap on **≡**

 **[![](https://lh3.googleusercontent.com/-tIwgQj5vdjY/ZERD54eyhlI/AAAAAAAAQ6U/EqXyjPKToRwFomB7zo-FRbLxTO69a4qiACNcBGAsYHQ/s1600/1682195428332092-1.png)](https://lh3.googleusercontent.com/-tIwgQj5vdjY/ZERD54eyhlI/AAAAAAAAQ6U/EqXyjPKToRwFomB7zo-FRbLxTO69a4qiACNcBGAsYHQ/s1600/1682195428332092-1.png)** 

\- Tap on **Theme.**

 **[![](https://lh3.googleusercontent.com/-QutydiYh1r8/ZERD5EFfvSI/AAAAAAAAQ6Q/Q6vbrCRJcP0se9MAVfAXL5pMEW7wlqRQACNcBGAsYHQ/s1600/1682195425279257-2.png)](https://lh3.googleusercontent.com/-QutydiYh1r8/ZERD5EFfvSI/AAAAAAAAQ6Q/Q6vbrCRJcP0se9MAVfAXL5pMEW7wlqRQACNcBGAsYHQ/s1600/1682195425279257-2.png)** 

\- Tap on **Edit HTML.**

 **[![](https://lh3.googleusercontent.com/-S3TzprRTKps/ZERD4T3uhWI/AAAAAAAAQ6M/IP7qJALiOdgqji1Mxid4Pnqr3DB_s3T0QCNcBGAsYHQ/s1600/1682195421447901-3.png)](https://lh3.googleusercontent.com/-S3TzprRTKps/ZERD4T3uhWI/AAAAAAAAQ6M/IP7qJALiOdgqji1Mxid4Pnqr3DB_s3T0QCNcBGAsYHQ/s1600/1682195421447901-3.png)** 

\- Add lazyload script above </body> tag then tap on **⋮** and on **Save.**

That's it, you successfully added lazyload images script on your blogger template.

  

Atlast, this are just highlighted features of Lazyload script there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, anyway if you want one of the best lazyload images script then this one at present seems on go worthy choice.

  

Overall, this lazy load images script is bit lengthy yet simple one that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will Radiogram get any major UI changes in future to make it even more better, as of now it's amazing.

  

Moreover, it's definitely worth to mention this is one of the very few lazyload images script available for blogger templates available out there on world wide web of internet, yes indeed if you're searching for such script then this one has potential to become your new favourite.

  

Finally, this is how you can simply add lazyload images script on blogger template for free, are you an existing user of this lazyload images script? If yes is it working for you if so do say your experience and kindly mention if you know any better lazyload images blogger script in our comment section below, see ya :)