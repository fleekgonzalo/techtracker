---
title: 'Future of CryptoCurrency''s'
date: 2019-12-11T23:43:00.001+05:30
draft: false
url: /2019/12/future-of-cryptocurrency.html
tags: 
- Bitcoin
- Blockchain
- CryptoCurrency
- Sathoshi
---

[![](https://1.bp.blogspot.com/-BUu1gUZuR_4/Xgn39vX25yI/AAAAAAAAAUI/6Q2VQi9seH8O0vDln11B_wsgYF5SLJblwCLcBGAsYHQ/s320/IMG_20191230_184139_309.jpg)](https://1.bp.blogspot.com/-BUu1gUZuR_4/Xgn39vX25yI/AAAAAAAAAUI/6Q2VQi9seH8O0vDln11B_wsgYF5SLJblwCLcBGAsYHQ/s1600/IMG_20191230_184139_309.jpg)

  

When Security was Foremost Priority For Everyone Than the techniques will be improved timely, from the ages of kings to the current government's money and power plays a major from a poor person to the richest person in the world.  

  

We know some facts that kings used to store the treasuries in the unknown islands to the underground secret rooms , to keep the money safe from invaders.

  

Then the era of banks has been started, that begin interesting and being regarded as safe, but later the fraud's begin that people won't imagine that could actually happen.

  

Even the trusted banks becoming an fraud agency either a single person become corrupted that will spoil the image of big banks.

  

The controversy's and security become doubted then public searching for alternative has been started.

  

The big conglomerate companies has been thinking like do the paper money would be really be a vendor in this technology era. Then the alternative is really needed but the currency either its a digital or paper that should be monitored by government.

  

They are several cyrpto currency's, like bitcoin, Bitcoin was the popular most priority considered digital currency,

  

This was started to be in 2008 by sathoshi nakamoto popularly known for implementing the first [blockchain](https://en.m.wikipedia.org/wiki/Blockchain "Blockchain"), deploying the first decentralized [digital currency](https://en.m.wikipedia.org/wiki/Digital_currency "Digital currency")

  

Blockchain would be simply record every transaction that happen through Bitcoin and it is visible to public.

  

Its been the first software of Bitcoin 0.1 has released in 9 January 2009

  

Being unpopular in 2009 Bitcoin future was  unexpectable that after 10years if you a own a single Bitcoin now you'll be a millionaire.

  

That in 2010 that a guy purchased a pizza with 200 Bitcoin's, 

  

Bitcoin rise and downfall can't be judged because it was completely based on mining and usage the more the transactions the more the growth of currency rate of will rise. You can be suprised you wake up tommorow you see a. Bitcoin price was 1crore dollors that you seen yesterday it was just 10lakh dollars.

  

That the Bitcoin use computer or hardware power the transaction charges will be upon it.

  

While as we now know how Bitcoin will work in a simplified view.

  

Now will see the effects that could happen in future and currently happening now.

  

Bitcoin was a secured wallet there no doubt about it, that it uses a secured encryption and considered as future of currency by some well-known business magnates popularly bill-gates.

  

Bitcoin being a peer to peer transaction, and every transaction recorded in blockchain still Bitcoin can't be a alternative unless the government accept it.

  

In the above case the every person who use or store bitcoin definitely needed to be identified by government that any illegal aspects could not take place for different aspects and issues that could rise up without authorized.

  

That some countries put ban on digital currency and some are on hold and some are free. The time when government's not focused on this currency they become a vendor to buy things in Bitcoin accepted shops. 

  

Later, the government taught it become a threat to current currency and unauthorized transaction's that happen with criminals was a big potential threat to the state and human kind.

  

Even the restrictions becoming strong day by day, digital currency situation becoming a roller coaster, that a government identity is compulsory needed to use wallets and other services,

  

However the identity cards are not valid in some countries and some countries are put on digital currency on hold.

  

India is a fastest growing technology hub with a young pubic ratio was high and technology was on rise from last decade that every thing that was happening around the world indian's will start using it,

  

Then the zebpay and other Indian wallets has been started that every indian can easily use in inr format and recharges can be done.

  

While coinbase was popularly considered Bitcoin wallet in the world.

  

Bitcoin has become very popular in india after 2015, and it become a faster lookup on the currency is required for the government to control.

  

However the experts say like this.

  

Bitcoin could be secured and advanced but even though the government ids you are using that you can use for some time, if the government think it was threat to current currency then the government won't think of complety banning it, or in a tough situation government will launch its own digital currency network rather than Bitcoin at any stage.

  

The future of Bitcoin is a puzzle if everything kept at correct spots it could survive, the government will put an eye on growth and results of digital currency's, and now a days a new digital currency for every 3 to 12 months can been seen so you can understand the problems that could arise in a complex technology era a small mistake it can become a big problem.

  

That government unable to control black money even taking extreme measures in different countries the growth of Bitcoin will become headache to the government's.

  

So the effectiveness was still doubty, even having these many issues, that many techies are interested in Bitcoin and many public interested to invest in Bitcoin.

  

That so many people who stored bitcoin's in their devices have lost that they didn't cared about later become very sad.

  

OK let's see, what will happen if bitcoin become a standard and official currency and completely accepted by every counties.

  

1\. Transparency 

  

2\. Security 

  

3\. Record in blockchain

  

4\. Faster

  

5\. No government UPI and other interfaces required, 

  

6\. It will become a threat to banks, that they invested a lot in several things for growth.

  

5\. Industries that completely change payement mode to bitcoin 

  

6\. Unemployment will rise. That major people working in government money related things. Government jobs become less 

  

7\. Can become a major attention to world tech experts and hackers , while some attracts ( Exploits ) has already happen, when it will become official it will become more danger from cyber criminals.

  

8\. Understanding can be problem for children and other visually impaired persons and other handicapped etc. It will become issue only if government only accepting digital currency's, currently the developing countries trying to become digitalized nations.

  

9\. If through some bug or something could take place that would effect much more than currently paper currency world.

  

10\. Concept can be  interesting.

  

Conclusion : 

  

New unheard currency arises, people not expected the growth, it suddenly mesmerized with the figures and got a global attention, government/worried some banned some are on hold, even though it continue to rise and people start using it, while the future can be doubty, currently a roller coaster is going on, do it will go safe or it will break is completely based on puzzle if everything set at right spot we can see a digital currency become completely official in every country,

  

Keep supporting : TechTracker.in