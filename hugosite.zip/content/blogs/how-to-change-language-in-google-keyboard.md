---
title: 'How To Change Language In Google Keyboard ?'
date: 2020-03-23T22:41:00.001+05:30
draft: false
url: /2020/03/how-to-change-language-in-google.html
tags: 
- technology
- translator
- keyboard
- google
- Language
---

  

[![](https://lh3.googleusercontent.com/-Ojs134hBH70/XoIduxxI6sI/AAAAAAAABSI/E05U-_lrqK87nwt7ryDS_3aVQFFYG4nhQCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-20.jpeg)](https://lh3.googleusercontent.com/-Ojs134hBH70/XoIduxxI6sI/AAAAAAAABSI/E05U-_lrqK87nwt7ryDS_3aVQFFYG4nhQCLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-20.jpeg)

  

The major reason that most people use google Keyboard that it comes pre-installed and mainly google keyboard gives many features that really make you stick to keyboard gifs, translator and the latest emoji's.

  

But there is one feature that connect the world other than translator is language selection that you can directly type in your country or state language directy or using english - global language.

  

Today, all the languages mainly in india the official languages 22 are getting importance that giving our language importance is priority thing so government giving and growing importance to the state language on every national platforms and using national language Hindi in most of the meetings and press meets, we thankful.

  

Ok, let's see how to change languages in gboard so that you can type your language in your gboard.

  

You can see the above gboard image as default it set to english long press on it and select language.

  

Once you tap on that you see this screen and then you can now tap on add keyboard and now you can add your language keyboard there are many languages available.

  

Once, you done come back to gboard and now again press on english and select you added lang. keyboard.

  

Now, Enjoy Gboard.