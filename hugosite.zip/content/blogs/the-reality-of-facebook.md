---
title: 'The Reality of Facebook'
date: 2019-12-16T12:32:00.001+05:30
draft: false
url: /2019/12/the-reality-of-facebook_15.html
tags: 
- Messaging
- technology
- Hacking
- Social
- Facebook
---

[![](https://1.bp.blogspot.com/-T75Pp49CrCk/Xgn86pG1QII/AAAAAAAAAUo/7zbYUeBazpEClBHbQ0ub8E9fwLLSs8bQQCLcBGAsYHQ/s320/IMG_20191230_190138_379.jpg)](https://1.bp.blogspot.com/-T75Pp49CrCk/Xgn86pG1QII/AAAAAAAAAUo/7zbYUeBazpEClBHbQ0ub8E9fwLLSs8bQQCLcBGAsYHQ/s1600/IMG_20191230_190138_379.jpg)

  

Facebook known for one of the most popular  

social messaging app, founded by mark zuckerberg and developed with this team together in the Harvard university and being an computer science student he developed some other projects by hacking into college database and creating some website like facematch and hot or not etc...

  

However he go this idea of Facebook one day to text his colleagues and friends and some allegations regarding has popup after Facebook slowly becoming popular, an Indian engineer has made allegation that mark used his project and resembled and copied my idea while this going on Facebook is still usable in college limits.

  

While the name was the Facebook at the time inspired by earlier facematch project, mark really need investment to expand the Facebook to more public after sometime Facebook recognised by two investors who funded it and expanded to nearby colleges and later got some problems in funding and they got out later other investors approached they given more support and it expanded to state and its going to become one of the fastest growing website. 

  

The popularity growing day by day and that mark zuckerberg definately need workers,

  

he got some talented team in his place, they worked day and night with many issues and developed alot with fixing bugs.

  

Mark zuckerberg designed logo in blue and white due to mark have colour blindness problem which he can't see yellow, green, red and f :

  

While Facebook has getting as much as investing they completely released the website to most countries including India and put firewalls in some countries for some reason.

  

When Facebook released in India it was become really become such popular that popular that everyone child wants to create facebook at 10years age to chat with friends, it become a fashion to own a Facebook then anything else, 

  

Facebook is made in such a way if you used to it, it will become addict Facebook themselves agree officially Facebook made for keep on using and the feature kept on polishing and adding according to it.

  

This is the major thing that they understand

What public wanted from them, they when becoming famous and downloads in playstore kept on increasing they changed the Facebook to Facebook. At first Facebook released on 2005 then most availability begin in the year 2007 then android and iOS stores got the fb app the first choice for major public was Facebook and it was no wonder that Facebook have one of the most downloaded app in both appstore & playstore 

  

Like wise, Facebook have major audience for any social media app, either mark have not selled the company to anyone, brought whatsapp and instagram,

  

Wherever there is more audience, it will become a popularity usability tool for politicians to share and get votes for using their own tactics, by the popularity and support that got from public major celebrities have switched to Facebook, 

  

When the major celebrities and politicians of nations showed up in a media officially the opponent country and inner political opponents will keep an eye on it, to make problems on the opponents.

  

Facebook is a hub of people around the world,

Hackers has changed focus on it , this become a major problem for Facebook , reason was simple companies need data, politicians need publicity, hackers wanted to check their capability, some fans intentionally hacked thier favorite celebrity, and some did for fun and some socio psychics have no major other than watching and monitoring chat of public and doing crime according to it. 

  

However, this will be a big problem for Facebook, they tried as much as much possible to prevent and fixed things, the attacts becoming high they increased server and added layers for ddos attacks, this helped a little but they later launched bounty program that will reward if anyone found bugs and report them.

  

Even this things happened, mark zuckerberg fb account was hacked to.. Later they become to rise up the more the attention the more the audience the more dark people interested So they find news ways the increasing features at least give an small bug that effecting large members. The hacking allegations and problems and big fines that was on Facebook has been seen recent years. 

  

Public primary needed thing was an secured and privacy social media app when some things that was effecting an ones privacy then the laws will give punishments for anyone Facebook was one of them as the court leaved putting a big fine.

  

Even having these many problems and allegations on facebook proofs surrounding in internet no major public interested to not use facebook and most public are not aware of this  things. 

  

Well, Facebook future whatever things things popups will be intersting.. But Facebook keep on increasing thier security and praise mark for such a amazing website for us.

  

Conclusion : An individual got an idea developed and expanded slowly and efficiently his teams put heart in it and worked day and night thier hardwork and dedication not got wasted Facebook begin to rise popularity all over the world, when popularity increases problems and hurdles begin facebook was not an exception, Facebook facing them with Sorrowness, Facebook trying thier hard but future is not in thier hands whatever it may be the public need privacy and security when its gone court will fine or punish when it become severe the ban may be not time taken.

  

Keep Supporting: TechTracker.in