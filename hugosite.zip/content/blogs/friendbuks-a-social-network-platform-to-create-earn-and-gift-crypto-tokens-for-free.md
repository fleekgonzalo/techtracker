---
title: 'FriendBuks - A social network platform to create, earn and gift crypto tokens for free.'
date: 2021-11-26T23:59:00.000+05:30
draft: false
url: /2021/11/friendbuks-social-network-platform-to.html
tags: 
- Apps
- Crypto Tokens
- Social Network
- FriendBuks
- Earn
---

 [![](https://lh3.googleusercontent.com/-ns2Zj1VCMKU/YaE71n9zyBI/AAAAAAAAHik/NwR8gcWUGcc7KSt-6K75JeMFo1u59_rEwCLcBGAsYHQ/s1600/1637956564262263-0.png)](https://lh3.googleusercontent.com/-ns2Zj1VCMKU/YaE71n9zyBI/AAAAAAAAHik/NwR8gcWUGcc7KSt-6K75JeMFo1u59_rEwCLcBGAsYHQ/s1600/1637956564262263-0.png) 

  

Internet is filled with different types of social networks where you can share your daily activities with fellow followers and users but most of them do not pay you any thing neither give you any option to gift to your followers, so people whoever want to earn money via thier social media account post ads for money and those who want to gift money to thier followers conduct give aways or contact them directly via chat to send gifts, money, crypto tokens etc.

  

However, these days we got to see many new social networks where user can earn money for just using thier platforms even some social networks giving direct option to user to send money to followers but the problem here is not everyone interested in money while some peeps like crypto who like to earn or gift crypto tokens to thier followers through social network.

  

But, the fact is there are very few social network platforms where you can earn or gift NFT's - non fungible crypto tokens for example : UHIVE is a social network where you can earn UHIVE crypto tokens but the drawback in UHIVE is you can't gift crypto tokens to followers, so if you specifically interested to gift crypto tokens then I say UHive may not work you. 

  

In this scenario, we are glad to announce we have a workaround we found a social network platform named FriendBuks where you can easily create your own NFT : non fungible token with your own name and design even gift your newly created tokens to followers and earn crypto tokens from fellow users by interacting with thier activities then convert them to cash and transfer to bank for free, isn't simple and amazing?

  

In FriendBuks, You will earn tokens when you join activities and you will gift tokens when you post activities, if you regularly do them then the time you spend on app will increase which will spike the value of your token and that will help you get high exchange rate for your tokens, so do you like it? are you interested in FriendBuks? let's know little more info before we sign up and explore more on FriendBuks.

  

**• FriendBuks Official Support •**

\- [Facebook](https://www.facebook.com/FriendBuks/)

\- [Twitter](https://twitter.com/FriendBuks)

\- [YouTube](https://www.youtube.com/channel/UCH4-n6dTjoxRcYy_vhNBdjQ/featured?view_as=subscriber)

\- [Instagram](https://www.instagram.com/friendbuks/)

**Website :** [friendbuks.com](http://friendbuks.com)

**Email :** [resianinnovations@gmail.com](mailto:resianinnovations@gmail.com)

**• How to download FriendBuks •**

It is very easy to get info and download FriendBuks from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.resianinnovations.friendbuks.droid.friendbuks_droid) / [App Store](https://itunes.apple.com/us/app/friendbuks/id1334720320)

**• How to signup on FriendBuks with key features and UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-Z_0260qfOuA/YaE7034D05I/AAAAAAAAHig/EfnyVwQT8P0FBUttmkYnvWiSYV1CBN4cgCLcBGAsYHQ/s1600/1637956560832473-1.png)](https://lh3.googleusercontent.com/-Z_0260qfOuA/YaE7034D05I/AAAAAAAAHig/EfnyVwQT8P0FBUttmkYnvWiSYV1CBN4cgCLcBGAsYHQ/s1600/1637956560832473-1.png)** 

\- Open FriendBuks app.

  

 [![](https://lh3.googleusercontent.com/-6KmDUHHu-Ao/YaE70LZdUUI/AAAAAAAAHic/Ujnje6_NBTQbYuGP4hByllKISfWYQ5IWQCLcBGAsYHQ/s1600/1637956557634388-2.png)](https://lh3.googleusercontent.com/-6KmDUHHu-Ao/YaE70LZdUUI/AAAAAAAAHic/Ujnje6_NBTQbYuGP4hByllKISfWYQ5IWQCLcBGAsYHQ/s1600/1637956557634388-2.png) 

  

\- Enter EMAIL, PASSWORD, then tap on **SIGN UP.**

 **[![](https://lh3.googleusercontent.com/-GODGxQeTt50/YaE7zRNRJuI/AAAAAAAAHiY/atqt4t1e6AM-NZ9CsIDDkrVE9WHjSgEhACLcBGAsYHQ/s1600/1637956554188477-3.png)](https://lh3.googleusercontent.com/-GODGxQeTt50/YaE7zRNRJuI/AAAAAAAAHiY/atqt4t1e6AM-NZ9CsIDDkrVE9WHjSgEhACLcBGAsYHQ/s1600/1637956554188477-3.png)** 

\- Enter First Name, Last Name, Location, Date of Birth, Gender, Bio then tap on **SAVE**.

  

 [![](https://lh3.googleusercontent.com/-XFSsTIi6_P0/YaE7ybcj2zI/AAAAAAAAHiU/VZ09JkbU83YBdb73FUHGIXsU3fNnxH_KgCLcBGAsYHQ/s1600/1637956551036391-4.png)](https://lh3.googleusercontent.com/-XFSsTIi6_P0/YaE7ybcj2zI/AAAAAAAAHiU/VZ09JkbU83YBdb73FUHGIXsU3fNnxH_KgCLcBGAsYHQ/s1600/1637956551036391-4.png) 

  

\- Add profile picture, Enter token name then tap on **SAVE.**

 **[![](https://lh3.googleusercontent.com/-XaIvYWQRAUg/YaE7xn_CKYI/AAAAAAAAHiQ/3luj828FaUEOv4osjxDMeBglIMCKToW4wCLcBGAsYHQ/s1600/1637956547895963-5.png)](https://lh3.googleusercontent.com/-XaIvYWQRAUg/YaE7xn_CKYI/AAAAAAAAHiQ/3luj828FaUEOv4osjxDMeBglIMCKToW4wCLcBGAsYHQ/s1600/1637956547895963-5.png)** 

  

\- Tap on Begin Using FriendBuks

  

 [![](https://lh3.googleusercontent.com/-YHM_L6tnG-s/YaE7w95mCVI/AAAAAAAAHiM/ZldpTEEISGMZHzXhI5k-fmvDhR2RRS_KwCLcBGAsYHQ/s1600/1637956544700636-6.png)](https://lh3.googleusercontent.com/-YHM_L6tnG-s/YaE7w95mCVI/AAAAAAAAHiM/ZldpTEEISGMZHzXhI5k-fmvDhR2RRS_KwCLcBGAsYHQ/s1600/1637956544700636-6.png) 

  

\- You're in FriendBuks, here you find latest activities from fellow users, you can like or dislike, share, join the activities to earn the crypto tokens.

  

\- Each user can set his own settings to activities, you can gift token to followers when they do comment, post photo or Video etc which increase engagement.

  

 [![](https://lh3.googleusercontent.com/-2nj8Nt-AZ8M/YaE7wCI9HQI/AAAAAAAAHiI/HB7mj3tC16QOe97rqmhvEQ2HelZlaxZGgCLcBGAsYHQ/s1600/1637956541750194-7.png)](https://lh3.googleusercontent.com/-2nj8Nt-AZ8M/YaE7wCI9HQI/AAAAAAAAHiI/HB7mj3tC16QOe97rqmhvEQ2HelZlaxZGgCLcBGAsYHQ/s1600/1637956541750194-7.png) 

  

\- In search, you can find PEOPLE, TOKEN and ACTIVITY.

  

 [![](https://lh3.googleusercontent.com/-HTXsUs1Tj4M/YaE7vWCwrtI/AAAAAAAAHiE/OPkjvfWEKZMIjP1iP94DNv5zyqKsKWbNwCLcBGAsYHQ/s1600/1637956538434327-8.png)](https://lh3.googleusercontent.com/-HTXsUs1Tj4M/YaE7vWCwrtI/AAAAAAAAHiE/OPkjvfWEKZMIjP1iP94DNv5zyqKsKWbNwCLcBGAsYHQ/s1600/1637956538434327-8.png) 

  

\- In +, you can create and share activities with specific settings, like you can reward to users who join your activity by replying video, image, comment etc based on the type of activity, you can set it.

  

 [![](https://lh3.googleusercontent.com/-_RqAFpesyF0/YaE7ubKl8MI/AAAAAAAAHiA/q2qPE58fmWwfUnkD46kDF0v2E2EeCf_RwCLcBGAsYHQ/s1600/1637956535302518-9.png)](https://lh3.googleusercontent.com/-_RqAFpesyF0/YaE7ubKl8MI/AAAAAAAAHiA/q2qPE58fmWwfUnkD46kDF0v2E2EeCf_RwCLcBGAsYHQ/s1600/1637956535302518-9.png) 

  

\- Notifications

  

 [![](https://lh3.googleusercontent.com/-Qroyum8vCp8/YaE7tlp3JWI/AAAAAAAAHh8/6LxoD744sXISxhk2Dgq05pUuZe5psHcoQCLcBGAsYHQ/s1600/1637956531576292-10.png)](https://lh3.googleusercontent.com/-Qroyum8vCp8/YaE7tlp3JWI/AAAAAAAAHh8/6LxoD744sXISxhk2Dgq05pUuZe5psHcoQCLcBGAsYHQ/s1600/1637956531576292-10.png) 

  

\- In •••, you can access more options.

  

 [![](https://lh3.googleusercontent.com/-8pqox87IajE/YaE7sruXbBI/AAAAAAAAHh4/W7jLkZWyx2YYk4MaYj5r-SIr-O02enQ3gCLcBGAsYHQ/s1600/1637956527546362-11.png)](https://lh3.googleusercontent.com/-8pqox87IajE/YaE7sruXbBI/AAAAAAAAHh4/W7jLkZWyx2YYk4MaYj5r-SIr-O02enQ3gCLcBGAsYHQ/s1600/1637956527546362-11.png) 

  

\- My profile

  

 [![](https://lh3.googleusercontent.com/-JFn-ScTAojc/YaE7rs1CVRI/AAAAAAAAHh0/V7XDF1f2IN8azPkxzyUlx2QdoA08tjY3wCLcBGAsYHQ/s1600/1637956522579250-12.png)](https://lh3.googleusercontent.com/-JFn-ScTAojc/YaE7rs1CVRI/AAAAAAAAHh0/V7XDF1f2IN8azPkxzyUlx2QdoA08tjY3wCLcBGAsYHQ/s1600/1637956522579250-12.png) 

  

  

\- My wallet, all you token will be stored here, you can convert them to real cash.

  

 [![](https://lh3.googleusercontent.com/-on-EyVd4_cQ/YaE7qesbVPI/AAAAAAAAHhw/GwkPFYtdLLU3QHR19WSV8VSmcYx6ETwbwCLcBGAsYHQ/s1600/1637956518237824-13.png)](https://lh3.googleusercontent.com/-on-EyVd4_cQ/YaE7qesbVPI/AAAAAAAAHhw/GwkPFYtdLLU3QHR19WSV8VSmcYx6ETwbwCLcBGAsYHQ/s1600/1637956518237824-13.png) 

  

\- My Activities

  

 [![](https://lh3.googleusercontent.com/-duraBhpNPBU/YaE7pWVTx1I/AAAAAAAAHhs/sKo7uz5j4sU0hOQNn3tlayv1NTGxdkuFQCLcBGAsYHQ/s1600/1637956513535357-14.png)](https://lh3.googleusercontent.com/-duraBhpNPBU/YaE7pWVTx1I/AAAAAAAAHhs/sKo7uz5j4sU0hOQNn3tlayv1NTGxdkuFQCLcBGAsYHQ/s1600/1637956513535357-14.png) 

  

\- Activities from others

  

 [![](https://lh3.googleusercontent.com/-xhZ6DZc1_84/YaE7od5yKwI/AAAAAAAAHho/MYNltVnMA4AQF6F6oZSmZe33AHVE7JU9gCLcBGAsYHQ/s1600/1637956495968502-15.png)](https://lh3.googleusercontent.com/-xhZ6DZc1_84/YaE7od5yKwI/AAAAAAAAHho/MYNltVnMA4AQF6F6oZSmZe33AHVE7JU9gCLcBGAsYHQ/s1600/1637956495968502-15.png) 

  

\- My Dashboard

  

 [![](https://lh3.googleusercontent.com/-CPogS6rE1Vs/YaE7gWX6vnI/AAAAAAAAHhg/b4trNfihCtIrR_qY7dP2Qgl3rARSTqf2ACLcBGAsYHQ/s1600/1637956462808938-16.png)](https://lh3.googleusercontent.com/-CPogS6rE1Vs/YaE7gWX6vnI/AAAAAAAAHhg/b4trNfihCtIrR_qY7dP2Qgl3rARSTqf2ACLcBGAsYHQ/s1600/1637956462808938-16.png) 

  

\- Privacy Settings

  

 [![](https://lh3.googleusercontent.com/-8d_tqo2mHLk/YaE7bWEoKMI/AAAAAAAAHhY/XNaf0x8wzrgaVD2HsiDp0zb-bkVuchChQCLcBGAsYHQ/s1600/1637956445807545-17.png)](https://lh3.googleusercontent.com/-8d_tqo2mHLk/YaE7bWEoKMI/AAAAAAAAHhY/XNaf0x8wzrgaVD2HsiDp0zb-bkVuchChQCLcBGAsYHQ/s1600/1637956445807545-17.png) 

  

  

 [![](https://lh3.googleusercontent.com/-F4qOgRSXcTU/YaE7XZ1ouWI/AAAAAAAAHhU/599k7X1fuYUm4Yw6hQBHNtzBW2_5vtDbACLcBGAsYHQ/s1600/1637956418462144-18.png)](https://lh3.googleusercontent.com/-F4qOgRSXcTU/YaE7XZ1ouWI/AAAAAAAAHhU/599k7X1fuYUm4Yw6hQBHNtzBW2_5vtDbACLcBGAsYHQ/s1600/1637956418462144-18.png) 

  

  

 [![](https://lh3.googleusercontent.com/-NPCNMpwX0cw/YaE7QSxZ5gI/AAAAAAAAHhQ/NttHh1o3urUrqqm1lIh1K-yW4_DC6-24wCLcBGAsYHQ/s1600/1637956391120810-19.png)](https://lh3.googleusercontent.com/-NPCNMpwX0cw/YaE7QSxZ5gI/AAAAAAAAHhQ/NttHh1o3urUrqqm1lIh1K-yW4_DC6-24wCLcBGAsYHQ/s1600/1637956391120810-19.png) 

  

\- Settings

  

Voila, you successfully registered and explored most features of FriendBuks.

  

Atlast, This are just highlighted key features of FriendBuks there may be many hidden features inbuild that provides you external benefits to give you the ultimate usage experience, so if you want a social network where you can create, earn, gift crypto then FriendBuks can be worthy choice.

  

Overall, FriendBuks is easy to use but user interface seems outdated, FriendBuks developers have to improve it's UI and make it more modern with better colors and graphics included with dark mode as of now FriendBuks UI is not impressive, but we have to wait and see will Friend Bucks get any major UI changes in future to make it even more better, as of now FriendBuks is assuring to use for sure.

  

Moreover, it is worth to mention FriendBuks is one of the very few social network platforms where you can create, earn and gift crypto tokens, even convert the tokens to real cash, simply superb idea and a potential project that has future but app seems like not receiving enough response or attention from public, but i hope it will get more spotlight in future.

  

Finally, This is FriendBuks a free social network to create, earn and gift crypto tokens to fellow users, so do you like it? are you an existing user of FriendBuks? If yes do share your experience and mention which feature you like the most in our comment section below, see ya :)