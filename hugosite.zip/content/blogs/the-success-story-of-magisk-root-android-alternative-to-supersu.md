---
title: 'The success story of Magisk, root Android alternative to SuperSU.'
date: 2022-09-23T20:00:00.001+05:30
draft: false
url: /2022/09/the-success-story-of-magisk-root.html
tags: 
- technology
- The
- Success
- magisk
- Story
---

 [![](https://lh3.googleusercontent.com/-6PII7_0eiJ4/Yyn4KyAaUBI/AAAAAAAAN6k/VnbRy5h2CdM803_khY7jlW-2jwCbiUHFgCNcBGAsYHQ/s1600/1663694887455905-0.png)](https://lh3.googleusercontent.com/-6PII7_0eiJ4/Yyn4KyAaUBI/AAAAAAAAN6k/VnbRy5h2CdM803_khY7jlW-2jwCbiUHFgCNcBGAsYHQ/s1600/1663694887455905-0.png) 

  

  

  

Now,  In this modern world full filled with technologies we are using smartphones every day which came in replacement of keypad mobile phones that boasts an GUI - graphical user interface operating system basically software like computer in hard or static drive storage where you can install and store more digital files and softwares according to storage capacity.

  

But, you can't directly delete system digital files and softwares of smartphones as they are required for operating system to work properly in connection with hardware which is why smartphones makers restrict any type of alteration of them as doing it 

without knowledge can soft or hard brick your smartphone including that it voids device warranty completely.

  

However, many people especially geeks want to modify or change even delete or add certain files into system directory for  customizion of operating system to get more features and options or even remove existing ones etc which is why since the beginning era of smartphones numerous developers created various rooting tricks and softwares to get full system write and read access for number of smartphones.

  

There are many rooting methods for different operating systems for instance on Apple inc. iPhone getting system level access on closed source iOS operating system is known as jailbreak which will allow you to install apps from unknown sources that was prior restricted to only app store due to that you will be free from iOS closed ecosystem which is created to provide best security and privacy.

  

Meanwhile, Google's FOSS aka free and open source operating system Android has 70% world wide smartphone market share concentrated mainly in developing countries like India because of it's less expensive smartphones which is known for customization with ability to install third party apps without rooting due to that many geeks like and prefer Android powered smartphones.

  

Even though, Android also continously upgrading to latest versions constantly to  increase customization at the same time improve and provide security and privacy to it's users more then iOS but still alot of people especially techies and old Android smartphone users like to root because of smartphones makers who stop providing softwares upgrades and security updates after few years as part of marketing plans and strategies for commercial reasons.

  

When Android or any other operating system smartphones don't get required upgrades and updates to keep up to date they will eventually be out dated not just in terms of software but also hardware here's where rooting comes as true savior which  bypass Android system limitations due to that you can install root apps and modules etc which have ability to get new features  catching up latest smartphones.

  

Rooting may extend the life span of Android smartphones little but it don't provide any official security fixes and updates including that as rooting gives complete access to system it allows any skilled hacker to exploit loop holes and simply get into Android devices which is why if you want privacy then it's better to not root as once you done smartphones makers won't send oem updates infinitely.

  

Anyhow, fortunately we have numerous Android rooting softwares out of them Kingoroot is most popular one after that  S-root, framaroot etc all of them used to root alot of Android smartphones in just one click as back in early development phases of Android is not fully secure but later on Android become more secure due to that it became impossible to root without unlocking bootloader for sure.

  

In sense, one click root will only work on old Android version smartphones even if you try on latest ones it won't work instead you'll most likely end up in soft or hard brick mode so be cautious due to that back in time many people searching for alternative Android rooting software which support latest smartphones.

  

Thankfully, Chainfire on well known trusted development forum XDA released  for developers released Android rooting software SuperSu which is not an app that root in one click but an software in archive format that has to be flashed in supported custom recovery like CWM - CyanogenMod or TWRP - team win recovery project then it will root smartphone after that an root app will be installed named SuperSu to maximize root benefits, useful right?

  

Unfortunately, SuperSU after rooting millions of smartphones it's developer Chainfire in year 2016 selled SuperSU to CCMT who released an final update to Android nougut same year after that no more new version rolled out yet at that time developer JohnWu on XDA released Android rooting software Magisk which eventually replaced SuperSU.

  

Magisk is modern Android rooting software better then SuperSU in constant development that support almost all latest smartphones which have in-built root hide mode with alot of features and options for users to utilise full potential and capability of rooting due to that it is now widely used on almost all smartphones and there is no best alternative and opponent as well.

  

John Wu implemented many new features and technologies on Magisk but some of them were removed like in build module repositories and MagiskHide in year 2018 which was used to hide root of device and run certain apps that won't work on rooted devies like banking related ones but after that John Wu released Zygisk which will run Magisk parts in Zygote daeomon that can only hide root of apps.

  

The reason behind removal of MagiskHide is to cut the red tape as John Wu joined Android security team but as Magisk is open source a developer with username TheHitman7 developed custom Magisk with MagiskHide and few extra features that are missing or removed by JohnWu by this it is evident Magisk is flexible.

  

Currently, on every latest update of Magisk developer John Wu releasing new features and option with bug fixes to make it more flexible and support new Android versions and smartphones upcoming in future, so do you like it? are you interested in Magisk ? If yes let's explore more.

  

**• Magisk official support •**

\- [XDA](https://forum.xda-developers.com/t/magisk-general-support-discussion.3432382/)

  

**• How to download Magisk •**

\- [GitHub](https://github.com/topjohnwu/Magisk/releases)

**• Magisk key features with UI / UX overview •**

 **[![](https://lh3.googleusercontent.com/-kPR895DMLZ0/Yyn4JsYzvwI/AAAAAAAAN6g/gb7NY8-3oeU6bg819VevuS0C_u_GzdWvQCNcBGAsYHQ/s1600/1663694883637527-1.png)](https://lh3.googleusercontent.com/-kPR895DMLZ0/Yyn4JsYzvwI/AAAAAAAAN6g/gb7NY8-3oeU6bg819VevuS0C_u_GzdWvQCNcBGAsYHQ/s1600/1663694883637527-1.png)** 

 **[![](https://lh3.googleusercontent.com/-JYVYy7YkW6g/Yyn4I3y-iGI/AAAAAAAAN6c/l5UtiPs6US0WExN8o08uQezMNPQnRqT2gCNcBGAsYHQ/s1600/1663694877798995-2.png)](https://lh3.googleusercontent.com/-JYVYy7YkW6g/Yyn4I3y-iGI/AAAAAAAAN6c/l5UtiPs6US0WExN8o08uQezMNPQnRqT2gCNcBGAsYHQ/s1600/1663694877798995-2.png)** 

 **[![](https://lh3.googleusercontent.com/-T302wEjYpvU/Yyn4GzToubI/AAAAAAAAN6Y/virDOgtCY_g1acEYQKxXxiIkGAOao3regCNcBGAsYHQ/s1600/1663694872572265-3.png)](https://lh3.googleusercontent.com/-T302wEjYpvU/Yyn4GzToubI/AAAAAAAAN6Y/virDOgtCY_g1acEYQKxXxiIkGAOao3regCNcBGAsYHQ/s1600/1663694872572265-3.png)** 

 **[![](https://lh3.googleusercontent.com/-0sw9Dy6csPA/Yyn4F7B31GI/AAAAAAAAN6U/Dhd47TdwyMk6xwfKiyEpGwKlCxWKjrOFACNcBGAsYHQ/s1600/1663694868405672-4.png)](https://lh3.googleusercontent.com/-0sw9Dy6csPA/Yyn4F7B31GI/AAAAAAAAN6U/Dhd47TdwyMk6xwfKiyEpGwKlCxWKjrOFACNcBGAsYHQ/s1600/1663694868405672-4.png)** 

 **[![](https://lh3.googleusercontent.com/-_PiB1WmRjCY/Yyn4E3xs5tI/AAAAAAAAN6Q/S-2PWAELwMkt2t3bfMVgt7HewVDs2ZjOwCNcBGAsYHQ/s1600/1663694864485985-5.png)](https://lh3.googleusercontent.com/-_PiB1WmRjCY/Yyn4E3xs5tI/AAAAAAAAN6Q/S-2PWAELwMkt2t3bfMVgt7HewVDs2ZjOwCNcBGAsYHQ/s1600/1663694864485985-5.png)** 

 **[![](https://lh3.googleusercontent.com/-X1Dl03VnWgc/Yyn4DyUDBDI/AAAAAAAAN6M/zCMFLIqub6MwKbUssn10w2Mm8EOP6cVdgCNcBGAsYHQ/s1600/1663694860099955-6.png)](https://lh3.googleusercontent.com/-X1Dl03VnWgc/Yyn4DyUDBDI/AAAAAAAAN6M/zCMFLIqub6MwKbUssn10w2Mm8EOP6cVdgCNcBGAsYHQ/s1600/1663694860099955-6.png)** 

Atlast, this are just highlighted features of  Magisk there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, anyway if you want one of the best Android rooting software alternative to SuperSU then Magisk on go choice.

  

Overall, Magisk comes with light and dark mode by default, it has clean and simple interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will Magisk Manager get any major UI changes in future to make it even more better as of now it's impressive.

  

Moreover, it is definitely worth to mention Magisk is one of the very few Android rooting software alternative to SuperSU with modern features and big support list of latest smartphones, yes indeed if you are searching for such rooting software then Magisk has potential to become your new favourite for sure.

  

Finally, this is success story of Magisk, am alternative to SuperSU to root Android smartphones, are you an existing user of Magisk? If yes do say your experience and mention why you like Magisk over SuperSU and vice versa and which feature of Magisk you like the most in our comment section below see ya :)