---
title: 'How To Diagnose Website''s ?'
date: 2020-01-12T23:19:00.001+05:30
draft: false
url: /2020/01/how-to-diagnose-website_86.html
tags: 
- technology
- Website
- Waterfall
- Speed
- Diagonose
---

**

  

[![](https://lh3.googleusercontent.com/-TQ-Xt9_wHeg/XhwSDTKOf0I/AAAAAAAAAxo/UVA8eKFKg8wD-kYeqgz9mQXj575_jhwJACLcBGAsYHQ/s1600/IMG_20200113_121325_200.jpg)](https://lh3.googleusercontent.com/-TQ-Xt9_wHeg/XhwSDTKOf0I/AAAAAAAAAxo/UVA8eKFKg8wD-kYeqgz9mQXj575_jhwJACLcBGAsYHQ/s1600/IMG_20200113_121325_200.jpg)

  

  






**

**How to Diagnose Website's ?**

  

Unlike the early stages of websites today we got alot of advancements in the field of web development from multiple languages that support to make website and it was really important to keep everything right to get into in the spotlight from Google to either rank in Google search or to reach more audience the better the website.

  

**Today** we are going to provide some websites that can check totally every things that need to be fixed and suggestions that can improve your site.

  

So let's get stared...

  

**1. **[Sinium.com](Sinium.com)

  

Seo Checker with plenty of tools to check either your site is compatible for search engine optimization and fixes and suggestions for site.

  

**2. **[Pingdom.com/tools](Pingdom.com/tools)

  

Check your website speed in different locations around the world and check where to optimize and get better speed to your site and see where your website lack and fixes that need to be done

  

**3. **[Page Insights By Google](https://developers.google.com/speed/pagespeed/insights/)

  

Fixes, For many things and the higher the score that it means the better your website structured and performed.

  

**4. **[Thinkbygoogle.com](Thinkbygoogle.com)

  

Mobile Website Experience Test By Google With 4g Speed, Check Your Site Performance and Fix what needed to fix in mobile site as it is one of the important thing.

  

**5. **[Lighthouse By Google](https://developers.google.com/web/tools/lighthouse)  

  

Check Errors, Speed, Images Optimize Many more tools with accurate info.

  

**6.** [Dareboost.com](Dareboost.com)

  

Check speed waterfall and speed of your site in 1st and repeat visit in several locations around the world.

  

**7. **[GTMetrix](https://gtmetrix.com/)

  

One of the popular site to check check performance.

  

**8. **[Uptrends](https://www.uptrends.com/tools/website-speed-test)

  

Tools to Check Website Speed, Images, Errors, Suggestions etc.

  

**9. **[DotCom Tools](https://www.dotcom-tools.com/website-speed-test.aspx)[ ](https://www.dotcom-tools.com/website-speed-test.aspx)  

  

Check load speed from 20 countries and detailed report where website have problems and steps to solve with detaied waterfall graph.

  

**10. **[WebPageTest](https://www.webpagetest.org/)

  

Test your site around the world in real browsers at consumer connection speed.

  

This are the ten websites that will diagonose your site and provide steps to fix them and detailed reported where the site lacks and either seo friendly or not, if it was seo friendly with good score than surely you won't have an issue.

> Keep Supporting : TechTracker.in