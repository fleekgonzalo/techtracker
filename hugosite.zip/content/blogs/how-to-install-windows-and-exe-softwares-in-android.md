---
title: 'How to install windows and .exe softwares in android |'
date: 2020-09-20T11:28:00.001+05:30
draft: false
url: /2020/09/how-to-install-windows-and-exe.html
tags: 
- How
- .exe
- install
- Windows
- Android
- windows 10
---

[![](https://lh3.googleusercontent.com/-6ZDoLrTxcvQ/X2bumhgF8PI/AAAAAAAABqE/6glkUUjfgUsDmFvG0TlO9VVL96TaOvXmgCLcBGAsYHQ/s1600/1600581270496390-0.png)](https://lh3.googleusercontent.com/-6ZDoLrTxcvQ/X2bumhgF8PI/AAAAAAAABqE/6glkUUjfgUsDmFvG0TlO9VVL96TaOvXmgCLcBGAsYHQ/s1600/1600581270496390-0.png)

  

It is well known fact that you can't run windows in android as both are different operating system's but there are many ways that you can remote run windows or any OS or .exe softwares using this methods 

  

**However**, you won't get butter smooth experience as you are not running windows or software in your android instead connecting to remote desktop that you installed.

  

\- **Install windows softwares \[ easily \]**

  

**• UserLand** 

  

**• VNC Viewer**

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  

\- **UserLand** 

  

This app provides different operating system's and softwares that can be run through VNC viewer it is very easy to setup.

  

**•** Go to playstore and search and install UserLand.

  

**•** open the app and install the app.

  

• Now you will find many distributions and software's.

  

• **Distributions**

  

\- Kali

  

\- Ubuntu

  

\- Debian

  

\- Arch

  

\- Alpine 

  

**• Browsers** 

  

\- Firefox

**• Desktop**

  

\- Lxde

  

\- Xfce

  

**• Development**

  

\- Git

  

\- Idle

  

**• Game**

  

\- Adventure

  

\- Zork

  

• Math

  

\- Gnuplot

  

\- Octave

  

\- R

  

• **Office**

  

\- Gimp

  

\- Inkscape

  

\- Libreoffice

  

**Now**, select any one of the available software and let the userland app install them.

  

**Once**, the software got installed you can now set the username and password and then go to playstore and install **VNC viewer.**

**Open, **the user land app and tap on the software that you installed and it will redirect to vnc viewer and enter the username and password.

  

**Now**, you successfully installed the software and you can use all the features.

  

For more details : [here](https://play.google.com/store/apps/details?id=tech.ula)

  

**\- Install windows ( easily )**

  

**1**. Go to [www.onworks.net](http://www.onworks.net/)

  

**2**. Install and run windows

  

**3**. Now you can run windows in 25 seconds you can even save the work with complete ISO file or you can save the work to Google drive.

  

**4**. You can even register in the site and save your work.

  

**Do remember** : if you run windows and done no activity in 5 minutes your session will be closed.

  

\- Install windows ( termux )

  

**1**. Go to playstore and install termux app

  

**2**. Now type : **apt update && apt upgrade –y **and press enter.

  

**3**. Now type : **pkg install x11-repo** and press enter.

  

**4**. Now type : **pkg install qemu-system-x86\_64 **and press enter.

  

**5**. Now you have to give access to storage, type : 

**termux-setup-storage** and press enter.  

  

**6**. Now, you have to remember the windows 10 file location in your android.

  

\- Start connection type : “**qemu-system-x86\_64 -m960****cdrom /sdcard/imgcache/Win10CDv2/Win10XPE.iso -vnc 127.0.0.1:2**” and press enter.

  

**7**. Once done, go to vnc viewer 127.0.0.1:2 and give name and tap on **CREATE.**

**Now,** you are running windows 10 on your android phone using termux.

  

**Finally**, this are some valid and authenticated methods to install windows or any other software do mention in our comment section which method you like the most. See ya :)