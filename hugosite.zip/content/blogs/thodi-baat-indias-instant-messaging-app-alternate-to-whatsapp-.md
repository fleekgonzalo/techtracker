---
title: 'Thodi Baat - India''s instant messaging app alternate to WhatsApp!'
date: 2021-10-07T23:52:00.001+05:30
draft: false
url: /2021/10/thodi-baat-indias-instant-messaging-app.html
tags: 
- Apps
- Messaging
- India
- instant
- Thodi Baat
---

 [![Thodi Baat - India's instant own messaging app.](https://lh3.googleusercontent.com/-dEAlfqwEdns/YV860vnQcxI/AAAAAAAAG4E/YMru5HYEUi85GFmO7ul9wO-wKXxW3R80wCLcBGAsYHQ/s1600/1633630927160758-0.png "Thodi Baat - India's own instant messaging app.")](https://lh3.googleusercontent.com/-dEAlfqwEdns/YV860vnQcxI/AAAAAAAAG4E/YMru5HYEUi85GFmO7ul9wO-wKXxW3R80wCLcBGAsYHQ/s1600/1633630927160758-0.png) 

  

  

We have millions of developers availabe in india who have skills and intelligence to create world class apps that can compete industry leading popular apps but due to no encouragement and financial issues, indian developers were unable to create world class apps instead they opting to work under foriegn companies which disrupting thier entrepreneurship, skills and creativity.

  

Indian government from 2019 banned many china apps in india including PUBG due to privacy and security concerns and indian government also noticed that they were not financially beneffiting much from the apps that were developed outside of India and it is also indirectly negatively effecting indian developers to get thier app into spot-light and succeed.

  

India is open economy so they can't restrict or ban overseas technologies or apps until they violates rules and cause problem to nation security, privacy and sovereignty so even if the foriegn apps cause problems and inconvenience to indian developers, indian government can't ban or restrict them as it will give bad effect on india financially and slow down the growth progress of digital technology.

  

However, To fix this problem, Narendra Modi - prime minister of india launched a program named aatma nirbhaar bharat in 2019 which means self reliant india to promote and uplift apps created by the Indian developers by providing rewards, financial help to creative world class competitive apps to improve and expand it's scale further to make it successful as the success of indian apps will provide full benefit and boost india's economy and technology to maximum.

  

The immense effect of Aatma nirbhaar bharat program is in continuous progress as it is inspiring talented developers to unlock thier creativity and develop world class indian desi apps that can compete international apps or become alternative to them like for example : we got to see many indian apps like tooter and koo become alternative to twitter and MX TakaTaka, josh etc become replacement to TikTok after it's ban while all them are successful and brand themselves as inspired by aatma nirbhaar bharat and made in india.

  

We fortunately seen many indian apps in spotlight with success, while most of the Indian developers brand thier apps as an made in india product inspired by aatma nirbhaar bharat which is amazing, now we are glad to announce we found an indian instant messaging app named Thodi baat with numerous potential features that is better then WhatsApp.

  

Thodi baat is currently in early access phase so you may find bugs and issues, but certainly Thodi Baat will be more amazing & better in upcoming releases, even now thodi baat is very nice according to our personal usage experience, so do we got your attention on Thodi Baat? Are you interested in Thodi Baat? If yes let's know little more before we start exploring Thodi Baat.

  

**• Thodi Baat Official Support •**

**Website** : [thodibaat.com](http://thodibaat.com)

**Email** : [sunflowerbiztech@gmail.com](mailto:sunflowerbiztech@gmail.com)

  

**\- App Info =** [Google Play](https://play.google.com/store/apps/details?id=com.thodibaat) **\-**

  

• **How to download Thodi baat •**

  

it is very easy to download Thodi baat from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.thodibaat)

  

**• How to register on Thodi Baat with key features and UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-J47pPdplD48/YV86zhNCiJI/AAAAAAAAG4A/qPvrQgMpKI4AyrUb4DKAKrlrLGPCJ5sewCLcBGAsYHQ/s1600/1633630923274030-1.png)](https://lh3.googleusercontent.com/-J47pPdplD48/YV86zhNCiJI/AAAAAAAAG4A/qPvrQgMpKI4AyrUb4DKAKrlrLGPCJ5sewCLcBGAsYHQ/s1600/1633630923274030-1.png)** 

**\-** Open **Thodi Baat**

 **[![](https://lh3.googleusercontent.com/-1OBlTx6jPyM/YV86yng7fII/AAAAAAAAG38/6ifIina8LmY0L1hv8jZgwD5p1r6jubBSgCLcBGAsYHQ/s1600/1633630919459057-2.png)](https://lh3.googleusercontent.com/-1OBlTx6jPyM/YV86yng7fII/AAAAAAAAG38/6ifIina8LmY0L1hv8jZgwD5p1r6jubBSgCLcBGAsYHQ/s1600/1633630919459057-2.png)** 

 - Tap on **SKIP**

  

 [![](https://lh3.googleusercontent.com/-GwfPayY-K6g/YV86xge8WeI/AAAAAAAAG34/9HgLPwDeKykFurWJljE5BkaiKIC5PdXWACLcBGAsYHQ/s1600/1633630915529598-3.png)](https://lh3.googleusercontent.com/-GwfPayY-K6g/YV86xge8WeI/AAAAAAAAG34/9HgLPwDeKykFurWJljE5BkaiKIC5PdXWACLcBGAsYHQ/s1600/1633630915529598-3.png) 

  

\- Tap on **Okay**

 **[![](https://lh3.googleusercontent.com/-PMOm5ggrz8E/YV86w-3Oq6I/AAAAAAAAG30/M3RP0i3EfBgXO9YgjOmNzrhxVcDEz6GNQCLcBGAsYHQ/s1600/1633630911625253-4.png)](https://lh3.googleusercontent.com/-PMOm5ggrz8E/YV86w-3Oq6I/AAAAAAAAG30/M3RP0i3EfBgXO9YgjOmNzrhxVcDEz6GNQCLcBGAsYHQ/s1600/1633630911625253-4.png)** 

**\-** Enter your phone number and tap on **Next**

 **[![](https://lh3.googleusercontent.com/-xKi4xfzArpc/YV86v1siPvI/AAAAAAAAG3w/344sxXLVVx4WG6wAA36Ym6bfSJy4mxKjQCLcBGAsYHQ/s1600/1633630907955126-5.png)](https://lh3.googleusercontent.com/-xKi4xfzArpc/YV86v1siPvI/AAAAAAAAG3w/344sxXLVVx4WG6wAA36Ym6bfSJy4mxKjQCLcBGAsYHQ/s1600/1633630907955126-5.png)** 

**\-** in order to get OTP to your phone number, you need to first solve captcha in browser on the link provided by thodi baat.

  

 [![](https://lh3.googleusercontent.com/-ES0ReFGfa08/YV86u3rfXWI/AAAAAAAAG3s/0LlzT4expqAg9pY3YpdENfwh0MV8fGVbQCLcBGAsYHQ/s1600/1633630904059625-6.png)](https://lh3.googleusercontent.com/-ES0ReFGfa08/YV86u3rfXWI/AAAAAAAAG3s/0LlzT4expqAg9pY3YpdENfwh0MV8fGVbQCLcBGAsYHQ/s1600/1633630904059625-6.png) 

  

  

\- Once you solve captcha, you will instantly get OTP to your phone number just check your sms box and find OTP recieved from Thodi Baat and acknowledge it then just enter the OTP here and tap on **Verify**.

  

 [![](https://lh3.googleusercontent.com/-2DWBIugZuCI/YV86t7bwFJI/AAAAAAAAG3o/VFVoSJ6Rt9QXQQSmI6XsEosvh6KMF0oKwCLcBGAsYHQ/s1600/1633630900208372-7.png)](https://lh3.googleusercontent.com/-2DWBIugZuCI/YV86t7bwFJI/AAAAAAAAG3o/VFVoSJ6Rt9QXQQSmI6XsEosvh6KMF0oKwCLcBGAsYHQ/s1600/1633630900208372-7.png) 

  

\- Select categories that you are interested in and tap on **Continue**

 **[![](https://lh3.googleusercontent.com/-9mxpm6gRRLM/YV86s5zeL-I/AAAAAAAAG3k/1KIshMPvP6Qle_Q64FGf-Jh4tSSUqzBzACLcBGAsYHQ/s1600/1633630896328482-8.png)](https://lh3.googleusercontent.com/-9mxpm6gRRLM/YV86s5zeL-I/AAAAAAAAG3k/1KIshMPvP6Qle_Q64FGf-Jh4tSSUqzBzACLcBGAsYHQ/s1600/1633630896328482-8.png)** 

**\-** Enter your date of birth and tap on **Continue**

 **[![](https://lh3.googleusercontent.com/-vvgcca7tSOk/YV86ryXB44I/AAAAAAAAG3g/fCcy-H0ZYHYI39weTV6OiTu8dOA6EL9zwCLcBGAsYHQ/s1600/1633630892360220-9.png)](https://lh3.googleusercontent.com/-vvgcca7tSOk/YV86ryXB44I/AAAAAAAAG3g/fCcy-H0ZYHYI39weTV6OiTu8dOA6EL9zwCLcBGAsYHQ/s1600/1633630892360220-9.png)** 

  

**\-** You can chat here.

\- Free Messaging 

\- Private Mode (Online but Offline)

\- Friends and Family Mode

\- Vanish Message

\- Hide Chat

\- Indian Stickers

\- 11 Colorful themes

\- Share data upto 100 MB

  

 [![](https://lh3.googleusercontent.com/-cHd9HJa97HU/YV86q2tDkLI/AAAAAAAAG3c/gT73nQXNBmUvKCgkU3EapC63FDYE_IWXACLcBGAsYHQ/s1600/1633630888404247-10.png)](https://lh3.googleusercontent.com/-cHd9HJa97HU/YV86q2tDkLI/AAAAAAAAG3c/gT73nQXNBmUvKCgkU3EapC63FDYE_IWXACLcBGAsYHQ/s1600/1633630888404247-10.png) 

  

\- You can create group chats with just one tap on **+** and also access groups and chat in it.

  

 [![](https://lh3.googleusercontent.com/-WLllXg5pdHs/YV86p3hmrYI/AAAAAAAAG3Y/_NHEtvIcDg8UO295WyfZE2f02WH6Tuv8gCLcBGAsYHQ/s1600/1633630884886860-11.png)](https://lh3.googleusercontent.com/-WLllXg5pdHs/YV86p3hmrYI/AAAAAAAAG3Y/_NHEtvIcDg8UO295WyfZE2f02WH6Tuv8gCLcBGAsYHQ/s1600/1633630884886860-11.png) 

  

  

  

\- You can check call logs here.

\- Audio and video calls

  

 [![](https://lh3.googleusercontent.com/-7wwmpAc0b0A/YV86pDQ7DcI/AAAAAAAAG3U/fYr6SXja2L8fGL9ql2fIg0kELviVaPkqwCLcBGAsYHQ/s1600/1633630878211621-12.png)](https://lh3.googleusercontent.com/-7wwmpAc0b0A/YV86pDQ7DcI/AAAAAAAAG3U/fYr6SXja2L8fGL9ql2fIg0kELviVaPkqwCLcBGAsYHQ/s1600/1633630878211621-12.png) 

  

\- In settings you can update your profile picture, name and status description, that's it.

  

Congratulations, you successfully learned to register on Thodi Baat and explored all its features.

  

Atlast, This are the only available features available in thodi baat - early access app there may be many upcoming features in future Thodi releases that can provide you external benefits to give you the ultimate usage experience but even with the early access limited features in thodi baat it is truly awesome so if you want the best instant messaging app then Thodi Baat can be worthy choice.

  

Overall, Thodi baat is quick, simple, fast, instant messaging app app that is very easy to use due to its clean and user friendly experience which gives you intuitive user experience but we have to wait & see will Thodi baat get any major UI changes in future to make it even more better, as of now the app have cool user interface that is pleasent.

  

Moreover, it is very important to mention Thodi baat is the one of the very few indian Instant messaging apps available out there on internet and even in early access phase Thodi baat is better then WhatsApp like in many aspects for example : whatsapp have file size send limit of 15mb but in thodi baat you can send upto 100mb and yeah it is also one of the very fews Instant messaging apps that supports 100mb file send size limit, so if you are searching for such Instant Messaging app then Thodi Baat has the potential to become your new favorite.

  

Finally, this is Thodi baat an indian instant messaging app with 100mb file send size limit that is better then WhatsApp, so do you like it? are you an existing user of Thodi baat? if yes do share your experience and mention why you like Thodi baat in our comment section below, see ya :)