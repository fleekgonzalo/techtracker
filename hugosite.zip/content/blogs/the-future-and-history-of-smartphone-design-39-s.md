---
title: 'The Future And History Of Smartphone Design&#39;s'
date: 2020-01-06T12:49:00.001+05:30
draft: false
url: /2020/01/the-changes-of-smartphone-designs_6.html
tags: 
- Design
- phone
- technology
- nokia
- Htc
- Motorola
- Sony
- Samsung
- smartphone
---

  

  

[![](https://lh3.googleusercontent.com/-LkI7KdFutlg/XhLnS69x2xI/AAAAAAAAAkw/3UMRmuoTIXkRRiS1TROxe15s98uEmE04gCLcBGAsYHQ/s1600/20191231_134255-39.jpeg)](https://lh3.googleusercontent.com/-LkI7KdFutlg/XhLnS69x2xI/AAAAAAAAAkw/3UMRmuoTIXkRRiS1TROxe15s98uEmE04gCLcBGAsYHQ/s1600/20191231_134255-39.jpeg)

  

**How important is design in smartphone's ?**

  

Do you ever consider a smartphone like a brick but plenty of features that other phones doesn't have it.

  

**Well, more probably you won't..😂**

  

Smartphone or any device design need to be comfort and travel go either it also need to worth the money that you paid for.

  

Design plays a major factor in every smartphone either to get more sells or to get attention from the purchasers and public.

  

The times from landlines to today world smallest smartphone everything is possible in technology

we changed designs and hardware and capibilty of smartphone's time to time.

  

**It is very interesting how the smartphone's are decade ago and now.**

  

We gone through some classic designs like chunky brick designs to today world's slimmest smartphone.

  

It's the time of advancements we seen keypad phones as time moves we amazed with qwerty keyboard which gives you computer keypad with hardware button with a decent wide screen.

  

It's not yet completed we seen many minor changes in either camera that manufactures tried several ways like slide up camera changing the size of lens to small etc.

  

We seen track balls and capicitive touch buttons and slide up phones integrated with qwerty keyboards not only limited to that even slide up and open up screen devices integrated with class keypad hardware designs.

  

Well, then the time change the after alot of attempts to improvise and release a well developed device improvements are continuing from almost every smartphone company trying thier own design creating and none of the them really given a big attention or have future changing aspect to it.

  

Then one day apple changed the design factor completely the design that mindblowed and change the complete fate not only interms of design but do the smartphone sector.

  

Apple comes with a sleek design with a huge screen - considered a decade ago with an integrated touch software mobilsed qwerty system and no open ups no slide ups and clean camera.

  

It is the first step towards the sleeky designs and comfort designs that we experience today. that Is most company's take inspiration from apple and modify or copy apple design for thier devices as apple is considered trend setter and still going on but apple is not that Steve jobs apple now times changed apple new things not mind-blowing everyone than criticism is more.

  

Ok, let's see as we said earlier design is a primary factor not only for consumers but also for the company's the better the design the better the smartphone standout in market.

  

And, yes features do have a major important role but a brick design with good features can't be a happy toaster every things at good limit can only joyful to public and as the market runs on uniqueness the better the company's focus on every factor the better the company's stand out in a crowd market.

  

Let's see why consumers like better design even there is less features. today we have one of the top notch designs keep on coming that we didn't have dma decade ago we have dot camera bump camera and add-ons to extend camera capabilities with lens etc if design is sleek and rounded edges it feel comfort.

  

Today we see glossy designs and glass coating on back with amazing displays with variety of colours unlike a decade ago there are very few companies that really modified much.

  

Companies like apple, samsung, nokia, motorola, htc have done thier hardwork that we are able to see the world thinnest phone today and thier technology and improvements does made possibility of world smallest phone to.

  

In terms of apple, apple take design seriously that they worked very hard to get a amazing design in the first release iphone 2g later modified a little and kept on releasing phones with same designs and then the notch thing come... Iphone 10 notch is one of the worst design - personally do notch have haters and likers to while samsung made fun of them with thier advertisement 😂 if yoh have not watched watch it you'll like it.

  

Apple say we made the design to work up with face unlock and 3d emojis and do that really make sense while one plus mads that without notch as apple say we integrated 3d scanning in notch to unlock phones in instant..

  

**While a similar twin like you can easily unlock your device 😂**

  

As i said it's not Steve jobs apple.. let's keep that aside even there is alot of criticism for apple, apple still become inspiration to company's for replicated and copied.

  

**Do you ever wondered, why ?**

  

**Nostalgic**, Yes even the design is not upto mark still apple reputation and brand value and lucky factors made company's to modify thier design to match with apple, and another main prime role that made apple design to reach more public is china smartphone's like apple design do whatever apple do they replicated not only design but software to 😂 like oppo and vivo many more companies.

  

But, yeah thanks apple for the designs until notch you bored up after that, and spoiled other phones to.

  

There is a tech giant which like old things...like to build to last and don't try to replicate apple than the company that comes in mind is Sony.

  

**Yes**, sony is mother of invention, either in design, audio, telivision and walkman and list keep on going.

  

Japanese coglomerate sony like to use and follow thier own rules even the demand is high and hyped even after the notch design being to flourish in every budget phones, sony stock to traditional design's and after 2years then they created own design and comes up with cinema wide screen and adding thier technology and displays which add cherishness.

  

Sony is considered as one of the most trusted and most fan base after apple, sony does not added any notch things and stick to thier premium designs till now and it is a good factor like many of notch haters.

  

Sony trying to improvise thier designs, mainly sony focus on user experience either in design software or hardware design is sleek and premium feel and look and mainly sony desig is major factor that devices to sell, moreover sony lacking interms of advertising that sony unable to compete still sony being favorite for either quality , designs and advancements, mainly camera is top notch thanks to sony that they won't compromise.

  

Then the korean company that ruled the world for almost more than decade, don't be scared I'm not saying about north korea 😂 **south korea** tech giant samsung is one of the main company that focus on design.

  

Samsung change design according to the price and series, for example samsungy duos is small and compatible, samsung note series include a touch pen and can be fixed in phone side which is big advancement one of the main reason that samsung have highest design fans, samsung not limited to that samsung edge design in sansung s6 edge which have classy edges which giving amazing look to smartphone, later punch hole display then dot design later samsung not series with pun hole and touch pens and still samsung continuing samsung touch pens which is nice things.

  

Samsung is such a company they keep on getting new things now samsung released foldable phones tablets, and samsung still working very hard to remove camera including in hardware without any irritating punch hole and drop designs they few months back finally showed the technology that can remove traditional camera placements.

  

**Motorola**, who forgot this company if you are living in us you may know this is the company that launched first phone to the world later matorola created designs worked on hardware qwerty later adapted apple iOS designs and technology then dropped out of market.

  

Re-entered in 2014 amazed with budget prices and desgin, with a curvy back and rounded camera with a comfort edges later modified camera to bump.

  

However motorola succeed in producing good design even it's not classic they made thier own cool design into the market with added advantage of good budget prices.

  

Motorola working on razr reback and they releaed some recently which is considered as classic adding today technology advancements.

  

Later motorola add-ons by attaching thier own hardware add-ons to increase capabilities of device extending features like audio, camera and other stuff is interesting.

  

Moreover, motorola selled to Lenovo Chinese tech giant and then alot of criticism begin for motorola that spoiled image of moto.

  

That's being said...

  

Then, **HTC**

  

Htc do like to follow old traditional design's and software too🍭 but due to whatever the reason htc is struggling in terms of productivity and even this time they managed to get good quality products even taught it lacks interms of software or hardware, collabarating with Lava well it's not a big success as well due to the problems htc doesn't have another ways unless to add notch design.

  

Nokia. Well the company from Finland with a river name from duck tapes manufaturing to revolutionizing and being a ruler for almost a decade made thier own touch ups to designs, and yeah like sony nokia likes quality and new, after the iOS and Android arrival, nokia have to do something they collabarating with Microsoft windows and desig nokia premium quality designs is still one of the best even the price considered a little high it worth the bucks.

  

Oh... I forgot google... The company that made the Android open source that you are using right now.. well google do stick to apple designs with modification here and there, either with nexus or pixel and it was good and can be said okish and moreover google not flourish interms of hardware they more actively glorify with software and do magic with code and technology that they created. and google projects like \_\_\_\_\_np. adding own camera modules by remove certain parts adding or modifying, google quietly working on it as some proto types can be seen in some YouTube videos.

  

Extra : Asus being have a unique glossy back finish do have many fan's and can be said it's gives almost any device to premium look and finsish.

  

Future designs of smartphones is really technology based as new things come up company have to modify thier design to fit and integrate according to the technology that they invented.

  

Design is not only about look and feel it was needed to integrate technology and related things in a simplified and user experience matters alot.

  

Lastly, yes companies other than then above stated made thier own designs and improvements but not really trend setting or the hype needed that most of them are minor improvisation's

  

Conclusion : design of phone is considered as prime factor like features design that you see daily is to polish wisely, as tech advancements arise it could apt and adapt according to it. Likely company's worked hard to get new and good designs into the market, while designs like notch are not a trendsetter and companies stick to traditional like sony, still samsung working to get a better designs and technology, future is keep on getting new designs as the technology keep on improvising and let's see what more can be seen in futur...

  

**Will update article, if necessary comment down if you want to add up anything info that could help the article,**

  

Keep supporting : TechTracker.in