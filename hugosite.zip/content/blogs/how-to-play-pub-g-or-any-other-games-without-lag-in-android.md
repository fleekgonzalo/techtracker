---
title: 'How to play PUB-G or any other games without Lag in android ?'
date: 2020-09-14T13:31:00.000+05:30
draft: false
url: /2020/09/how-to-play-pub-g-or-any-other-games.html
tags: 
- How
- Play
- technology
- Lag
- Pubg
- Games
- To
---

[  
  
](https://lh3.googleusercontent.com/-jkOpT0EfDek/X18jZsl72bI/AAAAAAAABnE/FtBlJuGqUHwNYape5v6agwJv742meqWmgCLcBGAsYHQ/s1600/1600070499591286-0.png)

[](https://lh3.googleusercontent.com/-jkOpT0EfDek/X18jZsl72bI/AAAAAAAABnE/FtBlJuGqUHwNYape5v6agwJv742meqWmgCLcBGAsYHQ/s1600/1600070499591286-0.png)[![](https://lh3.googleusercontent.com/-HGssWXppWgY/X19w4-jmSRI/AAAAAAAABng/hNjGCQGSfPI01SGsl6uUEy7aq5eRimrZgCLcBGAsYHQ/s1600/IMG_20200802_174023_304-01-04.jpeg)](https://lh3.googleusercontent.com/-HGssWXppWgY/X19w4-jmSRI/AAAAAAAABng/hNjGCQGSfPI01SGsl6uUEy7aq5eRimrZgCLcBGAsYHQ/s1600/IMG_20200802_174023_304-01-04.jpeg)

**Pub-G** or call of duty or any other heavy resource game require bigger ram and speed **CPU** and **GPU** for good performance.

  

**But**, if your android doesn"t have ram or CPU with sufficient mhz and GPU mhz then you may face glitches and lags while playing games.

  

To fix this android have the ability to modify CPU or GPU mhz to achieve best performance through some apps which requires your device rooted.

  

**Yes**, you must require to root your device because it changes the system level settings of kernel.

  

**For this**, we are using franco kernel manager this app is paid which have ability to modify CPU or GPU mhz per single app instead whole device by giving permission to access system overlays.

  

In this per app basis modification you can save alot of battery and switch back to normal CPU or GPU that your default ROM have it when you close the game or app.

  

Do remember changing this CPU or GPU mhz values without knowledge can get your device into bootloop or hard brick do at your own risk.

  

\- **Franco Kernel Manager**

  

**1**. Go to Playstore

  

**2**. Search for Franco Kernel Manager

  

**3**. Once found, install it.

  

**4**. Now open and give root access.

  

**5**. Now tap on hamburger menu

  

**6**. Now tap on per app profiles

  

**7**. Now tap on CPU and set the maximum : 2016 MHz and minimum : 2016 MHz

  

\- CPU governor : **Performance**

  

**8**. Now tap on GPU and set the maximum : 650 MHz and minimum : 650 MHz.

  

\- GPU governor : **Performance**

  

**9**. Now, once everything done check all the 0 to 7 cpu activated or not if not activated then tap on them to activate all.

  

**10**. You can change brightness, resolution, display orientation, battery saver, display pixel density & display resolution as per you wish.

  

**Once**, your per app settings completed tap on the SAVE button and give any name for it.

  

**\-** Now once you created name for you app profile.

  

**\-** Tap on apply and choose which app or game you want to add the profile settings that you created before.

  

**\-** Once, you tap on that app or game it will be ask to choose the profile, now select the profile you created just before.

  

**\-** You can even edit profiles via editing tab in app and even delete them when needed do make sure to give access to per app accessibility service in options tab.

  

**Now**, wait this settings will work for all apps and games but if you want to get best performance for game like Pub-G 

  

**•** Follow the same steps in Franco Kernel manager for Pub-G and apply the profile.

  

**•** Go to Playstore and search for GFX tool and do the settings like below.

  

**•** Note this settings change from device to device and thier features.

  

**•** this settings are made for 4gb ram and snap dragon 625 chipset and it"s a mid-range hand set.

  

\- **Pub-G GFX tool settings |**

  

**1**. Open GFX tool and Select the pub version that you are using global or korean or any other.

  

**2**. Resolution : 1280hd

  

**3**. FPS : 60fps

  

**4**. Anti aliasing : Disable

  

**5**. Style : choose as per your wish.

  

**6**. Now accept or submit and launch the Pub-G game now you"ll get the benefit.

  

**Now**, both the per app profiles and GFX tools work together to give you best performance in Pub-G without glitches and lags.

  

**Finally**, this is the best and authentic method to play pub g or any other game without glitches & lags do mention in our comment section below if you like this trick, see ya :-)