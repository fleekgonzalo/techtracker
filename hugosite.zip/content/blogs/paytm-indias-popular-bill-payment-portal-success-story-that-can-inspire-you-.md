---
title: 'PAYTM - India''s popular bill payment portal success story that can inspire you! '
date: 2021-02-24T17:08:00.000+05:30
draft: false
url: /2021/02/paytm-indias-popular-bill-payment.html
tags: 
- vijay Shekhar Sharma
- technology
- India
- PayTM
---

[![PAYTM - India's popular bill payment portal success story that can inspire you!](https://lh3.googleusercontent.com/-VRNEatraMvA/YBb796Sb6fI/AAAAAAAADE4/beDo4z9G6B89nc4aM4whzGZHYqmaF8bvACLcBGAsYHQ/s1600/1612119027538220-0.png "PAYTM - India's popular bill payment portal success story that can inspire you!")](https://lh3.googleusercontent.com/-VRNEatraMvA/YBb796Sb6fI/AAAAAAAADE4/beDo4z9G6B89nc4aM4whzGZHYqmaF8bvACLcBGAsYHQ/s1600/1612119027538220-0.png)

  

  

If you are living in India you probably know PayTM is one of the most popular utility and mobile recharge app, it is also one of the best startup success story in India owned by vijay shekar sharma with the company name one97 communications.

[![](https://lh3.googleusercontent.com/-Blp_psC3mnY/YBb78ja5HoI/AAAAAAAADE0/zGICmAiftA0v7sSwbnF11Sy0Nvlmd1C9gCLcBGAsYHQ/s1600/1612119022864501-1.png)](https://lh3.googleusercontent.com/-Blp_psC3mnY/YBb78ja5HoI/AAAAAAAADE0/zGICmAiftA0v7sSwbnF11Sy0Nvlmd1C9gCLcBGAsYHQ/s1600/1612119022864501-1.png)

  

  

PayTM founder Vijay shekar sharma come from lower middle class family he studied

In Hindi medium school from childhood due to that his knowledge on english is poor but still he was managed to get seat in engineering college in Delhi where he was struggling to cope up with english speaking teachers and syllabus but he never give up he used to go to library to learn different types of books including coding languages books where he learned alot then in college. 

  

Vijay shekar sharma used to stay more in library then college reading new books & increasing his grip on english subject and improving his coding skills due to that he sometimes even bunked college and class to stay in library this turned Vijay shekar sharma life to start his own startups in future. 

  

When Vijay shekar sharma completed his engineering course in Delhi engineering college he got job in startup companies and more companies even though the companies pays less salary but he worked in that companies to make him financially stable later he created his own company one97 communications with his friend. 

  

**Now**, when Vijay shekar sharma created one 97 communication he have only few employees working for him but the idea of paytm striked in 2010 when Android is getting popular and most people are able to afford smartphones and day by day more people started utilising digital technology which increasing digital presence. 

  

So, in this scenario Vijay shekar sharma got an idea to start mobile recharge website paytm which is inspired by ATM, paytm is nothing but pay any time money with initial funding of 1 lakh ruppess and help of his friend with few employees but no one believed Vijay shekar sharma including his employees but he never give up he focused on the project and build payTM with the company one 97 commu- nications. 

  

[![](https://lh3.googleusercontent.com/-aJiYf0yAzi8/YBb77tzRZNI/AAAAAAAADEw/4002UVPm18UWJr1MO0WSXPvc4mWiBFEgQCLcBGAsYHQ/s1600/1612119018435540-2.png)](https://lh3.googleusercontent.com/-aJiYf0yAzi8/YBb77tzRZNI/AAAAAAAADEw/4002UVPm18UWJr1MO0WSXPvc4mWiBFEgQCLcBGAsYHQ/s1600/1612119018435540-2.png)

  

  

PayTM is just a basic website at first with only ability to mobile recharge but when it got popularity rising day by day in India they started adding more features and also created mobile app for Android to serve the needs which got popularity like no other recharges app at the time due to the only reason paytm is simple to use and they have this unique cashback and offers system which attracted more people to use to save few money. 

  

Yes, one of the few reasons we can say paytm succeed due to hard work, risk, simple usage, cash back and offers system which really liked by Indian audience so paytm got huge craze but it is just beggining of paytm era the real craze for paytm was on currency ban in 2016 which paytm utilised this scenario and created huge impact on Indian merchants and people to buy and sell products and everything digitally through paytm in sense paytm used currency ban situation more than any recharge app out there including that in one word payTM digitalised India. 

  

[![](https://lh3.googleusercontent.com/-Olau07Es5mc/YBb76e_xt8I/AAAAAAAADEs/-f1N6-kg8yMjxj4-DrYpkyT8MSW6v8efQCLcBGAsYHQ/s1600/1612119014123168-3.png)](https://lh3.googleusercontent.com/-Olau07Es5mc/YBb76e_xt8I/AAAAAAAADEs/-f1N6-kg8yMjxj4-DrYpkyT8MSW6v8efQCLcBGAsYHQ/s1600/1612119014123168-3.png)

  

It is also worth to mention paytm also got popularity due to its shopping section where you can buy products with huge cashbacks using paytm promo codes for just 1rs or 10s to based on promo code this created huge hype and popularity among people which also the reason of success of payTM that we see today including that payTM always strive to provide new features like gold storage which is first in India and digital epan for one year and paytm games, lifafa, etc to benefit people who are using paytm. 

  

Due to the popularity of paytm shopping section which was combined for years with payTM recharge app which they later created and published new shopping app called paytm mall with heavy discount promo codes which people utilized to get huge discount and even got free products which got good appreciation from users and overtime paytm mall is huge success. 

  

[![](https://lh3.googleusercontent.com/-ZByvMIfR38k/YBb75bNQWiI/AAAAAAAADEo/WxlRhfqTtUUxnIXtw3aqq3xmYfcMGgXfACLcBGAsYHQ/s1600/1612119009017354-4.png)](https://lh3.googleusercontent.com/-ZByvMIfR38k/YBb75bNQWiI/AAAAAAAADEo/WxlRhfqTtUUxnIXtw3aqq3xmYfcMGgXfACLcBGAsYHQ/s1600/1612119009017354-4.png)

  

  

PAYTM not only provide new features and heavy discounts with promocodes they also collect donations from people to contribute for india like pm care fund and more which is also one of the reason PAY TM feels like homegrown app compared to other Indian recharge apps due to its india oriented features, banners etc. 

  

PAYTM received huge investment from companies all over the world and the bigger investment is from **Alibaba group **which own big share in payTM and this says the success of PAYTM from the company which have initial funding of 1 lakh ruppess from founder himself and no one believed Vijay shekar sharma at the time including his employees but he never give up due to that today PAYTM is a billion dollar worth company in the world and most popular recharge app in India with the highest downloads. 

  

**Finally**, The success of payTM definitely will inspire alot of people including me do you use PAYTM if yes say your experience of payTM anin comment section below, see ya :-)