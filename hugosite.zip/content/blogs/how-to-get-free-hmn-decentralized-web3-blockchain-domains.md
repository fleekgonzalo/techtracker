---
title: 'How to get free .hmn decentralized Web3 blockchain domains.'
date: 2022-05-17T21:55:00.000+05:30
draft: false
url: /2022/05/how-to-get-hmn-web3-decentralized.html
tags: 
- .hmn
- technology
- free
- Domains
- Web3
---

 [![](https://lh3.googleusercontent.com/-nVpp5ncxb1A/YoPMb9XMaVI/AAAAAAAALBI/-xKkg-AIzckyeH_8r6UOTVJ-N1fUmF7LACNcBGAsYHQ/s1600/1652804715912475-0.png)](https://lh3.googleusercontent.com/-nVpp5ncxb1A/YoPMb9XMaVI/AAAAAAAALBI/-xKkg-AIzckyeH_8r6UOTVJ-N1fUmF7LACNcBGAsYHQ/s1600/1652804715912475-0.png) 

  

  

  

  

We are progressing towards upgraded security and privacy focused decentralized internet known as Web3 as of now it is still in early phase and not many know about it but when Bitcoin a decentralized crypto currency launched in 2009 since slowly we got to see numerous web3 decentralized platforms.

  

Especially, from past few years Web3 platforms are on rise thanks to crypto enthusiasts and big investors we now have thousands of decentralized crypto currencies and DeFi platforms not just them we also have Web3 platforms like decentralized websites, dVPNs, cloud storage, social networks etc.

  

**[\+ Cactus - A simple decentralized comment system for privacy.](https://www.techtracker.in/2022/04/cactus-simple-decentralized-comment.html)**

**[\+ Storj - best decentralized cloud storage for security and privacy.](https://www.techtracker.in/2022/04/storj-best-decentralized-cloud-storage.html)**

**[\+ How to create Web3 decentralized website using Fleek for free.](https://www.techtracker.in/2022/04/how-to-create-web3-decentralized.html)**

**[\+ Steemit - best decentralized social network to earn crypto online.](https://www.techtracker.in/2022/04/steemit-best-decentralized-social.html)**

**[\+ Funkwhale - A decentralized social platform to get free licensed music.](https://www.techtracker.in/2022/04/funkwhale-decentralized-social-platform.html)**

**[\+ Exidio dVPN - Get 500GB of decentralized privacy for $1.](https://www.techtracker.in/2022/03/exidio-dvpn-get-500gb-of-decentralized.html)**

**[](https://www.techtracker.in/2022/01/sentinel-lite-de-centralised-vpn-for.html)[\+ Sentinel Lite - A de-centralised VPN for more privacy.](https://www.techtracker.in/2022/01/sentinel-lite-de-centralised-vpn-for.html)**

  

You may probably know we're now in web2.0 a upgraded version of web1.0 where most websites are hosted on centralized servers provided by single or multiple companies who can control all your website data whenever they insist with or without your permission thus you're data is not safe and secure including that hackers can exploit centralized servers and hack websites to gain access to data.

  

Even popular websites from big companies like facebook and Google are prone to hacking as they are hosted on centralized servers, but now fortunately we have several decentralized Web3 platforms where you can get Web3 domains and decentralized sites.

  

In Web3, Website data are divided into number of parts and encrypted using best encryption like AES 256 then they will be hosted on decentralized servers provided  by individuals like you from around the world known as nodes so as your website is hosted on numerous servers it is very hard even impossible to hack your website and Web3 websites will never go offline because if one node is down then another node will be running.

  

While, Decentralized Web3 domains are very new just 1year back impervious inc. launched world's first truly decentralized domain from then numerous companies involved and started providing Web3 decentralized domains like unstoppable domains and ens etc which are most costly then centralized domains.

  

Decentralized domains are connected to blockchain wallets instead of domain registries due to that they provide best security and privacy and now a days most decentralized centralized domains are connected and based on blockchain thus your domain can't be deleted by registry or blocked by DMCA as usually all Web3 decentralized are censorship resistant.

  

However, there is no platform available on internet that provide free decentralized Web3 domains but recently we found a platform sponsered by butterfly protocol and cortex app which provide .hmn aka .human blockchain domains for free, you just have to provide phone number and rest is handled, so do you like it? are you interested in .hmn blockchain domain? If yes let's know little more info before we explore more.

  

**• .hmn domains official support •**

\- [BProto](https://www.bproto.io/)

\- [Cortex](https://www.crtx.app/)

  

**Website :** [hmn.domains](http://hmn.domains)

  

**• How to get .hmn Web3 decentralized blockchain domain for free with key features and UI / UX overview •**

 **[![](https://lh3.googleusercontent.com/-UZxcbQbnwQU/YoS7c5fk_-I/AAAAAAAALCA/LSQO0-eSkm8XxNKtScep9RhUHtv75V1IwCNcBGAsYHQ/s1600/1652865903934983-0.png)](https://lh3.googleusercontent.com/-UZxcbQbnwQU/YoS7c5fk_-I/AAAAAAAALCA/LSQO0-eSkm8XxNKtScep9RhUHtv75V1IwCNcBGAsYHQ/s1600/1652865903934983-0.png)** 

\- Open your crypto wallet like TrustWallet, MetaMask then tap on **DApps**

 **[![](https://lh3.googleusercontent.com/-OdBsDKQBpz0/YoS7cE4CCZI/AAAAAAAALB8/iHrPLD4KQuM9peJ67e0lxtk1lGlpjTCsACNcBGAsYHQ/s1600/1652865901429753-1.png)](https://lh3.googleusercontent.com/-OdBsDKQBpz0/YoS7cE4CCZI/AAAAAAAALB8/iHrPLD4KQuM9peJ67e0lxtk1lGlpjTCsACNcBGAsYHQ/s1600/1652865901429753-1.png)** 

\- In search, enter and go to [hmn.domains](http://hmn.domains).

  

 [![](https://lh3.googleusercontent.com/-h0ujS5Xg_9w/YoS7bWRuQuI/AAAAAAAALB4/uR8E6jLjak0gzdxLLv6mUtK9Q6NMP0FAgCNcBGAsYHQ/s1600/1652865897959341-2.png)](https://lh3.googleusercontent.com/-h0ujS5Xg_9w/YoS7bWRuQuI/AAAAAAAALB4/uR8E6jLjak0gzdxLLv6mUtK9Q6NMP0FAgCNcBGAsYHQ/s1600/1652865897959341-2.png) 

  

\- Tap on Ethereum icon.  

  

 [![](https://lh3.googleusercontent.com/-hKGK805bB6E/YoS7aS8hVzI/AAAAAAAALB0/njE3VdhKMNsicp2CcgDBC_pMsTXMUUzVACNcBGAsYHQ/s1600/1652865894003235-3.png)](https://lh3.googleusercontent.com/-hKGK805bB6E/YoS7aS8hVzI/AAAAAAAALB0/njE3VdhKMNsicp2CcgDBC_pMsTXMUUzVACNcBGAsYHQ/s1600/1652865894003235-3.png) 

  

\- Tap on **Polygon**  

 **[![](https://lh3.googleusercontent.com/-Cti905FLx20/YoS7Zt_KD-I/AAAAAAAALBw/tq8BJDaKpe4gQrgfZ85hQY2nVKZ3OOW9gCNcBGAsYHQ/s1600/1652865890368667-4.png)](https://lh3.googleusercontent.com/-Cti905FLx20/YoS7Zt_KD-I/AAAAAAAALBw/tq8BJDaKpe4gQrgfZ85hQY2nVKZ3OOW9gCNcBGAsYHQ/s1600/1652865890368667-4.png)** 

\- Tap on **Connect Wallet**

 **[![](https://lh3.googleusercontent.com/-x5SIxr-_FZE/YoS7YtGqSjI/AAAAAAAALBs/WeCQBI6B4SAFb3EqV4KI8qeBA8nsLU-OwCNcBGAsYHQ/s1600/1652865887140286-5.png)](https://lh3.googleusercontent.com/-x5SIxr-_FZE/YoS7YtGqSjI/AAAAAAAALBs/WeCQBI6B4SAFb3EqV4KI8qeBA8nsLU-OwCNcBGAsYHQ/s1600/1652865887140286-5.png)** 

\- Select MetaMask even if you're on other crypto wallet like TrustWallet, it will work for sure.

 **[![](https://lh3.googleusercontent.com/-ArZ0WB307So/YoS7X3A06sI/AAAAAAAALBo/2H2VrzCx35gr8_zixoJlSVOMwzd5EKEawCNcBGAsYHQ/s1600/1652865883497826-6.png)](https://lh3.googleusercontent.com/-ArZ0WB307So/YoS7X3A06sI/AAAAAAAALBo/2H2VrzCx35gr8_zixoJlSVOMwzd5EKEawCNcBGAsYHQ/s1600/1652865883497826-6.png)** 

\- Tap on **CONNECT**

 **[![](https://lh3.googleusercontent.com/-6CBlnlDEb60/YoS7W4aZONI/AAAAAAAALBk/X8FNW51ZZNMVCPL5SEHt5Vm3tGWRy9U8ACNcBGAsYHQ/s1600/1652865871213386-7.png)](https://lh3.googleusercontent.com/-6CBlnlDEb60/YoS7W4aZONI/AAAAAAAALBk/X8FNW51ZZNMVCPL5SEHt5Vm3tGWRy9U8ACNcBGAsYHQ/s1600/1652865871213386-7.png)** 

  

\- Tap on **Get Started.**

 **[![](https://lh3.googleusercontent.com/-_ariOVM8QdQ/YoS7T4L3dPI/AAAAAAAALBg/go6q3FxpQJAUyhFtHkHJsbcTHa8pgfe4ACNcBGAsYHQ/s1600/1652865859902067-8.png)](https://lh3.googleusercontent.com/-_ariOVM8QdQ/YoS7T4L3dPI/AAAAAAAALBg/go6q3FxpQJAUyhFtHkHJsbcTHa8pgfe4ACNcBGAsYHQ/s1600/1652865859902067-8.png)** 

\- Tap on **Generate Tweet**

  

 [![](https://lh3.googleusercontent.com/-vDJW6j8Cals/YoPMS29jgFI/AAAAAAAALAk/dsItVQf7XGcFgERAoW3tRq8TPclmm-JNQCNcBGAsYHQ/s1600/1652804654983499-8.png)](https://lh3.googleusercontent.com/-vDJW6j8Cals/YoPMS29jgFI/AAAAAAAALAk/dsItVQf7XGcFgERAoW3tRq8TPclmm-JNQCNcBGAsYHQ/s1600/1652804654983499-8.png) 

  

\- You need to have Twitter account to get .hmn domain so create it if you don't have then tweet it and remember you will get .hmn blockchain domain based on your Twitter account username.

  

 [![](https://lh3.googleusercontent.com/-EZPlWWE8x9Q/YoPMLo0XBeI/AAAAAAAALAc/lX9CfK6EWT88G-lSgY7OOPEbNc0q7LulgCNcBGAsYHQ/s1600/1652804599461715-9.png)](https://lh3.googleusercontent.com/-EZPlWWE8x9Q/YoPMLo0XBeI/AAAAAAAALAc/lX9CfK6EWT88G-lSgY7OOPEbNc0q7LulgCNcBGAsYHQ/s1600/1652804599461715-9.png) 

  

\- With in 30 minutes, your .hmn domain registration request will be submitted on [polygonscan.com](https://polygonscan.com/tx/0x6a0e3ce5b49bc541faf078585d47035faaafc898012387531f6fb6230b513684)

  

 [![](https://lh3.googleusercontent.com/--QpY32oR504/YoPL9d8_pJI/AAAAAAAALAY/RpS7xJjLt4gtDTOvByhHO5FOpiRvV5CrwCNcBGAsYHQ/s1600/1652804571056317-10.png)](https://lh3.googleusercontent.com/--QpY32oR504/YoPL9d8_pJI/AAAAAAAALAY/RpS7xJjLt4gtDTOvByhHO5FOpiRvV5CrwCNcBGAsYHQ/s1600/1652804571056317-10.png) 

  

\- Bingo, once domain is submitted on Polygonscan it will become NFT asset which you can check and sell on NFT marketplaces like OpenSea.

  

Atlast, this are just highlighted features of .hmn domains there may be many hidden features in-build that provides external benefits to give the ultimate usage experience, anyway if you want one of the best platform to get free decentralized blockchain domains then hmn domains is worthy choice for sure.

  

Overall, .hmn domains site has light mode by default, it has well simple and clean interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will .hmn domain get any major UI changes in future to make it even more better, as of now it's fine.

  

Moreover, it is definitely worth to mention .hmn domains is one of the ber few platforms available out there on internet which provide decentralized Web3 blockchain domains for free and as per butterfly protocol and cortex app .hmn domains are successful thus they are planning to release more 4 free blockchain domains in future, isn't awesome?

  

Finally, this is how you can get free .hmn blockchain domains from butterfly protocol and cortex app, are you an existing user of .hmn domain? If yes do say your experience and mention why you like decentralized blockchain domains in our comment section below, see ya :)