---
title: 'Amaze - Best Bubble Browser With Media Sniffer On Android For Free. '
date: 2021-05-20T13:21:00.000+05:30
draft: false
url: /2021/05/amaze-best-bubble-browser-with-media.html
tags: 
- browser
- Apps
- Bubble
- Amaze
- Media Sniffer
---

  

 [![Amaze - Best Bubble Browser With Media Sniffer On Android For Free.](https://lh3.googleusercontent.com/-K02tPSdtdkc/YKYVGpFz1nI/AAAAAAAAEn0/93JYGPs5tXomA2hHIJlXxlYBL_WfqHbzwCLcBGAsYHQ/s1600/1621497110902081-0.png "Amaze - Best Bubble Browser With Media Sniffer On Android For Free.")](https://lh3.googleusercontent.com/-K02tPSdtdkc/YKYVGpFz1nI/AAAAAAAAEn0/93JYGPs5tXomA2hHIJlXxlYBL_WfqHbzwCLcBGAsYHQ/s1600/1621497110902081-0.png) 

  

It is very important to do multi-tasking on your Android device, if you are able to use browser without closing other apps or any other works on Android device will surely save alot of time and help you start more works with nice multi-tasking experience that you may like. 

  

**So**, Do you want to use browser app and surf internet without closing other apps it is now possible on Android, but there are very few browsing apps available that will help you surf internet without closing or leaving other apps. But most browsers available on playstore which have this feature doesn't have good quality due to that you may not get nice multi-tasking experience on your Android device. 

  

**In this scenario**, we found a workaround we found a browsing app named **Amaze** that will create a floating bubble on your Android device which you can Drag and Set anywhere on screen without closing other apps that you currently using so it will give ability to do multi-tasking.

  

**Yes**, Amaze browser popup bubble mode will loads webpage in the background by not interrupting your workflow with the current app. You can also search or enter address, access your bookmarks directly in bubble mode, switch between bubble mode and full browser mode without reloading a single webpage.  

  

**However**, Amaze browser also have inbuild media sniffer that will automatically detect any audio or video which you can download and play including that you can cast web video/audio to Chromecast and bubble mode, Amaze browser also have much needed ad-blocker with fast download manager with Multi-Threading support. 

  

**• Amaze Browser Key features •**

**\-** Start page

\- Bookmarks

\- Private/Incognito

\- Multi-tabs

\- No-image mode

\- Search engine switch

\- Desktop mode

\- Rendering mode

\- Customization (theme/layout)

\- Bubble browser mode

\- Ad-block

\- Video/audio detection

\- Download manager

\- Chromecast support

  

• Amaze Browser Official Support •

  

\- [XDA](https://forum.xda-developers.com/t/app-4-4-amaze-browser-adblock-fast-download-chromecast-support.3508876/)

  

\- **App Info** - [Google Play](https://play.google.com/store/apps/details?id=com.sibimobilelab.amazebrowser) \-

  

• How to download Amaze Browser •

  

It is very easy to download Amaze Browser from these platforms for free. 

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.sibimobilelab.amazebrowser)

\- [Apkpure](https://m.apkpure.com/amaze-browser-cast-web-videos/com.sibimobilelab.amazebrowser)

  

• **How to use Amaze Browser Popup / Bubble Mode • **

 **[![](https://lh3.googleusercontent.com/-bH4owJgDKbw/YKYVFvQ4hwI/AAAAAAAAEns/O9b9RzHYrTwooOba1lPBWnlXnnKg_rrRgCLcBGAsYHQ/s1600/1621497101575081-1.png)](https://lh3.googleusercontent.com/-bH4owJgDKbw/YKYVFvQ4hwI/AAAAAAAAEns/O9b9RzHYrTwooOba1lPBWnlXnnKg_rrRgCLcBGAsYHQ/s1600/1621497101575081-1.png)** 

\- Open **Amaze Browser** and Tap on **Menu**. 

  

 [![](https://lh3.googleusercontent.com/-IHfGWjcL2D0/YKYVDUVDf3I/AAAAAAAAEno/3hkpNWwWyQcpwZ5YhHBuyKFOsHsSuTyswCLcBGAsYHQ/s1600/1621497095602538-2.png)](https://lh3.googleusercontent.com/-IHfGWjcL2D0/YKYVDUVDf3I/AAAAAAAAEno/3hkpNWwWyQcpwZ5YhHBuyKFOsHsSuTyswCLcBGAsYHQ/s1600/1621497095602538-2.png) 

  

\- Tap on **Switch to Bubble Mode**. 

  

 [![](https://lh3.googleusercontent.com/-xB_zIbvBmpA/YKYVB_hkuEI/AAAAAAAAEnk/cDZyHXR29iwdEpsS1Je0e71YQmVwIWYYQCLcBGAsYHQ/s1600/1621497083380582-3.png)](https://lh3.googleusercontent.com/-xB_zIbvBmpA/YKYVB_hkuEI/AAAAAAAAEnk/cDZyHXR29iwdEpsS1Je0e71YQmVwIWYYQCLcBGAsYHQ/s1600/1621497083380582-3.png) 

  

\- **Now**, You Activated **Bubble Mode**, Tap on **Popup / Bubble** Icon To **Browse**. 

  

 [![](https://lh3.googleusercontent.com/-yb46OUpGcDc/YKYU-36jXPI/AAAAAAAAEng/YVOysnJMrd0oFvJ1816SmB7f10fSdXGWgCLcBGAsYHQ/s1600/1621497071406544-4.png)](https://lh3.googleusercontent.com/-yb46OUpGcDc/YKYU-36jXPI/AAAAAAAAEng/YVOysnJMrd0oFvJ1816SmB7f10fSdXGWgCLcBGAsYHQ/s1600/1621497071406544-4.png) 

  

\- Enter your **website url** and search it, then tap re-tap on bubble to access background current **workflow app.** Thats it. 

  

• **How to use Amaze Browser Media sniffer Mode •**

 **[![](https://lh3.googleusercontent.com/-vTlKmBiCswk/YKYU75VGiUI/AAAAAAAAEnc/8l_iUEp_CTwe09wyl0gjwy-SZk0xQc5zQCLcBGAsYHQ/s1600/1621497066680008-5.png)](https://lh3.googleusercontent.com/-vTlKmBiCswk/YKYU75VGiUI/AAAAAAAAEnc/8l_iUEp_CTwe09wyl0gjwy-SZk0xQc5zQCLcBGAsYHQ/s1600/1621497066680008-5.png)** 

\- Open **Amaze Browser** and Tap on **Menu**. 

  

 [![](https://lh3.googleusercontent.com/-_Xivt953Mdw/YKYU6snSXdI/AAAAAAAAEnY/VPHveQ5-8P4nBrLqUh9tfvld1A1BDxbgACLcBGAsYHQ/s1600/1621497060818811-6.png)](https://lh3.googleusercontent.com/-_Xivt953Mdw/YKYU6snSXdI/AAAAAAAAEnY/VPHveQ5-8P4nBrLqUh9tfvld1A1BDxbgACLcBGAsYHQ/s1600/1621497060818811-6.png) 

  

\- Turn on **Media Detection Mode. **

 **[![](https://lh3.googleusercontent.com/-KwLFwtHu9fk/YKYU5KHRvfI/AAAAAAAAEnU/UwHN3kWquGEuKcT9hDi6r4oaKP3b5VrdACLcBGAsYHQ/s1600/1621497055127474-7.png)](https://lh3.googleusercontent.com/-KwLFwtHu9fk/YKYU5KHRvfI/AAAAAAAAEnU/UwHN3kWquGEuKcT9hDi6r4oaKP3b5VrdACLcBGAsYHQ/s1600/1621497055127474-7.png)** 

**\- In search, **Go to your website where you want to **Download Media,** Amaze Browser will automatically detect **Media** files and show you at bottom, Tap on **numericals**. 

  

 [![](https://lh3.googleusercontent.com/-J4DSrenqHAo/YKYU3my-SjI/AAAAAAAAEnQ/t_W78M5mRR45xO4Em0aKdn5ulv1qfkmiQCLcBGAsYHQ/s1600/1621497050531541-8.png)](https://lh3.googleusercontent.com/-J4DSrenqHAo/YKYU3my-SjI/AAAAAAAAEnQ/t_W78M5mRR45xO4Em0aKdn5ulv1qfkmiQCLcBGAsYHQ/s1600/1621497050531541-8.png) 

  

\- Tap on detected media either it's Audio or Video to **Download** or **Play**. 

  

 [![](https://lh3.googleusercontent.com/-lmoDgljzoFo/YKYU2SkpwfI/AAAAAAAAEnM/mvqWOuyYJwYRbfuqyt83l_jqEQxv5-vVQCLcBGAsYHQ/s1600/1621497046101866-9.png)](https://lh3.googleusercontent.com/-lmoDgljzoFo/YKYU2SkpwfI/AAAAAAAAEnM/mvqWOuyYJwYRbfuqyt83l_jqEQxv5-vVQCLcBGAsYHQ/s1600/1621497046101866-9.png) 

  

\- You can now **download** or **play** and even, chromecast tap on the option you like. 

  

 [![](https://lh3.googleusercontent.com/-fIYRKj3cJHg/YKYU1YuY_WI/AAAAAAAAEnI/S1EcdF9DID8H7zwTnN7vot9VJWzKXcfKgCLcBGAsYHQ/s1600/1621497041907896-10.png)](https://lh3.googleusercontent.com/-fIYRKj3cJHg/YKYU1YuY_WI/AAAAAAAAEnI/S1EcdF9DID8H7zwTnN7vot9VJWzKXcfKgCLcBGAsYHQ/s1600/1621497041907896-10.png) 

  

**\- If downloading**, tap and select download mansger that you wanna use. 

  

 [![](https://lh3.googleusercontent.com/-uLKleEjMFYg/YKYU0cv4txI/AAAAAAAAEnE/QfwvknTwQLsUEFVZLRyjg8DD5NpWRNVigCLcBGAsYHQ/s1600/1621497036526500-11.png)](https://lh3.googleusercontent.com/-uLKleEjMFYg/YKYU0cv4txI/AAAAAAAAEnE/QfwvknTwQLsUEFVZLRyjg8DD5NpWRNVigCLcBGAsYHQ/s1600/1621497036526500-11.png) 

  

\- if you selected Amaze **in-build** **download**

manager it will start download **instantly**. 

  

**Yay**, You successfully learnt how to use bubble mode and media sniffer on the Amaze Browser. 

  

**Atlast,** Amaze Browser is the best popup bubble mode with media sniffer Browser available on play store, while other popup or floating browsers available on Google play store is not upto the Amaze browser standards, when we compare other bubble browser apps with Amaze browser, then Amaze browser will be the **Winner**. 

  

**Overall**, Amaze Browser is very easy to use due to its simple user interface which will gives you optimzed clean user experience but we have to wait and see will Amaze browser get any major UI changes in future to make it even more better, as of now Amaze browser have perfect user interface and user experience that you may like to use for sure.   

  

**Moreover**, it is worth to mention Amaze is top bubble browser with media sniffer and chrome cast app available in internet, **Yes**, Indeed so, if you are searching for an best popup bubble browser with media sniffer and chromecast then we recommend you to choose Amaze browser, it has potential to become your new favourite.   

  

**Note**, This browser is built on top of system webview, if you're on Android 5+, update your system webview to the latest version for better compatibility. Download videos from **YouTube** is not supported due to their term of services. So you are not able to download YouTube videos for that you have to use some other websites or apps. 

  

**Finally,** this is how you can multi-task with amaze browser popup bubble mode and it will also help you download media with its powerful media detecting feature included with required chromecast, do you like it? If yes have you tried it? If you are user of the amaze browser say experience and why do you like **Amaze browser** in our comment section below, see ya :)