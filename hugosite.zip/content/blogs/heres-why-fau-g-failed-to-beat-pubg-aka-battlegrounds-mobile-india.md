---
title: 'Here''s why, FAU-G failed to beat PUBG aka Battlegrounds Mobile India.'
date: 2022-04-20T22:51:00.001+05:30
draft: false
url: /2022/04/heres-why-fau-g-failed-to-beat-pubg-aka.html
tags: 
- Why
- technology
- Battlegrounds Mobile India
- Pubg
- FAU-G
---

 [![](https://lh3.googleusercontent.com/--M1n6L6qCi4/YmBBMSAVnJI/AAAAAAAAKVw/rXl7nxPPZQ0kASmDUITOyx9tJSklsULWwCNcBGAsYHQ/s1600/1650475309311296-0.png)](https://lh3.googleusercontent.com/--M1n6L6qCi4/YmBBMSAVnJI/AAAAAAAAKVw/rXl7nxPPZQ0kASmDUITOyx9tJSklsULWwCNcBGAsYHQ/s1600/1650475309311296-0.png) 

  

  

Indian government banned alot of china apps back in 2019 due to security issues as there is war between china and India troops at the border line, PUBG mobile a  popular first person shooter game also banned in india as the creator of game is Tencent Games a chinese company who acquired distribution rights from original developer Bluehole which is from south korea, anyway after the ban of PUBG in india Bluehole cut all ties with Tencent Games and re-entered in india by taking more then year with BGMI - Battlegrounds mobile india which got success in no time.

  

However, if you're living in india then you may probably know when PUBG banned in India we got to see alot of alternatives like FAU-G, WEX, Lands of price etc but the one which got immense popularity from people of india is FAU-G aka fearless and united guards that was actually inspired by self reliant india aka aatma nirbhar bharat.

  

**• FAU-G official support •**

  

\- [Twitter](https://mobile.twitter.com/ncore_games?lang=en)

  

**Email :** [contact@ncoregames.com](mailto:contact@ncoregames.com)

**Website** : [ncoregames.com](http://ncoregames.com)

  

**• How to download FAU-G** •

  

It is very easy to download FAU-G from these platforms for free.

  

\- [Play Store](https://play.google.com/store/apps/details?id=com.ncoregames.faug)

  

But, FAU-G was unable to beat PUBG as it doesn't achieved the gaming standards of PUBG - player unknown battlegrounds and COD - call of duty even at 10%, they seems like working hard to become alternative to PUBG but the founder of Studio nCore that develops FAU-G says don't compare FAUG with PUBG.

  

Yeah, He is right it will be funny if anyone compares FAU-G with PUBG as FAU-G look and feels like cartoon, while PUBG feel like real FPS game with amazing graphics but the concept of FAU-G is based on the true events of Indian soldiers so definitely it is filled with patriotism, that's why it reached 

millions of downloads in just few days.

  

• **FAU-G with key features and UI / UX overview •**

 **[![](https://lh3.googleusercontent.com/-hcnTN3UcA00/YmBBLAEdSRI/AAAAAAAAKVs/z9QwPMHnehI9SZuBeH_eiYDxn9N9NjA6QCNcBGAsYHQ/s1600/1650475304290167-1.png)](https://lh3.googleusercontent.com/-hcnTN3UcA00/YmBBLAEdSRI/AAAAAAAAKVs/z9QwPMHnehI9SZuBeH_eiYDxn9N9NjA6QCNcBGAsYHQ/s1600/1650475304290167-1.png)** 

 **[![](https://lh3.googleusercontent.com/-zhSbcmijkGA/YmBBJ7HM9PI/AAAAAAAAKVo/hK_a5CdeQN4xeAO1EwFL3kxxpC8_G3ytACNcBGAsYHQ/s1600/1650475299999758-2.png)](https://lh3.googleusercontent.com/-zhSbcmijkGA/YmBBJ7HM9PI/AAAAAAAAKVo/hK_a5CdeQN4xeAO1EwFL3kxxpC8_G3ytACNcBGAsYHQ/s1600/1650475299999758-2.png)** 

 **[![](https://lh3.googleusercontent.com/-EtGdvQWdpr8/YmBBI-8kuKI/AAAAAAAAKVk/WgRbwBa5_rwwvqNLSNEleeHpic5YVmIkwCNcBGAsYHQ/s1600/1650475295781320-3.png)](https://lh3.googleusercontent.com/-EtGdvQWdpr8/YmBBI-8kuKI/AAAAAAAAKVk/WgRbwBa5_rwwvqNLSNEleeHpic5YVmIkwCNcBGAsYHQ/s1600/1650475295781320-3.png)** 

 [![](https://lh3.googleusercontent.com/-ET4aj-9mHsw/YmBBH91GQNI/AAAAAAAAKVg/lJupOLDssD0so0WBZs1clqGR9u1FbnmeACNcBGAsYHQ/s1600/1650475291097100-4.png)](https://lh3.googleusercontent.com/-ET4aj-9mHsw/YmBBH91GQNI/AAAAAAAAKVg/lJupOLDssD0so0WBZs1clqGR9u1FbnmeACNcBGAsYHQ/s1600/1650475291097100-4.png) 

  

 [![](https://lh3.googleusercontent.com/-RObF1oTZ71I/YmBBGhAAReI/AAAAAAAAKVc/YPvsxVRs66UWPsk3nNGiTm3ROoVyUpSbACNcBGAsYHQ/s1600/1650475285912776-5.png)](https://lh3.googleusercontent.com/-RObF1oTZ71I/YmBBGhAAReI/AAAAAAAAKVc/YPvsxVRs66UWPsk3nNGiTm3ROoVyUpSbACNcBGAsYHQ/s1600/1650475285912776-5.png) 

  

 [![](https://lh3.googleusercontent.com/-jNa8wg5TG3o/YmBBFTDWwbI/AAAAAAAAKVY/Q6iiLWZfXigBFlTriVh3QLIy6XFWa8L3QCNcBGAsYHQ/s1600/1650475280854933-6.png)](https://lh3.googleusercontent.com/-jNa8wg5TG3o/YmBBFTDWwbI/AAAAAAAAKVY/Q6iiLWZfXigBFlTriVh3QLIy6XFWa8L3QCNcBGAsYHQ/s1600/1650475280854933-6.png) 

  

 [![](https://lh3.googleusercontent.com/-kgemecov-ig/YmBBEA265EI/AAAAAAAAKVU/mRvWXiAhEmQrIcUOMf7XVDt7o_IEU6PeQCNcBGAsYHQ/s1600/1650475275181355-7.png)](https://lh3.googleusercontent.com/-kgemecov-ig/YmBBEA265EI/AAAAAAAAKVU/mRvWXiAhEmQrIcUOMf7XVDt7o_IEU6PeQCNcBGAsYHQ/s1600/1650475275181355-7.png) 

  

 [![](https://lh3.googleusercontent.com/-A9qIJkERdDQ/YmBBCrXljkI/AAAAAAAAKVQ/OEuCIwS5j-kh8Kt-3EgHG4YmVMBUfQbmwCNcBGAsYHQ/s1600/1650475268945486-8.png)](https://lh3.googleusercontent.com/-A9qIJkERdDQ/YmBBCrXljkI/AAAAAAAAKVQ/OEuCIwS5j-kh8Kt-3EgHG4YmVMBUfQbmwCNcBGAsYHQ/s1600/1650475268945486-8.png) 

  

Eventhough, FAU-G is based on real story of Indian soldiers with indian artillery and 20% in-app purchases amount is donated to Bharat ke veer foundation which is good but still what matters at the end is people enjoying it or not isn't? if people didn't like the game they will stop playing it.

  

If you like PUBG alot then most probably you may used VPN to unlock and bypass india government restrictions right ? alot of people and YouTube streaming gamers used several VPNs to play south korea or US version of PUBG but somehow indian government blocked that as well, then the gamers started downloading south korea PUBG mobile to play which is working but the userdata base is not transferred.

  

FAU-G increased expectations as they announced the game after PUBG ban but frequently delayed and scheduled release of game, and when finally Studio nCore published the game on Play Store, all the hopes of people destroyed as FAU-G is in story mode with one button at bottom to move or fight the opponents which are bots and there are no guns and multi-player mode as well.

  

While, PUBG is equipped with world class artillery with cool concept like where you can land on island with 100 players which includes you and you have to kill everyone till you become sole player and then you will get winner winner chicken dinner for your victory, isn't it awesome?

  

PUBG also has fabulous skins, locations, characters, smooth momentum, super control gaming keyboard, numerous gaming modes, voice and text chat with your team or other players, and many more

features for perfect gameplay experience, that's why many people addicted to PUBG.

  

Incase of FAU-G, it doesn't even have one similar or competitive feature of PUBG and the major issue with FAU-G is momentum of player feels slow and feels cringe, I'm not the one who saying it there are many people and popular YouTube gamers who says they like movements of PUBG.

  

Anyhow, FAU-G eventually become unpopular and got lowest rating of 2.1 on playstore as now a days no one caring about FAU-G, most users who play FAU-G either uninstalled FAU-G or shifted to PUBG india's version Battlegrounds mobile india, and then recently Studio nCore released another early access Game of FAU-G stating it as Multi-player.

  

The Multi-player mode of FAU-G got 100K downloads which is very low considering the original version that has 5 millon downloads as of now, I don't know why Studio nCore released another game of same but it's a terrible mistake for sure as people usually don't show or have time to install same game when the game is below average, it's better if they can include Multi-player with original game.

  

I'm not dis-couraging Studio nCore or FAU-G, it's definitely a good effort to promote and fill patriotism in hearts of gamers I appreciate that but atleast they have to give some explanation to people on why FAU-G unable to progress to the level of PUBG? Is it due to lack of funds or game developers etc.

  

If FAU-G really facing troubles due to lack of funds or game developers then why don't they build game through crowd funding as they already have humongous support from india people and then hire talented developers to escalate and upgrade game, I'm just giving suggestions and it's upto Studio nCore now.

  

There is no doubt Aatma nirbhar bharat program is successful but only interms of apps not games, there is not even one big game that achieved popularity, even FAU-G disappointed but atleast we can say that PUBG is old game and it has taken more then 5 years to shape up to this level that it was today, while FAU-G is still new game from small company so it's struggling but after few years FAU-G will be beat PUBG aka Battlegrounds Mobile India.

  

The above words are satisfying and I hope FAU-G and other PUBG alternatives will get strength to beat PUBG, but there is another mistake done by Studio nCore that leaded to failure is making FAU-G a closed source game, if Studio nCore make FAU-G a open source software then the development of game will be fastracked with contributions from around the world, so it's better to be late then never I strongly suggest Studio nCore to make FAU-G open source.

  

Finally, this is why FAU-G failed to beat PUBG and the whopping failure of FAU-G is clearly visible on play store thanks to low rating from users, I believe Studio nCore have to awake and do something to step for success from failure, isn't? what do you think? have you played FAU-G and PUBG? If yes which game you like kindly say us in our comment section below, see ya :)