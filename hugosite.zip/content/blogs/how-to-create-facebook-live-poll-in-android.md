---
title: 'How To Create Facebook Live Poll In Android ?'
date: 2020-03-05T22:58:00.001+05:30
draft: false
url: /2020/03/how-to-create-facebook-live-poll-in.html
tags: 
- technology
- livestream
- fb
- reactions
- poll
---

**  

[![](https://lh3.googleusercontent.com/-tlP9hlav9nE/XoIbQFZxFDI/AAAAAAAABOc/Hc8dEpXs8_s_utKTqXgVcTQOHKBZmcMAACLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-03.jpeg)](https://lh3.googleusercontent.com/-tlP9hlav9nE/XoIbQFZxFDI/AAAAAAAABOc/Hc8dEpXs8_s_utKTqXgVcTQOHKBZmcMAACLcBGAsYHQ/s1600/IMG_20200111_105332_780-02-03.jpeg)

**

  

**

**Tech Tracker** | Do you want to create a celebrity poll or you love to know your new photoshoot pictures monitor which photo getting more likes or anyother fb live poll is useful.  


**

Unlike, PC doing live stream in android is little hard as pc offers more potential of power and usability, howeever as time goes android got some amazing livepoll apps that can easily create polls as fb is most popular social messaging app.

  

So, if you want to create fb polls with accurate reaction's value then follow our steps.

  

\- **Fb Live Poll Apps**

  

There are two such live polls apps that we found really amazing and with user quality is good and stable.

  

**1\. Live Polls For Facebook**

  

This is one of the best app for fb live stream for polls that get accurate fb reactions and take less data but for whatever reason it's not available in playstore but you can download from web.

  

**2\. Wizfeeds Live**

  

This is alternative app that we suggest you if you are not interested or you didn't liked live polls then we suggest you to try this app as it is both similar but we found wizfeeds is little hard but they improvised and fixed bugs you can check yourself available in playstore.

  

**\- Fb Live Poll Website's**

  

**1. [www.livereacting.com](www.livereacting.com)**

**2**. [**excitem.com**](excitem.com)

  

These are some ways that we found to live poll in facebook.

  

If you have any suggestions or queries you can comment down below.