---
title: 'Koo App - India''s micro-blogging platform alternative to twitter for regional language speakers! '
date: 2021-03-15T10:58:00.000+05:30
draft: false
url: /2021/02/koo-app-indias-micro-blogging-platform.html
tags: 
- technology
- India
- Koo
- App
- Twitter
---

 [![Koo App - India's micro-blogging platform alternative to twitter for regional language speakers!](https://lh3.googleusercontent.com/-vsFQ2yk2DJw/YFbZfmuidpI/AAAAAAAADyI/Ikjyd2KuFzQsfqosZqOgrk-Xm4kBF-60wCLcBGAsYHQ/s1600/1616304505468677-0.png "Koo App - India's micro-blogging platform alternative to twitter for regional language speakers!")](https://lh3.googleusercontent.com/-vsFQ2yk2DJw/YFbZfmuidpI/AAAAAAAADyI/Ikjyd2KuFzQsfqosZqOgrk-Xm4kBF-60wCLcBGAsYHQ/s1600/1616304505468677-0.png) 

  

Koo app by **Aprameya Radhakrishna** and **Mayank Bidawatka** is a micro-blogging

platform getting prominence these days was also considered as alternative to the popular micro-blogging website **Twitter, **it is specially made for all regional language speakers of India as per Koo app only 10% of india speaks english, almost 1 billion people in India don't know english now there are getting access to smartphones and they wil love to share their thoughts in their mother tongue. 

  

Koo app has been selected as winner of Prime Minister's Narendra Modi's Aatma Nirbhaar App challenge including that Koo app was mentioned and applauded by PM Narendra Modi in maan ki baat program

The Atma Nirbhar App Challenge was launched by Prime Minister to create and encourage digital innovation among start-ups and entrepreneurs in India by creating products that could cater to India and its digital needs in eight categories. Koo App was one of the winners of this Challenge, which received more than 6,900 entries from all over India.

  

  

It's been an year since the launch of Koo from them important personalities in India joined in Koo like Union Minister Ravi Shankar Prasad, Shri Sadhguru, Anil Kumble, Javagal Srinath, Karnataka MP Tejasvi Surya, Ashutosh Rana, Ashish Vidyarthi, CN Ashwathnarayan, Karnataka Deputy Chief Minister, and many IAS officers, actors, actresses, and sports personalities use it to connect with their fans, likers, supporters and followers and more. 

  

 [![](https://lh3.googleusercontent.com/--J0j_VNtTto/YCvo_Z9tfzI/AAAAAAAADSs/g5oHnuiFtM0LcRFo0BtZ79HXokaE8xsxgCLcBGAsYHQ/s1600/1613490407001352-1.png)](https://lh3.googleusercontent.com/--J0j_VNtTto/YCvo_Z9tfzI/AAAAAAAADSs/g5oHnuiFtM0LcRFo0BtZ79HXokaE8xsxgCLcBGAsYHQ/s1600/1613490407001352-1.png) 

  

When it comes to Koo co-founders  Aprameya Radhakrishna and Mayank Bidawatka, Aprameya Radhakrishna founded Taxi For Sure which brought by Ola company, and Mayank Bidawatka co-founded redBus while both are successful enterpreniul ventures.

  

Koo launched in march 2020 which voted as best essential app of the year in playstore that a impressive achievement for a startup, recently to encourage this Indian made Twitter alternative, there is buzz going on that government portals likely to announce important information 3 hours before in Koo then later on other social media handles which make more people to register on Koo. 

  

**Eventhough**, Koo app is huge popularity it definitely need more encouragement and support from Indian people to inspire more Indian developers to make global quality apps like this which will make India an self reliant Nation in all sections, which will improvise India's economy and make global super power in future. 

  

**However**, Elliot Alderson ( fs0c131y ) a French security researcher recently reported in his Twitter handle that koo app is leaking data of users due to its faulty API, while there is no reply or comment from Koo team yet we have wait little more time to get some clarification from Koo regarding this. 

  

If we keep aside the data leaking allegations from **Elliot Alderson**, Koo app havs potential to become India's alternative to Twitter in upcoming years due to increasing issues with Twitter policies  Indian government cheering up for alternative to Twitter and at the right time Koo appeared and getting good fortunes and encouragement from nationalists. 

  

The app even named according to Indian environments and style to make it more familiar to Indian people Koo is an voice of hen, most villages have hen in home or street, In country like US or UK bird chirping wake people or notify about morning but in India hen sound wake or notify about morning, so hen and it's sounds are more connected to Indian households so, that's an clever and interesting name choosen by **Koo** founders, we appreciate that! 

  

**Inshort**, Koo is an micro-blogging app specially made for regional speakers of India to share their thoughts, which won Aatma Nirbhaar challenge getting huge prominence these days due to popular personalities of India making accounts and applauded and mentioned by PM Narendra Modi in his Aatma Nirbhaar program which hyped the name. 

  

\- **App Info** - [Google Play](https://play.google.com/store/apps/details?id=com.koo.app) -  

  

**• How to install Koo App •**

It is very easy to download Koo App on these platforms for free!   

  

\- [Google Play ](https://play.google.com/store/apps/details?id=com.koo.app)

\- [Apkpure](https://www.google.com/amp/s/m.apkpure.com/koo-connect-with-indians-in-indian-languages-%2525F0%25259F%252599%252582/com.koo.app/amp)

\- [Apkmonk](https://www.apkmonk.com/app/com.koo.app/)

\- [downloadAPK](https://downloadapk.net/Koo-The-Voice-of-India-in-Indian-Languages-Koo.html)

**Contact : **hello@kooapp.com

**Website :** [www.kooapp.com](http://www.kooapp.com)

  

• **Koo App** key features with **UI** & **UX** Overview • 

  

 [![](https://lh3.googleusercontent.com/-EA2xm_yTTnc/YCvo5t5ltOI/AAAAAAAADSk/R0V9WijHpsoO5ZLftCYinwg8VFN15AKoACLcBGAsYHQ/s1600/1613490395867654-2.png)](https://lh3.googleusercontent.com/-EA2xm_yTTnc/YCvo5t5ltOI/AAAAAAAADSk/R0V9WijHpsoO5ZLftCYinwg8VFN15AKoACLcBGAsYHQ/s1600/1613490395867654-2.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-0XCEEKgix7A/YCvoGanc6-I/AAAAAAAADSQ/yzWWgmL2sNQpG-egJg4_pQzOFzR7WDnCwCLcBGAsYHQ/s1600/1613490151606237-3.png)](https://lh3.googleusercontent.com/-0XCEEKgix7A/YCvoGanc6-I/AAAAAAAADSQ/yzWWgmL2sNQpG-egJg4_pQzOFzR7WDnCwCLcBGAsYHQ/s1600/1613490151606237-3.png) 

  

  

  

  

 [![](https://lh3.googleusercontent.com/-XyVKYnnhO7g/YCvn51LqXQI/AAAAAAAADSM/IwYg8McsRJ44b4mbmXMyketXX-MZIuiCQCLcBGAsYHQ/s1600/1613490011477869-4.png)](https://lh3.googleusercontent.com/-XyVKYnnhO7g/YCvn51LqXQI/AAAAAAAADSM/IwYg8McsRJ44b4mbmXMyketXX-MZIuiCQCLcBGAsYHQ/s1600/1613490011477869-4.png) 

  

  

  

 **[![](https://lh3.googleusercontent.com/-OCoyZX0bi0E/YCvnWzVVKnI/AAAAAAAADSE/gqDJ4n1EIEks0Ds0okUKIgRMDk8aQScSQCLcBGAsYHQ/s1600/1613489942448118-5.png)](https://lh3.googleusercontent.com/-OCoyZX0bi0E/YCvnWzVVKnI/AAAAAAAADSE/gqDJ4n1EIEks0Ds0okUKIgRMDk8aQScSQCLcBGAsYHQ/s1600/1613489942448118-5.png)** 

  

  

 [![](https://lh3.googleusercontent.com/-4P9SqLxLFsU/YCvnFg9de8I/AAAAAAAADR0/4-HjDzdTabMzp64uvdt3lGJ0V-9Kv8VCgCLcBGAsYHQ/s1600/1613489925665700-6.png)](https://lh3.googleusercontent.com/-4P9SqLxLFsU/YCvnFg9de8I/AAAAAAAADR0/4-HjDzdTabMzp64uvdt3lGJ0V-9Kv8VCgCLcBGAsYHQ/s1600/1613489925665700-6.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-XgkuKP3NQGQ/YCvnBeON0WI/AAAAAAAADRw/G8t5MAfJMqIH0FETqxBxdyCK06LpSgO1gCLcBGAsYHQ/s1600/1613489910505052-7.png)](https://lh3.googleusercontent.com/-XgkuKP3NQGQ/YCvnBeON0WI/AAAAAAAADRw/G8t5MAfJMqIH0FETqxBxdyCK06LpSgO1gCLcBGAsYHQ/s1600/1613489910505052-7.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-lvPNUTpEq2I/YCvm9Q6GthI/AAAAAAAADRs/iL9Zxt533qYrvmdUxBj2cew7PhDA3MtIQCLcBGAsYHQ/s1600/1613489889515579-8.png)](https://lh3.googleusercontent.com/-lvPNUTpEq2I/YCvm9Q6GthI/AAAAAAAADRs/iL9Zxt533qYrvmdUxBj2cew7PhDA3MtIQCLcBGAsYHQ/s1600/1613489889515579-8.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-Kyv88fdItQ0/YCvm4OU4hRI/AAAAAAAADRo/NFXU9jBCgtA38cPAeUM4CA2br6HYHJpvwCLcBGAsYHQ/s1600/1613489823884482-9.png)](https://lh3.googleusercontent.com/-Kyv88fdItQ0/YCvm4OU4hRI/AAAAAAAADRo/NFXU9jBCgtA38cPAeUM4CA2br6HYHJpvwCLcBGAsYHQ/s1600/1613489823884482-9.png) 

  

  

 [![](https://lh3.googleusercontent.com/-La0BLraQrJw/YCvmnxKLEwI/AAAAAAAADRY/IMJdnsDt3NEau066YBgFk7Qjr0kWcj02gCLcBGAsYHQ/s1600/1613489785461066-10.png)](https://lh3.googleusercontent.com/-La0BLraQrJw/YCvmnxKLEwI/AAAAAAAADRY/IMJdnsDt3NEau066YBgFk7Qjr0kWcj02gCLcBGAsYHQ/s1600/1613489785461066-10.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-YGoluZPotLI/YCvmeZf3llI/AAAAAAAADRQ/cJemiiVHmgQKpYvLP1DihQaNv8F3dNniACLcBGAsYHQ/s1600/1613489769754838-11.png)](https://lh3.googleusercontent.com/-YGoluZPotLI/YCvmeZf3llI/AAAAAAAADRQ/cJemiiVHmgQKpYvLP1DihQaNv8F3dNniACLcBGAsYHQ/s1600/1613489769754838-11.png) 

  

￼

  

 [![](https://lh3.googleusercontent.com/-uLLrXxszOF8/YCvmabhOH9I/AAAAAAAADRM/K0Kr7fgkWNwMSE9tiaOB7Py83eC6kJu0ACLcBGAsYHQ/s1600/1613489759023682-12.png)](https://lh3.googleusercontent.com/-uLLrXxszOF8/YCvmabhOH9I/AAAAAAAADRM/K0Kr7fgkWNwMSE9tiaOB7Py83eC6kJu0ACLcBGAsYHQ/s1600/1613489759023682-12.png) 

  

  

  

 [![](https://lh3.googleusercontent.com/-1P8PpzstThU/YCvmXqZQy_I/AAAAAAAADRI/rO2oh3m4O3kL_K9pmVV-z7zOa7hIbrYUACLcBGAsYHQ/s1600/1613489739267538-13.png)](https://lh3.googleusercontent.com/-1P8PpzstThU/YCvmXqZQy_I/AAAAAAAADRI/rO2oh3m4O3kL_K9pmVV-z7zOa7hIbrYUACLcBGAsYHQ/s1600/1613489739267538-13.png) 

  

  

**Overall**, the UI is perfect for use it is just awesome such a clean and beautiful UI developed in short time, the UI will give simple and fabulous user experience for sure but it is user subjective. 

  

**Moreover**, koo app is attracting investors from India and overseas except china to increase its development and features to give more vivid experience to users of Koo in future, while the Koo parent company bombinate technology have a Chinese investor shunwei capital for the app named VOCAL, while shunwei capital is going to way out. 

  

**Finally**, Koo app made with pride in india, we personally appreciate for the name and logo it is cute and a clever decision by the founders app is awesome, considering all the factors Koo app it have huge potential which can replace Twitter in future, what do you think say your view about this in comment section below, see ya :)