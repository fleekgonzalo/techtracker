---
title: 'Why Country''s Censor Apps Or Website''s'
date: 2020-01-09T21:20:00.001+05:30
draft: false
url: /2020/01/why-countrys-censor-apps-or-websites.html
tags: 
- technology
- Security
- Privacy
- Country
---

  

[![](https://lh3.googleusercontent.com/-MhkPy21Y8sQ/Xhlfko6MlSI/AAAAAAAAAuI/Z751px0OVQADWJRzFZ97cXtHyP3fcq96wCLcBGAsYHQ/s1600/IMG_20200111_110853_755.jpg)](https://lh3.googleusercontent.com/-MhkPy21Y8sQ/Xhlfko6MlSI/AAAAAAAAAuI/Z751px0OVQADWJRzFZ97cXtHyP3fcq96wCLcBGAsYHQ/s1600/IMG_20200111_110853_755.jpg)

  

Why some countries censor some apps and websites at certain time and even completely.  

  

There are are alot reasons that could imply on website or apps. 

  

**• Security** 

  

Security and privacy for public is the main thing that every country wanted for thier public and do that country's blocked certain apps that do not

provide keys or assistance to the agencies if the

doesn't provide the requirement that wanted from them then country can't make it available in thier country as they have possibility of checking and managing certain things in emergency level and do have potential threat to country from the apps.

  

**• Privacy**

  

Privacy as most users who ever use app or sites like to accept certain terms and conditions and every country have thier privacy terms and condi

tions in internet like European union if any site or app that can't comply or assure will be blocked or will be fined if it used the data for thier profits as google android is fined in record.

  

  

**• Censor P+rnography**

  

Some countries have own set of rules interms of age limit of watching adult content while global counties like Germany have 16 india 18 and other have thier own as even if the country insisted or wanted to block adult content they can do that by blocking or putting firewalls to get ban per limit or permanent.

  

**• Blocking Global Companies**

  

Yes, some countries like to use and promote local companies instead of global companies to create

jobs within themself and for economic and country pride reasons like china blocked apps like whatsapp, twitter, facebook that have potential to get addicted or to reach more audience as this are global the country wouldn't have control on them.

  

Some website or apps that do not have censorship on tv shows and movies will be blocked like America do not want Japanese original cartoons and animes that have uneccesary scens that could effect children so the websites will blocked.

  

Country's block domains and apps if there is any illegal things going on in them so it will not reach larger audience.

  

These are some reasons why country's block apps or sites at certain times or permanent.

  

Keep supporting  : TechTracker in