---
title: 'What happened to Google''s Project Ara? A modular smartphone.'
date: 2022-07-27T12:00:00.000+05:30
draft: false
url: /2022/07/what-happened-to-googles-project-ara.html
tags: 
- technology
- Project Ara
- Happened
- What
- Modular Smartphone
---

 [![](https://lh3.googleusercontent.com/-6IkGroT-ETo/YuGHdrwVmGI/AAAAAAAAMv0/Ug50_zNAYUwe5fzH-8-vF_SNwz882XAigCNcBGAsYHQ/s1600/1658947442928035-0.png)](https://lh3.googleusercontent.com/-6IkGroT-ETo/YuGHdrwVmGI/AAAAAAAAMv0/Ug50_zNAYUwe5fzH-8-vF_SNwz882XAigCNcBGAsYHQ/s1600/1658947442928035-0.png) 

  

  

Backrub, a search engine founded by Larry Page and Sergey Brin in year 1997 that later re-named to Google since then with in few years Google become world's most popular search engine giant with millons of user per day with it's success Google to  move further developed and acquired alot of futuristic projects over the years to name a few Blogger, Chrome, Android OS,  Gmail, YouTube etc.

  

In year 2007, on January 9 Apple inc. a popular PC maker founder Steve jobs launched iPhone a revolutionary world's first multi-touch smartphone with powerful hardware and advanced software that has futuristic technologies and immense potential to totally replace keypad mobiles so people around the world started buying iPhone even though it's expensive at that time and now as well.

  

The popularity of iPhone keep on growing due to that Apple inc. was able to sell iPhones in it's stores within few minutes and go out of stock as people used to wait in long queues infront of Apple stores to get iPhone as there is huge demand for  iPhone alot of mobile companies around the world to supply and make business started making thier own smartphones like iPhone but the problem here is they lack operating system of iPhone.

  

iPhone 1st generation operating system don't have a name as per Apple inc. it uses a custom version of Apple's deskop operating OS X but from iPhone 2nd generation Apple inc. named it's operating system as iOS since then Apple inc. done alot of improvements and upgrades to provide new features and refreshing experience to iPhone users.

  

iOS is a advanced and powerful closed source operating system from Apple inc. that not just look cool but also provide amazing experience while keypad mobile operating systems like Java and Symbian OS is not even comparable to iOS in terms of features so alot of people used to buy iPhone especially for iOS.

  

Google, always created and entered into useful and worthy technologies when iPhone doing alot of buzz globally Google don't have any facilities to manufacture a smartphone like iPhone but they does have operating system named Android acquired from Andy Rubens in year 2005 that can compete with iOS so in year 2008 Google partnered with HTC a Taiwanese mobile company and released world's first Android operating system smartphone.

  

Android, is free and open source operating system from Google that has potential and capability to compete and become best alternative to iOS that anyone can build thier custom version using source available on AOSP aka Android open source project and install on thier smartphones so almost all companies started using Android OS on smartphones due to that Android OS has more then 72% worldwide market share.

  

Anyhow, smartphone is one electronic device made up of numerous hardware and software technologies and all of them are very essential to work properly you can't access software without hardware that's totally fine but the problem here is smartphones are not computers you can't easily replace it's parts as companies seal smartphones which are only replaceble by technicians with proper tools that require alot of knowledge on smartphones.

  

When you buy a smartphone you get hardware as said by mobile companies that you have to use forever if you want same smartphone with different hardware like suppose you have 10mp camera that you want to change it to 30mp then it's super hard you have to manually open smartphones and change alot of hardware parts and configure software to support it in that process you may even damage it as mobile companies don't provide slots to change hardware parts on smartphones.

  

In case, you damaged a hardware part like display and in order to change it you have to hire a technician who use number of tools to remove display and change it with same display supported by other hardware parts and operating systems which takes time and costly so in most cases you may feel like to buy a new smartphone instead of repairing old smartphone.

  

What if you can easily remove and upgrade hardware parts of smartphones by swapping with your fingers? for instance you have a LCD display that you want to change to OLED or Super Amoled display for that all you have to do is buy them and add on your smartphone isn't cool and awesome thus you never have to repair your smartphone with technician and buy a new smartphone to get new hardware parts and it's features right?

  

 [![](https://lh3.googleusercontent.com/-E3oLEHVS2X4/YuGHc1iLUfI/AAAAAAAAMvw/dsKq4Amxn3IHaAOkSQ7N6vh2OW4bq8QZgCNcBGAsYHQ/s1600/1658947437870410-1.png)](https://lh3.googleusercontent.com/-E3oLEHVS2X4/YuGHc1iLUfI/AAAAAAAAMvw/dsKq4Amxn3IHaAOkSQ7N6vh2OW4bq8QZgCNcBGAsYHQ/s1600/1658947437870410-1.png) 

  

  

Google Ara is a project to make modular smartphone that will let you replace and upgrade any hardware part of smartphone in seconds released on October 29, 2014 with proto type video that later gone through some developements but on September 2, 2016 Google confirmed that Project Ara is cancelled since then there is no new updates on Project Ara.

  

You may probably know Google acquired a Motorala Mobility in year 2011 prior to that Google acquired modular smartphone patent rights from israel company Modu after that they done workaround on Modular smartphones then on October 29, 2013 Motorola announced Project Ara that received global attention and applause from geeks around the world.

  

Modular smartphones concept is new and interesting it is possible if executed well that can totally replace old non-modular smartphones but it's not easy to make modular smartphones to make them companies need to spend alot of money on research and development to plan on  it's design and make profits out of it that take years for sure.

  

Most big mobile companies like Apple, Sony and Samsung etc can make modular smartphones but the problem here is on  modular smartphones any hardware part can be replaced thus there will be no requirement of technicians and service centers including that customers don't have buy smartphone parts from same mobile company or new smartphone to upgrade features that can leave mobile companies with huge losses.

  

In sense, most mobile companies are afraid of Project Ara as they don't have funds and infrastructure to adapt and make modular smartphones even if mobile companies want to make modular smartphones yet they can't as it looses thier service center and new smartphone business so there is high possibility that big mobile companies may put pressure on Google to shelve Project Ara.

  

Big mobile companies spend billions to manufacture seperate hardware parts and setup and maintain service centers with professional technicians world wide due to that if modular smartphones come into market at affordable prices from Google it can put big companies profits at risk even though they can divert and change thier working structure of hardware plants to modular smartphone modules and service centers to repair modules yet it can take years by the time they can loose grip on existing smartphone mobile market.

  

Meanwhile, new and small companies may face hard time to develop modular smartphones as it require advanced facilities and technologies if they are unable to adapt and make modular smartphones that can put them out of league which is not good as in order to make Project Ara successfull all mobile companies have to play it's role.

  

However, Google also make smartphones every year and has service centers to repair damaged smartphones and generate bussiness out of it that may be another reason why Google pull down Project Ara as the success of it not only problematic to profits of other mobile companies but also Google.

  

Motorola despite the cancellation of Project Ara from Google yet made a modular smartphones in year 2016 named Motorola Z even though it is not full fledged modular smartphone and not comparable to prototype of Project Ara but there are some Motorola mods like sound, 360° camera, stereo speakers, shells, 5G, sound boost and battery mode etc that you can replace on Moto Z smartphones.

  

Fortunately, Motorola is continuing the Motorola Z series and Mods but it seems like they're not receiving enough response and customers even though at first Motorola Z got alot of hype in year 2016 with Motorola mods but later on most people forgot about them mainly because Motorola mods are costly with the price of one Motorola Moto Z mod you can buy a high end flagship smartphone.

  

Motorola Z series is so far one of the working modular smartphones but it's not a complete modular smartphone you can only replace some hardware parts but in future Google may revive Project Ara as modular smartphones are future but as of now Project Ara is no more active.

  

Finally, in future almost all mobile companies will make modular smartphones for sure, are you an existing user of modular smartphone? If yes do say your experience and mention your opinion on the concept of modular smartphones will they work or not? in our comment section below, see ya :)