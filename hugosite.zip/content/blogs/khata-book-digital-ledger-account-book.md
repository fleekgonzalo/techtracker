---
title: 'Khata Book - Digital Ledger Account Book ?'
date: 2020-02-26T22:45:00.001+05:30
draft: false
url: /2020/02/khata-book-digital-ledger-account-book_26.html
tags: 
- Apps
- KhataBook
- Money
- Digital
- Account
- Ledger
---

**  

  

[![](https://lh3.googleusercontent.com/-HFCarvUxQV0/XlanllQn8sI/AAAAAAAABLw/-d6ygak5hxcWWY6NTxXC_Nh_KwoWPAspQCLcBGAsYHQ/s1600/IMG_20200226_224336_920.jpg)](https://lh3.googleusercontent.com/-HFCarvUxQV0/XlanllQn8sI/AAAAAAAABLw/-d6ygak5hxcWWY6NTxXC_Nh_KwoWPAspQCLcBGAsYHQ/s1600/IMG_20200226_224336_920.jpg)



**

**

Tech** **Tracker** | Khata Book - Ledger Account Book is primarily focuses on Indian audience as it can be replace the old traditional physical book with this digital app for multiple purposes and simple usage within your smartphone.

  

\- **Khata** **Book** **Features**

**•** 100% Free & Secure.

  

• Free SMS to your customers on every transaction.

  

• Automatic and Secure Online Backup

  

• Create Personal Khata Books

  

• Send **What'sApp** payment reminder to your customer's

  

• Manage Multiple Shops 

  

• Download Your Customer's PDF Report.

  

• Use one KhataBook Account On Multiple Accounts.

  

• Set Payment Reminder To Your Customers.

  

• Secure Your Account Book Using App Lock.

  

Khata Book got released in 2016 on PlayStore from then it got popularized with millions of download and proudly made in india.

  

If you are looking for any digital ledger account book this app can be useful as the app getting improved with added features.