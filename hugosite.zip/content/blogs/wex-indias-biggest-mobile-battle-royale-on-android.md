---
title: 'WEX -  India''s Biggest Mobile Battle Royale On Android |'
date: 2021-03-26T23:08:00.001+05:30
draft: false
url: /2021/03/wex-indias-biggest-mobile-battle-royale.html
tags: 
- technology
- WEX Mobile
- Royale
- Developers
- game
- Battle
- Indian
---

 [![WEX -  India's Biggest Mobile Battle Royale On Android |](https://lh3.googleusercontent.com/-S6n5vvuL8Ic/YF4cIbuMOeI/AAAAAAAAD2A/fy9fqFrYupk5nXVMGU3ylB5kUo0PAjNpACLcBGAsYHQ/s1600/1616780305377981-0.png "WEX -  India's Biggest Mobile Battle Royale On Android |")](https://lh3.googleusercontent.com/-S6n5vvuL8Ic/YF4cIbuMOeI/AAAAAAAAD2A/fy9fqFrYupk5nXVMGU3ylB5kUo0PAjNpACLcBGAsYHQ/s1600/1616780305377981-0.png) 

  

New battle royale games are on rage these days in india, every new week one new bat- tle royale game can be seen as Pub-G was banned and atma Nirbhar Bharat Program is inspiring and motivating many talented young developers to make amazing world class apps and games that can compete with global companies.   

  

**Yes**, After the ban of Pub-G due to many reasons and mainly because of security and data breach issues in India, we keen to see many new Battle Royale Games by indian developers and companies who are trying to compete other games.  

  

In this new battle royale games, we found an interesting game named WEX Mobile tdeveloped by indie developers who just released game teaser recently on play - store giving alot of information about the game to public. 

  

**WEX ( Mobile )** is a massive open world multiplayer Battle Royale game for mobile, which is being developed by 2 Indian Game Engineers using Unreal Engine 4. It is set to launch between December 2021 - March 2022. The game will feature a huge 64 sq. km. (8km x 8km) Indian map, bringing all the realism - including 9 Major Rivers, States, and one popular tourist place in almost every state, which might be a great way to keep our players engaged with the diversity that our country has.  

  

**• WEX ( Mobile ) Official Support •**

  

**\- **[Instagram](https://instagram.com/wexmobile)

\- [YouTube](https://www.youtube.com/channel/UCj441iE0Yg4UQGlc78qINSQ/)

  

Email : **wexmobileindia@gmail.com**

  

Website : [www.techtracker.in](http://www.techtracker.in)

  

**• WEX ( Mobile ) Game Team** •

  

\- **IIT'ian** - Harshdev Singh 

\- **Full Stack Engineer** - Ishtmeet Singh  

  

**• WEX ( Mobile ) Story •**

The plans to build WEX, started as soon as PUBG Mobile was banned, which resulted in a huge rage in Indian Gaming Community. IGC (Indian Gaming Community) has always been looking for an alternative Battle Royale, which will refresh all the memories they used to have while playing PUBG mobile, also providing similar or even better gaming experience.  
  
Since, it is a big responsibility - to deliver a level of gaming experience, which would enable players to enjoy as well as experience a fluid gameplay (which has always been missing in most of the multiplayer games developed in India) - we'd make sure to take all our time, and deliver a Robust and a Well Made game.

• **WEX ( Mobile ) Current Progress •**

WEX has been progressing really fast and under active development since last 6 and a half months.  

• **WEX ( Mobile ) Accomplishments** •

**1**. We've finished building the entire map, which includes the shape, roads, rivers and planning on how everything should be placed. We've thought about all the states in India, and how to make them appeal different from every other state, adding more randomness.

**2**. Carefully selecting all the props and assets we'll be using in the game which includes - A) All the towers, barriers, boxes, containers etc. which will be used to build every city, house and scenes. B) Guns, Health packs, First aid items, Drinks, Assault Rifles, Pistols, Shotguns, Sniper rifles, Character, Emotes etc.

**3**. The home screen and the general GUI for the application (what you see before you begin matchmaking)

**4**. Shooting animations, Climbing, Ledge Grab, Rope Swing (experimental - might not be in the final game), Jumping, Falling, Swimming, Hit Reaction.

**5**. Basic multiplayer setup - Currently the multiplayer is setup for 10 players. (More about it in Backlog/What's left section)

**6**. Vehicle Physics - Using Advanced Vehicle System, we've made a realistic vehicle physics system, including auto balance and precise driving.

**7**. We've modelled half of the vehicles for the game.

**8**. Bullet physics is in place for all the weapons, we'd be using real bullet physics instead of ray tracing.

**9**. TPP and FPP Game Modes - Both of them are ready and well tested.

**10**. Swimming physics, floating, driving in water have been finished. You'd find a video in our demos.

• **WEX Mobile What's Left** •

Multiplayer aspect of the game - Build high performant support for 100 players in a single game. 100 is a huge number, and we'd need a really performant/robust code to achieve that milestone. Expected finish date for this feature - September 2021  

Laying out houses/props/trees/rocks on every part on the map so that it looks playable and doesn't provide any huge location based benefit to any player/team at any time. Expected finish date for this feature - May 2021  

Adding at least one popular tourist attraction to every state (can be a forest, fort or anything which isn't religiously associated). Expected finish date for this feature - May-June 2021  

**Voice Chat Support** - This can be tricky. We're yet to decide a good VOIP infrastructure, and would be the least urgent thing on our backlog list. Expected finish date for this feature - December 2021  

**Lobby System** - Allowing people to invite, party up for matches or just having a chit chat is a very important aspect in any multiplayer game. We'd come up with a nice looking lobby design. Expected finish date for this feature - October 2021  

**Death Cam** - This is a really important feature if we decide to go into E-sports with our game. We don't expect to release it during our initial release, but we'd have it released according to the feedback we receive. Expected finish date for this feature - Post Launch (April - May 2022)  

**Controls Overlay** \- Controls should be good looking, non-blocking and easy to rearrange. We've been working on this, and would be soon out for a public review. Expected finish date of this feature - Late April or Early May 2021  

**GyroScope** - Gyroscope is what everyone loves. It is a must have feature for a battle royale, and will be included with the first release of WEX. It is still being worked on to make it as smooth as possible Expected finish date of this feature - Early July - Late July 2021  

Spectate (After death or a friend) - The more important aspect is - spectating after death. It's going to be in the initial release, however - spectating a friend will make it easier for cheaters (As that's how mostly players cheat in a game). Spectating a friend feature will be added later after we make sure we have a good cheat detection system in place, to make games fair for everyone. Expected finish date of this feature - Death Spectate (November 2021), Friend Spectate (lobby) - April - Aug 2022  

**Class system** - This is just a 'Feature in mind' but not at all being worked on or plan to work on. We'd decide this on the feedback we receive. Expected finish date - After release

**A mini mode** - The mini mode will have 5 map options - North India, South India, West India, Central India and East India. Map will be randomly selected and you will play in the selected region. Time to complete map will also be greatly reduced (8-10 minutes to finish). This could be part of the initial release but we're not sure about it's release date. Expected finish date - Early 2022.

A 5v5 team death match mode, which will again be played in a random small area in the map. It will be ranked as well as unranked. Expected finish date - Early Jan 2022

A 8v8 TDM mode to master skills and have even more short-term intense games. We're planning about it, and yet haven't decided on the logic/rules for this game mode. This might not be in the initial release, but we have mixed thoughts about it. Expected finish date - February 2022

A 8v8 TDM mode to master skills and have even more short-term intense games. We're planning about it, and yet haven't decided on the logic/rules for this game mode. This might not be in the initial release, but we have mixed thoughts about it. Expected finish date - February 2022

Emojis - Reaction emojis are fun. We'll add numerous emojis for you to have fun!

Dances from all parts of states will be a part of the game - including Bharatanatyam, Kathakali, Nati, Kuchipudi, Odissi, Bhangra/Gidha, Garba and many more. If a game that highlights India, and is built in India doesn't have all the dance forms, what good is it? ;)  

Weapon Skins and Character outfits are constantly being worked upon. We're looking for best possible designs for all the skin related assets in game. Many of the premium skins will be unlocked when you reach a certain level in WEX, or even reach an achievement. These premium skins would be related to Indian tradition. We've currently decided to keep Indian outfits to be 'unpurchaseable' forever, instead you'll earn them after completing in game achievements or reaching certain tiers.  

**• DONATE To WEX ( Mobile ) **

We didn't decide to ask for donations at first. As we went looking and estimating costs for a high quality server infrastructure, the costs are extremely high.  

We'll get over those costs by having in game purchases (Skins/Passes/Bundles etc.), but for the development and the initial stages of the release we might need some support to keep everything going as per plans.

We'd need a little bit of support from generous people, which will help us boost our productivity and focus on getting things done instead of worrying about the financial aspect of the game.  

Also, we are using Amazon's GameLift to host our online/multiplayer matchmaking which is quite expensive.  

**\- How much will the servers cost? -**

Suppose, a total of 5000 matches being played every day on WEX (the number is very small- just for the sake of explanation), that is 150,000 minutes (considering 30 minute for a match). On further calculation, it rounds out about roughly 2500 game hours. AWS game lift server (basic one) costs $0.311 per hour, that makes our daily server cost to around 777$ or Rs. 55,000. Which looks crazily high.

We'll get over those costs by having in game purchases (Skins/Passes/Bundles etc.), but for the development and the initial stages of the release we might need some support to keep everything going as per plans.

**• Donation Benefits In-Game** •

Once we release WEX, everyone who donated - no matter how much - will receive a PREMIUM in-game bundle, which will consist of limited skins/outfits and much more. These items will be limited and would not be available for anyone else except the ones who donated.  

**• WEX ( Mobile ) GamePlay Teaser •**

**\-** YouTube

  

 [![](https://lh3.googleusercontent.com/-d60qsjqA9Jg/YF4cEMXvJgI/AAAAAAAAD14/fYxhWPOakIY-tBheeuxDwmXFd3TbsdSYQCLcBGAsYHQ/s1600/1616780289092833-1.png)](https://lh3.googleusercontent.com/-d60qsjqA9Jg/YF4cEMXvJgI/AAAAAAAAD14/fYxhWPOakIY-tBheeuxDwmXFd3TbsdSYQCLcBGAsYHQ/s1600/1616780289092833-1.png) 

  

 [![](https://lh3.googleusercontent.com/-J6aDQdJvRy8/YF4cAHEnvVI/AAAAAAAAD1s/IrwB1-BmN_cOCTwgpdd9fx9dFlqEUQhlgCLcBGAsYHQ/s1600/1616780280160445-2.png)](https://lh3.googleusercontent.com/-J6aDQdJvRy8/YF4cAHEnvVI/AAAAAAAAD1s/IrwB1-BmN_cOCTwgpdd9fx9dFlqEUQhlgCLcBGAsYHQ/s1600/1616780280160445-2.png) 

  

 [![](https://lh3.googleusercontent.com/-mqtJSYFrURU/YF4b9-YXN0I/AAAAAAAAD1o/l7GzdGVrdIw9kP3Wo6BWsZltwfLIQmEmACLcBGAsYHQ/s1600/1616780271145396-3.png)](https://lh3.googleusercontent.com/-mqtJSYFrURU/YF4b9-YXN0I/AAAAAAAAD1o/l7GzdGVrdIw9kP3Wo6BWsZltwfLIQmEmACLcBGAsYHQ/s1600/1616780271145396-3.png) 

  

 [![](https://lh3.googleusercontent.com/-ioEPPO3BWB8/YF4b7ngyrzI/AAAAAAAAD1k/PLfyugQd1C00Da6_1KVDE2jYjXU4qDCqwCLcBGAsYHQ/s1600/1616780262205326-4.png)](https://lh3.googleusercontent.com/-ioEPPO3BWB8/YF4b7ngyrzI/AAAAAAAAD1k/PLfyugQd1C00Da6_1KVDE2jYjXU4qDCqwCLcBGAsYHQ/s1600/1616780262205326-4.png) 

  

 [![](https://lh3.googleusercontent.com/-nFQQdq9dX3o/YF4b5WuXThI/AAAAAAAAD1g/8ME4TaR89UI_kk72nyHNj6-Q9BtTNXZ_gCLcBGAsYHQ/s1600/1616780251490689-5.png)](https://lh3.googleusercontent.com/-nFQQdq9dX3o/YF4b5WuXThI/AAAAAAAAD1g/8ME4TaR89UI_kk72nyHNj6-Q9BtTNXZ_gCLcBGAsYHQ/s1600/1616780251490689-5.png) 

  

 [![](https://lh3.googleusercontent.com/-yAA0QT901Ns/YF4b280AoSI/AAAAAAAAD1c/H1GnwgafK3InnrxuC7E1Oonsw1r9yuHrACLcBGAsYHQ/s1600/1616780240993274-6.png)](https://lh3.googleusercontent.com/-yAA0QT901Ns/YF4b280AoSI/AAAAAAAAD1c/H1GnwgafK3InnrxuC7E1Oonsw1r9yuHrACLcBGAsYHQ/s1600/1616780240993274-6.png) 

  

 [![](https://lh3.googleusercontent.com/-0htIgP66vK8/YF4b0KVyStI/AAAAAAAAD1Y/SuJl6aVoRRA2ZwPWBXeSifu0Be5IwIFQACLcBGAsYHQ/s1600/1616780234452672-7.png)](https://lh3.googleusercontent.com/-0htIgP66vK8/YF4b0KVyStI/AAAAAAAAD1Y/SuJl6aVoRRA2ZwPWBXeSifu0Be5IwIFQACLcBGAsYHQ/s1600/1616780234452672-7.png) 

  

 [![](https://lh3.googleusercontent.com/-cRcL5nGPVRA/YF4byXgZiCI/AAAAAAAAD1U/n3aQj1evEDAZ3lNg24_pexduPgDbAGk0wCLcBGAsYHQ/s1600/1616780229522853-8.png)](https://lh3.googleusercontent.com/-cRcL5nGPVRA/YF4byXgZiCI/AAAAAAAAD1U/n3aQj1evEDAZ3lNg24_pexduPgDbAGk0wCLcBGAsYHQ/s1600/1616780229522853-8.png) 

  

 [![](https://lh3.googleusercontent.com/-mRCrGhJ-dKQ/YF4bxTP2bwI/AAAAAAAAD1Q/MCiP7MXa-1sjOiwrA1wyCtdhfiRuYB8lACLcBGAsYHQ/s1600/1616780222817748-9.png)](https://lh3.googleusercontent.com/-mRCrGhJ-dKQ/YF4bxTP2bwI/AAAAAAAAD1Q/MCiP7MXa-1sjOiwrA1wyCtdhfiRuYB8lACLcBGAsYHQ/s1600/1616780222817748-9.png) 

  

  

**Overall**, this pre-release teaser images of WEX game looks fine & interesting and this images are OK, based on all the images available out there, we can say the game will be impressive it increased alot of expectations. I hope the user interface and user experience will be good to compete other popular battle Royale game out there! 

  

**Moreover**, the game is made by young & aspiring Indie developers who want to make  an impact on gaming industry in India and this is thier big first serious project which they are continuously working to make it feel great, so we have to wait and see how **WEX** Battle Royale game will make an impact on the gamers especially who like to play multi-player and Battle Royale modes.   

  

**Finally**, this is the buzz and information about the game **WEX **which is proudly made in india, do we raised your interest on this game, do you like the pre-release images, are you awaiting for the game like us?, if yes do mention your view and also share anything that you want to convey about **WEX **game, we like to hear from you in our comment section below, see ya :)