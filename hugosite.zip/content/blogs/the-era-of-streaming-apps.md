---
title: 'The Era Of Streaming Apps ?'
date: 2020-01-27T23:35:00.001+05:30
draft: false
url: /2020/01/the-era-of-streaming-apps.html
tags: 
- netflix
- Apps
- streaming
- technology
- movie
- Amazon
- latest
- prime
---

**The Era Of Streaming Apps ?**

  

Have you ever wanted to watch your favorite film again without spending bucks in home that in a week or month of time.

  

If you wanna watch you favorite movie that you liked with spending little at your comfort without the haavy task and watch as many times you need.

  

Back in good old days people used to buy their favorite or rent CD of their favorite movie.

  

When Netflix got this movie streaming service via apps enabling free and paid service as this is new

thing in market people got used to movie rental's and purchase from CD stores.

  

But in CD stores, there are some drawbacks that you have to return the CD in limited time else you get penalty so if you wanna watch whenever you wanted is not possible and some sluggish people won't even return CDs to stores.

  

CD stores are very popular and goes without any big issues or interupptions but criticism regarding

no preview or trail period.

  

**Definitely**, to get a idea of movie there is need of trailer or customer need to know the quality of product and service.

  

This feature is not available in CD stores even it is

good in its own customers doesn't have any other

way then buying a CD without watching a bit clip based on posters or hype and the genre or movie you liked it or not is not cared by anyone.

  

If you didn't liked the movie or you didn't satisfied with the quality or service than lost the bucks.

  

There are many complaints regarding these has been popup and a lot of allegations has been seen frequently.

  

To fix this all things then the time that Netflix got into movie streaming service in 2010 both the Netflix have DVD rental business.

  

In 2010 Netflix slowly expand its movie streaming

services to different countries with the website and apps in iOS and Android.

  

However, Netflix got immense response from all over the world with their quality and new way of approach, Netflix not only made people to use thier services they added new things to their service timely adding shows, collabarting with movies as partnering with movie makers as movie streaming.

  

Netflix made people to switch from old style of watching films and it does made the downfall of CD stores,

  

More streaming apps and sites got inspired by Netflix and entered into movie streaming.

  

Netflix then started producing series and shows and got good overwhelming response and it was one of the best decision ever made.

  

It not only limited to movie streaming but shows are huge hit among watchers and made netfix spread to more people around the world.

  

But, wait even though Netflix being the top streaming app in us and canada and many other countries.

  

It lacked and can be said not much popular and many people didn't even know what is Netflix in India.

  

2010 is the year of new thigs in technology many things appeared and improvised.

  

But india scenario is completely this was the time

the very tech oriented people know about netflix and piracy making hot talk and It was the one of the most discussed and widely used thing.

  

Illegal CD's of newly released movies appeared in widely around India and its cheap to buy to.

  

Oh yeah its a different story right ? OK let's don't get into that due to lack of phones In everyone and the usage of WiFi in India at the time Is very low compared to today and being lack of having low internet connection and lesser data made people no way to use this kind of services as it's hard to play blue ray movies in 100mb and with little screens.

  

However, in PC it got some well response from the tech community and geeks and many students.

  

Even netflix have idea and reality of india so they do launched Netflix lately compared to other country's

  

The time that changed everything is after Jio got and made revolutionary statement of free three

3months 4g data and unlimted internet.

  

This statement and the reception from public is shocked whole world and made india to top of data usage and the users of movie streaming apps got like never before.

  

This is where Netflix india got popular as never before but still being paid service its doesn't got response from everyone.

  

But netflix free trail got covered to stabilise and this worked well.

  

After seeing immense popularity and craze of streaming apps many TV channel made thier own streaming apps.

  

Like online shopping India got mostly have to face sane things by company's

  

Then online shopping giant amazon comes into streaming service to offer movies and series at less prices compared to competitors.

  

This also become huge popular in india as amazon have good brand value.

  

As amazon know how to advertise themselves smartly compared to netflix.

  

Will update article later ....