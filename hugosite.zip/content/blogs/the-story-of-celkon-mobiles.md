---
title: 'The Story oF Celkon Mobiles'
date: 2020-01-04T20:46:00.001+05:30
draft: false
url: /2020/01/the-story-of-celkon.html
tags: 
- technology
- Story
- smartphone
- Mobiles
- Celkon
---

  

[![](https://lh3.googleusercontent.com/-62PgoxLitPA/XhGWaRU_efI/AAAAAAAAAjY/37C3FLffiJMC2H0czy37rccpX-s-kWuzQCLcBGAsYHQ/s1600/20191231_134255-35.jpeg)](https://lh3.googleusercontent.com/-62PgoxLitPA/XhGWaRU_efI/AAAAAAAAAjY/37C3FLffiJMC2H0czy37rccpX-s-kWuzQCLcBGAsYHQ/s1600/20191231_134255-35.jpeg)

  

Hi, Earlier in the article [\[ Rise And Fall Of Indian Tech Giants \]](https://www.techtracker.in/2019/12/rise-and-fall-of-indian-tech-giants.html) that we shared the info how Xiaomi beaten other Indian tech company's and become an budget phone king of India till now.

  

It is very interesting how Xiaomi started and developing thier product and decreasing the prices and providing an value for money product to the Indian consumers.

  

While there are some Indian company's like Lava, iBall, Xolo, etc are collapsed thier business sells and struggling to keep up the brand name and hardworking to get profits from outdated products.

  

Celkon being an home grown and well recognised company from india started in Hyderabad as the company doesn't have any investors abroad and luckily it completed owned by a Indian ceo.

  

There is some interesting back story how Celkon able to keep up the things stable while other manufactures got vanished.

  

Now we will share you the amazing and intersting Celkon travel in a busy track.

  

As Celkon have referance name of cell which is a popular word used by indian's to call cell over phone one of the most widely used device name over other to indicate phones or mobiles it does helped Celkon to get a psychological feeling in purchaser mind to get higher sells in retail stores.

  

While celkon not only got popularised just because the name that indicates cell most widely used word Celkon have given a good profit margin to the retail sellers who ever sell thier products. Like today's oppo and vivo.

  

There are other manufactures like Lava and reliance take less profit and give good profit margin to the sellers why they didn't keep up and be stable in competition.

  

Here why, Celkon like to be updated in terms of design and features.

  

Yes, Unlike other Indian phone manufactures Celkon like to give a best design before even the lauch of Xiaomi first phone, Celkon design are really amazing that top companies like samsung doesn't able to do in a competitive price that Celkon offers to the public.

  

Most popular series like Celkon canvas and Celkon millenia being having an amazing design and features at a good price and a big screen witn a decent developer or can be said technical support.

  

One of the major reason that Celkon able to give bigger screens at a lesser price and lite weight and decent camera with cool features that competitors doesn't provided even they able to do chuncky designs are one of the reason that manufactures like Xolo and Lava unable to cope up.

  

Well it's not over yet, Celkon wide distribution to each and every store in the country getting more and more Celkon service centers nearby does helped alot.

  

Even though the celkon service centers are upto mark can be said pathetic service at certain outlets but offers good warranty time without any extra charges.

  

Earlier as we said Celkon camera used to get a good attention from public and it gives decent camera that can be used daily with a good resolution screens.

  

Even Celkon advertising is more better than other manufactures, that more boards front of retail stores eye catch advertisement's not only for smartphone but yes for mobile phones does given a good reputation and attention from public.

  

Well even the smartphone lineup collapsed for celkon, Celkon keypad phones are first priority taken devices after nokia and samsung if it's even 1500rs inr than most people used to prefer Celkon over nokia and samsung in india as this helped alot to Celkon.

  

While the struggle of software updates is a headache for Indian manufactures Celkon given upto mostly stock software and two or three minor or one big update to top seller and higer priced version atleast.

  

One of the most important thing is that helped Celkon is being an indian company yes most Indian's if something is value for money than definitely they gonna choose a indian company over other it does help indian company to grown and a increase in indian economy.

  

Offers - Yes, Celkon used to give 1+1 offers for keypad and smartphone's and only that collabarating witn retail outlets like big c does helped alot.

  

Moreover Celkon strategy and features and providing value for money and a good design and camera helped to be stable in a tough match being not a looser or a winner but a watcher and being watcher till now will it will come to the ring of compete let's see in the future.

  

Conclusion : Celkon being indian company does given good design and being good at advertising and good collabarating witn eye catchy features and offers does helped to be a cloud without rain let's wait and see when it will rain again.

  

Keep Supporting : TechTracker.in