---
title: 'What changes 5G can make in india,  digital revolution in future.'
date: 2022-10-06T20:00:00.001+05:30
draft: false
url: /2022/10/what-changes-5g-can-make-in-india.html
tags: 
- technology
- 5G
- changes
- digital revolution
---

 [![](https://lh3.googleusercontent.com/-oWFTRLttdxk/Yzit2mk_AVI/AAAAAAAAOIk/YpikFSsz4m09EScmAfLwVXHhJoiajTXlQCNcBGAsYHQ/s1600/1664658902670569-0.png)](https://lh3.googleusercontent.com/-oWFTRLttdxk/Yzit2mk_AVI/AAAAAAAAOIk/YpikFSsz4m09EScmAfLwVXHhJoiajTXlQCNcBGAsYHQ/s1600/1664658902670569-0.png) 

  

  

In india, people got internet late due to various reasons mainly because back then government didn't focus much on it and after long time when developed countries like america, uk, russia and china already extensively using internet then india begin slowly started accessing internet available on computers which definately changed alot of aspects that drived india towards using different digital technologies.

  

When computers and internet was gradually become necessary in many indian companies back in 1980s and 90s era in that process alot of people started buying computers for different purposes mainly to develop digital softwares due to that IT - information technology improved and upgraded drastically and several cities in india become tech hubs to name few hyderabad, mumbai, bangalore etc.

  

Fortunately, the futuristic vision of Andhra Pradesh state chief minister N Chandra Babu who played prominent role in the advancements of technologies in india because of his effective adminstration and presentation Microsoft and Google setup it's research and development centres in hyderabad concentrated in hi-tech city also known as cyber city over any other city in the world due to that india received huge attention and recognition globally.

  

 [![](https://lh3.googleusercontent.com/-TYj7Qo2ANjE/Y0BRb9ogw9I/AAAAAAAAOMw/bENjUmDjrTYwiw4gjN1duZxtWbJlkOYBQCNcBGAsYHQ/s1600/1665159529315986-0.png)](https://lh3.googleusercontent.com/-TYj7Qo2ANjE/Y0BRb9ogw9I/AAAAAAAAOMw/bENjUmDjrTYwiw4gjN1duZxtWbJlkOYBQCNcBGAsYHQ/s1600/1665159529315986-0.png) 

  

In sense, Microsoft's R&D center in year 1998 played one of the main role in attracting numerous top tier companies to urban areas of india beside prime minister PV Narasimha Rao economic reforms in year 1991 due to that india not just spiked and amplified it's usage of digital technologies but also escalated number of information technology start ups and companies like Tata, Infosys, Wipro, Satyam etc.

  

Even though, most of India's revenue is generated through banking, auto mobiles, cement, steel etc sectors and companies because of that they used to largely depend on them but once information technology sector companies also raging up with booming profits indian government also started focusing on them mainly since year 1991 and early 20th century which is not to level of other developed countries but definitely helped india to get potential and capability to build and make it's own infrastructure for self reliance in future.

  

Computers are quite expensive in india back in 1990s era as almost all of them are imported ones from many foriegn companies not even few digital personal computers are self made in india due to that it's reach is limited to some people mainly permitted to only companies at that time majority of people don't even know about computers not just in rural areas but also in urban cities as well.  

  

However, by mid of 20th century in india we got less expensive computers and it's better improvised version laptops thanks to capitalist world including that back then big percentage of customers begin buying computers due to promotions like adding information technology related subjects like CSE aka computer science as course in engineering colleges and making jobs for them that attracted students of both urban and rural areas which eventually become revolutionery support of india.

  

But, In order to use internet created by ARPANET and access it's public contents known as digital platforms in format of websites and blogs on supported world wide web like software browsers it require network data which is super expensive in india not just in year 1990s but also in full 20th century as back then the government didn't properly focused and encouraged in improving infrastructure of internet service providers due to that india stayed behind number of countries for ex : Singapore.

  

Especially, In replacement of old chunky mobile phones we got small in size user friendly keypad mobile companies which come with operating system basically software like computers which has ability to install tiny softwares and open up any internet's digital platforms at that time indian telecom operators become internet service providers by totally developing and launching 2G network which is slow but used to work well in web 1.0 era.

  

 [![](https://lh3.googleusercontent.com/-pSFiR7U8BJo/Y0BRaLuXHCI/AAAAAAAAOMs/uMYc_QwZxrovLjRn0JIJDrUetGguVPuhwCNcBGAsYHQ/s1600/1665159515403193-1.png)](https://lh3.googleusercontent.com/-pSFiR7U8BJo/Y0BRaLuXHCI/AAAAAAAAOMs/uMYc_QwZxrovLjRn0JIJDrUetGguVPuhwCNcBGAsYHQ/s1600/1665159515403193-1.png) 

  

Thankfully, Apple inc. a popular PC maker developed closed source hardware and software world's first revolutionary multi-touch technology smartphone in order to fully replace keypad mobile phones named iPhone was launched by it's founder Steve Jobs on January 9, 2009 after that due to  high demand numerous companies around the world started manufacturing thier own version of smartphone like iPhone using open source materials in that process we they done alot of advancements because of that now we have modern smartphones.

  

Smartphones used to support only 2G network bands in begginings era which become relaxation to india to keep it's pace and then when world is continously working on upgrading smartphones to 3G network then in year 2007 under United progressive alliance government few India politicians of ruling party done one of the world's biggest never before 2G spectrum scam that approximately worth 70,000 INR crores ( 8.8$ billon ) disappointing isn't?

  

Anyhow, people of india after few years forgot about 2G spectrum scam and they begin using 3G smartphones when they entered in india from both foreign and indian companies which are much better and faster then 2G based smartphones but even after decade of 3G network entry in market still it's costly in india because india telecom operators like Airtel, Idea, Vodafone etc together partnered and done huge foul play basically scammed people of india with expensive mobile data plans. like 1GB of mobile used to cost 300 INR that to for monthly or annual basis.

  

 [![](https://lh3.googleusercontent.com/-vbLyFjbVQXg/Y0BRWgLdazI/AAAAAAAAOMo/F8n1yyXhejkNrqmFEeapHufaqlda0IztQCNcBGAsYHQ/s1600/1665159510414920-2.png)](https://lh3.googleusercontent.com/-vbLyFjbVQXg/Y0BRWgLdazI/AAAAAAAAOMo/F8n1yyXhejkNrqmFEeapHufaqlda0IztQCNcBGAsYHQ/s1600/1665159510414920-2.png) 

  

  

We have many conglomerates in india out of them Reliance is one founded by well known Dhirubhai Ambani but after his demise in year 2002 that was later divided and handed over to his sons Mukesh and Anil Mukesh under the supervision of thier mother Kokilaben Ambani in that scenario Reliance petroleum was given to Mukesh Ambani and Reliance tele-communications given to his younger brother Anil Ambani with a condition that up to certain period of time may be like 10 years one should not enter into another business.

  

Reliance tele-communications has long history which revolutionized telecom industry of india under Dhirubhai Ambani he visioned and manufactured low cost affordable smartphones to reach every household in india then after decade it came under hands of his son Anil Ambani who used to provide mobile data plans at almost same price of other indian mobile telecom operator companies.

  

 [![](https://lh3.googleusercontent.com/-rEx31cxwsnM/Y0BRVW9hHxI/AAAAAAAAOMk/gKOT7tAGuL4PHu0VWJZZuGELBf9RIbvegCNcBGAsYHQ/s1600/1665159505000681-3.png)](https://lh3.googleusercontent.com/-rEx31cxwsnM/Y0BRVW9hHxI/AAAAAAAAOMk/gKOT7tAGuL4PHu0VWJZZuGELBf9RIbvegCNcBGAsYHQ/s1600/1665159505000681-3.png) 

  

  

Mukesh Ambani after the validity expiry of condition he entered in telecom industry and started Jio which instead of using 2G and 3G build modern 4G LTE infrastructure that was on testing phase in year 2015 then after 1 year it was released in year 2016 with revolutionary mobile data plans like free 4GB mobile data per day for 3 months then extended for more 3 months and another 3 months with prime plan due to that mobile data not just become very affordable but also Indian people started using internet pretty extensively.

  

The mobile data usage in india went to such level it reached no 1 position globally and then Reliance freebies got to an end with amazing offers still going on but the price of 1GB mobile data is just 10rs per day making it much affordable as possible due to that Jio network gained millions of customers in quite short time and now an individual in india use atleast 14GB per month, cool and astonishing right?

  

Anyway, it's been more then 5 years of 4G launch in india and already many countries around the world developed thier own 5G network back then india used to rely on foriegn technologies to build mobile networks but this time it's different thanks to futuristic and visionary digital india, made and make in india, Aatma Nirbhaar Bharat aka self reliant india programs by current government that inspired and supported indian companies due to that now we have our own true 5G network.

  

5G network is first launched by South Korea in year 2019 then follows now this year India government conducted 5G network spectrum bands commercial auction in that many indian telecom operators joined and bid prices for 5G network bands out of them Jio is highest bidder which purchase strong and ultra low latency 5G network band to provide true 5G network outside and insider areas after that Airtel comes in place.

  

Now, companies around the world and in india as well Integrating 5G network not just in smartphones but in many other technologies as it has potential and capability with 10X then 4G that can not just stream 10 4K resolution videos simultaneously but also can also download giga bytes of files in one seconds that confirms its superiority over 4G network which is why it is going to be utilised in various sectors for sure.

  

If indian government rely on mobile towers to reach 5G network to every corner of india then it may not work as still in some rural tribal areas 4G not reached in full scale instead it's better to rely on satellite to provide 5G network services by using technologies like Tesla inc. Starlink that can provide uninterrupted seamless 5G network speed in area even performs well in bad weather conditions likerain, snow, and wind etc for sure.

  

Tata, an indian company already has it's own technologies like Starlink which they developed in partnership with an american company named Tata Nelco Telsat which can bring technologies of Starlink to india if we can get it soon then the usages of 5G network will maximize which unlock alot of possibilities by enabling it's expansion to more sectors at that same time reach every corner of india even to those areas that don't have 2G, 3G and 4G networks.

  

In case of 5G network price as we all know 4G network is undoubtedly at affordable price after that now telecom companies are setting up everything to launch 5G network so I expect price to be bit higher then existing 4G mobile network plans even companies like Jio may also provide first few months free 5G network as part of testing and promotions or even provide awesome offers to attract you and gain customers in huge numbers to stay and survive in this competition between existing telecom network operators.

  

Usually, once 5G launched commercially launched in india for public usage then at first it was heavily going to be used on smartphones and optical fiber networks for computers and smart tv etc after that thanks to 5G network long distance wide area powerful signal coverage it can be utilised to fly drones not just for photo or videography but also for surveillance and automation of on field works to name few like agriculture, products delivery through robots in e-commerce industry, cloud PCs to students in unavailable villages where they don't have facilities etc.

  

The another main speciality and advantage of true 5G network is if that can be utilised with virtual or augmented or it's hybrid mixed reality technology then users will feel the virtual world much better then before like atmost pin point accuracy with super high definition and resolution heavy resources intensive 4K or higher graphics that you can see and play immersively.

  

Recently, on Oct 1 speaking on different aspects of 5G network at IMC aka India mobile congress prime minister Narendra Modi launched 5G services in india which is not yet available in sim or e-sim card format yet but as per Mukesh Ambani Jio India's leading telecom network operator rapidly progressing to roll out 5G services in india by this month and every nook and corner of the country by year 2023.

  

Once, mobile network operators roll out 5G network in india as we already have many affordable 5G smartphones which people already begin buying from past few years but the percentage is not high yet when 5G mobile data will be released then alot of people started buying 5G smartphones to stay up to date by that time india fully get 5G by 90% there is chance of 6G trails.

  

In my perspective, if india can make it's own 5G network not depending on foreign companies two years after South Korea then there is possibility that 6G can be developed in india as well for that I believe if indian telecom operators from now itself start working on 6G like many countries for instance china launched world's first 6G satellite so that even if india don't launch 6G network first but it may be in top 5 countries to release 6G networks.

  

Finally, this are the changes 5G networks will get in india to futher revolutionize digital technology and when 5G network tuned it at right beat it will reach every where and provide services and enjoyment to each and every individual in the world, are you an existing user of 5G? If yes do say your experience and mention why you like and prefer 5G network in our comment section below, see ya :)