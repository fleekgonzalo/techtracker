---
title: 'Delta - Use your regular email for Instant messaging like signal!'
date: 2021-08-26T23:44:00.001+05:30
draft: false
url: /2021/08/delta-use-your-regular-email-for.html
tags: 
- email
- Apps
- Delta Chat
- Instant Messaging
---

 [![](https://lh3.googleusercontent.com/-D7I2KUOgG9I/YSfaHTYorPI/AAAAAAAAGe0/TrgzSvmbT2ocb4oxn3s57LTfOBzoW4O_ACLcBGAsYHQ/s1600/1630001690196986-0.png)](https://lh3.googleusercontent.com/-D7I2KUOgG9I/YSfaHTYorPI/AAAAAAAAGe0/TrgzSvmbT2ocb4oxn3s57LTfOBzoW4O_ACLcBGAsYHQ/s1600/1630001690196986-0.png) 

  

  

E-mail - Electronic mail is the first digital communication technology invented to send and receive information between two or more people with a unique digital email address for sender and reciever generated and provided by thier email service providers they must need computer and a internet connection to check & see emails.

  

It is known fact Email is widely used by people around the world as it is easy & very convenient way to send and receive information but as technology is in rapid advancements in 20th century we got to see many new technologies that can make communication more easy and simple.

  

Yes, In 20th century we got numerous new revolutionary technologies that will make communication more easy and better like one of coolest innovation was instant messaging apps which made people to convert from Email to this new instant messaging apps due to thier simplicity & user friendly experience people just mesmerized and got fond of them & yes most instant messaging apps don't need any email address but a phone number for registration and verification of indentity purposes.

  

So, most people started regularly using instant messaging apps to communicate over e-mail but e-mails are still in use and they still considered as a way of sending and receiving Information but it is known fact E-mail don't give you simple & easy communication experience due to that people at large scale occasionally using emails whenever it's required.

  

But, there are alot of people daily send & recieve numerous e-mails for them they still have to rely on e-mail clients which have old fashioned user interface that is little hard and boring to use and there is no choice,  isn't it better if we have a email client with user interface and features of instant messaging app so that you'll get simple and easy to use chatting experience? 

  

In this scenario, we have a workaround we found a app named Delta Chat which is basically a free open source email client but with modern user interface and features like Instant messaging apps and Delta Chat is a decentralised so contact data remain on your devices, No uploads of address book, calendar or other personal data, There simply are no Delta Chat servers where anything could be uploaded, do we got your attention? Are you interested on Delta Chat ? If yes let's know little more info about Delta Chat to get started.

  

**• Delta Chat Official Support •**

**Email** : [delta.merlinux.eu](http://delta.merlinux.eu)

  

**Website** : [delta.chat/en/](http://delta.chat/en/)

  

**\- App Info** = [Google Play](https://play.google.com/store/apps/details?id=chat.delta) / [App Store](https://apps.apple.com/us/app/delta-chat/id1459523234)

**• How to download Delta Chat •**

It is very easy to download Delta Chat from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=chat.delta)

\- [App Store](https://apps.apple.com/us/app/delta-chat/id1459523234)

\- [F-Droid](https://f-droid.org/app/com.b44t.messenger)

\- [Amazon App Store](https://www.amazon.com/dp/B0864PKVW3/)

\- [Windows](https://www.microsoft.com/en-us/p/deltachat/9pjtxx7hn3pk?activetab=pivot:overviewtab)

\- [Mac OS](https://apps.apple.com/us/app/delta-chat-desktop/id1462750497)

\- [Linux](https://flathub.org/apps/details/chat.delta.desktop) 

  

**Note** : Delta Chat offers quick chatting & synchronization across many devices, yes  Messages once sent one device will quickly show up on other devices, All Desktop versions can be used standalone or in conjunction with a mobile version either it's iphone, mac, windows, Linux etc.

  

**• Delta Chat key features with UI / UX Overview •**

 [![](https://lh3.googleusercontent.com/-0gP_FMrT81k/YSfaGKKkjxI/AAAAAAAAGew/0ZoUwqOsl5k06-H1B4AIxZ4sS_zaT4BrQCLcBGAsYHQ/s1600/1630001684120545-1.png)](https://lh3.googleusercontent.com/-0gP_FMrT81k/YSfaGKKkjxI/AAAAAAAAGew/0ZoUwqOsl5k06-H1B4AIxZ4sS_zaT4BrQCLcBGAsYHQ/s1600/1630001684120545-1.png) 

  

**\-** Open Delta Chat & Tap on **LOG IN TO YOUR SERVER.**

  

 [![](https://lh3.googleusercontent.com/-HxqP9ctW2zM/YSfaEjWQjuI/AAAAAAAAGes/ONpswSRyZGka7lTT7mV0IKbHMUFRDRs4ACLcBGAsYHQ/s1600/1630001678095866-2.png)](https://lh3.googleusercontent.com/-HxqP9ctW2zM/YSfaEjWQjuI/AAAAAAAAGes/ONpswSRyZGka7lTT7mV0IKbHMUFRDRs4ACLcBGAsYHQ/s1600/1630001678095866-2.png) 

  

**\-** Enter your E-mail Address, You can use any e-mail provided by your e-mail service provider like either it's Gmail, Yahoo, etc, all are supported in Delta Chat.

  

\- Then, Enter your Existing password of your email and  tap on **✓**

  

Note : You can do O2 type authentication for faster signup through browser.

  

 [![](https://lh3.googleusercontent.com/-RH8bqJxrwgQ/YSfaDJIIFOI/AAAAAAAAGeo/LsJz41Fx7mI5t3p-ri02kczKj9MDbTr_wCLcBGAsYHQ/s1600/1630001671065932-3.png)](https://lh3.googleusercontent.com/-RH8bqJxrwgQ/YSfaDJIIFOI/AAAAAAAAGeo/LsJz41Fx7mI5t3p-ri02kczKj9MDbTr_wCLcBGAsYHQ/s1600/1630001671065932-3.png) 

  

\- Tap on **CONTINUE** then allow permissions.

  

 [![](https://lh3.googleusercontent.com/-7AC78_VEAr0/YSfaBcCp7wI/AAAAAAAAGek/IhI6GOqpc5YoOwZ3JWf37k511XNhBQtJACLcBGAsYHQ/s1600/1630001666644542-4.png)](https://lh3.googleusercontent.com/-7AC78_VEAr0/YSfaBcCp7wI/AAAAAAAAGek/IhI6GOqpc5YoOwZ3JWf37k511XNhBQtJACLcBGAsYHQ/s1600/1630001666644542-4.png) 

  

**\-** You're in **Delta Chat.**

 **[![](https://lh3.googleusercontent.com/-xttItPAfn4I/YSfaASjuINI/AAAAAAAAGeg/51y0bwvKzWom4YtoRosj5vPlz_BlLqjaACLcBGAsYHQ/s1600/1630001661602936-5.png)](https://lh3.googleusercontent.com/-xttItPAfn4I/YSfaASjuINI/AAAAAAAAGeg/51y0bwvKzWom4YtoRosj5vPlz_BlLqjaACLcBGAsYHQ/s1600/1630001661602936-5.png)** 

**\- In saved messages**, you can take notes, voice memos, attach media to save them.

  

 [![](https://lh3.googleusercontent.com/-LBCSD2eTo2o/YSfZ_LYjrDI/AAAAAAAAGec/KKXlNbfz_I4w-JHAVpl6Pe-qqaJDCQ1RwCLcBGAsYHQ/s1600/1630001654685575-6.png)](https://lh3.googleusercontent.com/-LBCSD2eTo2o/YSfZ_LYjrDI/AAAAAAAAGec/KKXlNbfz_I4w-JHAVpl6Pe-qqaJDCQ1RwCLcBGAsYHQ/s1600/1630001654685575-6.png) 

  

\- In Device messages, you will get latest updates of Delta Chat.

  

 [![](https://lh3.googleusercontent.com/-bwPr8XTlzCU/YSfZ9Q8Q1pI/AAAAAAAAGeY/I_tP_YlvWP47IncVqhrq_4FLLeF9acv3QCLcBGAsYHQ/s1600/1630001649597512-7.png)](https://lh3.googleusercontent.com/-bwPr8XTlzCU/YSfZ9Q8Q1pI/AAAAAAAAGeY/I_tP_YlvWP47IncVqhrq_4FLLeF9acv3QCLcBGAsYHQ/s1600/1630001649597512-7.png) 

  

\- You can create Groups.

  

 [![](https://lh3.googleusercontent.com/-BY2zNuRx9O0/YSfZ8C9cmrI/AAAAAAAAGeU/CJgCctuDR_8penZT36R2-3i_2oYGmQzNwCLcBGAsYHQ/s1600/1630001644899815-8.png)](https://lh3.googleusercontent.com/-BY2zNuRx9O0/YSfZ8C9cmrI/AAAAAAAAGeU/CJgCctuDR_8penZT36R2-3i_2oYGmQzNwCLcBGAsYHQ/s1600/1630001644899815-8.png) 

  

**\- In menu**, we have New chat, Contact requests, Settings, help, switch accounts.

  

 [![](https://lh3.googleusercontent.com/-TS9ysdTEYdo/YSfZ6_SJkVI/AAAAAAAAGeQ/RlDo0X7H64g5ehYj8eb4VcZYbZ-Gh8iygCLcBGAsYHQ/s1600/1630001639964009-9.png)](https://lh3.googleusercontent.com/-TS9ysdTEYdo/YSfZ6_SJkVI/AAAAAAAAGeQ/RlDo0X7H64g5ehYj8eb4VcZYbZ-Gh8iygCLcBGAsYHQ/s1600/1630001639964009-9.png) 

  

\- **In settings**, we have this options.

  

 [![](https://lh3.googleusercontent.com/-ozS97-MjNQw/YSfZ5qxakqI/AAAAAAAAGeM/X2z8D6IohwMlWReF61UdBksLBILglQZUQCLcBGAsYHQ/s1600/1630001633164446-10.png)](https://lh3.googleusercontent.com/-ozS97-MjNQw/YSfZ5qxakqI/AAAAAAAAGeM/X2z8D6IohwMlWReF61UdBksLBILglQZUQCLcBGAsYHQ/s1600/1630001633164446-10.png) 

  

**\- In appearance**, we got light & dark theme

  

Atlast, By using Delta Chat you can chat with with anyone with thier e-mail address when you send a email, recipients will just see a simple e-mail and they can directly reply with thier own e-mail app, They don't need to install Delta Chat, visit websites or sign up anywhere else for example : if you send a picture or any other media to a chat group your chat recipients will see a nice normal regular e-mail with an attachment. If they send you a message & attachments back, you will see the media in your chat for this contact.

  

Overall, Delta Chat is quick, fast, simple, and useful just like Telegram, Signal, WhatsApp packed with instant messaging app features to communicate conveniently it is very easy to use due to its clean and user friendly interface which gives you superb user experience but we have to wait and see will Delta Chat get any major UI changes in future to make it even more better, as of now Delta Chat have perfect user interface that you may like to use for sure.

  

Moreover, Delta Chat establishes end-to-end encryption automatically when you start chatting with anyone, On a two people chat, for example : if you  just send a "Hola!" message and already receive an encrypted reply if the other side accepts you as a contact, End-to-End encryption not only works between Delta Chat apps but also it will work with other e-mail apps if they support the Autocrypt Level 1 encryption standard.

  

Finally, This is Delta Chat a free open source decentralised email client with user interface, functionality and features of instant messaging apps, so do you like it ? If yes do say your experience and incase if you are an existing user of Delta Chat do say which feature you like the most in our comment section below, see ya :)