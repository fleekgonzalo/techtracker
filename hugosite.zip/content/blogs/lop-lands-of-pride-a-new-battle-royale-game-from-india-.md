---
title: 'LOP - Lands of Pride : A New Battle Royale Game from India! '
date: 2021-02-01T23:32:00.002+05:30
draft: false
url: /2021/02/lop-lands-of-pride-new-battle-royale.html
tags: 
- Lands of Pride
- technology
- FAUG
- India
- Royale
- Pubg
- Battle
---

 [![](https://lh3.googleusercontent.com/-axbBWv-KhAQ/YBhCKHkHymI/AAAAAAAADG8/hkKE6LxNMmMj2lscaaK0NvoJLD5Kd49EACLcBGAsYHQ/s1600/1612202531038617-0.png)](https://lh3.googleusercontent.com/-axbBWv-KhAQ/YBhCKHkHymI/AAAAAAAADG8/hkKE6LxNMmMj2lscaaK0NvoJLD5Kd49EACLcBGAsYHQ/s1600/1612202531038617-0.png) 

  

PubG the most popular battle royale game is banned in India due to national integrity & data breach issues it is trying to return in India but not yet returned and in future it will return or not is in question! 

  

After the ban of pubg in India a Bangalore based Indian gaming company announced fearless and united guards action game with India's most popular actor akshay Kumar due to that faug got immense craze among Indian people and Indian gamers so people started thinking it as an alternative but after alot of delays faug was released on 26th January but it doesn't reached the expectations.

  

**Yes**, faug need alot of more features and modes due to that people started using pubg Korea or PC version but another gaming company in this situation named mahant gaming announced a new game called Lands of Pride which is a battle Royale game with Indian touch. 

  

It is made by small team of developers, designers and artists, who are trying to make difference in global game develop- ment industry by creating games that will make difference globally they start from Design and finish with a Game which can be played and analyzed by any gamer across the globe.

  

We know very few details of game the developers and company not yet released any big details regarding the app but they released a trailer which is promising but to see the reality of game we have wait till it's release of app on playstore or website. 

**LOP - Lands of Pride** use the tagline, ENTER. SURVIVE. TERMINATE Game will have more Indian Maps \[  Environments \] & Indianized Characters with customization of Indian outfits. You can localize your character with Indian Weapons, Props and Accessories. 

  

**LOP - Lands of Pride** game only have multiplayer and battle royale modes they just mentioned this in website but we have to wait for updates either it has any single player or not like faug or pubg or training mode etc. 

  

**Website** :- [mahantgames.com](https://mahantgames.com/)

  

**• Watch LOP Trailer •**

  

[https://youtu.be/hM0-9soLagQ](https://youtu.be/hM0-9soLagQ)  

  

**• Review of LOP Trailer with key features and UI & UX Overview •**

 **[![](https://lh3.googleusercontent.com/-Bk9rasO6WVw/YBhCIuJuEXI/AAAAAAAADG4/pJwxsE6GoQM9DUqgjtYqGl4Mk8vbTrNAQCLcBGAsYHQ/s1600/1612202525361405-1.png)](https://lh3.googleusercontent.com/-Bk9rasO6WVw/YBhCIuJuEXI/AAAAAAAADG4/pJwxsE6GoQM9DUqgjtYqGl4Mk8vbTrNAQCLcBGAsYHQ/s1600/1612202525361405-1.png)** 

**

[![](https://lh3.googleusercontent.com/-83E9teCVRhs/YBhCHABuZfI/AAAAAAAADG0/KrvMvvFNAHgBMY0n82WoHOoeNMYk_R_qwCLcBGAsYHQ/s1600/1612202521182143-2.png)](https://lh3.googleusercontent.com/-83E9teCVRhs/YBhCHABuZfI/AAAAAAAADG0/KrvMvvFNAHgBMY0n82WoHOoeNMYk_R_qwCLcBGAsYHQ/s1600/1612202521182143-2.png)

  
**

 [![](https://lh3.googleusercontent.com/--cRw8L86h2U/YBhCGPBMZ4I/AAAAAAAADGw/Xs3Fic1ybRwsXYKgKNWrIHYjGOa9B9QRgCLcBGAsYHQ/s1600/1612202516755684-3.png)](https://lh3.googleusercontent.com/--cRw8L86h2U/YBhCGPBMZ4I/AAAAAAAADGw/Xs3Fic1ybRwsXYKgKNWrIHYjGOa9B9QRgCLcBGAsYHQ/s1600/1612202516755684-3.png) 

  

 [![](https://lh3.googleusercontent.com/-JrwyUFETks4/YBhCFA-G6II/AAAAAAAADGs/fihBk4zntNwB8SsX-z_bFkASw0ICvOdiQCLcBGAsYHQ/s1600/1612202512392700-4.png)](https://lh3.googleusercontent.com/-JrwyUFETks4/YBhCFA-G6II/AAAAAAAADGs/fihBk4zntNwB8SsX-z_bFkASw0ICvOdiQCLcBGAsYHQ/s1600/1612202512392700-4.png) 

  

 [![](https://lh3.googleusercontent.com/-6scO3dP-pjM/YBhCD1rzPYI/AAAAAAAADGo/ntnlXeEnNv4IB9lvVhR24TNSkDyUxcvpQCLcBGAsYHQ/s1600/1612202506743294-5.png)](https://lh3.googleusercontent.com/-6scO3dP-pjM/YBhCD1rzPYI/AAAAAAAADGo/ntnlXeEnNv4IB9lvVhR24TNSkDyUxcvpQCLcBGAsYHQ/s1600/1612202506743294-5.png) 

  

 [![](https://lh3.googleusercontent.com/-zsjbIVjE3qE/YBhCCYecbGI/AAAAAAAADGk/Jfs-uhXAzIksICHKWISB4KIO7wtFQsV4gCLcBGAsYHQ/s1600/1612202501067704-6.png)](https://lh3.googleusercontent.com/-zsjbIVjE3qE/YBhCCYecbGI/AAAAAAAADGk/Jfs-uhXAzIksICHKWISB4KIO7wtFQsV4gCLcBGAsYHQ/s1600/1612202501067704-6.png) 

      

 **[![](https://lh3.googleusercontent.com/-RL4UQoGs1ZQ/YBhCBIX6piI/AAAAAAAADGg/q5eYxc-gW8AZcJ4gIB-4GyhlwXuZ5F2jgCLcBGAsYHQ/s1600/1612202495817703-7.png)](https://lh3.googleusercontent.com/-RL4UQoGs1ZQ/YBhCBIX6piI/AAAAAAAADGg/q5eYxc-gW8AZcJ4gIB-4GyhlwXuZ5F2jgCLcBGAsYHQ/s1600/1612202495817703-7.png)** 

 **[![](https://lh3.googleusercontent.com/-6NCipKt4Pyw/YBhB_q4xksI/AAAAAAAADGc/yiABY3fBWHc1sIzQx5eRrBegZKQKHJ5pgCLcBGAsYHQ/s1600/1612202489891578-8.png)](https://lh3.googleusercontent.com/-6NCipKt4Pyw/YBhB_q4xksI/AAAAAAAADGc/yiABY3fBWHc1sIzQx5eRrBegZKQKHJ5pgCLcBGAsYHQ/s1600/1612202489891578-8.png)** 

**Overall**, **LOP** trailer looks advanced the character movements and locations are cool with popular features as game also comes with Indian outfits and Indian characters which will be awesome but we have to wait and see either the trailer only amaze us or the game also have potential to make you feel awesome or not in future. 

  

**Finally**, it is nice to see more battle Royale games from indian developers which is a good fortune what do you think about the LOP - lands of pride game say in our comment section below, see ya :-)