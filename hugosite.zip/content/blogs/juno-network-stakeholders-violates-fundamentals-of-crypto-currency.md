---
title: 'Juno network stakeholders violates fundamentals of crypto currency.'
date: 2022-03-16T23:00:00.001+05:30
draft: false
url: /2022/03/juno-network-stakeholders-violates.html
tags: 
- Juno network
- Fundamentals
- Stake holders
- CryptoCurrency
- Voilates
---

 [![](https://lh3.googleusercontent.com/-7-fOM3K6A9U/YjIeuPy9NfI/AAAAAAAAJtE/7sAEMdMU_bAPG3XCwZGBG5clJ6rcicX6QCNcBGAsYHQ/s1600/1647451829653745-0.png)](https://lh3.googleusercontent.com/-7-fOM3K6A9U/YjIeuPy9NfI/AAAAAAAAJtE/7sAEMdMU_bAPG3XCwZGBG5clJ6rcicX6QCNcBGAsYHQ/s1600/1647451829653745-0.png) 

  

Juno network stakeholders for the first time voilates the fundamentals of crypto currency by voting a proposal to rug pull funds of whale wallet who gambled juno Airdrop by creating 51 wallets instead 1, eventhough there is no written rules from juno network which states that a person shouldn't create multiple wallets to join airdrop but still Juno network created a proposal to rug pull the funds of whale's wallet and interestingly proposal is passed and juno stakeholders are excited to see what's gonna happen in future.

  

In the history of crypto currency, Juno is the first crypto network to get a proposal to rug pull a crypto wallet which voilates the fundamentals of crypto currency, you may know the concept of crypto currency is to provide military grade security and privacy to users, that's why crypto wallets generate backup phrases and say users to backup somewhere safe as they are the only method to recover funds.

  

In terms of legal and ethical perspective, a crypto network shouldn't have right to rug pull a person crypto wallet, it's not the job of a crypto network, however in order to do this juno network may have to halt chain and do software upgrade to empty the wallet of one person who owns 50k juno tokens in each of his 50 wallets and then later transferred them to one wallet with total worth of 2.5m juno tokens which is max for 1 wallet.

  

But, the question arises here is how the unknown person who created proposal #16 even know that the person who got all airdrop winnings in 1 wallet really gambled Airdrop? Isn't there chance that airdrop winners intentionally transferred thier winnings to one wallet for whatever reasons, there is probability right, so how juno network able to create a proposal to rug pull some one's crypto wallet without knowing and verifying details? Juno must understand the propoosal is childish and unprofessional.

  

  

 [![](https://lh3.googleusercontent.com/-ge7yK7Awa7U/YjIetLSv0JI/AAAAAAAAJtA/gLFJmgEm8pQFWPbcERtk6LuZmE_E1v3jACNcBGAsYHQ/s1600/1647451825570278-1.png)](https://lh3.googleusercontent.com/-ge7yK7Awa7U/YjIetLSv0JI/AAAAAAAAJtA/gLFJmgEm8pQFWPbcERtk6LuZmE_E1v3jACNcBGAsYHQ/s1600/1647451825570278-1.png) 

  

 [![](https://lh3.googleusercontent.com/-ytFPtEsWTiY/YjIesJAzddI/AAAAAAAAJs8/V4LBgi8SbvEDobiOiI_gLvfve4Is4KWOACNcBGAsYHQ/s1600/1647451821390317-2.png)](https://lh3.googleusercontent.com/-ytFPtEsWTiY/YjIesJAzddI/AAAAAAAAJs8/V4LBgi8SbvEDobiOiI_gLvfve4Is4KWOACNcBGAsYHQ/s1600/1647451821390317-2.png) 

  

  

Eventhough, proposal #16 rug pull proposal won by slight upvote percentage and then only it was passed yet how juno network know the voting is genuine, isn't there chance of fake voting? people can create multiple wallets or account to fake vote same as the person who created 51 wallets to join airdrop.

  

Actually, a guy named Jacob Gadikian created a proposal #4 back in 2021-10-12 to reduce 90% fund and blacklist of same wallet, as they believe Airdrop is gamed, but thankfully proposol #4 was rejected, what's suspicious here is when the proposal #4 and proposal #16 is for same, purpose? why only proposal #16 passed? isn't this shady? 

  

Anyhow, proposal #16 to to rug pull funds of wallet was somehow passed, and juno stakeholders waiting to know how Juno network going to respond and move on this, if Juno network rejects the passed proposol #16 then there will be some dissapointed from juno stakeholders who voted to rug pull, but if juno network passes proposal #16 then it's illogical and voilates the fundamentals of crypto world, let's see what will happen?

  

 [![](https://lh3.googleusercontent.com/-xKerfQEzJFo/YjIerJIoEqI/AAAAAAAAJs4/mbKIMn9u8v8eL6ehGptTPT9U9y5Ac37kgCNcBGAsYHQ/s1600/1647451816444235-3.png)](https://lh3.googleusercontent.com/-xKerfQEzJFo/YjIerJIoEqI/AAAAAAAAJs4/mbKIMn9u8v8eL6ehGptTPT9U9y5Ac37kgCNcBGAsYHQ/s1600/1647451816444235-3.png) 

  

Meanwhile, Takumi Asano created and published draft of an official [constitution](https://commonwealth.im/juno/discussion/4054-create-an-official-constitution-including-the-vision-of-the-core1-team)  which includes the vision of the Core-1 team and for governence of Juno network, you heard that right constitution for crypto network, while in parallel Takuma Asano and his supporters already voilated the basic fundamentals or crypto currency with proposol #4 and #16.

  

In my opinion, proposal #4 and #16 are completely wrong, decentrailised crypto networks are created for security of funds and privacy of users, crypto networks are not banks to seize funds whenever they want, crypto networks work with different agenda and technologies, if you apply the principles of bank on crypto networks then it won't work as satoshi nakamoto created world's first decentrailised crypto currency bitcoin for an better and secure alternative to banks, including that crypto networks are not even legalised in most countries.

  

Finally, this is Juno a decentrailised crypto network just like bitcoin, ethereum tron and solana, but are you an existing user of juno network? If yes have you voted proposal #4 and proposal #16? do say us why you supported them in our comment section below, see ya :)