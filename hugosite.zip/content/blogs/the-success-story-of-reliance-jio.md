---
title: 'The success story of Reliance Jio.'
date: 2022-06-21T12:00:00.000+05:30
draft: false
url: /2022/06/the-success-story-of-reliance-jio.html
tags: 
- Jio
- technology
- Reliance
- Success
- Story
---

 [![](https://lh3.googleusercontent.com/-22LLA_n0_bA/YrIYcR59hBI/AAAAAAAAMA4/B7s4FPSOWAcqUnzxz9H1GPMG019CBpOMwCNcBGAsYHQ/s1600/1655838827866315-0.png)](https://lh3.googleusercontent.com/-22LLA_n0_bA/YrIYcR59hBI/AAAAAAAAMA4/B7s4FPSOWAcqUnzxz9H1GPMG019CBpOMwCNcBGAsYHQ/s1600/1655838827866315-0.png) 

  

  

Dhirubai Ambani, India's business tycoon born on December 28, 1932 in chorwad city of India who come from poor financial background family but still he always dream big right from his early childhood days Dhirubai Ambani shown interest to start something he didn't learn bussiness lessons from an college neither he have a degree instead he learnt business lessons through real life experiences.

  

 [![](https://lh3.googleusercontent.com/-32JRCJqzDq8/YrImdOS-POI/AAAAAAAAMBY/CU0DI-vprRgiXgLEyr0PkQGRIknooeWRgCNcBGAsYHQ/s1600/1655842416153334-0.png)](https://lh3.googleusercontent.com/-32JRCJqzDq8/YrImdOS-POI/AAAAAAAAMBY/CU0DI-vprRgiXgLEyr0PkQGRIknooeWRgCNcBGAsYHQ/s1600/1655842416153334-0.png) 

  

There are many entrepreneurs in the world who don't have education or degree yet they got success that proves education is not always necessary to be successful as real life lessons teach more then any one  incase of Dhirubai Ambani he has mindset of bussiness man from his childhood days that leaded him to rent a cycle to deliver news papers early in morning and then with that money he become small street tea seller.

  

We have numerous people in India who used to sell tea in thier childhood and then become international figures to name few India's prime minister Narendra Modi and Dhirubai Ambani respectively this shows anyone can achieve thier dreams if they have commitment to work hard and pure determination to face challenges.

  

It is well known fact there is no easy way to get victory even if there is one that won't work or sustain for long as empires are not build in one day they take years even decades for tough warships to get fruitful end like wise Dhirubai Ambani faced alot of struggles in his life and bussiness ventures but he never give up that attitude made him india's richest man.

  

 [![](https://lh3.googleusercontent.com/-mNMiwyhvuWI/YrImb1hJcdI/AAAAAAAAMBU/CN9k7kkC45UY8_Ltij5ArbYJUj0ACvjIwCNcBGAsYHQ/s1600/1655842412488372-1.png)](https://lh3.googleusercontent.com/-mNMiwyhvuWI/YrImb1hJcdI/AAAAAAAAMBU/CN9k7kkC45UY8_Ltij5ArbYJUj0ACvjIwCNcBGAsYHQ/s1600/1655842412488372-1.png) 

  

India's biggest conglomerate Reliance industries is founded by Dhirubai Ambani but that foundation was laid with his early childhood days money you heard that right Dhirubhai Ambani saved all money that he earn from small businesses then went to work in a petrol bunk in UAE - Dubai where he saved alot of money then after many years he came back to India and started a small factory named Reliance Textiles with brand named Vimal.

  

Reliance Textiles used to make high quality wool and polyster at that time in industry yet people didn't buy them but  Dhirubai Ambani didn't step back instead he went to public places and shown the quality of his textile products since then Reliance Textiles got super popularity with overwhelming sells due to that reliance become pioneer in textile industry.

  

In bussiness, you must have confidence on your products then anyone else that can be learnt from Dhirubai Ambani he didn't stop with textile factory later on Dhirubhai Ambani ventured into number of businesses like  telecommunications, petrochemicals, energy, natural gas, retail, mass media etc and all of them are profitable thanks to product quality and Dhirubai Ambani extensive capabilities to manage business in any situations.

  

Usually, when you start a business you'll get losses that is common but how you overcome it depend the future of your startup or well established company, in case of Dhirubai Ambani even when Reliance is in huge losses due to various reasons mainly because of india's biggest stock market crash in year April 1992 yet reliance survived because of Dhirubhai Ambani as he always say we must have good relationship with stock holders.

  

 [![](https://lh3.googleusercontent.com/-I96jG3kqPgA/YrImbGyRL0I/AAAAAAAAMBQ/rcTFBG-G6qQQM8rxcsRSuf0Eyg_jIP6jgCNcBGAsYHQ/s1600/1655842408395107-2.png)](https://lh3.googleusercontent.com/-I96jG3kqPgA/YrImbGyRL0I/AAAAAAAAMBQ/rcTFBG-G6qQQM8rxcsRSuf0Eyg_jIP6jgCNcBGAsYHQ/s1600/1655842408395107-2.png) 

  

  

In stock market, stock holders play major role in success of company and Dhirubai Ambani knows that very well as since the early days of Reliance he maintained good relationship with stock holders and build trust upon company including that reliance used to share bonus to all shareholders when company is in profits thus even at the time of reliance downfall stockholders didn't leave Reliance industries.

  

Reliance industries is mostly in profits for decades when Dhirubhai Ambani handled it but when he died in July 6, 2002 big issue arised between his sons Mukesh Ambani and Anil Ambani in distribution of assets then Dhirubhai Ambani wife Kokila Ambani solved assets dispute between his sons and shared companies equally with an agreement that no one will enter into each other businesses for some specific period of time.

  

Mukesh Ambani is very close to his father Dhirubhai Ambani where he learnt many bussiness lessons especially regarding petroleum thus he choosed petrochemical industry and made huge profits while his younger brother Anil Ambani choose Reliance telecommunications that failed miserably to such level that Anil Ambani got huge losses and he was no longer in position to repay his debts.

  

However, Reliance telecommunications did provided call and mobile data services for some years at approx same price of other tele networks like Airtel and idea etc who partnered and fooled indian people with expensive call and data rates we can say that joint tele networks scam while other nations are enjoying calls and data at very low price but most indian people don't know about it until Mukesh Ambani entered into telecom industry with Jio.

  

 [![](https://lh3.googleusercontent.com/-Lt-1x4EFogE/YrImZ-iVQSI/AAAAAAAAMBM/HOQvDb-WJxYNwJ3QsK0Mf2W0IfME7dE4ACNcBGAsYHQ/s1600/1655842402934263-3.png)](https://lh3.googleusercontent.com/-Lt-1x4EFogE/YrImZ-iVQSI/AAAAAAAAMBM/HOQvDb-WJxYNwJ3QsK0Mf2W0IfME7dE4ACNcBGAsYHQ/s1600/1655842402934263-3.png) 

  

  

In india, most people used to 3G network even though there is 4G network yet coverage is limited to few areas even if 4G network is available in some areas still people didn't like to recharge it as 4G plans are costly at that time Reliance  used thier existing telecom infrastructure and upgraded it to 4G VoLTE network then Reliance entered in telecom industry with Jio publicly on September 5, 2016.

  

Reliance is known for quality and genuinity for decades thus with Jio network they provided unlimited free calls and 4GB 4G mobile data every day for 3 months that used to cost 200rs per month on Airtel thus indian people amazed and started clueing up in large numbers infront of Reliance digital stores that made Jio sims go out of stock in few minutes thus it has become super hard to get Jio sim even people used to buy Jio sims in black but later on Reliance Jio fixed this issue and introduced home sim delivery.

  

Most indian people shifted to Jio network with that effect Telecom networks scam exposed and many people boycotted Airtel, Idea, Vodafone due to that they got immense lossess that they didn't recover even today especially Vodafone and idea reported that they can't pay debts but as indian government don't want such big companies to go down they given time to repay debts so in that process Vodafone and Idea partnered and formed Vi network.

  

 [![](https://lh3.googleusercontent.com/-6XoI8FY-6SE/YrImYjH8PpI/AAAAAAAAMBI/cTyzOqRINfMIWNsP4HVyidOzolg1FVHYQCNcBGAsYHQ/s1600/1655842399066503-4.png)](https://lh3.googleusercontent.com/-6XoI8FY-6SE/YrImYjH8PpI/AAAAAAAAMBI/cTyzOqRINfMIWNsP4HVyidOzolg1FVHYQCNcBGAsYHQ/s1600/1655842399066503-4.png) 

  

Jio eventually become top mobile data usage country in the world with 1 billion data per month thanks to it's 4GB per day data for 3 months but as per TRAI aka Telecom regulatory authority of India a company can only provide free services upto maximum 3months yet Jio extended free data and calls for another 3 months in name of prime subscription and then they extended more 3 months in name of festival offers that mesmerized everyone.

  

The effect of Jio network is in such level that other mobile network providers like Airtel, Idea and Vodafone has no choice other then to provide plans like Jio which they eventually did even though they tried to resist at first but taken some time that caused them to loss large customer base yet it's really amazing to see thier survival in those days when they faced backlash from it's customers and people supported it happily as they scammed indian users.

  

Now, Jio is super successful mobile network with 379 million active users as of now and the man behind this is Mukesh Ambani who visioned and collaborated with indian government to digitalize india and because of him we are now using GBs aka giga bytes of mobile data every days for months in few hundred ruppess so be thankful and grateful to him.

  

 [![](https://lh3.googleusercontent.com/-v3tuOuS2q3s/YrImXgUpknI/AAAAAAAAMBE/0RDFpYIXN843qwxS-oM0pAOGx7p6JgDNwCNcBGAsYHQ/s1600/1655842395052474-5.png)](https://lh3.googleusercontent.com/-v3tuOuS2q3s/YrImXgUpknI/AAAAAAAAMBE/0RDFpYIXN843qwxS-oM0pAOGx7p6JgDNwCNcBGAsYHQ/s1600/1655842395052474-5.png) 

  

The popularity of Jio network made Reliance and Mukesh Ambani confident to expand Jio products then to digitalize india again they created and released Jio fiber and TV that are super successful in meanwhile Reliance created and released Jio phone a keypad mobile with Kai OS at 500rs that was super hit in mobile market after that recently Reliance partnered with Google and made JioPhone Next.

  

 [![](https://lh3.googleusercontent.com/-RSLO5ioiLIc/YrImWtgFPtI/AAAAAAAAMBA/QibbXh9Y-cs_GqakytZo0vIw-_I1bM_JACNcBGAsYHQ/s1600/1655842390335742-6.png)](https://lh3.googleusercontent.com/-RSLO5ioiLIc/YrImWtgFPtI/AAAAAAAAMBA/QibbXh9Y-cs_GqakytZo0vIw-_I1bM_JACNcBGAsYHQ/s1600/1655842390335742-6.png) 

  

JioPhone, is a 4G smartphone with basic features overpriced at 4,500rs that didn't reached huge expectations of people as there are much better china smartphones most people not showing much interest to buy JioPhone Next except few people so it is very clear Reliance made a mistake and that failed JioPhone Next.  

  

I like many business aspects of Mukesh Ambani definitely there is strong influence and guidance of Dhirubhai Ambani in him for ex : Jio is potential product there is no doubt about it but still Mukesh Ambani didn't take risk he promoted Jio network in big events with top stars of India from this we can see even if we have good product still advertising is crucial in business to reach new heights and get success.

  

Finally, this is Jio success story, I hope Dhirubhai Ambani blessings shower on his sons future endeavours, are you an existing user of Reliance Jio? If yes say do say your experience and mention why do you think Reliance Jio got success in our comment section below, see ya :)