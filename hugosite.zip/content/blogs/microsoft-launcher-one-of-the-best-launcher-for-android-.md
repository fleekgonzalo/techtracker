---
title: 'Microsoft launcher - one of the best launcher for android !'
date: 2020-11-16T14:25:00.000+05:30
draft: false
url: /2020/11/microsoft-launcher-one-of-best-launcher.html
tags: 
- Apps
- Microsoft
- Best
- Launcher
- one
---

 [![](https://lh3.googleusercontent.com/-yk-1xmnCVVo/X7I-bDHIWTI/AAAAAAAACNY/xz-aDCNPtXwVqoiY4Z25d4IMkSA60judgCLcBGAsYHQ/s1600/1605516904444287-0.png)](https://lh3.googleusercontent.com/-yk-1xmnCVVo/X7I-bDHIWTI/AAAAAAAACNY/xz-aDCNPtXwVqoiY4Z25d4IMkSA60judgCLcBGAsYHQ/s1600/1605516904444287-0.png) 

  

We have numerous launchers available on play store and most of them are good but there is pixel launcher which exclusively made for only pixel launcher some how amazed me.

  

However, in search of finding best alternative to pixel launcher we find out the microsoft launcher made by well known company microsoft itself.

  

It is really subjective opinion, do try out yourself and decide as per your liking.

  

Microsoft launcher have many cool features like one tap wallpaper, inbuilt basic camera which will only snap back camera photos including flash if your device supports it and a microsoft based voice search for you.

  

The app also gives you hint of catalogue apps that you doesn't installed in your device made by microsoft that may be useful or else you can easily remove it.

  

▶ **App Info ✨**

 **[![](https://lh3.googleusercontent.com/-Ws4_IGS2vKA/X7JARYSzHVI/AAAAAAAACNk/4Ua4ZObeVQME8i1GkeXzIcvEIW2PWVqfwCLcBGAsYHQ/s1600/1605517377323257-0.png)](https://lh3.googleusercontent.com/-Ws4_IGS2vKA/X7JARYSzHVI/AAAAAAAACNk/4Ua4ZObeVQME8i1GkeXzIcvEIW2PWVqfwCLcBGAsYHQ/s1600/1605517377323257-0.png)** 

  

✓ **Microsoft Launcher Key Features ✨**

  

**•** one tap wallpaper

  

**•** alphatecal list

  

**•** dark layout

  

**•** hide apps

  

**•** edit icon

  

**•** display layout

  

**•** Themes

  

**•** Glance / News 

  

**•** Custom Build Time / Weather

  

**•** longpress - inbuilt recent apps layout

  

**•** Gestures

  

For more details : [here](https://play.google.com/store/apps/details?id=com.microsoft.launcher) 

  

Note : this is just few one word features they look more better in terms of look and usage and do have many more features available.

  

**Finally**, we really liked the simple functionality with amazing overall feel and look of microsoft launcher which poses good experience, do mention your views about microsoft launcher in our comment section below, see ya :-)