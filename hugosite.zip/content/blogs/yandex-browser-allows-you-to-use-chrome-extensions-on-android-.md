---
title: 'Yandex Browser - Allows You To Use Chrome Extensions On Android!'
date: 2021-05-26T16:58:00.001+05:30
draft: false
url: /2021/05/yandex-browser-allows-you-to-use-chrome.html
tags: 
- browser
- Chrome
- Apps
- YANDEX
- Extensions
---

 [![Yandex Browser - Allows You To Use Chrome Extensions On Android!](https://lh3.googleusercontent.com/-TZgIwojTMeA/YK4w69m6J6I/AAAAAAAAErE/XGJ8a2vLQrUkw2J3pyHdWmLvWNGZ54YjACLcBGAsYHQ/s1600/1622028518785373-0.png "Yandex Browser - Allows You To Use Chrome Extensions On Android!")](https://lh3.googleusercontent.com/-TZgIwojTMeA/YK4w69m6J6I/AAAAAAAAErE/XGJ8a2vLQrUkw2J3pyHdWmLvWNGZ54YjACLcBGAsYHQ/s1600/1622028518785373-0.png) 

  

Do you like **chrome extensions**? but they only work in pc chrome browser because google limited it to only pc they didn't add chrome extensions on chrome browser of Android due to that people whoever like chrome pc extensions were unable to use the same extensions on chrome Android browser due to no functionality.   

  

**Yes**, chrome Android browser doesn't have functionality to add chrome extensions due to this reason people who like the chrome extensions were searching for an browser which have functionality to add chrome extensions to experience them and use the awesome specific features this chrome extensions have inbuild on Android like in PC.   

  

**In this scenario**, we have a workaround for people or who want to utilise chrome web store extensions on Android we found a browser named Yandex that have feature to add chrome web store extensions or any third party extensions in format .crx and zip .user.js files to get same the same extensions usage experience like in pc on Android.   

  

**Yandex Browser** is based on Chromium 90

and WebKit engine that powers the most popular browsers in the world so you won't lose your habits it is made to browse the internet, read news, watch videos and listen to music, without annoyances and packed with essential extensions support.   

  

• **How to download Yandex Browser •**

It is very easy to download Yandex Browser on these platforms for free. 

  
\- [Google Play](https://play.google.com/store/apps/details?id=com.yandex.browser)

\- [Apkpure](https://m.apkpure.com/yandex-browser-with-protect/com.yandex.browser/amp)

\- [UpToDown](https://yandex-browser-for-android.en.uptodown.com/android)

\- [ApkMirror](https://www.apkmirror.com/apk/yandex-apps/yandex-browser/yandex-browser-15-6-2311-6088-release/)

  

**• YANDEX Browser Official Support •**

**Website :** [browser.yandex.com](http://browser.yandex.com)

**Email : **[mbrowser@support.yandex.ru](mailto:mbrowser@support.yandex.ru)

  

• **Yandex Browser Key Features •**  

\- View stories, news, and videos

\- Get rid of annoying ads

\- Protect your personal data 

\- Hide unrelated interface elements

\- Surf the web in Incognito mode

\- Customize your Yandex Browser

\- Access your favorite websites

\- Dark Theme

\- Yandex Messenger

\- Extensions Support

\- Battery Saving Mode

\- Save As PDF

\- Turbo Mode

\- Protect Mode

  

  

• **How to Add Chrome Web Store Extensions on Yandex Browser with UI & UX Overview • **

 **[![](https://lh3.googleusercontent.com/-YuP742lWXzA/YK4w5p-oN6I/AAAAAAAAErA/qoEC5e7hd_c2D8cDxDjs7pLyyF_rjU5uQCLcBGAsYHQ/s1600/1622028513401290-1.png)](https://lh3.googleusercontent.com/-YuP742lWXzA/YK4w5p-oN6I/AAAAAAAAErA/qoEC5e7hd_c2D8cDxDjs7pLyyF_rjU5uQCLcBGAsYHQ/s1600/1622028513401290-1.png)**   
\- Open **Kiwi Browser** and tap on** ⋮**  

 **[![](https://lh3.googleusercontent.com/-3oh8E5apags/YK4w4W0rFPI/AAAAAAAAEq8/l9fmgh8bY68YbE1QxYX3roo9p4hTvufzgCLcBGAsYHQ/s1600/1622028509099012-2.png)](https://lh3.googleusercontent.com/-3oh8E5apags/YK4w4W0rFPI/AAAAAAAAEq8/l9fmgh8bY68YbE1QxYX3roo9p4hTvufzgCLcBGAsYHQ/s1600/1622028509099012-2.png)** 

**\-** Tap on **Settings**

 **[![](https://lh3.googleusercontent.com/-YDdF7LV2zXs/YK4w3CJmI6I/AAAAAAAAEq4/yi73ne7xYDoVFhmQGP4ZLFcSeZ6HZ-6vQCLcBGAsYHQ/s1600/1622028504448385-3.png)](https://lh3.googleusercontent.com/-YDdF7LV2zXs/YK4w3CJmI6I/AAAAAAAAEq4/yi73ne7xYDoVFhmQGP4ZLFcSeZ6HZ-6vQCLcBGAsYHQ/s1600/1622028504448385-3.png)** 

\- Tap on Extension catolog to get existing few pre-available ad-ons. 

  

 [![](https://lh3.googleusercontent.com/-k1bFEh52qM0/YK4w2K035LI/AAAAAAAAEq0/bYepwHB0gTIjP5osFfU0NV44fTPhFmg_gCLcBGAsYHQ/s1600/1622028498869065-4.png)](https://lh3.googleusercontent.com/-k1bFEh52qM0/YK4w2K035LI/AAAAAAAAEq0/bYepwHB0gTIjP5osFfU0NV44fTPhFmg_gCLcBGAsYHQ/s1600/1622028498869065-4.png) 

  

**\-** You can install this existing extensions

or go to chrome web store to install the extentions directly you like from there. 

  

 [![](https://lh3.googleusercontent.com/-kf907N1fMMQ/YK4w0oqcrSI/AAAAAAAAEqw/NfMGlkKR4tkqarMJYKRWimxtK1IxD0OHACLcBGAsYHQ/s1600/1622028492259956-5.png)](https://lh3.googleusercontent.com/-kf907N1fMMQ/YK4w0oqcrSI/AAAAAAAAEqw/NfMGlkKR4tkqarMJYKRWimxtK1IxD0OHACLcBGAsYHQ/s1600/1622028492259956-5.png) 

  

\- Go to **Chrome Web Store, Now **select any chrome extensions that you want to use from catalog. 

  

  

 [![](https://lh3.googleusercontent.com/-k1av6wWleo8/YK4wy7TZGZI/AAAAAAAAEqs/wOmEv3ocdaUqKXt9kinBPqPToO64RgrQQCLcBGAsYHQ/s1600/1622028486390334-6.png)](https://lh3.googleusercontent.com/-k1av6wWleo8/YK4wy7TZGZI/AAAAAAAAEqs/wOmEv3ocdaUqKXt9kinBPqPToO64RgrQQCLcBGAsYHQ/s1600/1622028486390334-6.png) 

  

  

\- **Once**, Extension selected tap on **Add to** **Chrome** to Download and Install on **Yandex** **Browser**.  

  

 [![](https://lh3.googleusercontent.com/-b_xHTzb7suA/YK4wxd2ZyxI/AAAAAAAAEqo/0185eRxlsTQJCbxOduZ_l3IBDgFbDCTSwCLcBGAsYHQ/s1600/1622028482183494-7.png)](https://lh3.googleusercontent.com/-b_xHTzb7suA/YK4wxd2ZyxI/AAAAAAAAEqo/0185eRxlsTQJCbxOduZ_l3IBDgFbDCTSwCLcBGAsYHQ/s1600/1622028482183494-7.png) 

  

\- Tap on **Add Extensions**  

 **[![](https://lh3.googleusercontent.com/-SY8bsmsKqwM/YK4wwVH-g5I/AAAAAAAAEqk/g4E4ytoqP6g1KkNhTtkLGprD9QfBn2VkwCLcBGAsYHQ/s1600/1622028475180540-8.png)](https://lh3.googleusercontent.com/-SY8bsmsKqwM/YK4wwVH-g5I/AAAAAAAAEqk/g4E4ytoqP6g1KkNhTtkLGprD9QfBn2VkwCLcBGAsYHQ/s1600/1622028475180540-8.png)** 

\- Go back to **Extensions**, Here you will find all the **Extensions** that you just loaded or downloaded from **Chrome Web Store.** 

  

**Done**, You successfully learned how to add and utilise extensions on **Yandex Browser.** 

  

**Atlast**, **Yandex** **Browser** is the one of the  official legal browser that was available on Google Play to add and utilise Chrome Web store extensions or any extensions on Android for free, there is no other browser available in Google Play with Extension support, so if you want to use Chrome Web store or any extensions that you like then Yandex Browser is the choice available on **Google Play.**

**Overall**, **Yandex browser** is quick and fast to browse in peace, it is very easy to use due to its simple user interface which gives you clean user experience but we have to wait and see will Yandex Browser get any major UI changes in future to make it even more better, as of now Yandex Browser have perfect user interface and user experience that you may like to use for sure. 

  

**Finally, **This is how you can add and use Chrome Web Store Extensions on Android with Yandex Browser, it is very simple and useful to promote your website or blog, so do you like it? If yes do you tried Yandex Browser? if you are already been using Yandex Browser do say your experience in our comment section below, see ya :)