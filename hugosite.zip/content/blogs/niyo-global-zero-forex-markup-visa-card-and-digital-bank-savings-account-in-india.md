---
title: 'Niyo Global - Zero forex markup visa card and digital bank savings account in india.'
date: 2022-01-08T23:39:00.001+05:30
draft: false
url: /2022/01/niyo-global-zero-forex-markup-visa-card.html
tags: 
- technology
- Savings Account
- Zero Forex Markup
- Niyo Global
- Visa
---

 [![](https://lh3.googleusercontent.com/-kNhphecDvgo/YdnTZ8ysANI/AAAAAAAAIYo/YWmAYBK_m6kh1CvHRer_V-C3CxcrwmiMwCNcBGAsYHQ/s1600/1641665378594600-0.png)](https://lh3.googleusercontent.com/-kNhphecDvgo/YdnTZ8ysANI/AAAAAAAAIYo/YWmAYBK_m6kh1CvHRer_V-C3CxcrwmiMwCNcBGAsYHQ/s1600/1641665378594600-0.png) 

  

Niyo partnered with SBI - state bank of mauritius india to provide digital savings bank account and zero forex markup visa card to spend globally and save locally as on Niyo global you can load money in INR and spend in 150+ currencies so that you can use it for for all leisure, bussines and international travels and make payments such as car rentals, flight bookings and hotel bookings at zero forex markup.

  

Niyo global international signature travel debit card has no hidden charges, which means no more worries including that on Niyo digital savings bank account you can earn a high interest rate of 5% per annum to ensure your money keep growing even when you're on vacation, isn't this cool?

  

Niyo global has 100% digital on-boarding procedure to Instantly create your digital savings account, once niyo global digital bank account is created successfully you can easily and securely load money 24/7 via NEFT or IMPS from any where in the world and spend in 150+ countries.

  

Niyo global digital card and digital savings bank account comes with many features and benefits to ease your travels like free ATM locater, live currency converter, transaction notifications, best security features, 24/7 customer support including with exciting deals, debit card offers and complementary airport lounge access at all major in india, luxurious right?

  

However, So far we seen one drawback on Niyo global in order to get visa debit card for free you have to load 5k inr and this is limited time offer except this everything seems marvelous on Niyo global, so do you like it? are you interested in Niyo Global? If yes let's know little more info about it, before we register and open a digital savings account on Niyo global.

  

**• Niyo Global official support •**

**\-** [Facebook](https://www.facebook.com/getniyo/)

\- [YouTube](https://www.youtube.com/channel/UCS3ze-1OXrgXIW4jEWRcS8g)

\- [LinkedIn](https://in.linkedin.com/company/niyo-solutions-inc)

\- [Twitter](https://twitter.com/theniyo)

\- [Instagram](https://www.instagram.com/go_niyo)

  

**Email :** [global-dev@goniyo.com](mailto:global-dev@goniyo.com)

**Website :** **[goniyo.com](http://goniyo.com)**

**• How to download Niyo Global •**

  

It is very easy to download Niyo Global from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.niyo.sbm&hl=en&gl=US&auao=false&referrer=utm_source=google&utm_medium=organic&utm_term=niyo%20global%20app%20store&pcampaignid=APPU_1_kcjZYbmjBv71juMPuNyJ4A8) / [App Store](https://apps.apple.com/in/app/niyo-global-by-dcb/id1451275528)

**• How to register on Niyo Global •**

 [![](https://lh3.googleusercontent.com/-jWEpBf5en4g/YdnTY3ZkGWI/AAAAAAAAIYk/di0RpgdTv9o0CL2sEDDoWhhYKOJGen1oACNcBGAsYHQ/s1600/1641665374342057-1.png)](https://lh3.googleusercontent.com/-jWEpBf5en4g/YdnTY3ZkGWI/AAAAAAAAIYk/di0RpgdTv9o0CL2sEDDoWhhYKOJGen1oACNcBGAsYHQ/s1600/1641665374342057-1.png) 

  

\- Open Niyo Global and tap on **Skip**

 **[![](https://lh3.googleusercontent.com/-3M0G-HPzPaA/YdnTXgoTraI/AAAAAAAAIYg/b6GxRdB5JLgSWr3p-SrnshKMQWYl9-cbgCNcBGAsYHQ/s1600/1641665370179733-2.png)](https://lh3.googleusercontent.com/-3M0G-HPzPaA/YdnTXgoTraI/AAAAAAAAIYg/b6GxRdB5JLgSWr3p-SrnshKMQWYl9-cbgCNcBGAsYHQ/s1600/1641665370179733-2.png)** 

\- Enter your Phone Number and tap on **✓**

 **[![](https://lh3.googleusercontent.com/-aQSPV6Fy89c/YdnTWtBqcvI/AAAAAAAAIYc/uRIPGqlvxHw9e7hCJokJFvwURhyXBfkzwCNcBGAsYHQ/s1600/1641665366055097-3.png)](https://lh3.googleusercontent.com/-aQSPV6Fy89c/YdnTWtBqcvI/AAAAAAAAIYc/uRIPGqlvxHw9e7hCJokJFvwURhyXBfkzwCNcBGAsYHQ/s1600/1641665366055097-3.png)** 

  

  

\- You will receive a OTP from Niyo Global to your mobile number, so go to sms inbox and find it and acknowledge or copy it to enter or paste here then tap on **✓**

 **[![](https://lh3.googleusercontent.com/-ayU26tRq1OE/YdnTVl5AIOI/AAAAAAAAIYY/PifotnyAhkkf9dHBYMt0FFTfotnKRkBYQCNcBGAsYHQ/s1600/1641665361910287-4.png)](https://lh3.googleusercontent.com/-ayU26tRq1OE/YdnTVl5AIOI/AAAAAAAAIYY/PifotnyAhkkf9dHBYMt0FFTfotnKRkBYQCNcBGAsYHQ/s1600/1641665361910287-4.png)** 

\- Tap on **Continue with Google** to link your email with Niyo Global.

  

 [![](https://lh3.googleusercontent.com/-PtSojk7Hcoo/YdnTUmef_uI/AAAAAAAAIYU/ShZuSCNzFrksQ0ULB-cj-sOW4RX3Uie4wCNcBGAsYHQ/s1600/1641665357499621-5.png)](https://lh3.googleusercontent.com/-PtSojk7Hcoo/YdnTUmef_uI/AAAAAAAAIYU/ShZuSCNzFrksQ0ULB-cj-sOW4RX3Uie4wCNcBGAsYHQ/s1600/1641665357499621-5.png) 

  

\- Tap on **Start Account Creation**

 **[![](https://lh3.googleusercontent.com/-HvD7yuHjHiE/YdnTTUtJ34I/AAAAAAAAIYQ/OPT80t-AEa0IERWmu8GxwXvFbrz5IH4qgCNcBGAsYHQ/s1600/1641665353301582-6.png)](https://lh3.googleusercontent.com/-HvD7yuHjHiE/YdnTTUtJ34I/AAAAAAAAIYQ/OPT80t-AEa0IERWmu8GxwXvFbrz5IH4qgCNcBGAsYHQ/s1600/1641665353301582-6.png)** 

\- Enter your PAN number and tap on **Next**

 **[![](https://lh3.googleusercontent.com/-wtlRdnZeGlo/YdnTST1ts2I/AAAAAAAAIYM/kjMUV7TbXeAV-Y9OgubeWUK30XHuxx6tACNcBGAsYHQ/s1600/1641665349561220-7.png)](https://lh3.googleusercontent.com/-wtlRdnZeGlo/YdnTST1ts2I/AAAAAAAAIYM/kjMUV7TbXeAV-Y9OgubeWUK30XHuxx6tACNcBGAsYHQ/s1600/1641665349561220-7.png)** 

\- Verify your PAN details, if they are correct then tap on **Yes, this is me.**

 **[![](https://lh3.googleusercontent.com/-68BDfAVbCq0/YdnTRW3VHtI/AAAAAAAAIYI/lLUl0caE9gYeXAIR18EyJ1jC6SBnS1b2QCNcBGAsYHQ/s1600/1641665345128494-8.png)](https://lh3.googleusercontent.com/-68BDfAVbCq0/YdnTRW3VHtI/AAAAAAAAIYI/lLUl0caE9gYeXAIR18EyJ1jC6SBnS1b2QCNcBGAsYHQ/s1600/1641665345128494-8.png)** 

\- Enter your Aadhaar Number, and ✓ box then tap on **Next**

 **[![](https://lh3.googleusercontent.com/-zHXpvfK67eM/YdnTQdGaVDI/AAAAAAAAIYE/DT-w4OkHZRAaTRvAtiQJAeh5ihgOZ4-owCNcBGAsYHQ/s1600/1641665340413933-9.png)](https://lh3.googleusercontent.com/-zHXpvfK67eM/YdnTQdGaVDI/AAAAAAAAIYE/DT-w4OkHZRAaTRvAtiQJAeh5ihgOZ4-owCNcBGAsYHQ/s1600/1641665340413933-9.png)** 

  

\- You will receive a OTP to your Aadhaar linked mobile number, go to your SMS inbox and find it then acknowledge and enter here, and tap on **Verify**

 [![](https://lh3.googleusercontent.com/-fDgG2Lob6OU/YdnTPPAkJ2I/AAAAAAAAIYA/jmNEc2teNrgYmHIVuKGT-L6q-ndgp_gTwCNcBGAsYHQ/s1600/1641665336352539-10.png)](https://lh3.googleusercontent.com/-fDgG2Lob6OU/YdnTPPAkJ2I/AAAAAAAAIYA/jmNEc2teNrgYmHIVuKGT-L6q-ndgp_gTwCNcBGAsYHQ/s1600/1641665336352539-10.png) 

  

\- Check your Aadhaar details, if they are correct then tap on **Continue**

 **[![](https://lh3.googleusercontent.com/-S02Fv6hVcAs/YdnTOJ1ZY3I/AAAAAAAAIX8/xAo88SBEe18TEa-5f-Xp9ETldJLBTrl7ACNcBGAsYHQ/s1600/1641665332152847-11.png)](https://lh3.googleusercontent.com/-S02Fv6hVcAs/YdnTOJ1ZY3I/AAAAAAAAIX8/xAo88SBEe18TEa-5f-Xp9ETldJLBTrl7ACNcBGAsYHQ/s1600/1641665332152847-11.png)** 

\- Tap on Open Camera and capture selfie.

  

 [![](https://lh3.googleusercontent.com/-T7WNPp7zzWI/YdnTNMhupDI/AAAAAAAAIX0/taC4k8HdeLEwgtJHSpbmAl_fe9SVc8jcQCNcBGAsYHQ/s1600/1641665328087325-12.png)](https://lh3.googleusercontent.com/-T7WNPp7zzWI/YdnTNMhupDI/AAAAAAAAIX0/taC4k8HdeLEwgtJHSpbmAl_fe9SVc8jcQCNcBGAsYHQ/s1600/1641665328087325-12.png) 

  

\- Enter personal and professional details then tap on **Next**

 **[![](https://lh3.googleusercontent.com/-3AwE7SYSiYU/YdnTMMZYcQI/AAAAAAAAIXw/_V-98ahEt6c1gk1AhrUrj6DGHqTIeq7XgCNcBGAsYHQ/s1600/1641665323893174-13.png)](https://lh3.googleusercontent.com/-3AwE7SYSiYU/YdnTMMZYcQI/AAAAAAAAIXw/_V-98ahEt6c1gk1AhrUrj6DGHqTIeq7XgCNcBGAsYHQ/s1600/1641665323893174-13.png)** 

\- Select or add a new delivery address to receive visa no forex markup debit card and tap on **Next**

 **[![](https://lh3.googleusercontent.com/-oZ5vc4pfDUU/YdnTLBWqwMI/AAAAAAAAIXs/6m9n9p0g8AoAQRavdJnjrygNFivZmlGugCNcBGAsYHQ/s1600/1641665319293818-14.png)](https://lh3.googleusercontent.com/-oZ5vc4pfDUU/YdnTLBWqwMI/AAAAAAAAIXs/6m9n9p0g8AoAQRavdJnjrygNFivZmlGugCNcBGAsYHQ/s1600/1641665319293818-14.png)** 

\- Enter address details and tap on **Confirm**

 **[![](https://lh3.googleusercontent.com/-GHN5ROcqyCU/YdnTJyPvVoI/AAAAAAAAIXo/6TeCuHZjdigBMrDv2S9Zw70wKboZ_QXiACNcBGAsYHQ/s1600/1641665314814142-15.png)](https://lh3.googleusercontent.com/-GHN5ROcqyCU/YdnTJyPvVoI/AAAAAAAAIXo/6TeCuHZjdigBMrDv2S9Zw70wKboZ_QXiACNcBGAsYHQ/s1600/1641665314814142-15.png)** 

\- Add Nominee and tap on **Add Nominee**

 **[![](https://lh3.googleusercontent.com/-jTnnhDe_UCg/YdnTIhca3jI/AAAAAAAAIXk/d4JN6aarWDo_gzByyy5UEhkVTA4JCvBEwCNcBGAsYHQ/s1600/1641665310055332-16.png)](https://lh3.googleusercontent.com/-jTnnhDe_UCg/YdnTIhca3jI/AAAAAAAAIXk/d4JN6aarWDo_gzByyy5UEhkVTA4JCvBEwCNcBGAsYHQ/s1600/1641665310055332-16.png)** 

\- ✓ box to agree Terms and conditions etc and tap on **I Accept**

 **[![](https://lh3.googleusercontent.com/-eWb4jjnPtVs/YdnTHkLRccI/AAAAAAAAIXg/-HenulsXGoc1bL_vgGynRISHrmVB1DfygCNcBGAsYHQ/s1600/1641665305456962-17.png)](https://lh3.googleusercontent.com/-eWb4jjnPtVs/YdnTHkLRccI/AAAAAAAAIXg/-HenulsXGoc1bL_vgGynRISHrmVB1DfygCNcBGAsYHQ/s1600/1641665305456962-17.png)** 

  

Hurray, your Niyo Global savings bank account is successfully created, tap on Explore your account.

  

**• Niyo Global key features with UI / UX Overview •**

  

 [![](https://lh3.googleusercontent.com/-7ncT-ymcKtw/YdnTGUBawsI/AAAAAAAAIXc/O7xP_P5pbA0pLah-4xWIYVinZQUQIH0QwCNcBGAsYHQ/s1600/1641665301258160-18.png)](https://lh3.googleusercontent.com/-7ncT-ymcKtw/YdnTGUBawsI/AAAAAAAAIXc/O7xP_P5pbA0pLah-4xWIYVinZQUQIH0QwCNcBGAsYHQ/s1600/1641665301258160-18.png) 

  

  

\- Set your password and tap on **Confirm**

 [![](https://lh3.googleusercontent.com/-CPLpzwSxDcU/YdnTFaa7mMI/AAAAAAAAIXY/I7FGX-uS1DAH7AxZK3MqlZDyW3wsoKUewCNcBGAsYHQ/s1600/1641665296890285-19.png)](https://lh3.googleusercontent.com/-CPLpzwSxDcU/YdnTFaa7mMI/AAAAAAAAIXY/I7FGX-uS1DAH7AxZK3MqlZDyW3wsoKUewCNcBGAsYHQ/s1600/1641665296890285-19.png) 

  

\- Set Touch Id or tap on **Later**

 **[![](https://lh3.googleusercontent.com/-6QhJLOG38Mo/YdnTEGTawxI/AAAAAAAAIXU/4nUNk2YBwe0EEd7qz9iNzM8zzAaYxZDowCNcBGAsYHQ/s1600/1641665292206871-20.png)](https://lh3.googleusercontent.com/-6QhJLOG38Mo/YdnTEGTawxI/AAAAAAAAIXU/4nUNk2YBwe0EEd7qz9iNzM8zzAaYxZDowCNcBGAsYHQ/s1600/1641665292206871-20.png)** 

\- Add 5000 INR to Get Visa Signature Debit card for free, tap on **Not Now** to add later.

  

 [![](https://lh3.googleusercontent.com/-0R0m6Bl-dxw/YdnTDJEs_vI/AAAAAAAAIXQ/LO4iS8Y9g78pTe9asQ0wkJJ47i7iQcGvgCNcBGAsYHQ/s1600/1641665287829983-21.png)](https://lh3.googleusercontent.com/-0R0m6Bl-dxw/YdnTDJEs_vI/AAAAAAAAIXQ/LO4iS8Y9g78pTe9asQ0wkJJ47i7iQcGvgCNcBGAsYHQ/s1600/1641665287829983-21.png) 

  

  

\- Home, here you get all features that you normally get on digital savings bank.

  

 [![](https://lh3.googleusercontent.com/-YCpqFMQwGBY/YdnTB_IMEQI/AAAAAAAAIXM/Pyb8BM2bIhwuGZXDXlPLwwLsIXmD0SgrACNcBGAsYHQ/s1600/1641665283279381-22.png)](https://lh3.googleusercontent.com/-YCpqFMQwGBY/YdnTB_IMEQI/AAAAAAAAIXM/Pyb8BM2bIhwuGZXDXlPLwwLsIXmD0SgrACNcBGAsYHQ/s1600/1641665283279381-22.png) 

  

  

\- On Search, you can access Account details, Security Settings etc.

  

 [![](https://lh3.googleusercontent.com/-qUB5_wPkJi4/YdnTAybNvOI/AAAAAAAAIXI/H-fcSZzXO8s4AwH7sRGcUQ8f1AVnvVwdQCNcBGAsYHQ/s1600/1641665278664134-23.png)](https://lh3.googleusercontent.com/-qUB5_wPkJi4/YdnTAybNvOI/AAAAAAAAIXI/H-fcSZzXO8s4AwH7sRGcUQ8f1AVnvVwdQCNcBGAsYHQ/s1600/1641665278664134-23.png) 

  

\- **Currency Converter**

  

 [![](https://lh3.googleusercontent.com/-59IlvtV0Yhw/YdnS_uWohSI/AAAAAAAAIXE/3fCX-1SLlcMEt2XuBR9lSFjQX8EWDzIWACNcBGAsYHQ/s1600/1641665273983988-24.png)](https://lh3.googleusercontent.com/-59IlvtV0Yhw/YdnS_uWohSI/AAAAAAAAIXE/3fCX-1SLlcMEt2XuBR9lSFjQX8EWDzIWACNcBGAsYHQ/s1600/1641665273983988-24.png) 

  

\- **Card Settings**

 **[![](https://lh3.googleusercontent.com/-RRmaSS7C7as/YdnS-WYwHHI/AAAAAAAAIXA/4HlfSi3bHto9qgsti8K3uLBMPN112MOYwCNcBGAsYHQ/s1600/1641665267724294-25.png)](https://lh3.googleusercontent.com/-RRmaSS7C7as/YdnS-WYwHHI/AAAAAAAAIXA/4HlfSi3bHto9qgsti8K3uLBMPN112MOYwCNcBGAsYHQ/s1600/1641665267724294-25.png)** 

Atlast, this are just highlighted features of Niyo Global there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best zero forex markup global card and digital savings bank account in india then Niyo is surely a worthy choice.

  

Overall, Niyo Global comes with simple and clean intutive interface that ensure  user friendly experience on every corner, but in any project there is always space for improvement so let's wait and see will Niyo Global get any major UI changes in future to make it even more better, as of Niyo Global is pretty interesting!

  

Moreover, it is very important to mention Niyo Global is one of the very digital savings bank account in india which provide zero forex markup international visa debit card, yes indeed if you are searching for bussines travel card or student travel card then Niyo Global Card may work perfectly for you, do check it out.

  

Finally, Niyo Global is currently in early access phase, so you may able to find bugs but in future you may get stable and many more exciting and useful features, are you an existing user of Niyo Global? If yes do say your experience with Niyo Global and mention which feature you like the most in Niyo Global in our comment section below, see ya :)