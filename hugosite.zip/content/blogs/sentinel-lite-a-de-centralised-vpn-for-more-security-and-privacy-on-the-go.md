---
title: 'Sentinel Lite - A de-centralised VPN for more security and privacy on the go.'
date: 2022-01-05T21:55:00.000+05:30
draft: false
url: /2022/01/sentinel-lite-de-centralised-vpn-for.html
tags: 
- Sentinel Lite
- Apps
- Decentralised VPN
- Security
- Privacy
---

 [![](https://lh3.googleusercontent.com/-jwH2XM4Dw7I/YdW97fwfIeI/AAAAAAAAIT0/uQ90Ie9HTYEqSxDdwOxUj_FZEHMNqy9DACNcBGAsYHQ/s1600/1641397736912924-0.png)](https://lh3.googleusercontent.com/-jwH2XM4Dw7I/YdW97fwfIeI/AAAAAAAAIT0/uQ90Ie9HTYEqSxDdwOxUj_FZEHMNqy9DACNcBGAsYHQ/s1600/1641397736912924-0.png) 

  

VPN - Virtual private network is essential and necessary for security and privacy of personal data either on smartphone or pc this is why we have many VPN apps from numerous companies and individual dev's to safeguard and protect users from virus , trackers, hackers, malwares so they won't snoop into your personal data.

  

However, majority of smartphone and pc users doesn't even know about VPN even if they know they struggle to find best free VPN as most highly secured VPN apps are not available for free, even if the paid VPN apps or softwares available for free most of them put certain restrictions, even only provide you VPN on trail basis for 1 week or month which is not satisfactory.

  

Even though, there are some popular free VPN apps from trusted companies which users are ready to use, but whenever you choose VPN app or software from trusted popular company or individual you must first read terms & conditions with privacy polices, if policies of that VPN app is safe then you can use it as your personal data won't be shared as there are no trackers.

but there is no guaranteed protection.

  

Usually, most VPN apps or softwares give VPN service through country based single or multiple centralised servers at different locations for speed, security and privacy so the security and privacy issue lies here as VPN use centralised server, the VPN app provider can access centralised server to extract your personal data for marketing purposes, to comply with international or country based law enforcements etc, this can compromise your privacy and security, so now probably now understand the risk of using centralised VPN apps.

  

The un-deniable fact is most trusted VPN  apps and softwares use high technology to protect users personal data with best possible privacy & security enhancements but hackers are aware of this techniques and they know how to hijack and exploit most centralised VPN apps or softwares with advanced hacking tools and skills.

  

This is why, now we like to present a open source privacy first decentralised VPN app named Sentinel lite which can provide end to end encrypted through the VPN usage, Sentinel lite dVPN states that it can prove that your browsing history and information is not being stored for sure.

  

Sentinel Lite decentralised VPN don't own the exit servers you use to browse Internet but Sentinel lite VPN has hosted nodes from sentinel network developed on top of ethereum on mobile and tendermint and cosmos on desktop, so do you like it? are you interested in Sentinel lite? If yes let's know little more info about before we explore more.

  

**• Sentinel Lite official support •**

\- [Telegram \[ community chat \]](https://t.me/sentinel_co)

\-[ Telegram \[ announcements \]](https://t.me/sentinel_announcements)  

\- [Twitter](https://twitter.com/sentinel_co)

\- [Medium](https://medium.com/sentinel)

\- [Github](https://github.com/sentinel-official/sentinel/releases/)

  

**Website :** [sentinel.co](http://sentinel.co)

**Email :** [android.support@sentinel.co](mailto:android.support@sentinel.co)

  

**• Sentinel Lite key features with UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-r5rLsmFMVRs/YdXGh5GeW4I/AAAAAAAAIUU/T-RcW2f-QFoQMaL4QppLV8TR0EShKq-SACNcBGAsYHQ/s1600/1641399938358409-0.png)](https://lh3.googleusercontent.com/-r5rLsmFMVRs/YdXGh5GeW4I/AAAAAAAAIUU/T-RcW2f-QFoQMaL4QppLV8TR0EShKq-SACNcBGAsYHQ/s1600/1641399938358409-0.png)** 

 **[![](https://lh3.googleusercontent.com/-eEd4ZtfhJis/YdXGgiKHAII/AAAAAAAAIUQ/L1aefWZJgdkWdaw4fTnwnFFMA22oHNrlACNcBGAsYHQ/s1600/1641399933592420-1.png)](https://lh3.googleusercontent.com/-eEd4ZtfhJis/YdXGgiKHAII/AAAAAAAAIUQ/L1aefWZJgdkWdaw4fTnwnFFMA22oHNrlACNcBGAsYHQ/s1600/1641399933592420-1.png)** 

 **[![](https://lh3.googleusercontent.com/-ZU4xQGzOkfw/YdXGfdr71EI/AAAAAAAAIUM/-BXZzBhvXJ0FC7ayHxwrRgzRsfcZYdSlQCNcBGAsYHQ/s1600/1641399928826339-2.png)](https://lh3.googleusercontent.com/-ZU4xQGzOkfw/YdXGfdr71EI/AAAAAAAAIUM/-BXZzBhvXJ0FC7ayHxwrRgzRsfcZYdSlQCNcBGAsYHQ/s1600/1641399928826339-2.png)** 

 **[![](https://lh3.googleusercontent.com/-PfjRxB1IUgQ/YdXGeTE3wWI/AAAAAAAAIUI/i7KuMgMp7BYQsJoZUWhtGf2AsumOjtNWQCNcBGAsYHQ/s1600/1641399925293996-3.png)](https://lh3.googleusercontent.com/-PfjRxB1IUgQ/YdXGeTE3wWI/AAAAAAAAIUI/i7KuMgMp7BYQsJoZUWhtGf2AsumOjtNWQCNcBGAsYHQ/s1600/1641399925293996-3.png)** 

 **[![](https://lh3.googleusercontent.com/-UPxLEKt3zoA/YdXGdar8qiI/AAAAAAAAIUE/M7OZbX1UG1o7jn9JNCScOZP9qMDHndILwCNcBGAsYHQ/s1600/1641399920848112-4.png)](https://lh3.googleusercontent.com/-UPxLEKt3zoA/YdXGdar8qiI/AAAAAAAAIUE/M7OZbX1UG1o7jn9JNCScOZP9qMDHndILwCNcBGAsYHQ/s1600/1641399920848112-4.png)** 

 **[![](https://lh3.googleusercontent.com/-jxD8NnJbGSU/YdXGcDeYPHI/AAAAAAAAIUA/Ac-lxsqEEJow74NhBqadNgM1i8HBzq19QCNcBGAsYHQ/s1600/1641399916042197-5.png)](https://lh3.googleusercontent.com/-jxD8NnJbGSU/YdXGcDeYPHI/AAAAAAAAIUA/Ac-lxsqEEJow74NhBqadNgM1i8HBzq19QCNcBGAsYHQ/s1600/1641399916042197-5.png)** 

 **[![](https://lh3.googleusercontent.com/-y6Onas5l-5Y/YdXGbOcQfBI/AAAAAAAAIT8/DXzIthg-yLYaMiZ-QSRijTv3SKzCxE2mgCNcBGAsYHQ/s1600/1641399911660484-6.png)](https://lh3.googleusercontent.com/-y6Onas5l-5Y/YdXGbOcQfBI/AAAAAAAAIT8/DXzIthg-yLYaMiZ-QSRijTv3SKzCxE2mgCNcBGAsYHQ/s1600/1641399911660484-6.png)** 

Atlast, this are just highlighted features of Sentinel Lite there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best de-centralised VPN to surf Internet privately then Sentinel Lite is surely a worthy choice.

  

Overall, Sentinel Lite is clean and simple with default dark mode, it is easy to setup and use which ensure user friendly, but in any project there is always space for improvement so let's wait and see will Sentinel Lite get any major UI changes in future to make it even more better, as of now Sentinel Lite is pretty cool.

  

Moreover, it is worth to mention Sentinel Lite is one of the very few de-centralised VPN app available for free, there is another version of Sentinel network VPN where you need to pay for blockchain based decentralised VPN service, so if you want free dVPN then Sentinel Lite is the one.

  

Finally, Sentinel Lite is an open source free privacy first decentralised VPN app accessible on the go, are you an existing user of Sentinel Lite? If yes do say your experience with Sentinel Lite and mention which feature you like the most on Sentinel Lite in our comment section below, see ya :)