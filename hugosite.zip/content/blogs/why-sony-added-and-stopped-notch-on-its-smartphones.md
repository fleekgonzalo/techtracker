---
title: 'Why Sony added and stopped notch on it''s smartphones?'
date: 2022-04-21T02:12:00.000+05:30
draft: false
url: /2022/04/why-sony-added-and-stopped-notch-on-its.html
tags: 
- Why
- technology
- Notch
- Smartphones
- Sony
---

 [![](https://lh3.googleusercontent.com/-8Hro8DdzjyE/YmHBzGl-o3I/AAAAAAAAKWI/o21S_3JEwwkXlK7BcW-G2r4jsw5f6bHzwCNcBGAsYHQ/s1600/1650573768700789-0.png)](https://lh3.googleusercontent.com/-8Hro8DdzjyE/YmHBzGl-o3I/AAAAAAAAKWI/o21S_3JEwwkXlK7BcW-G2r4jsw5f6bHzwCNcBGAsYHQ/s1600/1650573768700789-0.png) 

  

  

Apple is father of smartphones as they released first touch screen smartphone named iPhone 1 back in 2007 from then whenever Apple does something new and innovative on it's smartphones every other mobile manufacturing company copying it especially china mobiles companies who make smartphones that reassembles Apple's iPhone in-terms of hardware, software, design, features etc.

  

In 2017, as part of innovation Apple added notch on iPhone X smartphone to fit facial sensor and 3d emojis which seems to give improved security and facial expressions emojis for fun but you may probably know how iPhone X face unlock failed you just have to use a photo of yours or a twin to unlock smartphone.

  

In simple iPhone X misfired, however as we said earlier when Apple do something on it's iPhone majority of other mobile companies copy it irrespective of either it look good or not, eventually with-in no time almost all companies started adding notches on smartphones.

  

But, Sony corporation a japanese company that I personally like because of thier quality didn't add notch on mobiles and sticked with old design that was appreciated by those who don't like notch including me, however Sony eventually break it's determination and added water  drop notch on Sony L4.

  

We notch dis-likers know how awful notch looks on smartphones but as people who like notch are increasing thus popularity growing day by day all smartphones are coming up with different style notches, and the main thing here is people only buying smartphones that has notch to get iPhone design not because they like notch.

  

Sony provide top quality high-end  smartphones that competes iPhone in every feature mainly in hardware and camera quality which is why they're expensive, but I don't know why Sony neglects it's budget and low end smartphones that comes with outdated features which are not worthy.

  

I think Sony slipped it's determination for once and added notch on buget model L4 to boost it's budget sales, and then they again stopped notches on it's budget series mobiles for instance Sony XA3 didn't got notch instead it was launched with one side chin instead of two that we got used to on old smartphones.

  

Sony undoubtedly make world class amazing smartphones that no other smartphone can beat it in camera wise but still people are not showing interest to buy them due to that Sony going through losses yet Sony still didn't step back it's goal to release super quality smartphones.

  

There are several reasons why people are not buying Sony smartphones, but the main ones are over pricing, poor marketing and no availability of smartphones in most countries, for instance when Sony Xperia 1 was officially launched I want to buy it so I went to popular online shopping platforms in india and it was not available even on official Sony india site as Sony limited Xperia 1 sells to few regions.

  

Sony not just do this with Sony Xperia 1 they do the same thing with other models as well for whatever reason, even now the Sony Xperia 1 is not available in india, and another issue with Sony is it's bit difficult to buy smartphones online thus you will no option other then buying at offline store.

  

Fortunately, Sony stopped adding notches on it's smartphones even though sells are dropping, thankfully Sony didn't added notches on high end models including Sony 1 series and I hope they never add notches which spoils the Sony's popular quality premium design smartphones.

  

Finally, this is why Sony add notch on few smartphones but we have to appreciate Sony determination to not add notch on smartphones, anyhow why do you think Sony add notch? Is there any chance that Sony add notch again? do say us your opinion and mention you like notch or not in our comment section below, see ya :)