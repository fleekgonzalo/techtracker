---
title: 'FAUG - The most awaited game teaser released !'
date: 2020-10-26T09:22:00.001+05:30
draft: false
url: /2020/10/faug-most-awaited-game-teaser-released.html
tags: 
- most
- technology
- FAUG
- released
- game
- teaser
---

 [![](https://lh3.googleusercontent.com/-McoeU-n28NE/X5ZO4xOU32I/AAAAAAAAB6U/xvNBFWjTQ8YMIMVQ-lzVyKR-sJD-DsBNACLcBGAsYHQ/s1600/1603686109404268-0.png)](https://lh3.googleusercontent.com/-McoeU-n28NE/X5ZO4xOU32I/AAAAAAAAB6U/xvNBFWjTQ8YMIMVQ-lzVyKR-sJD-DsBNACLcBGAsYHQ/s1600/1603686109404268-0.png) 

  

The most popular fps game all over the world pubg banned due to data breach and privacy concerns of indian people due to the servers are located in India.

  

To be self reliant in all digital platforms Aatma nirbhar bharat program launched which promote and encourage developers to create world class apps and games in India which help developers and financial growth of India.

  

This is when the indian company ncore games announced indian fps games through popular Indian actor akshay kumar instagram handle.

  

Faug - Fearless and united guards which the game will be situated around hilly areas and the game based upon clash between two forces.

> > > Good always triumphs over evil,  
> > > the light will always conquer the darkness.  
> > > May victory bless Fearless And United Guards, our FAU-G.  
> > > Launching in November 2020!  
> > >   
> > > Happy [#Dussehra](https://twitter.com/hashtag/Dussehra?src=hash&ref_src=twsrc%5Etfw)[@akshaykumar](https://twitter.com/akshaykumar?ref_src=twsrc%5Etfw) [@BharatKeVeer](https://twitter.com/BharatKeVeer?ref_src=twsrc%5Etfw) [@vishalgondal](https://twitter.com/vishalgondal?ref_src=twsrc%5Etfw) [#AtmanirbharBharat](https://twitter.com/hashtag/AtmanirbharBharat?src=hash&ref_src=twsrc%5Etfw) [#FAUG](https://twitter.com/hashtag/FAUG?src=hash&ref_src=twsrc%5Etfw) [pic.twitter.com/dZJgiVTxeT](https://t.co/dZJgiVTxeT)
> > > 
> > > — nCORE Games (@nCore\_games) [October 25, 2020](https://twitter.com/nCore_games/status/1320349542311620608?ref_src=twsrc%5Etfw)
> 
>   

[Twitter Embed Code](https://twitembed.com/)

.twit2{height:221px;width:211px;} #fav img{max-height:none!important;max-width:none!important;background:none!important} #twit twit{max-height:none!important;max-width:none!important;background:none!important}

  

On the even of dusshera, ncore games released teaser which shows indian flag and indian soldiers bravery.  

  

Today, ncore games give a deadline of Oct 20 but due to whatever reason game got delayed and it will going to launched in few weeks in november.

  

Finally, faug teaser is amazing do mention your thoughts about teaser and are you waiting for faug - fearless and united guard in our comment section below, see ya :-) jai bharat, jai hind 🇮🇳