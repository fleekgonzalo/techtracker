---
title: '0xTracker - The best one-stop DeFi portfolio tracker.'
date: 2022-04-02T23:51:00.001+05:30
draft: false
url: /2022/04/0xtracker-best-one-stop-defi-portfolio.html
tags: 
- Best
- DeFi portfolio tracker
- CryptoCurrency
- Optical
- 0xTracker
---

 [![](https://lh3.googleusercontent.com/-yeMRplQEOks/YkiUNiEZJ-I/AAAAAAAAJ-s/PGxufetUCr43C5GWKtgOiCsFornmB-VJQCNcBGAsYHQ/s1600/1648923684765142-0.png)](https://lh3.googleusercontent.com/-yeMRplQEOks/YkiUNiEZJ-I/AAAAAAAAJ-s/PGxufetUCr43C5GWKtgOiCsFornmB-VJQCNcBGAsYHQ/s1600/1648923684765142-0.png) 

  

DeFi aka decentralised finance platforms  based on web3 technology are specifically used to manage crypto currency, there you can store, buy, sell, stake crypto currencies eventhough many people don't know about DeFi platforms as it's still new in town but since 2018 DeFi platforms are on rise.

  

Thanks to crypto enthusiastics and big investors DeFi platforms receiving strong support to sustain and survive with latest and new features timely to be competitive and become useful for everyone, however now-a-days people relying on numerous DeFi platforms for various purposes.

  

So, if you're such person who use many DeFi platforms then most probably you have install or visit different apps or sites to check your portfolio which is little hard isn't? anyway If you're familiar with crypto currency then you may know most crypto networks are public which means anyone can check portfolio with just your wallet address except privacy oriented crypto networks like Monero, ZCash etc.

  

Incase, you have crypto currencies of public crypto networks then you can use DeFi tracker to check portfolio of all DeFi platforms in one place, not everyone know about DeFi tracker but it's very useful tool where you can simply submit DeFi wallet addresses and check portfolios on one app or website.

  

Fortunately, we have numerous DeFi trackers out there on internet but you have to choose the best one thus you won't face any issues in future, recently someone we know suggested to check out new optical version of 0xTracker, a DeFi tracker which supports more then 394+ crypto farms and networks isn't this amazing? 

  

We checked 0xTracker out of curiosity and you know what 0xTracker DeFi tracker is 

mesmerising because it has no tabs and all portfolio details displayed on 1 page, In sense 0xTracker is most comprehensive aggregated DeFi tracker that you ever need, so do you like it? are you interested in 0xTracker? If yes let's know little more info before we explore more.

  

** • 0xTracker official support •**

\- [Twitter](https://twitter.com/opticalfinance)

\- [Telegram](https://t.me/optical_finance)

\- [Github](https://github.com/0xTracker)

\- [Medium](https://medium.com/0x-tracker/announcing-the-0x-tracker-public-api-152e34fe70d6)

  

**Website :** [optical.0xtracker.app](http://optical.0xtracker.app)

**Email :** [hello@0xtracker.com](mailto:hello@0xtracker.com)

**• How to add your DeFi address and check portfolio on 0xTracker DeFi tracker •**

 **[![](https://lh3.googleusercontent.com/--Ea2HhruB4c/YkiUJJoMikI/AAAAAAAAJ-k/wLnwu-U1vfYPo-kM0nocNyajorrJpVqggCNcBGAsYHQ/s1600/1648923657867844-1.png)](https://lh3.googleusercontent.com/--Ea2HhruB4c/YkiUJJoMikI/AAAAAAAAJ-k/wLnwu-U1vfYPo-kM0nocNyajorrJpVqggCNcBGAsYHQ/s1600/1648923657867844-1.png)** 

\- Go to [optical.0xtracker.app](http://optical.0xtracker.app),  paste your wallet address then tap on **Let's Go ->**

 **[![](https://lh3.googleusercontent.com/-afHKE3JFBpE/YkiUCZitSeI/AAAAAAAAJ-c/RVUU-P7Dbp82s7p3X4l0cWSp_Hv2NMT7ACNcBGAsYHQ/s1600/1648923638074198-2.png)](https://lh3.googleusercontent.com/-afHKE3JFBpE/YkiUCZitSeI/AAAAAAAAJ-c/RVUU-P7Dbp82s7p3X4l0cWSp_Hv2NMT7ACNcBGAsYHQ/s1600/1648923638074198-2.png)** 

\- You're in 0xTracker DeFi tracker, Here you will check full details of your portfolio.

  

 [![](https://lh3.googleusercontent.com/-3JBtWA-ESDU/YkiT9afSZ2I/AAAAAAAAJ-U/P1HoFuY_VeQkRli6L0Lfqf3V5gMoh6I0ACNcBGAsYHQ/s1600/1648923619849704-3.png)](https://lh3.googleusercontent.com/-3JBtWA-ESDU/YkiT9afSZ2I/AAAAAAAAJ-U/P1HoFuY_VeQkRli6L0Lfqf3V5gMoh6I0ACNcBGAsYHQ/s1600/1648923619849704-3.png) 

  

\- Pools

  

 [![](https://lh3.googleusercontent.com/-T4nRg7aS_rI/YkiT4zPrz-I/AAAAAAAAJ-Q/aLSb6dv0Yuw3SFQru89SLx4h8TpFv_nzQCNcBGAsYHQ/s1600/1648923595654507-4.png)](https://lh3.googleusercontent.com/-T4nRg7aS_rI/YkiT4zPrz-I/AAAAAAAAJ-Q/aLSb6dv0Yuw3SFQru89SLx4h8TpFv_nzQCNcBGAsYHQ/s1600/1648923595654507-4.png) 

  

\- Portfolio, Assets, Analytics.

  

Atlast, this are just highlighted features of 0xTracker DeFi portfolio tracker there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best DeFi portfolio tracker then 0xTracker by optical is on go choice.

  

Overall, 0xTracker DeFi portfolio tracker comes with dark mode by default, it has well designed clean and simple interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will 0xTracker DeFi portfolio tracker get any major UI changes in future to make it better as of now it's nice.

  

 [![](https://lh3.googleusercontent.com/-LcCq1_l3yNk/YkiTy-5C7vI/AAAAAAAAJ-M/VKpdsfGJJA0Zpe6jdl1aA8QU1sYztsrrQCNcBGAsYHQ/s1600/1648923578401896-5.png)](https://lh3.googleusercontent.com/-LcCq1_l3yNk/YkiTy-5C7vI/AAAAAAAAJ-M/VKpdsfGJJA0Zpe6jdl1aA8QU1sYztsrrQCNcBGAsYHQ/s1600/1648923578401896-5.png) 

  

Moreover, it is definitely worth to mention 0xTracker by Optical is released today and it's a preview version still when compared with previous version of [](http://0xTracker.app)[0xTracker.app](http://0xTracker.app). it 

feels better and refreshing including that in order to add new DeFi wallet address you just have to sign out and then add new DeFi wallet address then go on. 

  

Finally, This is 0xTracker by [Optical.finance](http://Optical.finance) a DeFi portfolio tracker that has potential to become your new favourite choice, are you an existing user of 0xTracker DeFi portfolio tracker? If yes do say your experience and mention why you like 0xTracker by Optical in our comment section below, see ya :)