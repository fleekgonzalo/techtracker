---
title: 'Solar Labs dVPN - Get 1000+GB of decentralized privacy for 1$.'
date: 2022-08-08T23:54:00.000+05:30
draft: false
url: /2022/08/solar-labs-dvpn-get-1000gb-of.html
tags: 
- technology
- Solar Labs
- Decentralized privacy
- Privacy
- Sentinel dVPN
---

 [![](https://lh3.googleusercontent.com/-nElxZfkjD1I/YvFDRQuJ-KI/AAAAAAAAM-4/XJ4gaAjMP_kDzG3N5tjdFpr9Lp4Vut-dwCNcBGAsYHQ/s1600/1659978544385443-0.png)](https://lh3.googleusercontent.com/-nElxZfkjD1I/YvFDRQuJ-KI/AAAAAAAAM-4/XJ4gaAjMP_kDzG3N5tjdFpr9Lp4Vut-dwCNcBGAsYHQ/s1600/1659978544385443-0.png) 

  

VPN aka virtual private network is a software where you'll get numerous centralized cloud servers of different countries of continent by connecting to them on your personal computer or smartphone you can stay private and anonymous on world wide web, unlock blocked websites, protection from virus, malwares etc.

  

Now a days most people use VPNs but many of them don't know about back end process of VPNs they are developed and managed by one or multiple companies who can easily access your browsing data as it was stored on thier centralized cloud servers if they have log policy even though most VPNs say they don't log yet we can't trust because of various factors which is why it is always suggested to first check terms and conditions and mainly log policy of VPN before you use.

  

Especially, when you choose VPN software atleast make sure it was from trusted and reliable company with no log policies even if you got such VPN that will not track your data yet you can't rely on VPNs as most of them use centralized servers that are easy exploited by hackers who can extract data and publish it online or sell on darkweb that may cause privacy concerns.

  

The main drawback of VPNs is almost all of them are are managed by companies who do say we provide max security and privacy which some do but most of them use your online data for personal benefits even sell them to advertising agencies for money which is why alot of people shifting to dVPNs - decentralized VPNs.

  

Even though, individuals or teams also run VPN softwares but you can't trust them as well they are just like companies and very risky but one advantage of those VPNs is as individuals usually can't afford to setup centralized servers in every country they'll use paid or free cloud server platforms like Google Cloud, Amazon Azure etc still they are very much same.

  

Anyhow, dVPNs use decentralized servers which are known as nodes are hosted by individuals like you around the world when you connect to dVPN your online data will be encrypted using AES-286 bit security format then divided into many parts and go through many servers thus your online data is not accessible by even professional hackers and law enforcement agencies. 

  

But, if you're in most wanted list and a threat to country sovereignty and integrity then law enforcement agencies can use thier own CIA level technologies to track exit node of dVPNs where they can trace back to you but it's hard and very unlikely to happen unless in serious scenarios so you can happily use dVPNs.

  

Tor aka The onion project VPNs also work in same way of dVPNs they encrypt and pass all your device data traffic based on settings through numerous relays aka nodes or you can also call them as servers and then reach to exit node which can be traced and accessible by law enforcement agencies but they can't simply arrest you even if did yet thankfully as we have free speech and Internet freedom laws many global lawyers will help you.

  

Most people who want extreme privacy and security use Tor VPNs to stay fully anonymous mainly hackers and scammers use it to access Darkweb but there are many drawbacks with Tor VPNs as when  you increase level of security and privacy on Tor VPNs your online data will be encrypted to big extent due to that alot of processes run in background thus you'll get less internet speed, high battery and memory usage which is why alot of people don't like to use Tor VPNs.

  

**[\+ What is dark web and Tor, why you should stay away from them.](https://www.techtracker.in/2022/06/what-is-dark-web-and-tor-why-you-should.html)**

  

dVPNs are like VPN over Tor thus you not only get security and privacy but also fast data as it will tunnel your device traffic smartly so it's better then normal VPNs and Tor VPNs even if you agree or not but unfortunately majority of people unaware of dVPNs as only from past few years we got revolutionary dVPNs from futuristic companies and developers to upgrade Internet to Web3 as soon as possible.

  

Web3 is upcoming version of internet where people won't host digital platforms like websites and blogs etc on centralised servers instead they host them on decentralized servers provided by companies or individuals thus they are  hacker proof, censorship resistant and also run 24/7 with no downtime forever.

  

Thankfully, there are numerous Web3 products out of them you may probably know decentralized crypto currencies like Bitcoin after that because of Web3 enthusiasts we got many more Web3 products like DeFi decentralized finance, websites, social messengers, browsers, crypto wallets, domains, dVPNs etc and many more Web3 platforms will come in near future.

  

Now, we are going to focus on dVPNs which are not available in full extent there are only few dVPNs apps and softwares out of them most dVPNs gone down due to lack of support from node providers and people but fortunately thanks to Sentinel we have few dVPNs that are still working to give decentralized privacy and security.

  

However, dVPNs are not free as most of them don't put ads, they are hosted by individuals around the world who host nodes and run nodes independently thus when you top up dVPNs and connect to them some tokens will be shared with node provider thus they are able to cover expenses and run dVPNs for long time.

  

Sentinel is one of the most popular and leading dVPN provider they previously closed down Sentinel lite dVPN and partnered with Exidio to provide dVPN but for whatever reason few months back Exidio dVPN gone down and then Solar Labs using Sentinel network released Solar Labs dVPN.

  

**[\+ Exidio dVPN - Get 500GB of decentralized privacy for $1.](https://www.techtracker.in/2022/03/exidio-dvpn-get-500gb-of-decentralized.html?m=1)**

  

Currently, Sentinel focused on Solar Labs dVPNs and work in same way of Exidio dVPN, you need to top-up Solar Labs dVPN using Sentinel dVPN tokens but don't worry they are very cheap you can get more then 1000 GB of decentralized privacy for just 1$, so do you like it? are you interested in Solar Labs dVPN, if yes let's explore more.

  

Note : remember, before we continue further the method which we are going to provide below to add Sentinel dVPN tokens on Solar Labs dVPN is best and easy one, but it is little complicated and lengthty as we have to use 5 apps so it's not for lazy peeps and don't forget you have to use this method at your own risk we aren't responsible for any losses, kindly follow each and every step correctly else your funds will be lost, let's begin!

  

• **Solar Labs dVPN official support •**

\- [Facebook](https://www.facebook.com/solarlabsteam)

\- [Medium](https://blog.solarlabs.ee/)

\- [GitHub](https://github.com/solarlabsteam)

\- [Twitter](https://twitter.com/solarlabs_team)

\- [Telegram](https://t.me/solarlabs)

\- [LinkedIn](https://www.linkedin.com/company/solarlabs/)

\- [Instagram](https://www.linkedin.com/company/solarlabs/)

**Website :** [solarlabs.ee](http://solarlabs.ee)

**Email :** [support@solarlabs.ee](mailto:support@solarlabs.ee)

**• How to download Solar Labs dVPN •**

It is very easy to download Solar Labs dVPN from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=ee.solarlabs.dvpn) **/** [App Store](https://apps.apple.com/ee/app/solar-dvpn/id1597909295)

\- [Linux](https://t.me/+QqGdo3XHngkyZTc0)

\- [Linux / OS X](https://github.com/MathNodes/meile-gui/releases)

\- [CLI : Linux / Mac](https://docs.sentinel.co/clients/CLI/installation)

\- [Decentr](https://decentr.net/) ( integrated in browser )

  

**[\+ Decentr - First Web3 browser to sell browsing data and earn money.](https://www.techtracker.in/2022/06/decentr-first-web3-browser-to-sell.html)**

  

[![](https://lh3.googleusercontent.com/-CPa_hhXDFSU/YiRXYvqlMHI/AAAAAAAAJgs/THN7yhjF4hILJqfeZTaYtOYL88oNdAbMACNcBGAsYHQ/s1600/1646548831548236-1.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

**• How to download Crypto.com •**

It is very easy to download Crypto.com from these platforms for free.

  

\- [Google Play](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#) / [App Store](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)[](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

[![](https://lh3.googleusercontent.com/-5et5QWWRaXs/YiRXXqirguI/AAAAAAAAJgo/dPmYWkWsfv84omd14YZURot5E4XOaa2owCNcBGAsYHQ/s1600/1646548828322463-2.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

**• How to download Kepler wallet •**

It is very easy to download Kepler wallet from these platforms for free.

  

\- [Google Play](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#) / [App Store](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

[![](https://lh3.googleusercontent.com/-XZ-8ebg-ZIY/YiRXWwcRPuI/AAAAAAAAJgk/f2x39V92H3QZrc8Q4FOs_vHoNEKiPdZawCNcBGAsYHQ/s1600/1646548824841007-3.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

**• How to download Cosmostation •**

It is very easy to download Cosmostation from these platforms for free.

  

\- [Google Play](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

**• How to get 1000GB of decentralised privacy on Solar Labs dVPN for 1$ with key features and UI / UX Overview •**

**

[![](https://lh3.googleusercontent.com/-0K-UjE7hXtU/YiRXV5QjSEI/AAAAAAAAJgg/q3vycduYWXA2JOA7ZM_aOprmzIeRHd4jwCNcBGAsYHQ/s1600/1646548820954422-4.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Open Kepler then tap on **Create a new wallet**

**

[![](https://lh3.googleusercontent.com/-_5xaZjaX18g/YiRXVHCax1I/AAAAAAAAJgY/XURBcyRKUAIFt-6yvQvWnoLF_qw-jr9nQCNcBGAsYHQ/s1600/1646548817464529-5.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Don't and never sign in with Google.

  

\- Tap on **Create new mnemonic** and copy and backup phrases somewhere safe and secure as need them in future and also set wallet nickname and password.

  

[![](https://lh3.googleusercontent.com/-DJFGRfsPBLA/YiRXUDumc_I/AAAAAAAAJgU/tRxp0Bd96aAMtFdeuwvOX-b_jcqILHPogCNcBGAsYHQ/s1600/1646548813368547-6.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Enable or disable Biometric, then tap on **Done **and Instantly you'll be Kepler wallet.

  

[![](https://lh3.googleusercontent.com/-eWE-SLcc5rE/YiRXTH1S4II/AAAAAAAAJgM/6shLnnsPEUgeqWn5uuUEmnrlS_Irly_OACNcBGAsYHQ/s1600/1646548808599453-7.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Now open crypto.com app and tap on **Invited? Add Refferal code.**  

**

[![](https://lh3.googleusercontent.com/-2bOpqyoTt6g/YiRXRw8XrOI/AAAAAAAAJgI/PW_W4iM9Xn8il64_Tdf6cpKVcLfZFttygCNcBGAsYHQ/s1600/1646548804716702-8.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Once, refferal code is added then tap on **Create New Account.**

[![](https://lh3.googleusercontent.com/-2Mi4d6tyRIw/YiRXQ7eXAYI/AAAAAAAAJgA/G071ZaHtYVcMOJoFoh5UqKOUhA-ta1qlACNcBGAsYHQ/s1600/1646548800894125-9.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Enter this Refferal code : ×× and enter Your Email Address then tap on **Create New Account.**

**

[![](https://lh3.googleusercontent.com/-vp5iR0fnymI/YiRXP8MktwI/AAAAAAAAJf8/hmQK7gPxtxc8Z6i2kef2Xf497pi9qmVqwCNcBGAsYHQ/s1600/1646548797313067-10.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on Open Mail to check your email for a confirmation link from Crypto.com.

  

[![](https://lh3.googleusercontent.com/-mLBjyJd91zo/YiRXPBjC2AI/AAAAAAAAJf0/jaQyQEIiu5QbcDPudvlMkLugis2jbhE6QCNcBGAsYHQ/s1600/1646548793171274-11.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Find this mail, then tap on **LOG IN **instantly you will be redirected to app.

  

\- Once you're on app, crypto.com like any other crypto exchange, you have to submit documents and other details required.

  

\- When you complete setup and verified on crypto.com, just buy 21$ of CRO tokens as minimum withdraw is 20$ to be safe.

  

  

[![](https://lh3.googleusercontent.com/-z-o2JzkQd-k/YiRXOIfceNI/AAAAAAAAJfw/XTV63vpoYEcHnmIbLr9ez4YUR51gpVNVQCNcBGAsYHQ/s1600/1646548768212504-12.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

  

\- We are going to use CRO tokens to buy sentinel dVPN as CRO transaction fee is very low and fast, so are you ready?

  

[![](https://lh3.googleusercontent.com/-lgYq-8_ftCE/YiRXH7scJKI/AAAAAAAAJfs/cEdiboOzWxg7StDjLnPfXB-mYMxMwDj1ACNcBGAsYHQ/s1600/1646548764205996-13.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

  

\- Now, open Kepler wallet then tap on **\>> Cosmos Hub**

**

[![](https://lh3.googleusercontent.com/-equsr4ZgFI8/YiRXGvjpbjI/AAAAAAAAJfk/H_LwVW8x_ScBX931OYpJgYdjESl7fV5kACNcBGAsYHQ/s1600/1646548760005027-14.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on **Osmosis**

**

[![](https://lh3.googleusercontent.com/-KtDoKiZ2CZY/YiRXFjN0IZI/AAAAAAAAJfg/qEM7bLBffbIx7klpVJaRZRVd1Pe5ep8lgCNcBGAsYHQ/s1600/1646548755615690-15.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

  

\- Tap on your wallet name to copy your osmosis address then simply go to your crypto.com app and withdraw CRX tokens to your osmosis address.

  

[![](https://lh3.googleusercontent.com/-xCD_5qst2hY/YiRXEsF3gSI/AAAAAAAAJfc/oz_0gAhlMP44gPu_9IbLoQQbeVh01Da1ACNcBGAsYHQ/s1600/1646548751481687-16.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

  

\- Open Kepler again then tap on 🌎

  

[![](https://lh3.googleusercontent.com/-VNgFisy4l-8/YiRXDT5iJaI/AAAAAAAAJfY/ge2dhURXkrwrB93oS8LJS0J0VZIX5p-HgCNcBGAsYHQ/s1600/1646548747385813-17.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

  

\- Tap on **Osmosis --->**

**

[![](https://lh3.googleusercontent.com/-W4nDA0SEqGY/YiRXCV0PKLI/AAAAAAAAJfU/RciAfITCBq4v_YxdtuwSMGN5-NZCYZ1rQCNcBGAsYHQ/s1600/1646548743064838-18.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on ≡ then tap on **Assets**

**

[![](https://lh3.googleusercontent.com/-FUtq0rut_9M/YiRXBYc6rzI/AAAAAAAAJfQ/Qv5RXm4TAjETm52jDqvqB04Xxt2L-8S_QCNcBGAsYHQ/s1600/1646548738796355-19.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Find Crypto.org - CROthen tap on** Deposit**

**

[![](https://lh3.googleusercontent.com/-PGJ9NX4KCXg/YiRXAUvogII/AAAAAAAAJfM/ImMcvyUaDXQtTk_9IGfhkVsOvSHBr_VuACNcBGAsYHQ/s1600/1646548734539098-20.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on MAX then tap on **Deposit**  

**

[![](https://lh3.googleusercontent.com/-tR9dCee12oo/YiRW_W4WdXI/AAAAAAAAJfI/vsiQh6B_YCwXvlFuaMwX3xbFZ4uVtxymQCNcBGAsYHQ/s1600/1646548730308701-21.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on **Approve**

**

[![](https://lh3.googleusercontent.com/-9nLvKeit31A/YiRW-AYuyOI/AAAAAAAAJfE/h9nhtFuon7YV_9GbhATpDSfHFUETOh_HgCNcBGAsYHQ/s1600/1646548725915624-22.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- if successful, you will get transaction details on [finder.terra.money](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#).

  

[![](https://lh3.googleusercontent.com/-IS86omnXtn0/YiRW9CoO0_I/AAAAAAAAJfA/-BV9KxmCg7AKcAuEqIwOi-Z5OtbotoeywCNcBGAsYHQ/s1600/1646548721771712-23.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Go to Osmosis, from select - CRO and enter 3 or 2 and To - DVPN you will get around 180 DVPN tokens which will get you upto 1000GB on Solar Labs dVPN.

  

\- Set slippage to default then tap on **Swap**

  

\- Hold on, you can stake remaining CRO on osmosis to earn annual interest or swap CRO token to any token you like, experts suggest stable coins like UST or EEUR.

  

\- Anyhow you can also swap remaining CRO to Sentinel dVPN tokens in future to top-up Solar Labs dVPN, it's up to you.

  

**

[![](https://lh3.googleusercontent.com/-cQXr-kHacys/YiRW8AwVMBI/AAAAAAAAJe8/maLgDHOsHP4PfSQuX0cfXSIdROamd0-JQCNcBGAsYHQ/s1600/1646548717379553-24.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on **Approve**

**

[![](https://lh3.googleusercontent.com/-VX_5rXXO5rM/YiRW61DqxiI/AAAAAAAAJe4/vTX2cXD9rHIO4cjT944a5CjmEtFxY1ntwCNcBGAsYHQ/s1600/1646548712912981-25.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- if successful you will get transaction details on [www.mintscan.io](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

[![](https://lh3.googleusercontent.com/-YP6uze5Qmqc/YiRW5iLi-UI/AAAAAAAAJe0/ya6ZPYs8SaYidJ8_xQaKbZ-rW5qFUe3OQCNcBGAsYHQ/s1600/1646548708076965-26.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Again, go to Osmosis assets page and find Sentinel - DVPN then tap on **Deposit**

**

[![](https://lh3.googleusercontent.com/-eAOYbpsWFII/YiRW4kn7dcI/AAAAAAAAJes/vp8xdGHcJvsWLIQb9-vXn3dQog5yob1PgCNcBGAsYHQ/s1600/1646548703625216-27.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on MAX then tap on **Deposit**

**

[![](https://lh3.googleusercontent.com/-D_TedjuO0MI/YiRW3dw7qcI/AAAAAAAAJeo/wusLK7Ac2PEmnX4YrE7Yk9RApsWoslRuACNcBGAsYHQ/s1600/1646548699517478-28.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on **Approve**

**

[![](https://lh3.googleusercontent.com/--fNH7PFIEfA/YiRW2b4MoMI/AAAAAAAAJek/Qt0UIRl4-J8922sUrZ9YyazvVrpI1UuBQCNcBGAsYHQ/s1600/1646548694789723-29.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

  

\- if successful, you will get transaction details on [www.mintscan.io](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Wait, you now send Sentinel dVPN tokens to Sentinel dVPN wallet of Osmosis which you have have transfer on Solar Labs dVPN.

  

[![](https://lh3.googleusercontent.com/-wGNJJqDsuIo/YiRW1VNJHkI/AAAAAAAAJeg/5raK6UvDql887lbHnIuh07JjAI1gBrxCQCNcBGAsYHQ/s1600/1646548690921593-30.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Open Cosmostation then tap on **START**

  

[![](https://lh3.googleusercontent.com/-e_-npwGYT8w/YiRW0a4ls9I/AAAAAAAAJec/Vmy_KhjE00gps6K1krYLqgv53bk_EPzPQCNcBGAsYHQ/s1600/1646548686763774-31.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Find and select **Sentinel**

  

[![](https://lh3.googleusercontent.com/-QAHYDvl0Rcw/YiRWzWqSUpI/AAAAAAAAJeY/kue4rg6S6BUFENFRWM3Ev-70D5CXTQtQwCNcBGAsYHQ/s1600/1646548682733013-32.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- Tap on **Mnemonic** and enter your Kepler wallet backup phrases that I said earlier to backup somewhere safe and secure then tap on **START**

**

[![](https://lh3.googleusercontent.com/-uZyMUuMWgLI/YiRWyREnrAI/AAAAAAAAJeU/NW0uNkARX04eF6oquv3VcIR_8rrcANUDgCNcBGAsYHQ/s1600/1646548678579720-33.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Select **Sentinel dVPN wallet**.

  

\- it's time now you need Solar Labs VPN address to receive tokens from Osmosis Sentinel dVPN wallet via Cosmostation.

  

 [![](https://lh3.googleusercontent.com/-9J7sAj0ag5U/YvFU9XbqB8I/AAAAAAAANAQ/QQZURbZ8oBEiRtHTPP63Ja_R45qEPlWOACNcBGAsYHQ/s1600/1659983089256201-0.png)](https://lh3.googleusercontent.com/-9J7sAj0ag5U/YvFU9XbqB8I/AAAAAAAANAQ/QQZURbZ8oBEiRtHTPP63Ja_R45qEPlWOACNcBGAsYHQ/s1600/1659983089256201-0.png) 

  

\- Open Solar Labs dVPN then tap on Create new **SOLAR ID.**

 **[![](https://lh3.googleusercontent.com/-cd9rXw8fh94/YvFU8vnPLBI/AAAAAAAANAM/durrctYOkvAbrvLhXlFfsu-kRl_fGXOKwCNcBGAsYHQ/s1600/1659983085124266-1.png)](https://lh3.googleusercontent.com/-cd9rXw8fh94/YvFU8vnPLBI/AAAAAAAANAM/durrctYOkvAbrvLhXlFfsu-kRl_fGXOKwCNcBGAsYHQ/s1600/1659983085124266-1.png)** 

  

\- Enter required details, check ✓ SOLAR Lab's terms of service and privacy policy then tap on **Create Account.**

 **[![](https://lh3.googleusercontent.com/-AWUxdrArgGA/YvFU7v0q_5I/AAAAAAAANAI/ZNp2aKCIYvohnC8yQ45fPOEaLzufQEYkwCNcBGAsYHQ/s1600/1659983082160525-2.png)](https://lh3.googleusercontent.com/-AWUxdrArgGA/YvFU7v0q_5I/AAAAAAAANAI/ZNp2aKCIYvohnC8yQ45fPOEaLzufQEYkwCNcBGAsYHQ/s1600/1659983082160525-2.png)** 

\- Now, save your mnemonic phrases somewhere safe then tap on **Continue**.

  

 [![](https://lh3.googleusercontent.com/-OhBVYYOr3-o/YvFU62J4a5I/AAAAAAAANAE/tMSkYcK42sYvvbJiEST0CBlF0vFsGpxzgCNcBGAsYHQ/s1600/1659983079045660-3.png)](https://lh3.googleusercontent.com/-OhBVYYOr3-o/YvFU62J4a5I/AAAAAAAANAE/tMSkYcK42sYvvbJiEST0CBlF0vFsGpxzgCNcBGAsYHQ/s1600/1659983079045660-3.png) 

\- Tap on **Sign in.**

 **[![](https://lh3.googleusercontent.com/-QeoHxtAL0Tw/YvFU6NZiW-I/AAAAAAAANAA/Oq3A_m-wmkwXoyk5cAI2RkcLAE8AqhXRgCNcBGAsYHQ/s1600/1659983075975666-4.png)](https://lh3.googleusercontent.com/-QeoHxtAL0Tw/YvFU6NZiW-I/AAAAAAAANAA/Oq3A_m-wmkwXoyk5cAI2RkcLAE8AqhXRgCNcBGAsYHQ/s1600/1659983075975666-4.png)**   

\- Enter Email address, Your password then tap on **Sign in.**

 **[![](https://lh3.googleusercontent.com/-QRCAOORgzYA/YvFU5cbQ5JI/AAAAAAAAM_8/moHo3v8skwcYBX6xZhjjO7tG4a7DwYPPQCNcBGAsYHQ/s1600/1659983073268938-5.png)](https://lh3.googleusercontent.com/-QRCAOORgzYA/YvFU5cbQ5JI/AAAAAAAAM_8/moHo3v8skwcYBX6xZhjjO7tG4a7DwYPPQCNcBGAsYHQ/s1600/1659983073268938-5.png)** 

\- Tap on **Awesome!, let's go!.**

  

 [![](https://lh3.googleusercontent.com/-OCG24ohs7A4/YvFU4uWrcQI/AAAAAAAAM_4/AoN5p6XQgNkjgqRiC-QtNMxJqJa_XbNrgCNcBGAsYHQ/s1600/1659983069643115-6.png)](https://lh3.googleusercontent.com/-OCG24ohs7A4/YvFU4uWrcQI/AAAAAAAAM_4/AoN5p6XQgNkjgqRiC-QtNMxJqJa_XbNrgCNcBGAsYHQ/s1600/1659983069643115-6.png) 

  

  

\- You're in Solar Labs dVPN.

  

\- Tap on profile icon.

  

 [![](https://lh3.googleusercontent.com/-TdZEX69KfWc/YvFU3sXCFwI/AAAAAAAAM_0/QHUbIRAYzG8V9xlA81GZfIkDxErXRDGrgCNcBGAsYHQ/s1600/1659983065521839-7.png)](https://lh3.googleusercontent.com/-TdZEX69KfWc/YvFU3sXCFwI/AAAAAAAAM_0/QHUbIRAYzG8V9xlA81GZfIkDxErXRDGrgCNcBGAsYHQ/s1600/1659983065521839-7.png) 

  

  

\- You can see Sentinel dVPN address, Tap on Copy 📋 and go back to cosmostation.

  

[![](https://lh3.googleusercontent.com/-PntzZKZustY/YiRWsz6Ii4I/AAAAAAAAJeA/qeizbhp4cFAdu1hxjcQnXPGpJ_muSZRdwCNcBGAsYHQ/s1600/1646548656614540-38.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  

\- On Cosmostation, tap on **ASSETS**

**

[![](https://lh3.googleusercontent.com/-jC1DpnTFvZI/YiRWrpE2otI/AAAAAAAAJd8/VtNk1BMQ0BcPLU4a2bhG5iBG_4irKwAAACNcBGAsYHQ/s1600/1646548652421689-39.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on **DVPN >**

**

[![](https://lh3.googleusercontent.com/-cP3VnOFOno4/YiRWqn013GI/AAAAAAAAJd4/yRkZmWF5894zoRoG61jB5fA3ck4IXA-bQCNcBGAsYHQ/s1600/1646548648279605-40.png)](https://www.blogger.com/blog/post/edit/8984889699081605598/4911042232550436048#)

  
**

\- Tap on IBC Send and paste your Solar Labs dVPN address to send tokens.

  

\- Don't use Send option, it won't work and funds will be lost.

  

 [![](https://lh3.googleusercontent.com/-Y2H2PXzNW34/YvFU2ib8kpI/AAAAAAAAM_w/DtyRpRLXwXMCd1y9ehEDWoWBaPeNw9BHACNcBGAsYHQ/s1600/1659983062185251-8.png)](https://lh3.googleusercontent.com/-Y2H2PXzNW34/YvFU2ib8kpI/AAAAAAAAM_w/DtyRpRLXwXMCd1y9ehEDWoWBaPeNw9BHACNcBGAsYHQ/s1600/1659983062185251-8.png) 

  

\- Open Solar Labs dVPN, if you received tokens go back to home.

  

 [![](https://lh3.googleusercontent.com/-kmsaD3kP-Sg/YvFU12RDytI/AAAAAAAAM_s/xvb51Ualsn0cp-1_wFF_c4vs3scuOKjzQCNcBGAsYHQ/s1600/1659983054587863-9.png)](https://lh3.googleusercontent.com/-kmsaD3kP-Sg/YvFU12RDytI/AAAAAAAAM_s/xvb51Ualsn0cp-1_wFF_c4vs3scuOKjzQCNcBGAsYHQ/s1600/1659983054587863-9.png) 

  

\- Tap on **Switch** to select decentralized server.

  

 [![](https://lh3.googleusercontent.com/-tOotXJRCyOM/YvFUz_P18_I/AAAAAAAAM_o/AQa7U19qbXkA9nLhJebAPGhygOsijdHGACNcBGAsYHQ/s1600/1659983049671557-10.png)](https://lh3.googleusercontent.com/-tOotXJRCyOM/YvFUz_P18_I/AAAAAAAAM_o/AQa7U19qbXkA9nLhJebAPGhygOsijdHGACNcBGAsYHQ/s1600/1659983049671557-10.png) 

  

\- Select a decentralized server from number of continents.

  

 [![](https://lh3.googleusercontent.com/-CoJ5txJEsLY/YvFUygOsihI/AAAAAAAAM_k/cTBndgNHIKYst6kiaN55kPpgWxg53MsOACNcBGAsYHQ/s1600/1659983045174335-11.png)](https://lh3.googleusercontent.com/-CoJ5txJEsLY/YvFUygOsihI/AAAAAAAAM_k/cTBndgNHIKYst6kiaN55kPpgWxg53MsOACNcBGAsYHQ/s1600/1659983045174335-11.png) 

  

\- Once selected, tap on **CONNECT TO DVPN.**

 **[![](https://lh3.googleusercontent.com/-LZRVafgMTI8/YvFUxlj3xSI/AAAAAAAAM_g/dn_DPKayMAcYosZY-6aqUEaJYvmNf3vrACNcBGAsYHQ/s1600/1659983039924567-12.png)](https://lh3.googleusercontent.com/-LZRVafgMTI8/YvFUxlj3xSI/AAAAAAAAM_g/dn_DPKayMAcYosZY-6aqUEaJYvmNf3vrACNcBGAsYHQ/s1600/1659983039924567-12.png)** 

\- Tap on + to increase as much as you want, here for demo purposes I selected 1GB then tap on **SUBSCRIBE.**

 **[![](https://lh3.googleusercontent.com/-6G1_qe3R3vc/YvFUwHCdsgI/AAAAAAAAM_c/OEWEs7txL0ABfKzgs0BlZu3QZSw0qlavwCNcBGAsYHQ/s1600/1659983035655241-13.png)](https://lh3.googleusercontent.com/-6G1_qe3R3vc/YvFUwHCdsgI/AAAAAAAAM_c/OEWEs7txL0ABfKzgs0BlZu3QZSw0qlavwCNcBGAsYHQ/s1600/1659983035655241-13.png)** 

\- it will be connected.

  

 [![](https://lh3.googleusercontent.com/-DfUB4mPFP_U/YvFUvE2qtcI/AAAAAAAAM_Y/J7_HP3abRkEgvvOB58L8FQjWAUNf4UTDACNcBGAsYHQ/s1600/1659983029906319-14.png)](https://lh3.googleusercontent.com/-DfUB4mPFP_U/YvFUvE2qtcI/AAAAAAAAM_Y/J7_HP3abRkEgvvOB58L8FQjWAUNf4UTDACNcBGAsYHQ/s1600/1659983029906319-14.png) 

  

\- In settings, You can change DNS servers to HANDSHAKE, CLOUDFLARE, FREENOM and GOOGLE as well if you want it.

  

Atlast, Atlast, this are just highlighted features of Exidio dVPN, Crypto.com, Kepler wallet, Cosmostation and osmosis, there are many features hidden features in-build that give the ultimate usage experience which you have to explore based on requirements to get external benefits.

  

  

Overall Crypto.com is simple but has bugs so can't login on app, while cosmostation and Kepler has few bugs and they have to add more features and improve user interface so much as of now they just look fine, in case of Osmosis and Solar Labs dVPN they both look amazing with modern user interface and we didn't found bugs that ensures user-friendly experience.

  

Moreover, it is worth to mention don't buy through Solar Labs dVPN, in-app top-up is expensive and not worthy as you get only 100 gems for $1.19 the reason is they have to pay vat, chargeback risks, google playstore fees and developer salaries etc, so if you're not lazy buy and transfer the dVPN tokens using above procedure.

  

Finally, this is how you can get 100GB of decentrailized privacy and security for 1$ on Solar Labs dVPN, are you an existing user of Solar Labs dVPN? If yes have you ever tried this method to load Sentinel dVPN tokens on Solar Labs dVPN app? If yes do say your experience and say us is this method worked for you or not, including that mention why you like Solar Labs dVPN in our comment section below, see ya :)