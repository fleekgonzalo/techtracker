---
title: 'Flowdor -  A super cool substratum theme for Android custom roms.'
date: 2023-04-27T12:00:00.002+05:30
draft: false
url: /2023/07/flowdor-super-cool-substratum-theme-for.html
tags: 
- Substratum
- technology
- Theme
- Flowdor
- AOSP
---

 [![](https://blogger.googleusercontent.com/img/a/AVvXsEjk3zyF7OvCUqcLZwr5n-db1frs2A-v0TNFioLJMaNT87ueGXd7hI0js2j1dHgYXMZcJqg_r-Bpz7ICpMoTNr8SRSi3BOGBvptOsUhYI2xKtTXsU01jlnWzKtA3Z4-QjNADdV-JHoMYBerPnj_48ff5ig2GPgeAH0MQgj5ZyYmmL-BN7lkwWuCIXq_hjs6n)](https://blogger.googleusercontent.com/img/a/AVvXsEjk3zyF7OvCUqcLZwr5n-db1frs2A-v0TNFioLJMaNT87ueGXd7hI0js2j1dHgYXMZcJqg_r-Bpz7ICpMoTNr8SRSi3BOGBvptOsUhYI2xKtTXsU01jlnWzKtA3Z4-QjNADdV-JHoMYBerPnj_48ff5ig2GPgeAH0MQgj5ZyYmmL-BN7lkwWuCIXq_hjs6n) 

  

Interface is basically something it can be either physical or virtual by using that you can access or connect to something like  display screens and operating systems inshort OS which we use on electronic devices like PCs and smartphones are basically interfaces they let you execute certain tasks electronically and digitally due to such functionality of interface it's  quite essential and important thing as without that you can't access or connect anything thanks to that demand for better interfaces is always existed in market and to supply them many makers around the world created a lot of different types of useful amazing interfaces for various purposes out of them you have to choose right one according to the needs carefully so that you can do things effectively.

  

Eventhough, there are many types of interfaces but when it comes to electronic devices operating system is basically software created using programming languages like C, C++, Java, Python etc is considered as digital interface with that only you will be able to access and use hardware and software technologies efficiently at first in begginings electronic devices like PCs used to come with cmd aka command line interface which is not easy one in order to use that you have to send commands using keyboard for each and everything but eventually thanks to inventors by year 1980s we got to see GUI aka graphical user interface that comes with layout and let you use system using mouse cursor, isn't that fabulous?

  

In 21st century modern world of digital technologies we widely use GUI based  operating systems on almost all electronic devices at first in early era of GUIs we used to have simple ones but now we have modern ones thought most of them are super cool but thing is if you don't like the one you are using on your device then if system allows you can simply switch to different supported OS that has better GUI design and characteristics you like and prefer to use but the problem here is whenever you want to switch OS you have to go through certain process each and everytime including that if your device doesn't let you or don't support different operating systems then it is a setback and it'll be difficult for sure, isn't that right?

  

Especially, if you're someone who can't or don't want to switch to some other OS but still want different GUI then it's way more hard and difficult task as this time you have to manually change necessary inbuild system files to change GUI but thing is in order to do all this first your device system must allow and you have to be an skilled developer with understanding on structure of OS on which you may have to replace, change, modify system files to get desired GUI output or else you may mess up system files that may break device which is sometimes irreparable thought PCs and most of it's operating systems allow you to change anything internally without limits but when it comes to smartphone operating systems there are limits and voids device warranty.

  

In sense, on PC operating systems you'll get both read and write access in system partitions with just few clicks you can enable superadminstator to run or use it almost everywhere but when it comes to smartphone operating systems like for instance on Android which is popular foss aka free and open source software has more than 70% worldwide market share developed by search engine giant Google on that by default you'll get read access but in order to get write access on system partitions you have to unlock bootloader and install rooting software like SuperSu or Magisk at the end PC or smartphone changing inbuild OS GUI is hard task but don't worry even if you're not geek you can  still change GUI for that there are number of softwares to amaze you on the go.

  

Nowadays, most people around the world widely using smartphones over PCs as they are easily movable handheld devices including that they can do almost all tasks of PCs in their own way efficiently if you are someone who use smartphone and wanna change inbuild GUI of OS then you are at right place at first back in early versions of Android we used to don't have inbuild or external universal softwares to change inbuild GUI of stock roms thought we can find many for custom roms like CyanogenMod at the end they are not and won't work on stock ones but eventually in later versions of Android OS like 6.0 and above we got to see few external super cool universal softwares to change GUI of stock and custom Android roms which are known as custom theming engines out of them Substratum seems like worthy one.

  

You may probably know when you use pure stock Android OS you won't get any inbuilt theming engines as Google don't provide them but when you use custom OEM Android roms like MiUI, HiOS, FIUI, EMUI etc or custom roms you'll get one or more amazing theming engines with a lot of magnificent themes which can be bit disappointing if you're an stock Android user as you have to stick to same existing inbuilt UI for long time but don't worry as there is demand for softwares to change GUI on stock Android OS number of third party developers back in year 2016 made theming engine named Substratum which is now the top and most popular one that has thousands of custom themes to apply custom overlays on stock Android as well as some oem specific roms but to make it work well you better to do all this thing on your rooted Android device, gotcha?

  

Eventhough, Substratum can apply custom overlays on non rooted Android 8.0 oreo devices but for that you have to use PC and enable Andromeda which work on all smartphones except Samsung for that you need synergy at the end anyhow Google preventing stock Android users from using custom overlays due to that Substratum and most of it's custom themes support Android 10 Q and below versions thought there are some subtratum themes which support new Android versions but thing is if you're an avid substratum user then you may probably already used them or want better one right? in that case recently we got to know about one underated feature rich beautiful custom overlays Substratum theme named Flowdor that you may never heard off as it's not available on play store but it's assuring and super impressive for sure, so do you like it? are you interested in Flowdor? If yes let's explore more.

  

**• Substratum theme engine official support •**

\- [XDA](https://forum.xda-developers.com/apps/substratum/)

\- [Reddit](https://www.reddit.com/r/Substratum/)  

\- [GitHub](https://www.github.com/substratum)

\- [Crowdin](http://translate.projektsubstratum.com/)  

\- [Telegram](https://telegram.me/substratum)

  

**• How to download Substratum theme engine •**

  

It is very easy to download that from these platforms for free.

\- [Google Play ](https://play.google.com/store/apps/details?id=projekt.substratum)

\- [Google Play \[ Lite \]](https://play.google.com/store/apps/details?id=projekt.substratum.lite&hl=en_US&gl=US&referrer=utm_source=google&utm_medium=organic&utm_term=substratum+lite&pcampaignid=APPU_1_HdP7YtjnB5uHptQPgPe1gA4)

**• Flowdor official support •**

\- [Telegram channel](https://t.me/flowdor)

\- [Telegram showcase](https://t.me/flowdorShowcase)

\- [Telegram group | English |](https://t.me/flowdor_theme)

\- [Telegram group | Indonesia |](https://t.me/Flowdor_indo)

**• How to download Flowdor •**

It is very easy to download that from these platforms for free.

\- [Telegram](https://t.me/flowdor)

**• Flowdor unsupported OEMs •**

\- OOS

\- MiUI

\- HiOS

**• How to apply Flowdor using Substratum  with key features and UI / UX overview •**

 **[![](https://blogger.googleusercontent.com/img/a/AVvXsEi4hwEwMxqc71hlJCY99NKXfxKk0QYh7dobWbnWn1nedRLXpNSAqX_Hd5dXVAWX68RsnckFmpmHFvYrnZhKqOT94vM0qHkwr_JXHtUqFmmw28oMSi56n8_YtEgKK-0GSAu0P3oCV57TLIXCUOeZMP3jZ1TKy9tB3WZ90wwMtNvMFMHchak9gfePoj_PbYWT)](https://blogger.googleusercontent.com/img/a/AVvXsEi4hwEwMxqc71hlJCY99NKXfxKk0QYh7dobWbnWn1nedRLXpNSAqX_Hd5dXVAWX68RsnckFmpmHFvYrnZhKqOT94vM0qHkwr_JXHtUqFmmw28oMSi56n8_YtEgKK-0GSAu0P3oCV57TLIXCUOeZMP3jZ1TKy9tB3WZ90wwMtNvMFMHchak9gfePoj_PbYWT)** 

\- Open Substratum lite only on Magisk rooted stock Android or custom roms.

  

 [![](https://blogger.googleusercontent.com/img/a/AVvXsEhaEtV1tCCJdBY3GpILL5seQBlhmzgAkNFyDj_qY5ApazAa_nK7HEsx7ywnHqrLyp7l4ILhE6JPMHzsLQ9zUbLRD_OM0eJ3x5LYsGKh_qUB0nAbuhOi3jQBV2Xs1xpBy8ifBFICCAaZ4bISKZIRDDl5JvxoDJWzhTIMBTDATy_3Fg91zZwpyV5tRyr2jfmT)](https://blogger.googleusercontent.com/img/a/AVvXsEhaEtV1tCCJdBY3GpILL5seQBlhmzgAkNFyDj_qY5ApazAa_nK7HEsx7ywnHqrLyp7l4ILhE6JPMHzsLQ9zUbLRD_OM0eJ3x5LYsGKh_qUB0nAbuhOi3jQBV2Xs1xpBy8ifBFICCAaZ4bISKZIRDDl5JvxoDJWzhTIMBTDATy_3Fg91zZwpyV5tRyr2jfmT) 

 [![](https://blogger.googleusercontent.com/img/a/AVvXsEgQTXqk-D-dxqRJ48LYRV4KZvLSdUl34geqE-CM8xekPPMkcALzzBbCb0npTd8aKFnwVzfC5W6rRjv36Q1VrgIXqwBCQyoqbMjLI4mBrtS_7kLwCvH-DCs6EHL0s3ZAm9DBoNItil5umfCSDgtrsnN_tVvLrQ9kNojXxp5-ycSYqmH7ciM2MpF6fmze4IsW)](https://blogger.googleusercontent.com/img/a/AVvXsEgQTXqk-D-dxqRJ48LYRV4KZvLSdUl34geqE-CM8xekPPMkcALzzBbCb0npTd8aKFnwVzfC5W6rRjv36Q1VrgIXqwBCQyoqbMjLI4mBrtS_7kLwCvH-DCs6EHL0s3ZAm9DBoNItil5umfCSDgtrsnN_tVvLrQ9kNojXxp5-ycSYqmH7ciM2MpF6fmze4IsW) 

  

\- Select whichever you want to theme then tap on SELECTED to continue further.

  

 [![](https://blogger.googleusercontent.com/img/a/AVvXsEhofoRAcR9fYln6uexWLckxq0nVn-Te54NLaCk8r_E1QBtwoYhqgQ3NO10MZYOu-cjpmCstmOD4HRBgPApa4m_Lyv4Z1i2u4lR6I7sugRG74ByLWh3iUOpidiUSr_0TcwUogpdjZhd7OELiY6vjmRZlV8YV8Hrx-5PIoAfrcfzmN_HU3J6gHrCLjFsOyAq1)](https://blogger.googleusercontent.com/img/a/AVvXsEhofoRAcR9fYln6uexWLckxq0nVn-Te54NLaCk8r_E1QBtwoYhqgQ3NO10MZYOu-cjpmCstmOD4HRBgPApa4m_Lyv4Z1i2u4lR6I7sugRG74ByLWh3iUOpidiUSr_0TcwUogpdjZhd7OELiY6vjmRZlV8YV8Hrx-5PIoAfrcfzmN_HU3J6gHrCLjFsOyAq1) 

  

\- Tap on Install selected and reboot device.

  

Bingo, you successfully installed Flowdor theme on your Android device.

  

Atlast, this are just highlighted features of Flowdor there may be many hidden features in-build that provides external benefits to give the ultimate usage experience, anyway if you want one of the best feature rich custom overlay packed subtratum theme then at present Flowdor is on go worthy choice for sure.

  

Overall, Flowdor comes with thousands of custom overlays by default and divided in two packages lite and expert mode, it has clean and simple user interface that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will Flowdor get any major UI changes in future to make it even more better, as of  Flowdor is simply quite awesome.

  

Moreover, it is definitely worth to mention Flowdor is one of the very few subtratum themes available out there on world wide web of internet that has thousands of custom overlays though you only need Substratum to use them on Android but if you want additional modules for that you need Magisk module that you have to make it work for yourself, yes indeed if you're searching for such subtratum theme then Flowdor has immense potential to become your new favorite.

  

Finally, this is Flowdor a beautiful feature rich subtratum theme that only work on AOSP aka Android open source project based stock and custom roms not on custom closed source OEMs so don't try on them it may hard or softbrick devices which is sometimes irreparable, anyway this is how you can apply Flowdor, are you an existing user of Flowdor? If yes do say your experience and mention if you any way better subtratum theme than Flowdor in our comment section below, see ya :)