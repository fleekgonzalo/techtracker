---
title: 'Why you shouldn''t buy Xiaomi MI Android One smartphones.'
date: 2022-07-23T23:29:00.001+05:30
draft: false
url: /2022/07/heres-why-you-shouldnt-buy-xiaomi-mi.html
tags: 
- technology
- Xiaomi
- Shouldn't Buy
- Android One Series
- Smartphones
---

 [![](https://lh3.googleusercontent.com/-EWsu-zDwZxQ/Ytw3AxINLkI/AAAAAAAAMpc/SXI9RK23Ww89Y2mnWSjOFVZS_HSDnerZACNcBGAsYHQ/s1600/1658599164671204-0.png)](https://lh3.googleusercontent.com/-EWsu-zDwZxQ/Ytw3AxINLkI/AAAAAAAAMpc/SXI9RK23Ww89Y2mnWSjOFVZS_HSDnerZACNcBGAsYHQ/s1600/1658599164671204-0.png) 

  

  

Android, a open source mobile operating from search engine giant Google released in year 2008 with HTC Dream smartphone from then alot of mobile companies build thier own version of Android to Install on thier smartphones and sell them online or offline market in thier targeted country but the advantage and drawback of Android OS is it can be used by any individual or company for free.

  

Google didn't found Android OS it was actually developed by Andy Rubens from him Google aquired in year 2005 for $50 million and then developed to release with smartphones to compete with Apple inc. iPhones world's first multi-touch technology smartphone with powerful hardware and advanced software named iOS that can fully replace almost all keypad mobile phones in the world.

  

The main speciality of Android OS is it is very customizable and as it's FOSS aka free and open source software Android powered smartphones are bit less expensive then closed source iOS powered Apple inc. iPhones including that over the years alot of mobile companies used on thier smartphones due to that now Android has more then 72.11% world wide share while Apple inc. iPhone iOS has just 27% and struggling to increase it in developing countries like india.

  

But, most companies who build and use Android OS on thier smartphones usually stop providing software updates after 1 or 2 year based on the mobile company thus majority of Android smartphones users depend on outdated software which has less features and unfixed security bugs and loop holes that can be exploited by hackers using malware to take complete control and surveillance your smartphone that can cause privacy issues.

  

Even though, Google actually developed Android OS for it's smartphones like Nexus which is now succeeded by Pixel on this smartphones Google regularly upgrade Android OS version with monthly security updates for few years thus you'll get new and exciting features every year so you don't have to buy another smartphone.

  

Anyhow, some people who have old Android OS smartphone and don't want to buy new one have as no choice other then to unlock bootloader and root Android OS smartphone that voids device warranty yet it will allow you to install custom Android OS roms aka softwares especially for your smartphone build by third party developers using AOSP - Android open source project.

  

However, most people don't like to unlock bootloader and root Android OS smartphones as it require some technical knowledge mainly newbies who are new to development stuff usually don't know how to install customs roms even though we have XDA portal with detailed guides for most smartphones yet if you didn't follow them currently then it can software that you can repair and hardbrick which is sometimes irreparable so it's up to you.

  

Thankfully, Google know that there is big problem with mobile companies who don't build and provide latest Android OS versions timely as it's not easy to build Android OS it can take few months to stable one so Google released a programme named Android One which any mobile company can join to partner with Google and provide latest Android OS upgrades and updates on smartphones for few years like Google Pixel smartphones.

  

Fortunately, many mobile companies around the world released Android One smartphones which get latest stock pure Android OS software upgrades for few years that includes Xiaomi a popular china mobile company well known for low price smartphones globally but they build and release most smartphones with custom skin Android OS named MIUI with extra features that are not available on stock pure Android OS smartphones.

  

Xiaomi has huge fanbase and it is one of the best custom Android OS but like any other mobile company Xiaomi stop releasing software upgrades and updates after 1 or 2 years including that there are many people who like stock Android OS over custom one due to that Xiaomi is loosing some customers which is why Xiaomi joined Android One programme and made Xiaomi A series smartphones.

  

Xiaomi A series got global attention as alot of Xiaomi customers want stock Android OS software on Xiaomi smartphones but so far Xiaomi's Android One series smartphones are not impressive for instance there are three MI series smartphones out of them MI A2 released in year August 16, 2018 from then it only received two Android OS upgrades from 8.0 Oreo to 10.0 Q since then it stopped receiving Android one software updates.

  

In sense, MI A2 only received two Android OS software upgrades in addition with monthly security updates which is unacceptable as even mobile companies who are not in Android One programme provide 1 or 2 years even more if you have Nokia smartphone so what's the benefit use of Android One smartphone? 

  

It is well known fact Google known for bug free and stable Android OS smartphones on Nexus or Pixel as it has all resources but in case of MI A2 it's way different there are several software problems on each Android OS in addition hardware problems that you may face on daily basis which will disturb overall user experience.

  

MI A2, Android OS is not optimized even being software is developed and released  by Google due to that on MI A2 software will struck and lag number of times every day when you open a simple app or play heavy resources game no matter for whatever reason because of that you have to switch off MI A2 to get use smartphone again that's irritating for sure.

  

When you use MI A2 there is high possibility that it will switch off or reboot numerous times on it's own even when you didn't done do anything which is probably a Android OS bug that Android One developers didn't check yet it can fixed fixed with future update but they didn't even now due to that it will stop the task that you're doing on smartphone at some point and you can only start again when you turn on smartphone again.

  

There are some issues with power off and on to like if MI A2 switch off on it's own then in order to enter into Android OS again you have to turn on MI A2 multiple times as it won't get into Android OS at first try most times including that MI 2 may reboot itself for more then 10 times you have to accept that as there is no way you can fix this so you have to wait until it get back to Android OS on it's own after numerous reboots it taken more then 1 hours in my case to use it so beware.

  

In any smartphone, long lasting battery life is essential MI A2 has 3,010 mah that can last one day at moderate usage but it won't on MI A2 battery percentage drop quicker then other smartphones like 20% in 10 minutes it is highly possible that was battery issue as on old smartphones Lithium batteris drain faster but very likely as Android OS is not optimised on MI A2 battery consumption is very high that can only fixed by optimization and battery life fix software updates.

  

If MI A2 power off at 100% battery on it's own then when it will power on you most likely see different battery life even 20% as battery drained itself or most likely it's Android OS issue as it was unable to detect the actual percentage of battery available on your smartphone which is enough to stay away from MI A2.

  

In case of hardware problems there are numerous on MI A2, we already know about poor battery life then there is speaker problem that will not just give you low sound but also sometimes stop working and require a reboot to make it work again even if you want to use headphones as there is no port you have to use hybrid USB C charging port to put headphones, isn't this disappointing?

  

On some MI A2 smartphones, you won't even able to listen with USB C charging port for whatever reason it will stop sending audio through cable after few usages but charging can be done there is no issue with that yet as you can't listen audio through USB port you need wireless bluetooth headphones and connect with MI A2 to listen audio and enjoy.

  

It seems like neither Xiaomi or Android One team didn't focused on MI A2 may be it was limited to only this model but there is high possibility that other Xiaomi MI model smartphones has same hardware and software issues we can complain to Xiaomi on hardware problems but for software issues Android One developers has to take blame from MI A2 series.

  

Android One programme has responsibility to send proper bug free software updates  from the start but it didn't like most mobile companies they sent softwares updates that has alot of bugs with hardware problems to make it worst even small and new mobile companies provide stable Android OS on thier smartphones considering that being Android One is created by Google owner of Android OS sending buggy software is not ideal.

  

Luckily, Xiaomi Android One smartphones has nice third party developers support on XDA who release latest less bugs and we'll stable Android OS custom roms but even there on MI A series smartphones you will get two partitions where you you have to install on 1 partition which is new and hard to use and there is no recovery partition on MI A series smartphones so you have to boot recovery using PC everu time so to fix this now most custom roms coming with custom recovery by default thanks to them MI A series smartphones are usable.

  

Anyway, Xiaomi also have to look upon MI A2 software updates and check with Android One developers to fix and send bug free and stable Android OS but they didn't instead fixing issues on old MI A series smartphones they are making plans to release new MI A series smartphones in sense they didn't care about MI A2 at all so both Xiaomi and Android One went wrong at the end it's evident that's it's better not to buy Xiaomi Android One smartphones atleast MI A2.

  

I believe as Xiaomi has large MIUI powerful smartphones with profits they are not focusing much on Android One smartphones but for sure in future Xiaomi may developed better hardware and come with stable and optimized bug free Android OS software atleast 5 years regular software upgrades and updates in future MI A series smartphones.

  

Finally, this is why you shouldn't buy Xiaomi Android One series smartphones mainly MI A2 it is not worthy, are you an existing user of Xiaomi Android One smartphones? If yes do say your experience and mention have you faced any hardware problems and software bugs on Xiaomi Android One smartphones in our comment section below, see ya :)