---
title: 'The Journey Of Android Software Updates '
date: 2020-01-28T23:29:00.001+05:30
draft: false
url: /2020/01/the-journey-of-android-software-updates.html
tags: 
- Version's
- Updates
- google
- smartphone
- Android
---

**

  

[![](https://lh3.googleusercontent.com/-TSps5767ZqY/XjPeN94YYLI/AAAAAAAABAM/-EulAPKl1ocSNV-KpRa1D8z1wTfXj3JYACLcBGAsYHQ/s1600/IMG_20200131_132823_309.jpg)](https://lh3.googleusercontent.com/-TSps5767ZqY/XjPeN94YYLI/AAAAAAAABAM/-EulAPKl1ocSNV-KpRa1D8z1wTfXj3JYACLcBGAsYHQ/s1600/IMG_20200131_132823_309.jpg)



**

**

The Journey Of Android Software Updates !**

  

After the marvellous step of apple with iPhone and with iOS software and shocked entire phone users and world.

  

Search engine giant was in dialemma and it has do something to get into smartphone track.

  

The former google employee Andy Rubin's has in a working project android, this is right time to get this opportunity to be taken by google.

  

Google done right thing, google approached Andy Rubin's and offered to sell the android company to google and purchased it and it become subsidiary of google.

  

The competitor arises and only company that have potential to do magics as google do wonders with software.  

  

Today If there is any smartphone softwares that are top in usage and numbers is iOS & Android.

  

Unlike apple, android is a open source software operating system it has it's own pros and cons.

  

Android Is one of the most revolutionized thing ever done and most widely popular and ruling today mobile market with the software.

  

Android specifically made for nexus and pixel devices lineup and being the first devices to get latest software updates from any other device that uses android open source project.

  

Android being the sweetest software ever made in entire world and can be assured in future to android keep on giving sweetness to users before and future to the entire world.

  

Unlike apple or any other operating system android used desserts names for thier software updates - code name and include security updates as separately If device needed.

  

\- Android use alphatical order and name a dessert name according to it and release publicly till now from A to Q has been released.

  

\- Let's get into the subject -

  

• **Android : 1.0**

  

This is the first release of android in 2008 it does not have code name but is was the first release that made some sweety upgraded releases.

  

• **Cup Cake : 1.5**

  

Its the version that really feel like a cup cake with the hardware covered as a layer to the software that android prepared to get in track of software.

  

• **Donut : 1.6**

  

A slight modifications and improvement from the version 1.5 an updated software with goodies.

  

• **Eclair - 2.0 to 2.1**

  

The start of upgrade from 1.0 to 2.0 the mediator digits in between ressembles no major update or upgrade.

  

The upgraded digit ressembles new major updates and upgrade.

  

• **Froyo - 2.2**

  

This is was the time, android really got into more popular as this is the version being available in most of the devices and sells got hiked.

  

• **Ginger Bread - 2.3**

  

Modern features and track of advancement begin In this stage and being one of the most popular android releases ever, can be said the ginger worked very well for android, it still supports WhatsApp and major updates from dev's,

  

However, support of updates has been stopped from google for this classic version.

  

•  **Honey Comb - 3.0 to 3.2**

  

The software that loaded with the sweety and smoothness from google.

  

Upgraded software comes with loads of features integraded with updated google services for better usage and look.

  

•  **Ice Cream SandWich - 4.0 **

  

The year 2011 the time the smartphone business really got standard around the world and google software to got standardized and a nice release of 4.0 work well without any issues.

  

• **Jelly Bean - 4.1 to 4.3**

  

One of the most widely used software from phone's to tablets.

  

Jelly bean one of the compact and safety release from google after 4.0

  

• **KitKat - 4.4**

  

One of the most popular and most used and wide recognition operating ever in the world is KitKat.

  

This is the times budget and entry level phones flourished everywhere with the popular moto e got used this software and hiked the hype.

  

Most installed software update being available for tons of device's.

  

• **Lollipop - 5.0 to 5.1.2**

  

The time of something new android new features and look after trying a new design with KitKat.

  

Android tried something new here with material design and its got same huge response.

  

• **Marsh Mellow - 6.0 to 6.0.1**

  

The update and a upgrade to hardware features like USB - C and FingerPrint Readers.  

  

• **Nought - 7.0 to 7.1.1**

  

This is the time of split screen feature that android uses wanted from google to add.

  

This is one of the good release from androd with dark look.

  

• **Oreo 8.0 to 8.1.1**

  

Things got changed mainly here the new user interface with plenty of new feature's.

  

Android tried new things like go version for low powered smartphone - budget and entry level smartphone's.

  

Introducing treble in same year to fix lack of updates for older and most devices.

  

• **Pie : 9.0**

  

Most probably that you are using this software if you are a stock user released in the year 2019

  

One of fine releases from android with digital well being and privacy and security enhancements.

  

• **Q : 10**

  

Don't know the name of the version, a good update to the existing pie.

  

Still not in widely used status with important updated security measures and look of most of the ui and ux.

  

This is the journey of google's - android software updates even though its not an overview but a simple lookup to get know the releases.

  

Finally, waiting for more sweetness from android to have a look and feel.

  

How many of you wanted android to name code name of android version to be named a Indian dessert. Comment Down Below ?

**バイバイ - Bye Bye In Japanese**