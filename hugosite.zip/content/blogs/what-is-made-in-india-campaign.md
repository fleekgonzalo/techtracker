---
title: 'What Is Made in India Campaign ?'
date: 2020-01-02T12:31:00.001+05:30
draft: false
url: /2020/01/what-is-made-in-india-campaign.html
tags: 
- technology
- manufacturing
- Industry
- India
- investors
---

 [![](https://lh3.googleusercontent.com/-c1LGdIfTzS8/Xg9Viif22fI/AAAAAAAAAdI/cD-h0cpMN9IGXogp2DXW_iv5VJoJ15mpwCLcBGAsYHQ/s1600/1578063233659441-0.png)](https://lh3.googleusercontent.com/-c1LGdIfTzS8/Xg9Viif22fI/AAAAAAAAAdI/cD-h0cpMN9IGXogp2DXW_iv5VJoJ15mpwCLcBGAsYHQ/s1600/1578063233659441-0.png) 

  

Hi, Do you ever seen the tech products that you recently purchased with the name made in india applied do you ever wondered does this thing doesn't seen before 2015 products that has been launched by same company that you have buyed  

Instead the products have made in china or japan

Even the products popular in india.

  

Now you'll know why these happened, after the indian government change in india 2014 there was dropdown of economic value of country and growth of new companies was decreasing instead the companies opting a better infrastructure country than india and less wages labour as possible like china and taiwanese.

  

To keep up the economic value and increase productivity in the country there should be something done to save india unemployment problem even not completely but yes a standard job employment for people.

  

To rival neighbour counties like china vietnem etc in terms of productivity and manufacturing day by day the products from china increasing in india country that helping china economy alot that india relying mostly for everything needed to end.

  

Instead of getting products that being manufactured in other country indian public like to use desi products and like products which are made in india as it increases india economy and a tag of made in india feels patriotic.

  

To counter and develop economic and employement growth the new government taken a intitative make in india and made in india and launched them on 25 September 2014.

  

Now let's see what are make in india and made in india.

  

Make in india : make in india means the foriegn or domestic companies had to manufactur in india and provide employment to india public and low wages based on the company.

  

Made in india : made in india applies to the products that has been manufactured in india.

  

After the launch of this intitative and easy of business rules changed to easily plant a manufacturing or assembling unit or any other company sectors in india.

  

This intitative does helped many companies as thiere is no heavy import charges and products that made in india have wide recognition from indian public to boost thier sells and promote themselves in name of made in india taglines.

  

Made in india and make in india made company's like Xiaomi and other foriegn companies to build tv manufacturing unit and phone assembling units in india and many other companies has build thier own unit in serveral states of India giving employement to indian youth and public.

  

This way it does helped in employment increase not completely but yes it does decreased unemployment issue in india and tax reduction to the companies that build manufacturing unit or anyother products based unit india.

  

Many companies have joined in this intiative as the popularity grows for the made in india taglinr it had successfully going till now and more companies are taking part.

  

Companies advertised thier products highlighting made in india tag to boost thier sells and reputation among india people.

  

In this way if not a immediate solution for unemployment and economic problem instead the future can be standard in terms of manufacturing and recognition instead depending and giving recognition to other countries like China interms of productivity.

  

Conclusion : Unemployment and economic problem is a big problem in india after the government change thier intitaive has been launched in the name of make in india and made in india updating rules giving relaxation to companies made many companies to build thier manufacturing units and others in several states in india and wide recognition and popularity among indian helped to success this india and standard even not completely but helped indian unemployment and economic decrease issue.

  

Keep Supporting : TechTracker.in