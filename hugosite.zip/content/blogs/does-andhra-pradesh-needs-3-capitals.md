---
title: 'Does Andhra Pradesh Needs 3 Capitals ?'
date: 2020-02-01T22:58:00.001+05:30
draft: false
url: /2020/02/does-andhra-pradesh-needs-3-capitals.html
tags: 
- technology
---

**  

[![](https://lh3.googleusercontent.com/-OqAL277oN_w/XjklW8EmGsI/AAAAAAAABB0/MSW9XqTK-Q4rFdoUxytv8aSyvuG3HxaLgCLcBGAsYHQ/s1600/IMG_20200204_123511_803.jpg)](https://lh3.googleusercontent.com/-OqAL277oN_w/XjklW8EmGsI/AAAAAAAABB0/MSW9XqTK-Q4rFdoUxytv8aSyvuG3HxaLgCLcBGAsYHQ/s1600/IMG_20200204_123511_803.jpg)

**

**

Does Andhra Pradesh Need 3 Capitals ?**

  

After the bifurcation of state Ap into two states **Telangana** & **AndhraPradesh** that led protests around the state with the slogan of samyakhya andhra and also the separate rayalasemma.

  

**\- Understanding Situation In Ap**

  

After the long struggle of telangana movement finally in 2014 bill passed for separate state telangana that caused many property and life loss that taken about more the 60years of raging protests that central has no choice as there is no strong leader in state that the chief minister of ap - YSR lost life in helicopter crash while going to rachakonda in nallamala forests, pavurala gutta.

  

It saddened the state of andhrapradesh and many people died with the unexpected shock that made people lost a great leader as the situation made there is lack of administration in the state which the central appointed presidential rule and changed chief minsters frequently and finally the last two major known chief ministers are roshayya and Kiran Kumar reddy then after the bill passed in assembly for separate state telangana that the time of bill passing the andhra pradesh MLAs and MPs made horrifying moments that pepper spray and knifes in the history of India for the first time in ap assembly.

  

However, it doesn't stopped the long struggle of telangana moment as 1000's of suicides and raging protests and property loss and strong tensified telangana people emotional connection for separate state of telangana is deeply rooted in themselves.

  

\- **Reasons for telangana movement **

  

• Small sight on telangana people.

  

• No bigger government jobs allocating for telangana people.

  

• No private jobs allocating for telangana people and giving high priority to andhra people in most of the state, central, and private jobs.

  

• Discrimination on telangana slang, songs and people and being backward in wealth, and education.

  

• No bigger culture or importance projecting for telangana people as they don't getting bigger spotlight in movies and the slang is shown very rare.

  

Being the keypoint for major telangana movement is for jobs and development and giving high priority to Andhra people over other.

  

This made andhra pradesh go for long protests against seperate telangana even after telangana is in celebrations all over the state as that made the ex - chief minister Kiran Kumar reddy to launch seperate party - samyakhya andhra party which doesn't got big attention as it needed to get later joined it to **INC** in 2018.

  

However, andhra united ap slogans and seperate telangana has made confusion and shocked both telangana and andhra people and real estate brokers. as the tension surrounded as their I's many unparliamentary and unconstitutional words spoken from the lead protestor and being reason for high protests around the state trs party founder k.chadrashekar rao.

  

This protests and slogans slow down as thier is no bigger changes that made in state of telangana that the trs party

founder made as time goes there is no change to the decision or ground report that made people of andhra separated as 13 and 14 districts with respectively and joint capital hyderabad for 10years.

  

The time of elections in telangana and andhra pradesh - telangana - trs party got elected as cm and in ap - tdp got elected with the support of bjp and jsp and newly formed jsp has stated that we have to support the senior party tdp as the newly formed messed up things has to be settled by tdp as it has experience in many things as we are new party we have no choice other than supporting.

  

The time of andhra pradesh that was in lack of big capital for either revenue productivity as the capital which served for united ap has with telangana as part of bifurcation as they lost bigger capital the central elections comes in place this I's when the minister from ap venkayya naidu has asked in assembly for special status for ap which the party congress and bjp which agreed if we come into power we will grant special status to ap.

  

Bjp got in power and the time goes the party asked for either the state want special status or special package even the special status has its own pros and cons for a state like ap as it can only granted for states like Bihar which is backwards in education, tourism, literacy etc even taking risk as per prime minister that tdp insisted for special package instead special status and even tdp themselves agreed in interviews from different channels and even after bifurcation the ap state has bigger cities like Vizag, rajamundry, amaravati as revenue generating and developed cities being even selected for smart cities as andhra pradesh topped in ease of doing business and even the revenue is higher than most other backward states in India so there is big trouble for giving special status granted to ap. this made some protests in Vizag different parties used different strategic plans to let central government grant special status but most of them didn't last long as the tdp party was in confusion as there is big mistake they done accepting special package time goes ap got some iconic companies like kia motors in anatapur - penukonda and manufacturing hub from xiaomi TV sector and many global recognized institutes in different parts of state as the special status is not tensified nor got strong commandment from politicians from different party's as thier is no strong hold on the subject.

  

The time comes the 5 years rule doesn't make special status to ap but they have to make a capital for ap as it lacks and lost hyderabad which developed by united ap people and politicians,  the span of 5 years tdp government chosen amaravati as it has connectivity and being center to most of the districts and by obeying Siva rama Krishna committee which appointed by central for capital selection which commitee States that there shouldn't be one superior city but ap needs all round developments and states many relevant points which didn't noticed or obeyed by tdp government and chosen amaravati and partnered with Singapore company's to build amaravati by taking help from world bank and little depended on state revenue.

  

Amaravati is known for Buddhist orgins and history related to gautaum budha and being having world heritage site which budha stupa found in excavation in amaravati, amaravati being having high kamma community and farmers known for greenary and major families depended on farming for thier livelihood.

  

Even though the greenary could effect with the the construction of bigger buildings and thier daily life cycle and related things that tdp government finally still choosed and started land pooling and the farmers given acres of land for the development of amaravati and thier lives and there is no criticism or any objections recieved from other parts of state and the things worked well for tdp without bigger interupptions and launched amaravati with modern graphics design demo circulated in youtube and the design is mind blowing and futuristic look but being criticised for forcefull land excavation and getting land at low prices from minor community's.

  

However, tdp party struggled a lot as they are having low budget crisis in ap which is keypoint that has to be noted even with the crisis they managed or forcefully tried to construct impossible things using different tactics which will be headache to upcoming **chief** **minister's** and state as it has to depend on world bank again or to do hard tasks to get out of low budget crisis and completing amarvati will become impossible in upcoming years as tdp got obections from oppontent party for utilising more money than required and spending more money than needed with secretly partnering with Singapore companies.

  

The opponent party - ycp which got tremendous victory in elections with never before seats 151 MLAs and 22 MPs and cm of state - ys jagan mohan reddy who is none other then ex - chief minster son of ys raja shekhar reddy and become third person to become youngest chief minster of state in age of 45 years in india.

  

Ycp party being strong opponent to tdp has made many objections and allegations on tdp party regarding corruption and choosing capital for personal gain of thier political leaders and party as they highlighted **insider** **trading** that the party leaders buyed 100s of acres from farmers at less prices as they known the capital will be in amaravati and shown reports in assembly recently.

  

The chief minister - ys jagan mohan reddy said that there is a lot of things that choosing amaravati could result ap in bad position in future and many things that tdp government didn't focused or looked and choosed amaravati based on centric location and for personal and political gain as they given and explained issues and problems that ap people have to face and said to be having three capitals reffering south africa.

  

\- **Amaravati** 

  

\- **Vishakapatnam** 

  

\- **Kurnool** 

  

As three capitals for state and appointed siva Rama krishna to look for the faults and report to the state government to get it have more look up on the statement as the Amaravati farmers are going on for long protests and many outrages taking place and tdp and jsp party supporting Amaravati as the background intentions are to either cash amaravati people vote bank for future elections or not should is in unknown and should be noted as time goes even after months of protests against 3 capitals from Amaravati people there is strong hold on 3 capitals from ycp government and trying to convey thier best to let people know.

  

The situation in Amaravati is still not got settled as the opponent political leaders trying to envoke emotions of amaravati people as the situation didn't got settled ycp appointed well known lawyer to see the situation on finalising completely on 3 capitals but they 99% finalised 3 capitals there will be no looking back as three capitals were agreed by most the people other than Amaravati and tdp party leaders, most of the intellectuals supported 3 capitals for example the siva Rama krishna is well known expertise commitee in India which known different aspects of India and having deep knowledge on various things supported 3 capitals before and today with no changes the only fact that committe agrees with tdp government is centric location that can't be disputed but there is no removing of capital list as Amaravati still in capital list and act as per the acts.

  

**\- Importance of 3 capitals.**

  

Andhra Pradesh comes from long way after bifurcation from Madras based on linguistic basis that Madras showing discrimination on telugu people and long fast of freedom fighter potti sree ramulu died in protest that outraged protest around the state telugu people is in anger that is uncontrollable as situation tensified the central government which is congress has no option other than dividing Madras on linguistic basis after the bifurcation from madras presidency Andhra Pradesh choosen Kurnool as capital which is in rayalaseema which got name from the era of glorifying and being richest times krishna deva raya.

  

Kurnool being capital for ap and it was going fine then the government chooses hyderabad as capital as it is developed jointly in United ap and known for wide recognition from around the world as it become technology hub in 2000's that the tdp - chief minister visions of technology hub for hyderabad as his visions worked very well by getting microsoft research and development

center in hyderabad is his first mile stone that laid foundation for hyderabad technology development which has to be appreciated and being thankful but however the hyderabad is not developed in single decade that microsoft has choosed it as it is in developing from last 60years as many big industries, manufacturers and central projects like bhel which export different types of equipment to various countries, microsoft is smart enough to understand ground reality of hyderabad but cbn has done his major contribution for settling microsoft and other tech company's will be remembered but giving hyderabad lands to real estate company's like Raheja mindspace that they made major contribution for technology company as they created blocks for company's over placements which made traffic and today's sluggish development of hyderabad and development being limited to sub-urbs not complete telangana and many districts in telangana is still in backwards.

  

The major mistake that cbn done is limiting development to only one city and giving development work to real estate they made block development than land development as not focusing on environmental and infrastructure sections and even after decades of development in telangana still musi river is one of the dirtiest river in the world and just not reparing that like in Paris if that got repaired the tourism will be lot better and road construction are irregular that the appointed corporators done irregular works that most of the roads even today have mud roads and the roads are being constructed by the real estate people who trying to do bigger projects etc and corruption plays a major role in hyderabad sluggish development compared to other developed cities in the world.

  

However, being hyderabad still served as capital for United ap and still got alot attention for companies like microsoft and google but yeah it got wide attention that made more companies to get it settled in hyderabad over other parts of India thats a good sign but it limited that to only hyderabad that to slowly and being not having ease of doing business re-arrangements like we have today made no bigger than normal which is okish for a city that be in developed for decades compared to other cities if hyderabad is considerable developed city that today it should be having an virology institute and no bigger traffic issues like in us but from drainage to infrastructure, irregular works and being criticised for corruption of law agencies and finally hyderabad limted development and surrounding areas suffering from lack of infrastructure and development and limited to suburbs and going and moving with slugging with the over highlighting and hype all the time protests and outrages all over the state for many things.

  

So, telangana and hyderabad can not be a role model for ap and Amaravati as the history and development of hyderabad is sudden and unexpected and different things make a major role but still it's not in active.

  

In case of ap it's differents as the government has to develop a capital from scratch for revenue and iconic stature and it has the possibility of doing modern arrangements doing mistakes again like in past.

  

If we compare with United states with india, india is alot different to United States which india is diverisfied and politics here are completely different and being fast growing developing country being still using and trying to do it's best facing issues and struggles with religions and region fights and today even after decades of developement stage there is only single virology institute and the neigbour country china got economic, gdp, literacy, productive giving on point competition to "USA" and Russia if we compare "USA" to india cities one of the city of us is triple higher developed than hyderabad which developed in decades of time even being two big giants like microsoft, google.

  

First thing that every one should remember development is not about company's it's about infrastructure - environmental, space, roads and proper designing and proper policy and education for example : Finland being top in education as it is small country in the world and they don't have tech giants like google or microsoft they have thier home grown nokia, and the gaming revolutionary company - **angry birds**.

  

It's not about company's that thinking getting company's is development it's about creativity, entrepreneurship, giving proper education without suicides and Siva Rama Krishna commitee given long report on indian education system does it implemented - no instead colleges being running with fake certifacates in appartments and the example of developed country is china which doesn't have google or microsoft they have home grown company's even apple have to connect with Chinese company to get thier devices fixed.

  

Government has to give support to the people who want to do something new developing education - beating won't help growing little minds a word can change life than a physical act and after getting good education and schemes like made in india and make in India schemes could push better and by limiting that scheme to just amaravati won't help as Amaravati have good tourist attractions development should not be damaging natural resources and it should need to understand geographical and understanding different parts of states and its people 

  

Let's come to **Kurnool** which is known for **sona massori rice** and being capital in past and being backward and having bad water system and even after having 10s of chief ministers coming from rayalaseema still Kurnool being backward as there is political party demanding seperate rayalaseema movement and Kurnool demanding capital as they criticised for showing small sight on them from past decades indian political and state politics is unexpectable there will be chance of some politician like kcr to cash the feeling of rayalaseema and get beneficial from it to form a seperate rayalaseema can be taken so do this all headaches neccesary for the state as they option of capitalising the cities they can now then

the ycp government taken a wise decision for 3 capitals and choosen Kurnool as judical capital as it respects the long waiting for Kurnool people for capital  and respecting thier emotions and stopping evolution of movements etc that could take place.

  

**Visakhapatnam** - vizag is known for the tourist and being beautiful city with breeze winds and iconic beach has been in development from past slowly and actively got different iconic company's and central projects like vizag steel plant and port and even good have good education literacy rate has choosen as executive capital which makes the city more fastly developed than half the time that take in developing Amaravati with less cost and being having compatible for most of things and it has potentional of becoming more better than hyderabad in few years that it make ap to get a good capital with revenue in toursim, productivity, manufacturing etc in less time and being capital having good benifits being beside beach as you can take reference of dubia with beautiful views of oceans from Burj Khalifa will make seperate identity all over the world.

  

Amaravati - amaravati being having good farming community and large area of greenary as it gives good amount of oxygen to state and getting high revenue in farming and most of the people there have farming as thier primary work and other are very less as delhi being one superior capital suffering from pollution and has to get oxygen cylinders for tackle ongoing dangerous levels of pollution as everyone from all parts of country has to go to New Delhi for different things and being capital for all the states in india as it increases traffic and pollution in one area does it effect one particular area got environment disturbed so making a good greenary area like Amaravati being utilised as capital for development is not a wise decision over the already developed and having good infrastructure and cleanliness and with good tourist attractions and iconic beach that being popular all over the country choosing it as capital will make quicker way to get out of low budget crisis.

  

Let's greenary be greenary rather than disturbing try to improvise it with the technology and get benefitted from it over damaging that with the name of development and its consequences can be really hard in future as delhi is live example compared to telangana with ap, ap has ability to modify and refurbish or improve transport system as it is having wide roads and land uitising it for creating good transport system with good gap between houses like in "USA" will gave good look and modern rather than like in hyderabad small roads and joint houses will spoil infrastructure and look and visibility will be cracky.

  

So ap government has the option and time eradicating mistakes that happened in hyderabad and most the houses in ap are build in good space and most the roads are not build and the option of building proper roads referring china and usa with wide area does put an effective role in developing.

  

For example some people taking Paris showing its capital need to be taken as reference in the case of Paris is different in many things and its has world's most popular Eiffel tower which Paris mostly get revenue from tourism and getting high revenue from tower itself and beautiful spacing and architecture is so different than india.

  

"USA" shouldn't be compared as I said earlier us one city is equals to triple higher than hyderabad and there economy, technology development, and education what not every field there are in top and being super power even after big natural disasters they still being one and thier infrastructure, house placements, law agencies and policy and enforcement, architecture and thier culture is top notch and mainly politics are corruption free and being watched carefully by Americans and they vote based on work over for 500rs or 1000rs and they do give competition between ex and new party contestors and note points of them and decide.

  

As I said earlier india is one of the corrupted nation and people don't question authority's rather most of them accept the things that ongoing from decades and finally "USA" cities and area are all developed perfectly.

  

If some wanted to developed thier state competely there is no way of developing building one city or one area as capital there should be wide developement

choosing perfect planning and execution for any projects and mainly adminstration skills and ability to direct ground level authority's to work and this skills has been seen in new CM of ap - ys Jagan Mohan Reddy he have strong knowledge and commitment towards the state of Andhra Pradesh and futuristic planning as he got tremendous victory as from ground level authority's worked with sencerity and good image being son of late ys raja Shekhar reddy that played a keyrole and trust.

  

The state shouldn't need to erase the things that already have good potential as state have to understand farming is more than company's and develop according to it rather removing it even though "USA" is less in population and even being got farming lately as india showed what is farming as being developed area from history that we today lack interms of agriculture and suicides are numerous and being no big support first consider agriculture as potential sector and it can do wonders as "USA" have good policy and cold storages for farmers and they doing agriculture very efficiently with utilising technology develop the sectors which are already have potential rather than erasing it for personal gain in the name of developments and tieing clothes on Amaravati people and farmers and masking truth is not good for future of ap.

  

Again, we wanna conclude that this mistake is completely done by cbn and development subject and vision should be future oriented and cover all districts and area and people well being over just for Amaravati area as limiting development makes another hyderabad and residing districts will get out of development view and people feel suppressed and for everything people have to travel to Amaravati for education, hospital and feel lower like that happened incase of hyderabad.

  

That mistake should not be done as the tdp - ex chief minister states that we developed brown city in hyderabad and we going to develop green city in Amaravati how it will happen is wonder as 1000's of acres are taking in land polling and 100's of acres are owned by thier party people themselves.

  

It should be happened again, choosing industrial and manufacturing area like Vishakapatnam having good weather conditions and iconic steel plant and port is wise and best decision for rapid development of state and executing things perfectly ys Jagan have good abilities to do that as his government jobs and kissan scheme and pensions scheme success in months of time as the previous government are unable to generate jobs.

  

Finally, Yes, we supported 3 capital after the announcement as we have idea about ap and after seeing some videos that i reanalysed points and i got to agree that 3 capitals is one the wise and perfect decision understanding situation of ap and its environment and people even taught some people doesn't get to understand they will soon understand once neccesary steps and works starts.

  

**We will definitely add more points soon, until then good bye..**