---
title: 'CONFINED - The Horror Game! '
date: 2021-03-08T13:30:00.000+05:30
draft: false
url: /2021/03/confined-horror-game.html
tags: 
- technology
- CONFINED
- Horror
- game
---

[![CONFINED - The Horror Game!](https://lh3.googleusercontent.com/-vTth8qnzoqE/YEsVnWJtkII/AAAAAAAADfM/Of5-A_LYB0szXg3D5m1cwJnC2-Ojg8KYQCLcBGAsYHQ/s1600/1615533464045985-0.png "CONFINED - The Horror Game!")](https://lh3.googleusercontent.com/-vTth8qnzoqE/YEsVnWJtkII/AAAAAAAADfM/Of5-A_LYB0szXg3D5m1cwJnC2-Ojg8KYQCLcBGAsYHQ/s1600/1615533464045985-0.png)

  

Do you like horror? Then probably you like to watch alot of horror movies isn't, horror is just not limited to horror movies, we can now play horror games to be tensified, it is know fact horror is one of the key emotion of life which you accept or not, these days due to technology advancements we can see alot of horror games available for PC and Android or iOS. 

  

**Yes**, we have amazing Horror games that can make you more horrified then movies

due to that many horror genre likers trying alot of new horror games to satisfy them- selfs yet many people doesn't even know there are horror games, so many people limit them-selfs with horror movies. 

  

**However**, Today we like to present you an interesting horror game made by the indie developers who working towards to make an impact in the gaming industry, yes the game they made is still in development but the working process is likable to view. 

  

We are the first website to get interview with the game founder who given us an opportunity to interview and get to know alot of details regarding the game and the future endeavors of their gaming company **GamersInUnity, **we thank them for all the time given for the interview. 

  

CONFINED - The horror game was started development in **April 7th 2020** where play- ers needs to survive while gathering info- about the antagonist ( Elder ) as per the founder of CONFINED - the game will be available for both PC and Android and they are working to release in Google Play Store at the end of **2021** or start of **2022**.

  

The minimum requirements need for the game is intel **i3** processor and **3GB** ram, the developers made sure the game will work in low end devices, and yes the game will be released in beta and later they work to make it stable like any other modern games do these days. 

  

**CONFINED** - will have good graphics as per the founder and they said in our interview the game will have 5 chapters but they are not interested to provide any leaks due to spoilers alerts but the game itself inspired by popular games like home sweet home and granny horror games. 

  

•  **CONFINED - Horror Game Team** • 

  

**\- Abhishek Chedwal**

" He is a 3D artist and music composer "

  

**\- Mohammed Nawaz**

"He is the lead story writer"

  

\- **Swarnaditya Singh**

"Lead programmer"

  

•** CONFINED - official support** • 

  

• Instagram : [@gamersunitystudio](https://instagram.com/gamersinunitystudio)

  

• Twitter : [@gamersinunity](https://twitter.com/GamersInUnity)

  

• Itch : [GamersInUnity-Studio](https://gamersinunity-studio.itch.io/). 

  

Website : [gamersinstudio.weebly.com](https://gamersinunitystudios.weebly.com/)

  

• **CONFINED - Horror Game Images** • 

  

[![](https://lh3.googleusercontent.com/-eMqy2PH2naY/YEsVl5khTzI/AAAAAAAADfI/c9r12Y0MzwkAx8q2W4ozc6XoR2dsb0syQCLcBGAsYHQ/s1600/1615533459951358-1.png)](https://lh3.googleusercontent.com/-eMqy2PH2naY/YEsVl5khTzI/AAAAAAAADfI/c9r12Y0MzwkAx8q2W4ozc6XoR2dsb0syQCLcBGAsYHQ/s1600/1615533459951358-1.png)

  

[![](https://lh3.googleusercontent.com/-MuveQ79M4rg/YEsVk5JSXfI/AAAAAAAADfE/Mio9VdDzl9cRaCYSPX9yd3vkfzsKk4inwCLcBGAsYHQ/s1600/1615533452624889-2.png)](https://lh3.googleusercontent.com/-MuveQ79M4rg/YEsVk5JSXfI/AAAAAAAADfE/Mio9VdDzl9cRaCYSPX9yd3vkfzsKk4inwCLcBGAsYHQ/s1600/1615533452624889-2.png)

  

￼

[![](https://lh3.googleusercontent.com/-mlzgHQEx2eI/YEsVjN8HSII/AAAAAAAADfA/TMJLRirTHWsU_e942CJhIrnDp90UoWRHQCLcBGAsYHQ/s1600/1615533447420130-3.png)](https://lh3.googleusercontent.com/-mlzgHQEx2eI/YEsVjN8HSII/AAAAAAAADfA/TMJLRirTHWsU_e942CJhIrnDp90UoWRHQCLcBGAsYHQ/s1600/1615533447420130-3.png)

  

\- this new floor texture made by their talented texture artist - **Ryan**! 

  

[![](https://lh3.googleusercontent.com/-mblrngFU_RM/YEsVh8vL8pI/AAAAAAAADe8/HUCOlr-RWmwwybPXf5HxwUtqnaQLnuHDACLcBGAsYHQ/s1600/1615533441997876-4.png)](https://lh3.googleusercontent.com/-mblrngFU_RM/YEsVh8vL8pI/AAAAAAAADe8/HUCOlr-RWmwwybPXf5HxwUtqnaQLnuHDACLcBGAsYHQ/s1600/1615533441997876-4.png)

  

**Overall**, this pre-made working images of CONFINED horror game looks fabulous & promising and this low poly and high poly 3d images are super fine, based on all the images available out there, we can say the game will be impressive it increased alot of expectations. I hope the user interface and user experience will be good! 

  

**Moreover**, the game is made by the young & aspiring developers who want to make  an impact on gaming industry and this is thier big first serious project which they are continuously working to make it feel great, so we have to wait and see how CONFINED will make an impact on the gamers especially horrifiers! 

  

**Finally**, this is the buzz and information about the game CONFINED, do we raised your interest on this game, do you like the working images, are you awaiting for the game like us?, if yes do mention your view and also share anything that you want to convey with the confined developers like tips etc in our comment section below. See ya :)