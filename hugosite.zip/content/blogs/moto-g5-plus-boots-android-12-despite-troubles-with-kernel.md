---
title: 'Moto G5 Plus boots Android 12 despite troubles with kernel.'
date: 2022-01-27T22:04:00.001+05:30
draft: false
url: /2022/01/moto-g5-plus-boots-android-12-despite.html
tags: 
- technology
- Android 12
- Evervolv
- Moto G5 Plus
- Potter
---

 [![](https://lh3.googleusercontent.com/-7MOk5LW5Dbs/YfLJkTBYI6I/AAAAAAAAI3M/gBm4lSO2Lq4MU-KsZc2I3gguzOE-WXeAQCNcBGAsYHQ/s1600/1643301260920186-0.png)](https://lh3.googleusercontent.com/-7MOk5LW5Dbs/YfLJkTBYI6I/AAAAAAAAI3M/gBm4lSO2Lq4MU-KsZc2I3gguzOE-WXeAQCNcBGAsYHQ/s1600/1643301260920186-0.png) 

  

Moto G5 plus is well known budget smartphone from motorola packed with qualcomm snapdragon 625 chipset and  value added features to ensure pretty good experience on the go, how ever this smartphone comes with 32 bit os which means running 64 bit os is not supported yet thanks to XDA portal talented and recognised developer vache brings 64bit rom support for Moto G5 plus in 2017, he also created a guide to run 64 bit roms and TWRP recovery on Moto G5 plus.

  

Moto G5 plus didn't had any issues to run 64bit roms till Android 11, after that due to issues with kernel Moto G5 plus unable to boot Andriod 12, while developers trying to boot Andriod 12 on Moto G5 plus despite of challenges and then after few months wait on January 25 a geeky developer named flintman successfully booted Andriod 12 evervolv custom rom with some stuff working on Moto G5 plus despite troubles with 3.18 kernel.

  

 [![](https://lh3.googleusercontent.com/-poLqRlbeiuc/YfLJjcmrJ2I/AAAAAAAAI3I/Sgngz7jQ8Gg8hBrwVEeoEaDwqhzniWvZwCNcBGAsYHQ/s1600/1643301256088692-1.png)](https://lh3.googleusercontent.com/-poLqRlbeiuc/YfLJjcmrJ2I/AAAAAAAAI3I/Sgngz7jQ8Gg8hBrwVEeoEaDwqhzniWvZwCNcBGAsYHQ/s1600/1643301256088692-1.png) 

  

He posted a screenshot of Android 12 Evervolv rom on Moto G5 plus in telegram channel stating No ETA's which means it is still under development & not yet released publicly so don't ask for updates, Flintman is not big fan of XDA so don't expect him to post this Evervolv rom on Moto G5 plus XDA forum, instead you may expect this Andriod 12 evervolv custom rom download links on [Moto G5 Plus Global](https://t.me/potterofficial) telegram channel near in future.

  

Billy ( Flintman ) Bellavance said he is currently working with Nick Reuter and Elginsk86 to upgrade Moto G5 plus kernel to 4.9 as 3.18 kernel has some challenges with Andriod 12 new code, however Flintman wanted to boot Andriod 12 on Moto G5 plus with 3.18 kernel as device tree is good enough and fortunately he successfully booted Andriod 12 with 3.18 kernel on Moto G5 plus.

  

Flintman and his team with latest 4.9 kernel was able boot recovery with no adb and display so far on Moto G5 plus, but he insists that other developers will join and work with 3.18 kernel or help fixing issues with 4.9 kernel, but I expect as Flintman already boots Andriod 12 with 3.18 kernel on Moto G5 plus, so may other developers use 3.18 kernel itself to boot Andriod 12 as working with new kernel takes more time and delay Android 12 custom roms for Moto G5 plus.

  

Moto G5 plus is already late in getting Android 12 custom rom and users of Moto G5 plus eagerly waiting for Android 12 custom rom to try out new features of Andriod 12 and get modern user interface and experience, while Moto G3 a 2015 smartphone with qualcomm snapdragon msm8916 chipset already boots Andriod 12 LineageOS few months back itself.

  

Well, Flintman willing to look into Moto G3 2015 Andriod 12 LineageOS custom rom so that he can see what exactly Moto G3 custom rom developers Althafvly, chill360, squid2, jeferson1979, Alberto97 etc done to boot Android 12 on such old device, it may help him boot Andriod 12 with 4.9 kernel on Moto G5 plus little faster then usual or fix troubles with 3.18 kernel.

  

Finally, Moto G5 plus ( Potter ) boots Android 12 thanks Flintman, Nick Reuter, Elginsk8r, do you own Moto G5 plus? are you eagerly waiting for Evervolv Android 12 custom rom to come out so that you  can try it out? If yes do say how do you feel about Andriod 12 on Moto G5 plus, in our comment section below, see ya :)