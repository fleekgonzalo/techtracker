---
title: 'LiveStatus - Now chat from home screen widgets on smartphones.'
date: 2022-12-21T12:00:00.000+05:30
draft: false
url: /2022/12/livestatus-now-chat-from-home-screen.html
tags: 
- Apps
- Innovative
- iOS 16
- LiveStatus
- Home messenger
---

 [![](https://lh3.googleusercontent.com/-uDeqdAoYs6w/Y6ND9FDMwgI/AAAAAAAAP4U/d6hdnA9bWzE4o3uvy0VFrY_FttvfqC4UgCNcBGAsYHQ/s1600/1671644142610295-0.png)](https://lh3.googleusercontent.com/-uDeqdAoYs6w/Y6ND9FDMwgI/AAAAAAAAP4U/d6hdnA9bWzE4o3uvy0VFrY_FttvfqC4UgCNcBGAsYHQ/s1600/1671644142610295-0.png) 

  

Messenger, the word is widely used by almost all communication softwares available for electronic devices like computers and smartphones with them you can send messages and make both voice and video calls to anyone thus they are known as social messengers which are usually equipped with many options and features to get your attention and recognition and keep you connected like for Instance Facebook, Telegram etc.

  

Even though, the functions provided by social messaging softwares are amazing and very useful but not everyone like and prefer them as some people want simple and minimalist products and consider to many options and features as bloatware as in some cases they disturb clean and well minded communication experience which is why companies develop simple social messaging softwares as well.

  

There are numerous lite messengers basically simple and lightweight social messaging platforms like facebook lite, imo lite, messages lite etc which are removed of heavy resources from original app yet still in certain cases developer somehow manage to get most options and features into lite softwares without compromising and negatively effecting user experience isn't that super cool?

  

Generally, majority of social messaging platforms you'll find innovation in various different aspects of software but the thing is as said earlier they are filled with a lot of options and features that are not required by minimalists due to that they're not only big in size but also look and feel heavy so certain percentage of people who like and prefer simple messaging experience don't use them instead look for alternatives that provide minimal experience on the go.

  

There are number of messaging platforms designed and developed to provide simple communication experience but in most of them you find similar options and features though they're modern and innovative but don't you want something new that not available on most messaging softwares to improve online chatting experience? It will be super cool and amazing right?

  

Usually, on most messaging softwares available for electronic devices like PCs aka personal computers and smartphones when a new recieve come in you have to check on notification bar or open software itself isn't it? there is no other way, what if we are able to check and send messages including images right from home screen widgets isn't that quite innovative?

  

There are many popular and well messaging softwares like WhatsApp and Signal etc which does have powerful and advanced options and features but for whatever reasons may due to lack of demand from users by default didn't provided widgets to chat from home screen isn't that dissapointing?

  

Recently, we got to know about a simple yet modern innovative messenger named LiveStatus that provide widgets to chat from your home screen on smartphone which has pip aka picture in picture mode for photos like YouTube including that you also get big 100+ emoji status collection with vanish mode for photos ,so do you like it? are you interested If yes then let's explore more.

  

**• LiveStatus official support •**

**Email :** [livestatus.widget@gmail.com](mailto:livestatus.widget@gmail.com)

**Website :** [livestatus.web.app](http://livestatus.web.app)

**• How to download LiveStatus •**

It is very easy to download LiveStatus from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.livehousex.lively) / [App Store](https://apps.apple.com/us/app/livestatus-share-your-life/id6443503124)

  

**• LiveStatus key features with UI / UX overview •**

 **[![](https://lh3.googleusercontent.com/-FLB6kAHyVfI/Y6P9wslXHsI/AAAAAAAAP5U/TKXBi_UJpbE7pt_ZKGQgyyzhxN-pB5odACNcBGAsYHQ/s1600/1671691709842327-0.png)](https://lh3.googleusercontent.com/-FLB6kAHyVfI/Y6P9wslXHsI/AAAAAAAAP5U/TKXBi_UJpbE7pt_ZKGQgyyzhxN-pB5odACNcBGAsYHQ/s1600/1671691709842327-0.png)** 

 - Open LiveStatus and tap on Continue with Google to login with Gmail.

  

 [![](https://lh3.googleusercontent.com/-z4wZeZMX2K4/Y6P9vl8AlFI/AAAAAAAAP5Q/TYlWFYIs5iY-AGrsQ4A3xFhLJ09apf5XgCNcBGAsYHQ/s1600/1671691705916442-1.png)](https://lh3.googleusercontent.com/-z4wZeZMX2K4/Y6P9vl8AlFI/AAAAAAAAP5Q/TYlWFYIs5iY-AGrsQ4A3xFhLJ09apf5XgCNcBGAsYHQ/s1600/1671691705916442-1.png) 

  

\- Enter username then tap on **Continue.**

  

 [![](https://lh3.googleusercontent.com/-1hLp0uSWJCQ/Y6P9ur5mB1I/AAAAAAAAP5M/RPnKP8z_g2cAVtoSKXTjdGoGH-vz4rbjQCNcBGAsYHQ/s1600/1671691701760160-2.png)](https://lh3.googleusercontent.com/-1hLp0uSWJCQ/Y6P9ur5mB1I/AAAAAAAAP5M/RPnKP8z_g2cAVtoSKXTjdGoGH-vz4rbjQCNcBGAsYHQ/s1600/1671691701760160-2.png) 

  

  

\- You're in **LiveStatus.**

 **[![](https://lh3.googleusercontent.com/-0VRcvsL2oEk/Y6P9trT9ksI/AAAAAAAAP5I/Fa7YSpm28FgV_krW5-72UtglMhuFKznFQCNcBGAsYHQ/s1600/1671691697652126-3.png)](https://lh3.googleusercontent.com/-0VRcvsL2oEk/Y6P9trT9ksI/AAAAAAAAP5I/Fa7YSpm28FgV_krW5-72UtglMhuFKznFQCNcBGAsYHQ/s1600/1671691697652126-3.png) 

 [![](https://lh3.googleusercontent.com/-gTz6IKS7278/Y6P9sipReLI/AAAAAAAAP5E/1xyCTpHyGW4csI5e98Wo9kt2T4ef-7oswCNcBGAsYHQ/s1600/1671691693618526-4.png)](https://lh3.googleusercontent.com/-gTz6IKS7278/Y6P9sipReLI/AAAAAAAAP5E/1xyCTpHyGW4csI5e98Wo9kt2T4ef-7oswCNcBGAsYHQ/s1600/1671691693618526-4.png) 

 [![](https://lh3.googleusercontent.com/-ZiX-6BmMOxI/Y6P9rq_0aMI/AAAAAAAAP5A/sNFe-2JKcIIUz6Thc7-ZlODMNzPS0ETOQCNcBGAsYHQ/s1600/1671691689363026-5.png)](https://lh3.googleusercontent.com/-ZiX-6BmMOxI/Y6P9rq_0aMI/AAAAAAAAP5A/sNFe-2JKcIIUz6Thc7-ZlODMNzPS0ETOQCNcBGAsYHQ/s1600/1671691689363026-5.png) 

 [![](https://lh3.googleusercontent.com/-AdujaW02JuU/Y6P9qh8i2DI/AAAAAAAAP48/HeEvul7SyM0IXORnfX3xXHm-cBzwGAeMgCNcBGAsYHQ/s1600/1671691685379429-6.png)](https://lh3.googleusercontent.com/-AdujaW02JuU/Y6P9qh8i2DI/AAAAAAAAP48/HeEvul7SyM0IXORnfX3xXHm-cBzwGAeMgCNcBGAsYHQ/s1600/1671691685379429-6.png) 

 [![](https://lh3.googleusercontent.com/-QQkDx0fK9pw/Y6P9pVcDflI/AAAAAAAAP44/xVWrvomrsb4aLhb9PvI0pg5-w3JtcjvGwCNcBGAsYHQ/s1600/1671691681181120-7.png)](https://lh3.googleusercontent.com/-QQkDx0fK9pw/Y6P9pVcDflI/AAAAAAAAP44/xVWrvomrsb4aLhb9PvI0pg5-w3JtcjvGwCNcBGAsYHQ/s1600/1671691681181120-7.png) 

 [![](https://lh3.googleusercontent.com/-ShnXjQTVSro/Y6P9odUfbfI/AAAAAAAAP40/t_wCuB1vag8ju6Vlnztda6S0Lw7B62CQQCNcBGAsYHQ/s1600/1671691677172948-8.png)](https://lh3.googleusercontent.com/-ShnXjQTVSro/Y6P9odUfbfI/AAAAAAAAP40/t_wCuB1vag8ju6Vlnztda6S0Lw7B62CQQCNcBGAsYHQ/s1600/1671691677172948-8.png)** 

 **[![](https://lh3.googleusercontent.com/-CmFsQmyPBuA/Y6P9nYSZitI/AAAAAAAAP4w/McJ9UxICfi8-p20BrVq6U8DI0ljnxe6gQCNcBGAsYHQ/s1600/1671691672829460-9.png)](https://lh3.googleusercontent.com/-CmFsQmyPBuA/Y6P9nYSZitI/AAAAAAAAP4w/McJ9UxICfi8-p20BrVq6U8DI0ljnxe6gQCNcBGAsYHQ/s1600/1671691672829460-9.png) 

 [![](https://lh3.googleusercontent.com/-7SjKsIZszgc/Y6P9mQiU8FI/AAAAAAAAP4s/cXnGp-mRVdQTYJb9BtUSRIkLM4vUTYHMgCNcBGAsYHQ/s1600/1671691669056226-10.png)](https://lh3.googleusercontent.com/-7SjKsIZszgc/Y6P9mQiU8FI/AAAAAAAAP4s/cXnGp-mRVdQTYJb9BtUSRIkLM4vUTYHMgCNcBGAsYHQ/s1600/1671691669056226-10.png) 

 [![](https://lh3.googleusercontent.com/-J82HyMF5MwQ/Y6P9lUKi0ZI/AAAAAAAAP4o/o_wbBQufNB4v6of2s4w3VSgoN67IwI0OgCNcBGAsYHQ/s1600/1671691664955362-11.png)](https://lh3.googleusercontent.com/-J82HyMF5MwQ/Y6P9lUKi0ZI/AAAAAAAAP4o/o_wbBQufNB4v6of2s4w3VSgoN67IwI0OgCNcBGAsYHQ/s1600/1671691664955362-11.png) 

 [![](https://lh3.googleusercontent.com/-KsRyFYnv9dQ/Y6P9kdCPMnI/AAAAAAAAP4k/Ojlb1tJqq6MLF_M5FP9wbkluS6GZwQueQCNcBGAsYHQ/s1600/1671691660760169-12.png)](https://lh3.googleusercontent.com/-KsRyFYnv9dQ/Y6P9kdCPMnI/AAAAAAAAP4k/Ojlb1tJqq6MLF_M5FP9wbkluS6GZwQueQCNcBGAsYHQ/s1600/1671691660760169-12.png) 

 [![](https://lh3.googleusercontent.com/-w1XA_mSvauE/Y6P9jWvvR0I/AAAAAAAAP4g/U8_VJTH4V-ktYWCoEj6UnnbS35Ol4th-wCNcBGAsYHQ/s1600/1671691656576966-13.png)](https://lh3.googleusercontent.com/-w1XA_mSvauE/Y6P9jWvvR0I/AAAAAAAAP4g/U8_VJTH4V-ktYWCoEj6UnnbS35Ol4th-wCNcBGAsYHQ/s1600/1671691656576966-13.png)** 

Atlast, this are just highlighted features of LiveStatus there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, anyway if you want one of the best simple and innovative messenger then LiveStatus is worthy choice.

  

Overall, LiveStatus comes with light and dark mode by default, it has clean and simple interface that ensures user friendly experience but in any project there is always space for improvement so let's wait and see will LiveStatus get any major UI changes in future to make it even more better, as of now it's impressive.

  

Moreover, it is definitely worth to mention LiveStatus is one of the very few simple and modern social messengers available out there on world wide web of internet that allow you to add widget in home screen and get messages in it which is something new and innovative, yes indeed if you are searching for such messenger then LiveStatus has potential to become your new favourite for sure.

  

Finally, this is LiveStatus a simple yet modern and innovative social messenger for minimalists to chat with friends and close ones, are you an existing user of LiveStatus? If yes do say your experience and mention why you choose LiveStatus over other social messengers in our comment section below, see ya :)