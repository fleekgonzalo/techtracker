---
title: 'Micromax IN Note 1 & 1b Launched In India !'
date: 2020-11-03T14:02:00.000+05:30
draft: false
url: /2020/11/micromax-in-note-1-1b-launched-in-india.html
tags: 
- technology
- note 1
- In mobiles
- Micromax
- 1b
---

 [![](https://lh3.googleusercontent.com/-kDy4HfMFqWE/X6EVr1TlggI/AAAAAAAACFg/j1KGWoNPMiYS14_tAzH9_dhIvOEYmHBpwCLcBGAsYHQ/s1600/1604392365969911-0.png)](https://lh3.googleusercontent.com/-kDy4HfMFqWE/X6EVr1TlggI/AAAAAAAACFg/j1KGWoNPMiYS14_tAzH9_dhIvOEYmHBpwCLcBGAsYHQ/s1600/1604392365969911-0.png) 

  

Micromax well known indian company being the world's 10 biggest mobile vendor released many popular phones in India thier are in profits until chinese mobile company's entered in India.

  

Due to several clashes between indian & china while there is bigger dependence on chinese mobiles which causing privacy of Indian users at risk.

  

In this situation, pm modi launched aatma nirbhar program which provide required support to local company's to get on track to compete chinese & world wide company's 

  

In this scenario micromax got chance to come back to indian market and get thier previous glory that they lost due to poor specs & after market service.

  

In this situation, micromax said we heard you, we will come back with budget value phones with IN for India series.

  

**Today**, nov 3 micromax launched two micromax in mobiles named micromax in note 1 & in 1b while note 1 is the higher variant and 1b is lower variant of the IN series.

  

Micromax says they use world class cutting edge technology machines called fuji from japan which provides quality and perfect assurance.

  

Micromax this time comes with new design called X factor which will look like X back of the device which is good but not upto the expectations.

  

Micromax teased the nov 3 launch with tagline aao cheeni kumm tagline and wait is over.  

**▶ Micromax IN Note 1 ✨**

  

In software, micromax IN note 1 comes with pure android os, no bloatware, no ads, guaranteed updates for 2 years.

  

**▶ Micromax IN key features ✨**  

•  MediaTek Helio G85

  

**•** 48MP + 5MP + 2MP + 2MP with powerful AI quad camera.

  

• 6.67" FHD+ ultra bright resolution with punch hole display.

  

• 5000mAh battery with reverse charging and 18W fast charger.

  

• 4GB + 64GB & 2GB + 32GB

  

**Proccessor** : Helio G85 is a gaming processor for ultimate gaming experience without latency with huge 6.7 FHD display for seamless experience.

  

**Camera** : Micromax IN comes with 48 MP primary camera with 5 MP wide angle, 2 MP macro lens & 2 MP depth sensor with flash including 16 MP wide angle selfie camera which have 78° wide angle to shoot directly to gif.

  

**Battery** : Micromax in note 1 comes with 5000 mah powerful battery with reverse charging and 18 watt fast charger in box that can last upto 2 days with normal moderate usage.

  

**WiFi** : Micromax IN note 1 supports 5ghz WiFi.  

  

**Colors** : green, white with India the X factor design with rainbow effect which is cool.  

  

**Price** : Micromax IN note 1 : 10,999 for 4gb ram & 64 gb storage while 4gb & 128gb for 12,500rs.

  

Micromax IN Note 1 seems the only indian phone to provide cutting edge competitive price beating chinese phones in this price range.

  

**Moreover**, Micromax IN note 1 & 1b definately meet the expectations on paper specs which surely tackle chinese mobile, however but how does it will perform in real day to day usage we have to wait and see.

  

**▶ Micromax IN 1b**  

Micromax IN 1b also launched thier India's budget champion comes with Helio G35 processor with 5000mAh battery with 10 watt charger in box with USB type C.

  

**▶Micromax IN 1b Key Features ✨**  

•MediaTek Helio G35 with hyper engine.

  

**•** 13 + 2MP with powerful AI camera.

  

• 6.5" HD+ ultra bright resolution with mini drop display.

  

• 5000mAh battery with reverse charging and 18W fast charger.

  

• 4GB + 64GB 

  

• Colors : green, white, mettalic finish.

  

**Proccessor** : Helio G35 is a gaming processor for ultimate gaming experience without latency with huge 6.5 HD+ display for seamless experience.

  

**Camera** : Micromax IN 1b comes with 13 MP primary camera 2 MP depth sensor with flash including 8 MP  selfie camera.

  

**Battery** : Micromax in note 1 comes with 5000 mah powerful battery with reverse charging and 10 watt fast charger in box that can last upto 2 days with normal moderate usage.

  

**WiFi** : Micromax IN note 1b supports 5ghz WiFi.  

  

**Colors** : green, white with India the X factor design with rainbow effect which is cool

  

**Price** : Micromax IN 1b : 7,999 for 4gb ram & 64 gb storage while 2gb & 32gb for 6,999rs.  

  

Micromax IN Note 1b seems good budget phone to provide cutting edge competitive price beating chinese phone in entry level phone segment.  

  

**However**, to be straight on point, the only thing that micromax has to fix was after sales service which lack alot compared to any other mobile company's to fix anything the authorized service center's charge alot of money and they won't repair your device on time they will take months of time to repair and they won't even notify you about status of repair we have follow up about it, we faced alot of bad experience with micromax products and seen many people facing the issue, the another thing that micromax lacks the on paper specs are just excite you alot but real day to day usage is worst which need to fixed which is very crucial except that this on paper specs seems very interested who knows this is the first successful lineup of Micromax company.

  

**Micromax #IN for India**

  

**Finally**,  Micromax In going to appear for sales on nov 24 in flipkart & amazon, do mention have you had any bad experience with micromax will you buy this IN mobiles in our comment section down below. micromax #IN for India, jai hind 🇮🇳,  see ya :-)