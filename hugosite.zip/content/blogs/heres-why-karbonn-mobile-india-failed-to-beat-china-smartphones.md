---
title: 'Here''s why, Karbonn Mobile India failed to beat china smartphones.'
date: 2022-06-15T23:56:00.001+05:30
draft: false
url: /2022/06/heres-why-karbonn-mobile-india-failed.html
tags: 
- Failed
- Why
- technology
- Karbonn Mobile India
- Smartphones
---

 [![](https://lh3.googleusercontent.com/-NR6AT7a6QD0/YqokS_7aqoI/AAAAAAAAL3c/y9hfSFfcTPcKLXMB-HkJIxCkyONo9L1hwCNcBGAsYHQ/s1600/1655317574114833-0.png)](https://lh3.googleusercontent.com/-NR6AT7a6QD0/YqokS_7aqoI/AAAAAAAAL3c/y9hfSFfcTPcKLXMB-HkJIxCkyONo9L1hwCNcBGAsYHQ/s1600/1655317574114833-0.png) 

  

In india, back in 2000s there are very few companies that manufacture keypad phones thus foriegn mobile companies like Nokia and samsung used to release thier quality keypad mobiles that are very expensive but still indian people used to buy them as there are better then landline phones and very convenient to use.

  

 [![](https://lh3.googleusercontent.com/-vSSUh5UOVlI/Yqqc_UkU52I/AAAAAAAAL34/iBs63ynzb6ImD6GaJzW5Wo5b9Wtu88BQACNcBGAsYHQ/s1600/1655348471377139-0.png)](https://lh3.googleusercontent.com/-vSSUh5UOVlI/Yqqc_UkU52I/AAAAAAAAL34/iBs63ynzb6ImD6GaJzW5Wo5b9Wtu88BQACNcBGAsYHQ/s1600/1655348471377139-0.png) 

  

However, there are many companies in india which has potential to manufacture keypad phones but for whatever reason they didn't and then India's most popular and biggest company reliance industries founder Dhirubai Ambani who is India's richest man at that time though to make keypad mobiles in india itself at very low price with good quality possible so that everyone can access them.

  

 [![](https://lh3.googleusercontent.com/-HmP1BBbD17U/Yqqc9pHxfLI/AAAAAAAAL30/1EWoBxHQhe4tg3ox4BgtfCpdrSRfKQqzACNcBGAsYHQ/s1600/1655348466412089-1.png)](https://lh3.googleusercontent.com/-HmP1BBbD17U/Yqqc9pHxfLI/AAAAAAAAL30/1EWoBxHQhe4tg3ox4BgtfCpdrSRfKQqzACNcBGAsYHQ/s1600/1655348466412089-1.png) 

  

People in India especially in rural areas used to think that keypad mobiles are very expensive and not easy to use as at that time most people don't even know about sim cards even though there are some sim card network providers like BSNL and this scenario was completely changed with the entry of reliance keypad mobiles.

 [![](https://lh3.googleusercontent.com/-DWMrejZ13Nk/Yqqc8oLo0kI/AAAAAAAAL3w/e5vzq7zLC7cZa6OQ2dFT6FSNwfe3unRdACNcBGAsYHQ/s1600/1655348441793940-2.png)](https://lh3.googleusercontent.com/-DWMrejZ13Nk/Yqqc8oLo0kI/AAAAAAAAL3w/e5vzq7zLC7cZa6OQ2dFT6FSNwfe3unRdACNcBGAsYHQ/s1600/1655348441793940-2.png) 

  

Reliance always mesmerized indian people with it's revolutionary products that comes with good quality at best price so people eventually started buying reliance mobiles over others but the era of keypad mobiles put to an end with the release of multi-touch smartphones from year 2007 that're better then any keypad mobiles with powerful hardware and advanced software but for some reasons reliance didn't make smartphones until year 2015 with Reliance LYF.

  

 [![](https://lh3.googleusercontent.com/-8kWn3Ia6RNU/Yqqc2Se3R0I/AAAAAAAAL3s/5p4gV-3-MUQ5zG23J6ykbB9TstiCsR6bgCNcBGAsYHQ/s1600/1655348437318268-3.png)](https://lh3.googleusercontent.com/-8kWn3Ia6RNU/Yqqc2Se3R0I/AAAAAAAAL3s/5p4gV-3-MUQ5zG23J6ykbB9TstiCsR6bgCNcBGAsYHQ/s1600/1655348437318268-3.png) 

  

Even though, smartphones started to shake market from year 2007 yet they're expensive thus not everyone can afford them especially in india and then in year 2014 xiaomi a chinese mobile company released it's budget smartphone at very low price that has many features that're better then any budget smartphones at that time since then numerous chinese budget smartphones released in india.

  

Reliance LYF smartphones failed and there are many indian companies in the list like Micromax, Lava, iBall, Videocon, Karbonn which failed to make smartphone that are worthy enough to beat foreign and chinese smartphones companies and each indian mobile companies has thier own decisions and faults that leaded them to failure.

  

The problem with indian smartphones companies is as in india we don't have proper infrastructure to develop full smartphones so they order and Import smartphones or mobile parts from china then assemble or add thier logo on them to sell in india with made in india tagline which is completely fine but they can't run thier business with patriotism for long when thier smartphones are not fully made in india and not competitive to chinese smartphones.

  

In case of Karbonn, a indian mobile company founded in year 2009 by Sudhir Hasija and Pardeep Jain which used to manufacture keypad mobiles but later on in year 2009 in month of July launched it's first Android powered smartphone named Karbonn A1 with 2.8 inch touch screen display and 1,100 battery Mah that got pretty sufficient sells.

  

But, the bad days for Karbonn smartphones started in year 2014 as said earlier when chinese smartphones entered in india with it's budget smartphones that are not just superior to Karbonn and other Indian mobile companies companies but also for foriegn companies like Nokia and Samsung, Motorola, Sony etc in various matters.

  

In year 2012, Karbonn said it will invest Rs 445 crore in brand promotion and product development for next two years and they gradually done numerous advertisements and strategies over the years like for ex : they have tie ups with most india mobile networks like Airtel, idea, Vodafone and Jio etc and also sponsored IPL - indian premier league in year 2012.

  

But, the rise of Karbonn smartphones fall down especially because of their high price smartphones with less features that are not even comparable to china budget smartphones so day by day smartphones sells of Karbonn smartphones got reduced to such extent now a days in india most Millennials and Gen-Z don't know about Karbonn mobiles. 

  

Karbonn smartphones are not even secondary choice in india as still Karbonn not manufacturing smartphones which has potential to beat chinese smartphones in every edge like Interms of hardware and software etc yet there are some people who buy Karbonn mobiles mainly in retail market who don't know how to pick best budget smartphones or want to support Karbonn mobiles for patriotic reasons.

  

Karbonn just like any other indian mobile company has major focus on retail market where they can sells products while online market is dominated by china and foriegn smartphones even on retail market china smartphones like oppo and vivo put strong influence due to that Karbonn struggling to sell it's products in retail market as well.

  

 [![](https://lh3.googleusercontent.com/-dm8LJWAvvBY/Yqqc1Q1GHxI/AAAAAAAAL3o/nJvepXnRF60Zh6RyS0SchtQroHrep8ACACNcBGAsYHQ/s1600/1655348432738737-4.png)](https://lh3.googleusercontent.com/-dm8LJWAvvBY/Yqqc1Q1GHxI/AAAAAAAAL3o/nJvepXnRF60Zh6RyS0SchtQroHrep8ACACNcBGAsYHQ/s1600/1655348432738737-4.png) 

  

Microsoft, announced Karbonn as hardware partner for Windows Phone in February 2015 but that didn't went well as Microsoft Windows Phone struggled to beat Google's Android OS smartphones market share due to that both Karbonn and Microsoft didn't succeed to establish big presense in mobile market.

  

 [![](https://lh3.googleusercontent.com/-FGarxJ_SDg8/Yqqc0IxmxiI/AAAAAAAAL3k/FIQIuh9FkW8ZypRfQYWrU3cvj4SDVXb4QCNcBGAsYHQ/s1600/1655348420286834-5.png)](https://lh3.googleusercontent.com/-FGarxJ_SDg8/Yqqc0IxmxiI/AAAAAAAAL3k/FIQIuh9FkW8ZypRfQYWrU3cvj4SDVXb4QCNcBGAsYHQ/s1600/1655348420286834-5.png) 

  

We seen many indian smartphones failed to beat chinese smartphones but do you know there are some chinese mobile companies who failed to continue in mobile market like for instance Gionee a chinese mobile giant went bankrupt and closed all its operations world wide that was acquired by Karbonn in 2019 and announced it as sub brand of Karbonn.

  

The fate of Karbonn really didn't change much even though it has Gionee as sub brand but fortunately Karbonn released some worthy smartphones from past few years like Gionee Max Pro and Karbonn P10 that has features like china budget smartphones but still most people didn't choose Karbonn as they know they are better alternatives to them.

  

There are numerous reasons why Karbonn smartphones failed out of them the main one is lack of promotions Karbonn is not doing enough advertising on television channels and online streaming platforms even not sponsoring big events in india or global like IPL or world cup etc due to that Karbonn unable to reach and create hype or psychological impression on people to make them buy thier smartphones.

  

It's time for Karbonn and other mobile companies to restructure it's strategies and make innovations like Apple to reach people around world I mean you have to create a smartphone like iPhone else give features like china Android smartphones if you can't do neither of them then no one will buy your smartphones as of now most indian mobile companies surviving in this 

era because of thier big profit margins that won't last long so before you become Gionee open your eyes and make paths to beat china and foriegn smartphones.

  

Finally, this is why Karbonn Mobile India failed to beat chinese smartphones, are you an existing user of Karbonn Mobiles, if so do say your experience and mention why do you think Karbonn smartphones failed in india in our comment section below, see ya :)