---
title: 'How To Make Apps In Android ?'
date: 2020-01-21T22:42:00.001+05:30
draft: false
url: /2020/01/how-to-make-apps-in-android.html
tags: 
- Java
- IDE
- Coding
- Android Studio
- Javascript
- Android
---

**

[  
![](https://lh3.googleusercontent.com/-e7o8NudZ3iY/Xi1ougIkU9I/AAAAAAAAA5U/CXV_YWSoVnkP8oWldUQ7jJO428MG-lnQACLcBGAsYHQ/s1600/20191231_134255-41-01-37.jpeg)](https://lh3.googleusercontent.com/-e7o8NudZ3iY/Xi1ougIkU9I/AAAAAAAAA5U/CXV_YWSoVnkP8oWldUQ7jJO428MG-lnQACLcBGAsYHQ/s1600/20191231_134255-41-01-37.jpeg)

**

**

How To Make Apps In Android !**

  

Do you ever wondered to create apps in android and that to in advance level being getting an ide for android is a hard task as it require to do the things that a powerful android studio able to.

  

Android come long alot of new things been seen in years and features and power of the devices increasing day by day.

  

If we go back to a decade ago and wanna develop apps in android then it's a big **NO** but today we got alot of new things and updates.

  

That can make this hard task simple and easy so lf you want to develop apps in android then follow our steps mentioned below.

  

App development requires coding to make apps you need to have knowledge in java or javascript.

  

Java and JavaScript are the main two languages being used for app development and being most popular coding languages interms of android and technology as it is not a interpreted language.

  

If you wanna develop apps in pc its easy as it support android studio official support from Google.

  

But google has not given any availability or resources that can make app developing

possible like in android studio.

  

Android studio being a powerful software and resource needed thing that can only handle by a good mediocre pc.

  

To test and debug app in core !

  

But android power is not sufficient to get android studio.

  

However, there is some apps that have most features of android studio in mobile version.

  

If you wanna develop or test apps in android then follow below simple instructions !

  

**Follow Our Instructions Below #**

  

**1**. Go to PlayStore 

  

**2**. Search Keyword - AIDE 

  

**3**. Install It And Open And Start Coding.

  

**AIDE Support Coding Languages - Java****  C****++**

  

This App Features Most Features That Available In Android Studio With Syntax Error Marking.

  

Now, if you don't want to code in java but you are a javascript oriented than also you can develop apps in android.

  

**JavaScript - App Development In Android**

  

•**1** Go To PlayStore

  

•**2** Search For DroidScript 

  

•**3** Install And Open 

  

Now you can develop javascript apps in your phone apps support's phone, tablet, chromebook.

  

**Extra :-**

  

If you are not a coder or you insist to learn only want a app that done your job.

  

App Development Without Coding

  

•1 Go To PlayStore

  

•2 Search For SketchWare

  

•3 Install And Open It

  

Instead of Having Compiler Or Any Coding Sketware Uses Block Programming similar to mit scratch.

  

Now you can use above ways to develop or build apps in your android.

  

Keep Supporting : TechTracker.In