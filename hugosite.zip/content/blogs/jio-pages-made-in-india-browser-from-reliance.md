---
title: 'Jio pages - made in India browser from reliance.'
date: 2020-10-22T07:46:00.000+05:30
draft: false
url: /2020/10/jio-pages-made-in-india-browser-from.html
tags: 
- browser
- Apps
- Jio
- India
- pages
- Relaince
---

 [![](https://lh3.googleusercontent.com/-LJi-UJgkpuY/X5Drf2aYN2I/AAAAAAAAB34/mPteVmyY-qk35NP-Om4p5H_pvgBE0C93QCLcBGAsYHQ/s1600/1603332988271326-0.png)](https://lh3.googleusercontent.com/-LJi-UJgkpuY/X5Drf2aYN2I/AAAAAAAAB34/mPteVmyY-qk35NP-Om4p5H_pvgBE0C93QCLcBGAsYHQ/s1600/1603332988271326-0.png) 

  

Aatma nirbhar bharat working very well, the self reliance not only on products but digital to.. the indian government banned many chinese apps due to privacy & data breach issues.

  

India have lack of world class apps to become self reliant India should be self reliant in all the factors in digital technology either apps or any software etc.

  

To tackle this issue, pm modi launched Aatma nirbhar bharat scheme that help Indian devs & promote them, many developers got profited today developers started using made in India titles to get popularity & audience.

  

Recent ban of tiktok made indian developers to make alternative to app then after few months of time indian developers successfully made couple of tiktok alternatives that millions of users already started using them.

  

In this matter, browser is the most essential tool in any digital interface that plays key role in any software you use android or ios, that tracks your data and the better the browser the better the security  & privacy.

  

So today there is no world class browser like google chrome from well known google from india there is definate neccessity and oppurtunity and reliance utilised it.

  

Relaince a indian conglomerate company recently launched Jio pages browser so that you can rely on it for your browsing needs with security and privacy as the data servers and company offices located in India itself.

  

It is more likely, the app will get alot of updates and refined experience already as relaince put all the effort to give seamless experience with thier products always.

  

To be particular, reliance making wonders with thier new apps either Jio Saavn or Jio switch the apps made by relaince are top notch and are a great competitor to popular apps in category.

  

 [![](https://lh3.googleusercontent.com/-uq41bGRb39s/X5Dre1lXsqI/AAAAAAAAB30/jlWHzAOMKqUSq3sW9hmn1xRGjCzSYGB0ACLcBGAsYHQ/s1600/1603332983286549-1.png)](https://lh3.googleusercontent.com/-uq41bGRb39s/X5Dre1lXsqI/AAAAAAAAB30/jlWHzAOMKqUSq3sW9hmn1xRGjCzSYGB0ACLcBGAsYHQ/s1600/1603332983286549-1.png) 

  

  

\- **Jio pages by reliance**

  

Jio pages was made on chromium blink engine which provides enhanced browsing migration, faster engine migration, faster page loads, faster media streaming, emoji domain support & encrypted connection.

  

 [![](https://lh3.googleusercontent.com/-HF3L-PwvJj0/X5DrdvtdadI/AAAAAAAAB3w/F0hTZzCND1U4GyEW9qdwBFzzmL50xm38QCLcBGAsYHQ/s1600/1603332978801328-2.png)](https://lh3.googleusercontent.com/-HF3L-PwvJj0/X5DrdvtdadI/AAAAAAAAB3w/F0hTZzCND1U4GyEW9qdwBFzzmL50xm38QCLcBGAsYHQ/s1600/1603332978801328-2.png) 

  

  

Jio pages offered by Jio platforms limited released on **10 Dec 2018** with latest version **2.0** updated on **21 Oct 2020** with **4.0** rating and **10m**\+ downloads in size of **53.48** mb

  

 [![](https://lh3.googleusercontent.com/-LzIReJHzoc8/X5Drcim9bZI/AAAAAAAAB3s/-4w-O3AjiCIURJsHs-W9LrIc2wkyl05UwCLcBGAsYHQ/s1600/1603332972817543-3.png)](https://lh3.googleusercontent.com/-LzIReJHzoc8/X5Drcim9bZI/AAAAAAAAB3s/-4w-O3AjiCIURJsHs-W9LrIc2wkyl05UwCLcBGAsYHQ/s1600/1603332972817543-3.png) 

  

  

**What's new ✨**

  

 **•**  Personalized home screen

 **•**  Customizable Quick links

 **•**  Informative Cards

 **•**  Advance Download Manager

  

 [![](https://lh3.googleusercontent.com/-FSX-Y1Fh-4Q/X5DrbFY0CmI/AAAAAAAAB3o/LhXTc6lh3DUn4DXuoJUEy4xbFBpuhfNqgCLcBGAsYHQ/s1600/1603332967304838-4.png)](https://lh3.googleusercontent.com/-FSX-Y1Fh-4Q/X5DrbFY0CmI/AAAAAAAAB3o/LhXTc6lh3DUn4DXuoJUEy4xbFBpuhfNqgCLcBGAsYHQ/s1600/1603332967304838-4.png) 

  

  

**\- Jio pages key features !**

  

**•** Customise quick links

  

**•** Informative cards

  

**•** Dark mode

  

**•** Available in 8 languages 

  

**Hindi, Gujarati, Marathi, Tamil, Telugu, Malayalam, Kannada and Bengali.**  

  

**•** Access popular regional sites across categories & add them to your home screen

  

**•** News feeds in regional language: Stay updated with local, national and international events.

  

**•** secure incognito mode

  

**•** uninterrupted browsing

  

**•** QR code scanner

  

**•** Ad - blocker

  

**•** Desktop view 

  

**•** landscape view

  

For more details : [here](https://play.google.com/store/apps/details?id=com.jio.web)

  

**Finally**, the digital spike of reliance increasing day by day with new investments from google & many company's will lead reliance to become #1 in terms of efficiency & financial, the digital line is just in the sector it will bloom in future, in case of Jio pages the browser seems very cool we have not tried yet do mention your thoughts in our comment section below, see ya :-)