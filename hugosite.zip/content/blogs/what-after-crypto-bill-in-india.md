---
title: 'What after crypto bill in india?'
date: 2021-12-04T14:29:00.001+05:30
draft: false
url: /2021/12/what-after-crypto-bill-in-india.html
tags: 
- Crypto Bill
- India Crypto Exchanges
- India
- CryptoCurrency
- Matic
---

 [![](https://lh3.googleusercontent.com/-squOyfJiZBM/Yast793hCVI/AAAAAAAAHsk/6QRyiTPfTTAbYBNp6qBnGJC25VBbyX-KACNcBGAsYHQ/s1600/1638608358706496-0.png)](https://lh3.googleusercontent.com/-squOyfJiZBM/Yast793hCVI/AAAAAAAAHsk/6QRyiTPfTTAbYBNp6qBnGJC25VBbyX-KACNcBGAsYHQ/s1600/1638608358706496-0.png) 

  

India government as expected didn't ban crypto currencies as it will decrease india's economy and also people who own crypto currencies from india can get huge losses which they may not able to recover so the india government instead of ban on crypto currency they opted to regulate them with the bill named crypto bill, this bill going to regulate all crypto currencies in india and classify them as assets instead of money and this bill also states crypto currencies will no longer work as money lender.

  

This is one of the most intelligent crypto regulation bill that has to passed in both lower and upper house to get into action which ensure india safety and security as once bill is passed crypto currencies will no longer work as money lender that will put an end to illegal activities done using crypto currencies, and crypto currencies will be regulated by sebi : the securities and exchange board of india who also regulate india's stock market.

  

Crypto bill also states people should not store thier currencies in personal wallets, they should only use indian exchanges to store thier assets and people who voilate this conditions will be penalised with 2 yr prison or fine of 10 to 20 cr, so from now on crypto currencies will be legal but this conditions has be to followed strictly yet the question comes is this crypto bill will become standard? or can something may change in future.

  

If india government consider crypto tokens as assets instead of money then there will be high probability that they're not going to ban them including that once crypto bill is passed india's crypto market will be under regulation of sebi so crypto currencies will be in safe zone as they are like digital gold so it will work like this you can store all the crypto assets in indian crypto exchanges & that crypto assets may transferrable within indian crypto exchanges but in order to use all your crypto assets as money you may have to sell them and get central bank crypto currency - cbcc or fiat currency.

  

In this way, centralised crypto currency by government will be used as legal lender & irregularities that used to happen because of de-centralised crypto currencies will be ended in one go, and crypto bill also states personal wallets will be banned so that no  more black money can be holded, even if you have crypto currency in your personal wallet then you may have to transfer them to legal indian crypto exchange to get fiat currency or central bank crypto currency so that all assets value, transactions will be under view of government so that taxes will be applied properly.

  

However, the only issue here is personal wallets transfers can be banned in india but still over the globe personal wallets crypto transfers will be valid what if the Indian citizens who hold crypto currency on thier personal wallet transfer them or receive them from other countries crypto wallets to exchange items, cash or works done? which is threat to national security and economy.

  

The latest crypto bill regulate crypto currencies using indian crypto exchanges  but there are still some loop holes which government has to close else the same old story continues, as of now this are some details roaming around regarding crypto bill, but more information will be uncovered once bill is made public.

  

Even though, india crypto exchanges will be regulated by government body sebi but another issue here is crypto currencies are very different from stocks, as most of the crypto currency creators not available to reach and not known to world even the most popular crypto currency bitcoin founder is not known to world except the name satoshi nakamoto which can some how lead to irregularities.

  

In such scenario, sebi can't follow old model of regulating exchanges which they used in stock market exchanges, so they  may have to adopt the current structure of crypto exchange platforms else they have to only list such crypto currencies which are registered with sebi, sebi can put some checks and balances, the owners of crypto currencies have to reach themselves to sebi and follow the rules and requirements of sebi in order to list thier crypto currency on indian exchanges like companies in stock market, 

  

If crypto bill follows above mentioned

method then bitcoin will no longer listed on indian crypto exchanges & other crypto currencies whose founder is not known to public can't be registered with sebi thus that currencies will be not available in indian crypto market, so there is high possibility that indian government follow this procedure and allow only that crypto currencies which are registered with sebi.

  

If government implement above method then due to the effect of Aatma Nirbhaar Bharat and make in India program and slogans, sebi and government may put ban and not allow foriegn crypto currencies on indian crypto exchanges, so that all indian crypto currencies will be benefited and the price of indian crypto currencies will be sky rocked for sure and indian economy will increase itself.

  

The most popular Indian crypto currency Matic which is now polygon can become the first indian crypto currency to be listed on indian crypto exchanges followed by other Indian crypto currencies, but yeah before we draw assumptions let's wait and see what they said exactly in crypto bill which will be publicly available soon.

  

Now, you may think the ban of global crypto currencies can have negative impact on india economy and people, you may even start to fear as you owned global crypto currencies, wait I clarify you this the ban of global currencies in india will not have any negative impact on economy or people, if you are indian citizen you can exchange your global crypto currencies with local crypto currencies of india, it's very simple procedure that will also boost indian crypto currencies price in global level, so be relaxed even government or indian crypto exchanges may even open a platform to exchange global crypto currencies with local crypto currencies.

  

I hope indian government crypto bill will follow the above mentioned method so that indian people will not get losses at the same time indian crypto currencies founders and companies will grow together that will boost economy, also this method provide nation security and privacy at best levels as all the data either personal or transaction will be in indian servers with government & indian crypto exchanges, 

  

I hope government will follow the above mentioned mentioned in crypto bill that I assumed, if not they may atleast revise it to make like this, else I hope crypto bill is better then my assumptions, do you like this method? If yes do you think crypto bill and government follow above mentioned procedure? If yes Kindly say your opinion on this method that assumed, & also say your views on crypto bill in our comment section below, see ya :)