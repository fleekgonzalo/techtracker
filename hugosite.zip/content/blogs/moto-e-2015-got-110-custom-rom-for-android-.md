---
title: 'Moto E 2015 got 11.0 Custom ROM for Android !'
date: 2020-10-26T17:17:00.000+05:30
draft: false
url: /2020/10/moto-e-2015-got-110-custom-rom-for.html
tags: 
- 11.0
- Moto E 2015
- Rom
- Android
---

**Motorola** launched many amazing budget phones Moto E 2015 is one of them, it was launched long back but it's still alive due to it's third party deve - loper support.

  

Moto E 2015 released in 2015 with budget specs at that time it comes in 5.0 lollipop and official software updates stopped at 6.0.1 marshmallow.

  

**However**, due to its immense third party developer support from XDA it's still got latest android OS every time.

  

It is amazing to see a budget phone from 2015 support the latest android os that today we can see.

  

The XDA developer named **althafly** made custom ROM called mallu os which is based on lineage os with hardware specific code which will slowly get open sourced, mallu os 2.0  released 11.0 for Moto E 2015 which support all the features of 11.0 android OS.

  

But, In mallu os 2.0 rom most of the features working but some features are broken which are going to be fixed soon as this is beta version 2.0 for Moto E 2015 code named : surnia.

  

**What's working ✨**

*   Camera
*   WiFi
*   Battery LED
*   Bluetooth
*   Telephony (Calls and Data)
*   Audio (Record and Playback)
*   Video Playback
*   Sensors

**Broken ✨**

*   VoLTE
*   HW crypto
*   Video Recording
*   Maybe more

Go to this link  below to download mallu os 11.0 ROM for moto e 2015 ( surnia ) 

  

Download : [here](https://www.androidfilehost.com/?fid=8889791610682948886)

  

**Installation : ✨**

*   Reboot to recovery
*   Format /system,/data and /cache
*   Install MalluOS zip package

> **Important notes:**
> 
> *   **\* Required \*** firmware version must be based on MM builds.
> *   GApps can only be flashed on clean installs.
> *   Formatting data (all user data is wiped, including internal storage) is a must if Stockrom was previously installed and device was encrypted.

  

Telegram : [malluos](http://t.me/malluoss)

  

**Contributors ✨**

[althafvly](https://forum.xda-developers.com/member.php?u=5881712), chil360 

  
**Source Code:** [https://github.com/MalluOS](https://github.com/MalluOS)  
  
**ROM OS Version:** Android 10

  
**Based On:** Lineage  
  
**Version Information ✨**

**  
Status:** Beta  
  
**Created** 2020-09-30

  
**Last Updated** 2020-10-01  

  

**Finally**, Moto E 2015 got 11.0 which is a bliss for the users, it was amazing to see Moto E 2015 got the latest version of android, thanks to the devs who working very hard to get them working,. do you have moto e 2015 have your tried do mention in our comment section below, see ya :-)