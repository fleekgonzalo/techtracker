---
title: 'How to auto post latest articles of your blog on Telegram channel.'
date: 2022-01-29T22:31:00.001+05:30
draft: false
url: /2022/01/how-to-auto-post-latest-articles-of.html
tags: 
- Blog
- How
- technology
- Telegram
- RSS
---

 [![](https://lh3.googleusercontent.com/-XD1xqWqv13E/YfVy61dBmmI/AAAAAAAAI5k/psw1rMLtR0czxtzpw48y5O9KmvAhfDv1QCNcBGAsYHQ/s1600/1643475686405598-0.png)](https://lh3.googleusercontent.com/-XD1xqWqv13E/YfVy61dBmmI/AAAAAAAAI5k/psw1rMLtR0czxtzpw48y5O9KmvAhfDv1QCNcBGAsYHQ/s1600/1643475686405598-0.png) 

  

Do you run a blog? then probably you may have to post your latest articles on social media platforms right? to reach audience and increase engagement, If you manage many social media platforms then you can use IFTTT - if this then that platform which you can setup and auto post latest articles on your social media platforms like twitter, facebook, telegram etc at once.

  

how ever, if you just want to auto send your blog latest articles links on Telegram channel or group then you can simply use a telegram bot named [@rss2tg\_bot](http://t.me/rss2tg_bot)[](http://@rss2tg_bot) where you just have to submit your blog RSS feed url, once you setup [@rss2tg\_bot](http://t.me/%20rss2tg_bot) on your telegram channel or group, it will detect new articles on your blog using RSS feed and automatically send latest article links on your telegram channel or groups.

  

Usually, most bloggers know about RSS feed but it's ok if you don't know RSS full form is really simple syndication, once you create RSS feed for your blog, you will get a RSS feed url where you can access your latest articles in simple format, we have several platforms available out there on internet to generate RSS feeds for blogs but most bloggers use feedburner. 

  

Feedburner is a old and reliable platform to generate RSS feeds for blog, that's why we will show you how you can create RSS feed url using feedburner, you can also use any other RSS feed url generator platform, but just make sure it's working and url end with .XML format, once done just copy the rss feed url to submit on [@rss2tg\_bot](http://t.me/%20rss2tg_bot)

  

[@rss2tg\_bot](http://t.me/%20rss2tg_bot) is a fast RSS/Atom bot for notifications with 10 minute update interval, using this bot you can send your blog articles to channels or groups in numerous formats like disable or enable webpage preview, show the source name, URL only, only title as hyperlink, full article ( experimental ) etc, so do you like it? are you interested in [@rss2tg\_bot](http://t.me/rss2tg_bot)? If yes let's know little more info about it before we explore more.

  

• [@rss2tg\_bot](http://t.me/@rss2tg_bot) **official support •**

  

\- [Telegram community](https://t.me/rss2tg_community)

  

• **How to generate RSS feed url for your blog using feedburner •**

 **[![](https://lh3.googleusercontent.com/-oOLU5xkKD8E/YfVy5koB-uI/AAAAAAAAI5g/HEVOlN20vqUFYfbG65qT-De2MQ7CYILjQCNcBGAsYHQ/s1600/1643475681974690-1.png)](https://lh3.googleusercontent.com/-oOLU5xkKD8E/YfVy5koB-uI/AAAAAAAAI5g/HEVOlN20vqUFYfbG65qT-De2MQ7CYILjQCNcBGAsYHQ/s1600/1643475681974690-1.png)** 

\- Go to [feedburner.google.com](http://feedburner.google.com), enter your blog url in blank field then tap on **Next >>**

 **[![](https://lh3.googleusercontent.com/-laZu6-2RKIs/YfVy4oqtiDI/AAAAAAAAI5c/QOM0Rtx9-og_DAltRJqE0YYx2nJrQKy8wCNcBGAsYHQ/s1600/1643475677587197-2.png)](https://lh3.googleusercontent.com/-laZu6-2RKIs/YfVy4oqtiDI/AAAAAAAAI5c/QOM0Rtx9-og_DAltRJqE0YYx2nJrQKy8wCNcBGAsYHQ/s1600/1643475677587197-2.png)** 

\- choose your rss feed url format then tap on **Next >>**

 [![](https://lh3.googleusercontent.com/-6ZsNPKslGJc/YfVy3RMOayI/AAAAAAAAI5Y/IJh-H-z4ECsra0Lqrjc14MUIUQoOmNtdwCNcBGAsYHQ/s1600/1643475673370270-3.png)](https://lh3.googleusercontent.com/-6ZsNPKslGJc/YfVy3RMOayI/AAAAAAAAI5Y/IJh-H-z4ECsra0Lqrjc14MUIUQoOmNtdwCNcBGAsYHQ/s1600/1643475673370270-3.png) 

  

\- Enter your feed title, edit your feed address and tap on **Next >>**

 **[![](https://lh3.googleusercontent.com/-je1c3MHgLLM/YfVy2YSnXTI/AAAAAAAAI5U/1-Zs_zrEXuk9SLdC-s5zGVZBFGedWVG0gCNcBGAsYHQ/s1600/1643475668713029-4.png)](https://lh3.googleusercontent.com/-je1c3MHgLLM/YfVy2YSnXTI/AAAAAAAAI5U/1-Zs_zrEXuk9SLdC-s5zGVZBFGedWVG0gCNcBGAsYHQ/s1600/1643475668713029-4.png)** 

\- Copy your RSS feed url and tap on Skip directly to feed management.

  

That's it, you successfully generated RSS feed url for your blog for free.

  

**• How to auto send latest blog articles to your Telegram channel or group using  **

**[@rss2tg\_bot](http://t.me/rss2tg_bot)** **for free •**

 **[![](https://lh3.googleusercontent.com/-huw69efUjRg/YfVy1I2B6LI/AAAAAAAAI5Q/S_621393I9ggYcE5uyfHjTsjbH8hi0ytwCNcBGAsYHQ/s1600/1643475664307511-5.png)](https://lh3.googleusercontent.com/-huw69efUjRg/YfVy1I2B6LI/AAAAAAAAI5Q/S_621393I9ggYcE5uyfHjTsjbH8hi0ytwCNcBGAsYHQ/s1600/1643475664307511-5.png)** 

\- Open your telegram channel or group then tap on its name.

  

 [![](https://lh3.googleusercontent.com/-rPae6fqzb_8/YfVy0BrDg1I/AAAAAAAAI5M/zuCm6pk8IgE--PH1VQuYUS7sE7-SH4XGwCNcBGAsYHQ/s1600/1643475660025383-6.png)](https://lh3.googleusercontent.com/-rPae6fqzb_8/YfVy0BrDg1I/AAAAAAAAI5M/zuCm6pk8IgE--PH1VQuYUS7sE7-SH4XGwCNcBGAsYHQ/s1600/1643475660025383-6.png) 

  

\- Tap on **Administrators**

 **[![](https://lh3.googleusercontent.com/-OmbdTSF3q7U/YfVyzCR-5sI/AAAAAAAAI5I/qU9T39_eCEgIpEDLKmOk0BT9qHDRVy_aQCNcBGAsYHQ/s1600/1643475655632253-7.png)](https://lh3.googleusercontent.com/-OmbdTSF3q7U/YfVyzCR-5sI/AAAAAAAAI5I/qU9T39_eCEgIpEDLKmOk0BT9qHDRVy_aQCNcBGAsYHQ/s1600/1643475655632253-7.png)** 

\- Tap on **Add Admin**

 **[![](https://lh3.googleusercontent.com/-z_xdaDytmMA/YfVyx5XzPuI/AAAAAAAAI5E/tZm9jhrFQYU6fSMyMb_7E7kHubzLqdqjgCNcBGAsYHQ/s1600/1643475651230429-8.png)](https://lh3.googleusercontent.com/-z_xdaDytmMA/YfVyx5XzPuI/AAAAAAAAI5E/tZm9jhrFQYU6fSMyMb_7E7kHubzLqdqjgCNcBGAsYHQ/s1600/1643475651230429-8.png)** 

\- Enter @rss2tg\_bot and search then tap on @rss2tg\_bot available in list.

  

 [![](https://lh3.googleusercontent.com/-F9ZgCBoBTxU/YfVywmqFOpI/AAAAAAAAI5A/G6rwFvCs67waoB_ZKTiVyJJMe-6Uzt5dwCNcBGAsYHQ/s1600/1643475646415343-9.png)](https://lh3.googleusercontent.com/-F9ZgCBoBTxU/YfVywmqFOpI/AAAAAAAAI5A/G6rwFvCs67waoB_ZKTiVyJJMe-6Uzt5dwCNcBGAsYHQ/s1600/1643475646415343-9.png) 

  

\- Enable Post Messages, this is enough then tap on **✓**

 **[![](https://lh3.googleusercontent.com/-xbvK3DQfsW8/YfVyvgd1fHI/AAAAAAAAI48/PZ2Iyb1woWUHZeDK5EPY3WzUxJIvcZokgCNcBGAsYHQ/s1600/1643475642422209-10.png)](https://lh3.googleusercontent.com/-xbvK3DQfsW8/YfVyvgd1fHI/AAAAAAAAI48/PZ2Iyb1woWUHZeDK5EPY3WzUxJIvcZokgCNcBGAsYHQ/s1600/1643475642422209-10.png)** 

\- Go to [@rss2tg\_bot](http://t.me/rss2tg_bot) and tap on **START**

 **[![](https://lh3.googleusercontent.com/-_Eks9KVXyzY/YfVyusr_uUI/AAAAAAAAI44/KaN6QJG1YfkQNAod6MO7tUDWoU8rx4Q8wCNcBGAsYHQ/s1600/1643475637915273-11.png)](https://lh3.googleusercontent.com/-_Eks9KVXyzY/YfVyusr_uUI/AAAAAAAAI44/KaN6QJG1YfkQNAod6MO7tUDWoU8rx4Q8wCNcBGAsYHQ/s1600/1643475637915273-11.png)** 

\- Send your RSS feed url that you earlier copied from feedburner, it will added.

  

 [![](https://lh3.googleusercontent.com/-gMEj-zE8LPA/YfVytv3ZgdI/AAAAAAAAI40/jlTyGlnYkfEbFp9fqdHp09UGvLEZ3lRKACNcBGAsYHQ/s1600/1643475633474887-12.png)](https://lh3.googleusercontent.com/-gMEj-zE8LPA/YfVytv3ZgdI/AAAAAAAAI40/jlTyGlnYkfEbFp9fqdHp09UGvLEZ3lRKACNcBGAsYHQ/s1600/1643475633474887-12.png) 

  

\- Enter and send /settings commands, here you can tweak article post format.

  

\- Once done go back to your telegram group or channel.

  

 [![](https://lh3.googleusercontent.com/-eLyiuzWQ4cc/YfVysTIB9zI/AAAAAAAAI4w/YtBq3-2-5-A9wr6DlE3oIC4fdtd0UOdgQCNcBGAsYHQ/s1600/1643475628826055-13.png)](https://lh3.googleusercontent.com/-eLyiuzWQ4cc/YfVysTIB9zI/AAAAAAAAI4w/YtBq3-2-5-A9wr6DlE3oIC4fdtd0UOdgQCNcBGAsYHQ/s1600/1643475628826055-13.png) 

  

\- Enter @rss2tg\_bot your blog RSS feed url and send it on telegram channel or group.

  

Bingo, now onwards whenever you publish a new article on your blog, @rss2tg\_bot will detect and post article on your Telegram group or channel.

  

 [![](https://lh3.googleusercontent.com/-0kEL4OlrP5A/YfVyrEvfBeI/AAAAAAAAI4s/FNmMv2KJj7IIn-SUMLOd-afhd5cbU83uACNcBGAsYHQ/s1600/1643475622182540-14.png)](https://lh3.googleusercontent.com/-0kEL4OlrP5A/YfVyrEvfBeI/AAAAAAAAI4s/FNmMv2KJj7IIn-SUMLOd-afhd5cbU83uACNcBGAsYHQ/s1600/1643475622182540-14.png) 

  

Atlast, this are just highlighted features of @rss2tg\_bot there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want simple and easy bot to send updated blog articles on Telegram group or channel then @rss2tg\_bot will work flawless.

  

Overall, @rss2tg\_bot has well designed intuitive clean and simple interface that ensures user friendly experience thanks to Telegram API as developers were only able to provide features through buttons, yet in any project there is always space for improvement so let's wait and see will @rsst2g\_bot app get any major UI changes in future to make it even more better, as of now @rss2tg\_bot is nice.

  

Moreover, it is worth to mention @rss2tg\_bot is one of the very few telegram bots which will auto post articles using RSS feed url, and @rss2tg\_bot is very easy to use when compared with other RSS bots, even complete newbie can easily setup @rss2tg, including that @rss2tg\_bot is free, yes indeed if you're are searching for such platform then @rss2tg\_bot has potential to become your new favorite choice.

  

Finally, this is @rss2tg\_bot, a telegram bot to auto post blog articles on your Telegram group or channel, are you an existing user of @rss2tg\_bot? If yes do say your experience and mention which feature you like the most on @rss2tg\_bot in our comment section below, see ya :)