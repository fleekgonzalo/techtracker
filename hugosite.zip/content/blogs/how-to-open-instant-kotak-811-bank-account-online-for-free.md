---
title: 'How To Open Instant Kotak 811 Bank Account Online For Free ?'
date: 2020-08-21T21:16:00.001+05:30
draft: false
url: /2020/08/how-to-open-instant-kotak-811-bank.html
---

  

[![](https://lh3.googleusercontent.com/-16uQVPBNcCs/X0B9dzCnH8I/AAAAAAAABeo/MVcLHcOPSI4xUL0efl3zI6iGAgoKz8-MQCLcBGAsYHQ/s1600/20200821_214751-02.jpeg)](https://lh3.googleusercontent.com/-16uQVPBNcCs/X0B9dzCnH8I/AAAAAAAABeo/MVcLHcOPSI4xUL0efl3zI6iGAgoKz8-MQCLcBGAsYHQ/s1600/20200821_214751-02.jpeg)

  

Do you ever wanted to create bank account for free without visiting any bank then kotak 811 for you it is very easy process that you can open instant bank account in few minutes.

  

There are only few options available to open instant bank account through your aadhar card and pan card.

  

You must have aadhar card number linked with your mobile number and pan card for sign up.

  

**Prerequisites** : 

  

\- Aadhaar number 

  

\- Pan Card 

  

[How to get epan card for free in 1 minute](http://www.techtracker.in/2020/08/how-to-get-instant-pan-card-in-1-minute.html)  

  

• **1** Open you Playstore and search for kotak 811 

  

• **2** install kotak 811 app 

  

• **3** Now you can see **get** **started** option click on the that now choose browser to open the url.

  

  

[![](https://lh3.googleusercontent.com/-K3c7uS4ekGM/Xz_sPOkay5I/AAAAAAAABcs/2CRjrccI_6MLOzmEBHZo8JksSigel49JQCLcBGAsYHQ/s1600/Screenshot_20200821-204903_Via.png)](https://lh3.googleusercontent.com/-K3c7uS4ekGM/Xz_sPOkay5I/AAAAAAAABcs/2CRjrccI_6MLOzmEBHZo8JksSigel49JQCLcBGAsYHQ/s1600/Screenshot_20200821-204903_Via.png)

  

  

• **4** Now enter you name and mobile numbers as per your Aadhaar card in the above and check both of the boxes.  

  

  

  

[![](https://lh3.googleusercontent.com/-HK2n5BUAuPI/Xz_sQBj12TI/AAAAAAAABc0/noOR9GlUdZQa1Lyd0T_G7KP-YOtHataTACLcBGAsYHQ/s1600/Screenshot_20200821_205702.jpg)](https://lh3.googleusercontent.com/-HK2n5BUAuPI/Xz_sQBj12TI/AAAAAAAABc0/noOR9GlUdZQa1Lyd0T_G7KP-YOtHataTACLcBGAsYHQ/s1600/Screenshot_20200821_205702.jpg)

  

• **5** Now you need to enter the otp from your mobile number which is linked with aadhaar card.

  

• **6** once you enter the otp then tap on next and now enter you aadhaar card number and pan card no. 

  

• Name as per aadhaar

  

• Aaadhaar Number

  

• Pan Card No.

  

• Date of Birth

  

• Email 

  

• Father Name As Per Aadhaar

  

  

• **7** Once you enter all the above details and press next you will get this info like below.

  

[![](https://lh3.googleusercontent.com/-0Mx5m-itKxw/Xz_sQ3K2GNI/AAAAAAAABc8/e8bU35k1qIIcMqoAN-qJGz3THRYSdBZKACLcBGAsYHQ/s1600/Screenshot_20200821_210231.jpg)](https://lh3.googleusercontent.com/-0Mx5m-itKxw/Xz_sQ3K2GNI/AAAAAAAABc8/e8bU35k1qIIcMqoAN-qJGz3THRYSdBZKACLcBGAsYHQ/s1600/Screenshot_20200821_210231.jpg)

• **8** You can now press on continue and enter the otp that you received.

  

• **9** hoila. Your new kotak mahindra bank has opened.

  

Your limted account have restricted features to get unlimited access you have to complete full kyc.

  

Instead of opening the url from app use the website kotak 811 to complete kyc through video conference.

  

Due to covid 19 pandemic kyc agents availability is delayed. 

  

Kotak 811 features - 

  

\- Zero balance and no maintenance of balance

  

\- Earn upto 4% interest

  

\- Virtual Visa Classic Debit Card

  

\- You can even apply for checkque book no other bank offer you.

  

\- first 5 atm transactions free for month.

  

\- annual charges for debit catd is 150rs + gst and inclusive charges.

For more details you can visit thier website.