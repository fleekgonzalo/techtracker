---
title: 'How To Create A Website For Free'
date: 2019-12-27T14:58:00.001+05:30
draft: false
url: /2019/12/how-to-create-website-for-free.html
tags: 
- technology
- free
- easy
- Domain
---

  

[![](https://1.bp.blogspot.com/-r1iLiwEimLw/XgsFJRe2tzI/AAAAAAAAAaM/arskwjd0QccDmj9gnWMJKPj9TiehBbLLACLcBGAsYHQ/s320/IMG_20191231_135119_230.jpg)](https://1.bp.blogspot.com/-r1iLiwEimLw/XgsFJRe2tzI/AAAAAAAAAaM/arskwjd0QccDmj9gnWMJKPj9TiehBbLLACLcBGAsYHQ/s1600/IMG_20191231_135119_230.jpg)

  
Hi, Do you wanna create a website for free or in cheap well you are at right place we are giving you an easy method to create a website either for hobby or professional just follow our instructions and hurray you'll get your website live in few minutes,  

  

Creating a website have many uses either for you product or hobby to write versatile subjects.

  

It is a good idea to share your knowledge through world there are alot of ways to create website while this method is easy and hassle free and it do provide.  
  

You can easily post your artciles on go also to earn through it via adsense approval also can be done...so worries.

  

Let's get started.  
  

[![](https://1.bp.blogspot.com/-EnZz2VDwbzI/XgsFjsrTsfI/AAAAAAAAAaU/F5p_RnnfH2cTdKevWjGQzQty3RyanldzQCLcBGAsYHQ/s320/IMG_20191231_135315_867.jpg)](https://1.bp.blogspot.com/-EnZz2VDwbzI/XgsFjsrTsfI/AAAAAAAAAaU/F5p_RnnfH2cTdKevWjGQzQty3RyanldzQCLcBGAsYHQ/s1600/IMG_20191231_135315_867.jpg)

  

Ok. First go to you browser and search for **www.freenom.com** andsign up with your email address or facebook once you sign up go to your email inbox and verify the email address through the link that freenom send you.

  

  

[![](https://1.bp.blogspot.com/-aT7rykH2QlU/XgsF6qSbZnI/AAAAAAAAAag/M6LrX_uo0gcbG_Hj-loSSLqKBRRnfLw_wCEwYBhgL/s320/IMG_20191231_135446_181.jpg)](https://1.bp.blogspot.com/-aT7rykH2QlU/XgsF6qSbZnI/AAAAAAAAAag/M6LrX_uo0gcbG_Hj-loSSLqKBRRnfLw_wCEwYBhgL/s1600/IMG_20191231_135446_181.jpg)

  

Once you sign up you will see search box and enter your desired domain name and check availability if your domain is available you can add that to cart and then proceed and now enter your details and buy now  
  

[![](https://1.bp.blogspot.com/-M27axrJ_ml0/XgsGVJ6LYbI/AAAAAAAAAao/uJ-6NVwK120ilVZjlyq3vYIHUQQaKaLMwCLcBGAsYHQ/s320/IMG_20191231_135621_492.jpg)](https://1.bp.blogspot.com/-M27axrJ_ml0/XgsGVJ6LYbI/AAAAAAAAAao/uJ-6NVwK120ilVZjlyq3vYIHUQQaKaLMwCLcBGAsYHQ/s1600/IMG_20191231_135621_492.jpg)

  

Now your domained will be added now navigate to manage settings and you get control panel - client area go to your domain name servers you

will be getting four or either two name servers let it be.

  

Next, now open another tab in your browser and search for awardspace.com or freehosting.com these website give you free hosting to store yiur website and main highlight is that this website provides you unlimited disk space and give you all main features that paid hosting websites give you.

  

Ok. Now go to either any free hosting website that you like and sign up after sign up verify your email and then go to your cpanel that you will be recieving in your inbox  
  

[![](https://1.bp.blogspot.com/-lK0v6AopCrE/XgsHBlXU85I/AAAAAAAAAaw/_-GGW0D3RaoqJh7ibUaCFPRnmYo05DGVgCLcBGAsYHQ/s320/IMG_20191231_135923_436.jpg)](https://1.bp.blogspot.com/-lK0v6AopCrE/XgsHBlXU85I/AAAAAAAAAaw/_-GGW0D3RaoqJh7ibUaCFPRnmYo05DGVgCLcBGAsYHQ/s1600/IMG_20191231_135923_436.jpg)

  

Now in your cpanel you will getting many features for many uses now you navigate to add domain option and enter your domain name that your purchased in freenom website and tap continud or ok you will be getting four name or two name servers from hosting website.  
  

[![](https://1.bp.blogspot.com/-3f8vvXZBkNE/XgsHZ1UFuqI/AAAAAAAAAa8/M6R7uq4OIakoM2HPlVBsZniKLHK5DbbKwCLcBGAsYHQ/s320/IMG_20191231_140100_714.jpg)](https://1.bp.blogspot.com/-3f8vvXZBkNE/XgsHZ1UFuqI/AAAAAAAAAa8/M6R7uq4OIakoM2HPlVBsZniKLHK5DbbKwCLcBGAsYHQ/s1600/IMG_20191231_140100_714.jpg)

  

[![](https://1.bp.blogspot.com/-SSRwDR3TIuI/XgsHb_beHbI/AAAAAAAAAbA/FIotFSnaaIkcVhkkCyaCR9d9RVTCs_Z4QCLcBGAsYHQ/s320/IMG_20191231_140103_114.jpg)](https://1.bp.blogspot.com/-SSRwDR3TIuI/XgsHb_beHbI/AAAAAAAAAbA/FIotFSnaaIkcVhkkCyaCR9d9RVTCs_Z4QCLcBGAsYHQ/s1600/IMG_20191231_140103_114.jpg)

  

[![](https://1.bp.blogspot.com/-SSRwDR3TIuI/XgsHb_beHbI/AAAAAAAAAbA/FIotFSnaaIkcVhkkCyaCR9d9RVTCs_Z4QCLcBGAsYHQ/s320/IMG_20191231_140103_114.jpg)](https://1.bp.blogspot.com/-SSRwDR3TIuI/XgsHb_beHbI/AAAAAAAAAbA/FIotFSnaaIkcVhkkCyaCR9d9RVTCs_Z4QCLcBGAsYHQ/s1600/IMG_20191231_140103_114.jpg)

  

Now copy the name servers that you got from hosting website and get back to freenom and name servers options in your cpanel remove existing name and add the new hosting name severs and update.

  

Now get back to hosting provide and press ok another time now you'll be getting your domain is successfully added and it can take upto 24hours to point name servers.

  

Now most probably it will be updated in 1hr, to check your name servers updated or not go to intodns.com and enter your domain name and press ok now you'll be getting current name servers of your. Site if it was updates than your site will be live.

  

Once completing everything above. Now you need to install a content management system - cms in your hosting you can do that in two ways manual installation and script installer while script installer is easy and for manual installation you have to open ftp of your host and adding the files required from your computer or any device.

  

Well. most website's now supports script installer

you just have go to cpanel of your hosting and tap on script installer then choose whatever content management system you like as the most popular and beginners wordpress let's choose this Joomla and other are for advanced users for free users wordpress give professional quality and features now add your email , username, the directory that you want to install your site etc most probably install in home directory rather than sub directory if you need to do your wish. 

  

After adding the details and start installing it does take upto 3 to 5min of time not more than that unless there is slow issue or bug once the in installation has be done you'll be getting the email of your wordpress installation successful message in your email that you provided in wordpress installation time .

  

Now go to the address that got from the wordpres installation email and enter your details and login in. 

  

Hurray now you can enjoy every wordpress feature , themes and live a professional site without any single dollor or penny.

  

Do you have any doubts ? Comment down below.

  

Keep supporting : TechTracker.in