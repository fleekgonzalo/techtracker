---
title: 'LG G8x Think Q - The ultimate dual screen flagship mobile  !'
date: 2020-10-23T17:34:00.001+05:30
draft: false
url: /2020/10/lg-g8x-think-q-ultimate-dual-screen.html
tags: 
- technology
- dualscreen
- thinkQ
- flagship
- LG
---

 [![](https://lh3.googleusercontent.com/-xkCq5ZMm1u8/X5LGwX04NEI/AAAAAAAAB5w/zYMBerczVQwuYod31yViVFnKcSODggzBACLcBGAsYHQ/s1600/1603454653339535-0.png)](https://lh3.googleusercontent.com/-xkCq5ZMm1u8/X5LGwX04NEI/AAAAAAAAB5w/zYMBerczVQwuYod31yViVFnKcSODggzBACLcBGAsYHQ/s1600/1603454653339535-0.png) 

  

Dual screen smartphones are new not yet popular getting them cost alot of money many company's trying to give dual screen mobile at lower cost and then LG succeed not only they launched dual screen mobiles but also launched in very good price with 855 snapdragon chipset.

  

You heard right, snapdragon 855 in 58k price range with dual screen that's amazing.

  

 [![](https://lh3.googleusercontent.com/-CuLSO2rklFU/X5LGvZwAShI/AAAAAAAAB5s/07RPn-9MxR8yCNsnqK8vy3XMBfw0q2MpQCLcBGAsYHQ/s1600/1603454648568889-1.png)](https://lh3.googleusercontent.com/-CuLSO2rklFU/X5LGvZwAShI/AAAAAAAAB5s/07RPn-9MxR8yCNsnqK8vy3XMBfw0q2MpQCLcBGAsYHQ/s1600/1603454648568889-1.png) 

  

  

**\- LG G8x Think Q Key Features !**

  

*   Detachable 2 Screen Design
*   Dual 6.4” OLED FHD Displays
*   Work, Play & Multi-Task Like Never Before
*   32 MP Front Camera
*   136˚ Ultra-Wide and 78˚ Standard Rear Cameras
*   Balanced Stereo Sound
*   Longer-Lasting\* 4,000 mAh Battery

  

**Recently**, in flipkart big billion days the price gone down from **54,990** to **21,990** it's a awesome deal congrats to those who buyed this mobile in the flipkart big billion days.

  

The only two drawbacks of LG G8x thinkQ was battery and software out of box will be pie 9.0 you can update to 10.0 with august security patch the question will it get 11.0 it depends on LG.

  

For more details : [here](https://www.lg.com/us/mobile-phones/g8x-thinq-dual-screen)

  

Flipkart : here

  

Amazon : here

  

7am - Midnight CST  

  

Consumer support : **(800) 243-0000** 

  

8am - 6pm CST  

  

Commerical support : **(800) 243-3026**

  

**Finally**, LG G8x think Q really done great job but there are alot of best options available in this price range if you got in flipkart sale then you  are lucky, do dual screen amazed you, if so do say your thoughts in our comment section below, see ya :-)