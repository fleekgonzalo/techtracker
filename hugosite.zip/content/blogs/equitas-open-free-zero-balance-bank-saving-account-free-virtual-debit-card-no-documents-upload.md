---
title: 'Equitas - Open Free Zero Balance Bank Saving Account | Free Virtual Debit Card | No Documents Upload | '
date: 2021-06-27T00:48:00.002+05:30
draft: false
url: /2021/06/equitas-open-free-zero-balance-bank.html
tags: 
- technology
- free
- Savings Account
- Equitas
- Virtual Debit Card
---

 [![Equitas - Open FREE Bank Saving Account | Free Virtual Debit Card | No Documents Upload |](https://lh3.googleusercontent.com/--JJMZtS2DjQ/YNd9gUsGscI/AAAAAAAAFRg/rkCumVBfvXUz57aqJvYCaz0kxuQsMuCWQCLcBGAsYHQ/s1600/1624735099185357-0.png "Equitas - Open FREE Bank Saving Account | Free Virtual Debit Card | No Documents Upload |")](https://lh3.googleusercontent.com/--JJMZtS2DjQ/YNd9gUsGscI/AAAAAAAAFRg/rkCumVBfvXUz57aqJvYCaz0kxuQsMuCWQCLcBGAsYHQ/s1600/1624735099185357-0.png) 

  

We have numerous banks available while most banks need you to complete KYC in thier bank itself to open any kind of bank account but due to today's digital era and technology and mainly due to limitations of COVID19 pandemic most banks either government owned or private using EKYC to verify person identity in india that takes less then a minute if your phone number is connected to your Aaadhar Card.

  

Most people prefer to open bank account online there are millions of students want to open savings account for thier personal and shopping needs due to huge craze for zero balance savings account most banks already started online bank open facility in thier own apps and websites in india.

  

If you are planning to open bank account online then it is very important to choose bank wisely else you may face issue later because there are some banks which will provide zero balance savings account for name sake online but asks you to deposit minimum account balance & most banks ask you to upload documents which alot of people don't like including that alot of asks you do video kyc and restrict alot of features & don't provide you virtual debit card which is another drawback.

  

In this scenario, we have a workaround we found a bank named equitas which is now providing zero balance savings account to everyone who linked thier mobile number with Aadhaar card to do E-KYC by verifying OTP you don't need to visit bank or upload documents everything will be done online smoothly on thier official website for free Including that you'll get free virtual debit card, so are you in equitas? If yes let's know little more info before we start registering!

  

• **Equitas Bank** **Official Support** •

  

\- [Facebook](https://www.facebook.com/EquitasBank)

\- [Twitter](https://twitter.com/EquitasIR?lang=en)

\- [Linkedin](https://www.linkedin.com/company/equitas-micro-finance-india-pvt-ltd)

\- [YouTube](https://www.youtube.com/channel/UCQVXnzmkbs7d0ZAJVhl3pUg)

  

**Email :** [corporate@equitas.in](mailto:corporate@equitas.in)

**Website :** [equitas.in](http://equitas.in)

  

**\- App Info -** [Google Play](https://play.google.com/store/apps/details?id=com.iexceed.equitas.consumer) -

  

• **How to download Equitas Mobile Banking App •**

  

It is very easy to download Equitas Mobile

Banking app from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=com.iexceed.equitas.consumer)

  

• **How to open zero balance bank savings account on Equitas small finance bank in few minutes online for free •**

 **[![](https://lh3.googleusercontent.com/-IQgbgK89M9c/YNd9etVJGZI/AAAAAAAAFRc/jNRrl_vj3Wo0hgwQ8C2TmrF7PQgCGhnuwCLcBGAsYHQ/s1600/1624735091952253-1.png)](https://lh3.googleusercontent.com/-IQgbgK89M9c/YNd9etVJGZI/AAAAAAAAFRc/jNRrl_vj3Wo0hgwQ8C2TmrF7PQgCGhnuwCLcBGAsYHQ/s1600/1624735091952253-1.png)** 

**\-** Go to [inet.equitasbank.com/selfe/](https://bit.ly/3tKKUQF) and tap on **LET'S GET STARTED.**

 **[![](https://lh3.googleusercontent.com/-is4Y0j49ahA/YNd9cywyKNI/AAAAAAAAFRY/YsGwEm9nlDkYTAAv7OubGuHwVTC9A3eMACLcBGAsYHQ/s1600/1624735085975034-2.png)](https://lh3.googleusercontent.com/-is4Y0j49ahA/YNd9cywyKNI/AAAAAAAAFRY/YsGwEm9nlDkYTAAv7OubGuHwVTC9A3eMACLcBGAsYHQ/s1600/1624735085975034-2.png)** 

**\-** Select State, Location, Branch And  Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-c08a17Pgkzg/YNd9bZc8ioI/AAAAAAAAFRU/oyqjt8vDWX4iwAQ6SZGU1s035MJFggTygCLcBGAsYHQ/s1600/1624735080138911-3.png)](https://lh3.googleusercontent.com/-c08a17Pgkzg/YNd9bZc8ioI/AAAAAAAAFRU/oyqjt8vDWX4iwAQ6SZGU1s035MJFggTygCLcBGAsYHQ/s1600/1624735080138911-3.png)** 

**\-** Enter Name, Mobile Number ( Registered with Aadhaar ) Tap on **Next**

 **[![](https://lh3.googleusercontent.com/-2nYVOrkYXm4/YNd9ZzkZSyI/AAAAAAAAFRQ/3vWn45YlTuULWwIAKLExqpOrc3DmNs7pwCLcBGAsYHQ/s1600/1624735072107577-4.png)](https://lh3.googleusercontent.com/-2nYVOrkYXm4/YNd9ZzkZSyI/AAAAAAAAFRQ/3vWn45YlTuULWwIAKLExqpOrc3DmNs7pwCLcBGAsYHQ/s1600/1624735072107577-4.png)** 

\- Enter Aadhaar Numer, PAN, Tap on **NEXT**

  

 [![](https://lh3.googleusercontent.com/--gscK4IHzbA/YNd9Xy44vWI/AAAAAAAAFRM/0Ax0xRZQ-H8YVZq2x7Y_SwhFac57La6YwCLcBGAsYHQ/s1600/1624735064860068-5.png)](https://lh3.googleusercontent.com/--gscK4IHzbA/YNd9Xy44vWI/AAAAAAAAFRM/0Ax0xRZQ-H8YVZq2x7Y_SwhFac57La6YwCLcBGAsYHQ/s1600/1624735064860068-5.png) 

  

\- Tap on **GENERATE AADHAAR OTP**

  

 [![](https://lh3.googleusercontent.com/-tvZgWqrTQ7M/YNd9WGJTuOI/AAAAAAAAFRI/uBJcHHRuTwYPy3FdJiI41cSjSxgs34JVgCLcBGAsYHQ/s1600/1624735059088463-6.png)](https://lh3.googleusercontent.com/-tvZgWqrTQ7M/YNd9WGJTuOI/AAAAAAAAFRI/uBJcHHRuTwYPy3FdJiI41cSjSxgs34JVgCLcBGAsYHQ/s1600/1624735059088463-6.png) 

  

\- Enter OTP ( From Aadhaar ) Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-Ca6JIUqFX5I/YNd9UoORh3I/AAAAAAAAFRE/zxCCF83sy7EzUVfDe4yAb5HeU4pNQL1QgCLcBGAsYHQ/s1600/1624735051486292-7.png)](https://lh3.googleusercontent.com/-Ca6JIUqFX5I/YNd9UoORh3I/AAAAAAAAFRE/zxCCF83sy7EzUVfDe4yAb5HeU4pNQL1QgCLcBGAsYHQ/s1600/1624735051486292-7.png)** 

\- Check your details, Tap on **VERIFY PAN**

 **[![](https://lh3.googleusercontent.com/-lNKBRi30_14/YNd9SiVb_LI/AAAAAAAAFQ8/Rajd5-P6PQ0Wui1AmyWkWJFwjzr1ANLCwCLcBGAsYHQ/s1600/1624735045179836-8.png)](https://lh3.googleusercontent.com/-lNKBRi30_14/YNd9SiVb_LI/AAAAAAAAFQ8/Rajd5-P6PQ0Wui1AmyWkWJFwjzr1ANLCwCLcBGAsYHQ/s1600/1624735045179836-8.png)** 

**\-** Select Home Branch, Check ✓ I agree to FATCA Declaration Then Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-1IixGBwdWJ8/YNd9RMZxSsI/AAAAAAAAFQ4/7KyCp8Ylnlcve10xKUVbFTIZHXo1yjQQwCLcBGAsYHQ/s1600/1624735038059947-9.png)](https://lh3.googleusercontent.com/-1IixGBwdWJ8/YNd9RMZxSsI/AAAAAAAAFQ4/7KyCp8Ylnlcve10xKUVbFTIZHXo1yjQQwCLcBGAsYHQ/s1600/1624735038059947-9.png)** 

**\-** Enter Mother's Name Father's Name, And Email Then Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-NoVVIzE00Ac/YNd9PcvPaqI/AAAAAAAAFQ0/YupBdkanH4otSLun6Ew0USrmw0dvYHbrACLcBGAsYHQ/s1600/1624735029278347-10.png)](https://lh3.googleusercontent.com/-NoVVIzE00Ac/YNd9PcvPaqI/AAAAAAAAFQ0/YupBdkanH4otSLun6Ew0USrmw0dvYHbrACLcBGAsYHQ/s1600/1624735029278347-10.png)** 

**\-** Enter OTP received to your Email then Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-BwCERekpGcw/YNd9NGXuevI/AAAAAAAAFQw/_0y7DGSKq0IY3wHvIJinGuoECe0c2KWwwCLcBGAsYHQ/s1600/1624735021490272-11.png)](https://lh3.googleusercontent.com/-BwCERekpGcw/YNd9NGXuevI/AAAAAAAAFQw/_0y7DGSKq0IY3wHvIJinGuoECe0c2KWwwCLcBGAsYHQ/s1600/1624735021490272-11.png)** 

**\-** Select Marital Status, Occupation, Yearly Income, Tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-JyXvldV2VtA/YNd9LNvpO2I/AAAAAAAAFQs/ekfJ5n7lSbsAXA6P-kBkNzMlP7W4btp2gCLcBGAsYHQ/s1600/1624735015530091-12.png)](https://lh3.googleusercontent.com/-JyXvldV2VtA/YNd9LNvpO2I/AAAAAAAAFQs/ekfJ5n7lSbsAXA6P-kBkNzMlP7W4btp2gCLcBGAsYHQ/s1600/1624735015530091-12.png)** 

**•** You can NOMINEE DETAILS Now or later, check ✓ I agree to Declaration then tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-1OoYmfdqudM/YNd9Jmr8eFI/AAAAAAAAFQo/BlSDzBTDJiMxJ9gMGWv7W6USnbzOBULNACLcBGAsYHQ/s1600/1624735010050950-13.png)](https://lh3.googleusercontent.com/-1OoYmfdqudM/YNd9Jmr8eFI/AAAAAAAAFQo/BlSDzBTDJiMxJ9gMGWv7W6USnbzOBULNACLcBGAsYHQ/s1600/1624735010050950-13.png)** 

\- Enter Desired name on card, Then Tap on **NEXT** to proceed further.

  

 [![](https://lh3.googleusercontent.com/-gUBairugq1Q/YNd9IYpnddI/AAAAAAAAFQk/ajB5g9ik7doRROKCVcmnx93XWikan6mvgCLcBGAsYHQ/s1600/1624735004859917-14.png)](https://lh3.googleusercontent.com/-gUBairugq1Q/YNd9IYpnddI/AAAAAAAAFQk/ajB5g9ik7doRROKCVcmnx93XWikan6mvgCLcBGAsYHQ/s1600/1624735004859917-14.png) 

  

**\-** Enter OTP received to your mobile number again and tap on **NEXT**

 **[![](https://lh3.googleusercontent.com/-XHyJnIIZTig/YNd9HGi92JI/AAAAAAAAFQg/Wz76ltYZsDoEQnZn9MosiOfmUaz8L7HpgCLcBGAsYHQ/s1600/1624734996213182-15.png)](https://lh3.googleusercontent.com/-XHyJnIIZTig/YNd9HGi92JI/AAAAAAAAFQg/Wz76ltYZsDoEQnZn9MosiOfmUaz8L7HpgCLcBGAsYHQ/s1600/1624734996213182-15.png)** 

**Hurray**, You got free zero balance savings account & virtual debit card from Equitas small finance bank Ltd for free online.

  

• **Equitas Mobile Banking Key features with UI / UX Overview •**

 **[![](https://lh3.googleusercontent.com/-a7YOeK9czpA/YNd9E707mjI/AAAAAAAAFQc/SGyv45hv4Q8m-bEOrxe2NZW5gnM-eimDwCLcBGAsYHQ/s1600/1624734989757637-16.png)](https://lh3.googleusercontent.com/-a7YOeK9czpA/YNd9E707mjI/AAAAAAAAFQc/SGyv45hv4Q8m-bEOrxe2NZW5gnM-eimDwCLcBGAsYHQ/s1600/1624734989757637-16.png)** 

 [![](https://lh3.googleusercontent.com/-vkJXnMyCaxI/YNd9DDu9WPI/AAAAAAAAFQY/038l6rOF_kgmVcAd213SVd0NljUMZ5tVwCLcBGAsYHQ/s1600/1624734984242037-17.png)](https://lh3.googleusercontent.com/-vkJXnMyCaxI/YNd9DDu9WPI/AAAAAAAAFQY/038l6rOF_kgmVcAd213SVd0NljUMZ5tVwCLcBGAsYHQ/s1600/1624734984242037-17.png) 

  

 [![](https://lh3.googleusercontent.com/-zXvQaW0be1o/YNd9Bz5ZLiI/AAAAAAAAFQU/8XCzrHyzNRkmd68z7yuyC76xj57-wpZ9QCLcBGAsYHQ/s1600/1624734979336634-18.png)](https://lh3.googleusercontent.com/-zXvQaW0be1o/YNd9Bz5ZLiI/AAAAAAAAFQU/8XCzrHyzNRkmd68z7yuyC76xj57-wpZ9QCLcBGAsYHQ/s1600/1624734979336634-18.png) 

  

 [![](https://lh3.googleusercontent.com/-POty2ldvz4M/YNd9Au54XpI/AAAAAAAAFQQ/PfiMwicd254NKMxejY_o1JypYhUtA58YwCLcBGAsYHQ/s1600/1624734973621646-19.png)](https://lh3.googleusercontent.com/-POty2ldvz4M/YNd9Au54XpI/AAAAAAAAFQQ/PfiMwicd254NKMxejY_o1JypYhUtA58YwCLcBGAsYHQ/s1600/1624734973621646-19.png) 

  

 [![](https://lh3.googleusercontent.com/-wSSY7KQYGpQ/YNd8_PqtZVI/AAAAAAAAFQM/6AhXPKRcq4gA3YHlhPsOw_hYQdBTDitAwCLcBGAsYHQ/s1600/1624734967256991-20.png)](https://lh3.googleusercontent.com/-wSSY7KQYGpQ/YNd8_PqtZVI/AAAAAAAAFQM/6AhXPKRcq4gA3YHlhPsOw_hYQdBTDitAwCLcBGAsYHQ/s1600/1624734967256991-20.png) 

  

 [![](https://lh3.googleusercontent.com/-Z-7JJ35WhQw/YNd89oZeuMI/AAAAAAAAFQI/QLSf1aIGwvYky2bUS3pXGAx4NvcfNazRQCLcBGAsYHQ/s1600/1624734957843903-21.png)](https://lh3.googleusercontent.com/-Z-7JJ35WhQw/YNd89oZeuMI/AAAAAAAAFQI/QLSf1aIGwvYky2bUS3pXGAx4NvcfNazRQCLcBGAsYHQ/s1600/1624734957843903-21.png) 

  

  

Atlast, Equitas simplified the process of opening bank account online making it more convenient, simple and easy, due to that now you can now easily open bank account online in minutes for free without uploading documents or doing video KYC etc, you just need Aaadhar , Aadhar linked mobile number, pan card, that's it.

  

Overall, Equitas online bank opening portal is simple, clean, quick fast, user friendly while the mobile banking app also seems same with good top rating reviews, it is very easy to use due to its simple user interface that gives clean user experience packed with the required features but we have to wait and see will Equitas get any major UI improvements in future to make it even more better, as of now Equitas bank opening portal and mobile banking app feels fine that give likable user interface and user experience which you may like to use for sure.  

  

Moreover, it is worth to mention Equitas is one of the very few banks that provide you bank account without doing physical KYC, video KYC, uploading documents etc, due to its easy bank open process it has more advantage to gain users over other banks which is major prospect Yes, Indeed so, if you are searching for bank to open bank account that is very easy to open and use with many features then we suggest you to prefer and choose Equitas it is an excellent choice that has potential to become your new favorite.

  

Finally**,** This is Equitas, one of the best and easy to open zero balance bank saving account in India online for free without uploading documents so, do you like it? If yes are you existing customer of Equitas bank , then do say your experience also mention why you like Equitas  in our comment section below, see ya :)