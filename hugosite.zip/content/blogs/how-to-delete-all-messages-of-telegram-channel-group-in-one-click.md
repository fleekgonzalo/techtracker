---
title: 'How to delete all messages of Telegram channel / group in one click.'
date: 2022-02-26T21:55:00.001+05:30
draft: false
url: /2022/02/how-to-delete-all-messages-of-telegram.html
tags: 
- How
- technology
- Telegram
- All messages
- Delete
---

 [![](https://lh3.googleusercontent.com/-GLUWU47tH9Y/YhpUiYCPJ6I/AAAAAAAAJWc/0N9u4Knhi2Ex8tWBmMODSh2Os5HojHaNgCNcBGAsYHQ/s1600/1645892742404864-0.png)](https://lh3.googleusercontent.com/-GLUWU47tH9Y/YhpUiYCPJ6I/AAAAAAAAJWc/0N9u4Knhi2Ex8tWBmMODSh2Os5HojHaNgCNcBGAsYHQ/s1600/1645892742404864-0.png) 

  

Telegram is a popular social messaging app which focuses on privacy and security of users with advanced features created by pavel durov and nikoi durov who also founded russia's social media network VKontakte which is considered as best and top alternative to Facebook.

  

Telegram progressed alot over the years, where you can create unlimited Telegram channels and group and have upto 2 lakh members, this is why people like to create channels / groups on telegram over other social messaging apps, including that you can send stickers, collect donations even manage telegram channel or group using bots etc to simplify your work due to this amazing features telegram become best destination for creators on internet.

  

Even though Telegram have numerous advanced features still it lacks one important feature, when you create a channel or group on Telegram and start sending messages on it then you have to delete those messages manually as there is no option available on telegram app to delele all messages of channel or group.

  

I'm not sure why telegram not added such simple feature required by most creators till now, however there is this un-official Telegram bot named Delall bot which you have to add on your Telegram channel or group as admin if you want to delete all messages in one click for free.

  

Note : Telegram won't take responsibility on un-official bots as they were created by third party developers using Telegram bot public API, so there is data theft risk even if un-official bot ensure you safety of your personal data still you can't trust it, so we are not responsible for any personal and financial losses occurred to you by using Dellall bot, we just shown for information and knowledge purposes, are you ready?

  

**• How to download Telegram** •

  

It is very easy to download Telegram from these platforms for free.

  

\- [Google Play](https://play.google.com/store/apps/details?id=org.telegram.messenger) / [App Store](https://apps.apple.com/us/app/telegram-messenger/id686449807)

  

**• How to delete all messages of Telegram channel / group in just one click •**

 **[![](https://lh3.googleusercontent.com/-3_DRTImVow0/YhpUhXUot-I/AAAAAAAAJWY/5Nz366iDopEFXPsbnUzwqGL32pL7jUJaACNcBGAsYHQ/s1600/1645892738089797-1.png)](https://lh3.googleusercontent.com/-3_DRTImVow0/YhpUhXUot-I/AAAAAAAAJWY/5Nz366iDopEFXPsbnUzwqGL32pL7jUJaACNcBGAsYHQ/s1600/1645892738089797-1.png)** 

\- Open your Telegram channel or group then tap on it's name.

  

 [![](https://lh3.googleusercontent.com/-OZnBz-zUlzE/YhpUgdL2l6I/AAAAAAAAJWU/N5A1d8D7W7Ib6asoFz0aieTWAOZg6JN4ACNcBGAsYHQ/s1600/1645892734463813-2.png)](https://lh3.googleusercontent.com/-OZnBz-zUlzE/YhpUgdL2l6I/AAAAAAAAJWU/N5A1d8D7W7Ib6asoFz0aieTWAOZg6JN4ACNcBGAsYHQ/s1600/1645892734463813-2.png) 

  

\- Tap on **Administrators**

 **[![](https://lh3.googleusercontent.com/-siJHw18wiNs/YhpUffldcLI/AAAAAAAAJWQ/l40jmaWm3bwBpaTZOi-LLHvZTPTF-nVfQCNcBGAsYHQ/s1600/1645892731027359-3.png)](https://lh3.googleusercontent.com/-siJHw18wiNs/YhpUffldcLI/AAAAAAAAJWQ/l40jmaWm3bwBpaTZOi-LLHvZTPTF-nVfQCNcBGAsYHQ/s1600/1645892731027359-3.png)** 

\- Tap on **Add Admin**

 **[![](https://lh3.googleusercontent.com/-GfUA1ggHfyY/YhpUegRSOOI/AAAAAAAAJWM/MJGFW-kZR9UaNFgxaGwyX-G2YEejy4gkQCNcBGAsYHQ/s1600/1645892727487141-4.png)](https://lh3.googleusercontent.com/-GfUA1ggHfyY/YhpUegRSOOI/AAAAAAAAJWM/MJGFW-kZR9UaNFgxaGwyX-G2YEejy4gkQCNcBGAsYHQ/s1600/1645892727487141-4.png)** 

\- Search Dellall bot and tap on that one which has access to messages.

  

 [![](https://lh3.googleusercontent.com/-8sXcYlgh6Xs/YhpUdzD71PI/AAAAAAAAJWI/nAOsN4xHszwZWTF6lv3SPRw5H8tUcUylgCNcBGAsYHQ/s1600/1645892723876801-5.png)](https://lh3.googleusercontent.com/-8sXcYlgh6Xs/YhpUdzD71PI/AAAAAAAAJWI/nAOsN4xHszwZWTF6lv3SPRw5H8tUcUylgCNcBGAsYHQ/s1600/1645892723876801-5.png) 

  

\- Just enable Delete messages of others Admin Right then tap on ✓

  

 [![](https://lh3.googleusercontent.com/-7CYtWx4Moss/YhpUc18udUI/AAAAAAAAJWE/bCSWfqyDG6MubpY_SacbuCxf_j3JcafiwCNcBGAsYHQ/s1600/1645892718799073-6.png)](https://lh3.googleusercontent.com/-7CYtWx4Moss/YhpUc18udUI/AAAAAAAAJWE/bCSWfqyDG6MubpY_SacbuCxf_j3JcafiwCNcBGAsYHQ/s1600/1645892718799073-6.png) 

  

\- Once bot added, open your telegram channel / group then simply send /delall command to delete all messages in one click, incase if you want to delete from specific message.

  

\- Long press on message and send /delfrom command.

  

Bingo, you successfully deleted all messages of your telegram channel / group in one click.

  

Atlast, this are just highlighted features of Delall bot there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, so if you want one of the best Telegram bot delete all messages of your Telegram channel or group then delall bot is best and worthy choice.

  

Overall, Dellall bot is very easy to use, as you just have to add it on your Telegram channel or group as admin then send just command to the delete all messages of telegram channel or group which gives user friendly experience and thanks to Telegram for clean user interface, but in any project there is always space available for improvement so let's wait and see will Dellall get any major changes in future to make it even better as of now it's nice.

  

Moreover, Delall is one of the very few un-official Telegram bots which can delete all messages of Telegram channel / group for free, created by Manuel15, yes indeed if you are searching for such telegram bot then Delall bot has potential to become your new favorite for sure.

  

Finally, this is Delall a un-official useful free Telegram bot to delete all messages of Telegram channel / group, are you an existing user of Delall bot? If yes do say your experience and mention why you like Delall bot in our comment section below, see ya :)