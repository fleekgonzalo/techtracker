---
title: 'The success, struggle and revival of Motorola smartphones.'
date: 2022-07-20T12:00:00.001+05:30
draft: false
url: /2022/07/the-success-struggle-and-revival-of.html
tags: 
- technology
- Success
- Motorola smartphones
- Revival
- Struggle
---

 [![](https://lh3.googleusercontent.com/-D1glMX1RKCc/Ythyf8EylvI/AAAAAAAAMlQ/hxPa7c7vgj4t4zbwADmEmSaNukwzYH48QCNcBGAsYHQ/s1600/1658352189822301-0.png)](https://lh3.googleusercontent.com/-D1glMX1RKCc/Ythyf8EylvI/AAAAAAAAMlQ/hxPa7c7vgj4t4zbwADmEmSaNukwzYH48QCNcBGAsYHQ/s1600/1658352189822301-0.png) 

  

  

Motorola Inc, is a American multi-national company founded by Paul Galvin on 25th September 1928 at first they used to make and sell wireless network equipment like radios, broadbands, cellular transmission base stations, set up boxes, digital video recorders, cable modems etc but later on in year 1973 they made world's first wire-less commercial handheld mobile named Motorola DynaTac 8000X that can make long distance calls without cords & lines in-replacement to Telephones.

  

 [![](https://lh3.googleusercontent.com/-ZxEly7jLfpY/YtoGuJfCvjI/AAAAAAAAMow/yxfKCKZU28cZQH1Aurvob3Nb1r1mxs2ywCNcBGAsYHQ/s1600/1658455732198994-0.png)](https://lh3.googleusercontent.com/-ZxEly7jLfpY/YtoGuJfCvjI/AAAAAAAAMow/yxfKCKZU28cZQH1Aurvob3Nb1r1mxs2ywCNcBGAsYHQ/s1600/1658455732198994-0.png) 

  

  

Motorola DynaTac 8000X is expensive as it's first wireless handheld mobile that can make voice calls to anyone in longer distances so it recieved high demand from people around the world especially in USA thus many companies to use this opportunity and supply started making thier own wireless mobiles like Motorola DynaTac 8000X with new technologies to upgrade features and increase potential of wireless handheld mobiles phones thanks to never ending competition among companies gradually we got wireless modern hand-held keypad mobiles phones from 20th century.

  

 [![](https://lh3.googleusercontent.com/-L_uK3wkJ5k4/YtoGtbsiEUI/AAAAAAAAMos/nqeIUfwahywPKD9Zgf5lSCWzBtgNtv4AwCNcBGAsYHQ/s1600/1658455728798007-1.png)](https://lh3.googleusercontent.com/-L_uK3wkJ5k4/YtoGtbsiEUI/AAAAAAAAMos/nqeIUfwahywPKD9Zgf5lSCWzBtgNtv4AwCNcBGAsYHQ/s1600/1658455728798007-1.png) 

  

Modern hand-held keypad mobile phones are small in size and costly but they have much better features and more comfortable to use then early mobile phones so as most people like to get new and better products then existing ones they eventually shifted to modern keypad mobile phones but the only drawback of modern keypad mobile phones is there are no match to PC aka personal computers.

  

 [![](https://lh3.googleusercontent.com/-6A5agYZxq-Q/YtoGsULrS8I/AAAAAAAAMoo/Jel_w-tdbLocn4KL3GZSYPTtXdNUcZmGACNcBGAsYHQ/s1600/1658455724868706-2.png)](https://lh3.googleusercontent.com/-6A5agYZxq-Q/YtoGsULrS8I/AAAAAAAAMoo/Jel_w-tdbLocn4KL3GZSYPTtXdNUcZmGACNcBGAsYHQ/s1600/1658455724868706-2.png) 

  

  

PC's with it's powerful hardware and software can do alot of works electronically using it's technologies and softwares but they are big and not pocket friendly you can't hold them easily and also lack sim card option thus you can't make mobile network calls instead you have to make Internet based calls while most people like to make sim card based mobile networks calls so they prefer modern hand-held keypad mobile phones.

  

 [![](https://lh3.googleusercontent.com/-yOapQ9IDLm4/YtoGrld4EVI/AAAAAAAAMok/v5J7UkkPxvMgO_SuVRhyNfCGv_HCqpGUACNcBGAsYHQ/s1600/1658455721071315-3.png)](https://lh3.googleusercontent.com/-yOapQ9IDLm4/YtoGrld4EVI/AAAAAAAAMok/v5J7UkkPxvMgO_SuVRhyNfCGv_HCqpGUACNcBGAsYHQ/s1600/1658455721071315-3.png) 

  

  

Anyhow, Motorola since it's first wireless handheld mobile phone in 1973 they keep on working to make and sell better wireless keypad mobiles phones to compete with other modern keypad mobile phones companies in that process over the years Motorola released numerous amazing modern keypad mobile phones till 2008 with Motorola ZN5.

  

 [![](https://lh3.googleusercontent.com/-eqxi_FTnPBs/YtoGqkscREI/AAAAAAAAMog/MGof_VEL024-gtqTc6ekS_mJz17sVUkEACNcBGAsYHQ/s1600/1658455717846467-4.png)](https://lh3.googleusercontent.com/-eqxi_FTnPBs/YtoGqkscREI/AAAAAAAAMog/MGof_VEL024-gtqTc6ekS_mJz17sVUkEACNcBGAsYHQ/s1600/1658455717846467-4.png) 

  

  

Most successful companies have set backs and losses at one point Motorola inc. is not an exception they lost about $4.3 billion from year 2007 to 2009 so Motorola inc. split into two companies Motorola Mobility and Motorola solutions since then they are working seperately.

  

 [![](https://lh3.googleusercontent.com/-U6w1hVcnvpI/YtoGpsS7LMI/AAAAAAAAMoc/JSnL8hDXUKYIr3mtOrflh1WaDWUhxq32wCNcBGAsYHQ/s1600/1658455712204883-5.png)](https://lh3.googleusercontent.com/-U6w1hVcnvpI/YtoGpsS7LMI/AAAAAAAAMoc/JSnL8hDXUKYIr3mtOrflh1WaDWUhxq32wCNcBGAsYHQ/s1600/1658455712204883-5.png) 

  

  

Motorola Mobility is focused on producing mobiles while Motorola Solutions is handling other Motorola products anyway Motorola mobility like any other mobile company put an end to modern keypad mobiles and started making thier own smartphones in year 2009 Motorola Mobility made smartphone named Motorola Droid to compete with Apple's iPhone and other smarphone companies.

  

 [![](https://lh3.googleusercontent.com/-eGXsNxdAXWk/YtoGoRMWvwI/AAAAAAAAMoU/MGuyabDOyJ0WaF908EqlOngNlR1sZ9alACNcBGAsYHQ/s1600/1658455708093223-6.png)](https://lh3.googleusercontent.com/-eGXsNxdAXWk/YtoGoRMWvwI/AAAAAAAAMoU/MGuyabDOyJ0WaF908EqlOngNlR1sZ9alACNcBGAsYHQ/s1600/1658455708093223-6.png) 

  

Apple inc. is founded by Steve Jobs and Steve Wozniak they first used to make bit expensive personal computers known as Macintosh aka i Mac debuted in August 1990s which are pretty successfull but later on Apple shareholders had some differences with Steve Jobs so they send him out in year 1985 but Steve Jobs kept 1 share to attend AGM's of Apple inc. 

  

 [![](https://lh3.googleusercontent.com/-QrfccUrv9pQ/YtoGnOPEhqI/AAAAAAAAMoQ/3V90s2QRCxM5UaFCsAnfoSvLO4hCM8efACNcBGAsYHQ/s1600/1658455704240317-7.png)](https://lh3.googleusercontent.com/-QrfccUrv9pQ/YtoGnOPEhqI/AAAAAAAAMoQ/3V90s2QRCxM5UaFCsAnfoSvLO4hCM8efACNcBGAsYHQ/s1600/1658455704240317-7.png) 

  

  

Steve Jobs after getting out of Apple inc. founded a new computer company named Next in year 1985 after that in year 1986 he started a animation production company named Pixar that made Toy Story which is 19th highest grossing franchise in the world since then Pixar made numerous animated films and become most profitable animation company while Apple inc. is struggling and going through losess with it's personal computers so to revive Apple inc. shareholders decided to get Steve Jobs back on team.

  

 [![](https://lh3.googleusercontent.com/-FaZls7x-cz0/YtoGmRVd7UI/AAAAAAAAMoM/OubCSpdTqcULG4PIklvLiV05Gbi4fFa7QCNcBGAsYHQ/s1600/1658455700398610-8.png)](https://lh3.googleusercontent.com/-FaZls7x-cz0/YtoGmRVd7UI/AAAAAAAAMoM/OubCSpdTqcULG4PIklvLiV05Gbi4fFa7QCNcBGAsYHQ/s1600/1658455700398610-8.png) 

  

  

The re-entry of Steve Jobs as advisor in year 1997 boosted Apple inc. operations and saved Apple inc. from complete down fall then in year 2005 Steve Jobs released world's first Apple iPod that can save and play thousands of music files in one tiny device with that you no more require portable media players and multipurpose mobile devices to enjoy music on the go.

  

 [![](https://lh3.googleusercontent.com/-A-HfuWgZ1JM/YtoGlYrvk3I/AAAAAAAAMoI/iTY4NmDkZwYFukCKIbTxpLNzXRd588LFQCNcBGAsYHQ/s1600/1658455696334179-9.png)](https://lh3.googleusercontent.com/-A-HfuWgZ1JM/YtoGlYrvk3I/AAAAAAAAMoI/iTY4NmDkZwYFukCKIbTxpLNzXRd588LFQCNcBGAsYHQ/s1600/1658455696334179-9.png) 

  

iPod is very successful product world wide that inspired many companies to make thier own custom iPods and then in year 2007 on January 9 Steve Jobs released iPhone a revolutionary multi touch technology mobile powered by a mobile operating system in sense software that has no name but Apple marketing said iPhone runs a version of i Mac desktop operating system OS X but from iPhone 2 in year 2008 Apple named it's operating system as iOS.

  

 [![](https://lh3.googleusercontent.com/-dSmoHrBFyLo/YtoGkfBczjI/AAAAAAAAMoA/eNLy_kQ22HchGASWB8VJbxm1wRDOBkrKACNcBGAsYHQ/s1600/1658455692420444-10.png)](https://lh3.googleusercontent.com/-dSmoHrBFyLo/YtoGkfBczjI/AAAAAAAAMoA/eNLy_kQ22HchGASWB8VJbxm1wRDOBkrKACNcBGAsYHQ/s1600/1658455692420444-10.png) 

  

  

iPhone and it's operating system iOS is way more advanced and powerful then keypad mobile phone operating system like Java and Symbian etc but iPhone is expensive even now still as iPhone with iOS is very futuristic people went crazy to buy iPhone as demand for iPhone is very high it got sold out in minutes on most Apple Stores in USA and worldwide.

  

The world runs as following demand and supply as there is huge demand for mobiles like iPhone from people to encash that mobile companies around the world started developing and executing plans to make thier own mobiles like iPhone even though most mobile companies has top notch powerful hardware yet what they miss is operating system like iOS due to that most mobile companies unable to make mobile like iPhone.

  

 [![](https://lh3.googleusercontent.com/-x6Sfp4NY2JE/YtoGjdOfUMI/AAAAAAAAMn8/S_c4RJm1Vo437Oxye0TAiLQFce-DMMGdQCNcBGAsYHQ/s1600/1658455681614719-11.png)](https://lh3.googleusercontent.com/-x6Sfp4NY2JE/YtoGjdOfUMI/AAAAAAAAMn8/S_c4RJm1Vo437Oxye0TAiLQFce-DMMGdQCNcBGAsYHQ/s1600/1658455681614719-11.png) 

  

Fortunately, the global search engine giant Google in partnership with HTC on September 23, 2008 released it's first smartphone HTC Dream powered by Android a operating system that was buyed in year 2005 from Andy Rubens then Google smartly made Android a open source project aka AOSP so any individual or company can contribute or build his own custom version of Android OS to install on thier mobiles.

  

 [![](https://lh3.googleusercontent.com/-BAMeH54iagw/YtoGgmPuubI/AAAAAAAAMn4/OKFJbjBDn3UHWK5mpnUmkKtbznImBsQBQCNcBGAsYHQ/s1600/1658455677378137-12.png)](https://lh3.googleusercontent.com/-BAMeH54iagw/YtoGgmPuubI/AAAAAAAAMn4/OKFJbjBDn3UHWK5mpnUmkKtbznImBsQBQCNcBGAsYHQ/s1600/1658455677378137-12.png) 

  

Thankfully, Android has potential to compete with iOS so most mobile companies mainly Samsung, HTC Motorola, started building thier own version of Android with custom skins like Samsung OS, HTC Sense, Motorola pure stock with enhancements, OEM apps,  additional features and required optimization to adapt software to mobile hardware and work properly.

  

 [![](https://lh3.googleusercontent.com/-4-BQQckmPFI/YtoGfgqLMGI/AAAAAAAAMn0/saOZuVru-FQ3oc90L71IDDhRGVAxzCw_QCNcBGAsYHQ/s1600/1658455673852888-13.png)](https://lh3.googleusercontent.com/-4-BQQckmPFI/YtoGfgqLMGI/AAAAAAAAMn0/saOZuVru-FQ3oc90L71IDDhRGVAxzCw_QCNcBGAsYHQ/s1600/1658455673852888-13.png) 

  

  

Most people started calling mobiles with iOS or Android as smartphones as they're advanced and powerful with multi-touch technology but the term smartphones coined in year on August 16, 1996 with the release of touch screen phone IBM simon personal communicator any how Motorola DynaTac 8000X wireless mobile is stepping stone of modern smartphones that we use now.

  

 [![](https://lh3.googleusercontent.com/-TZIvVK63xLw/YtoGejqseTI/AAAAAAAAMnw/Fs0XVtf6E4cJWzuLdvbVZ5HVqbA4QYCsgCNcBGAsYHQ/s1600/1658455669574534-14.png)](https://lh3.googleusercontent.com/-TZIvVK63xLw/YtoGejqseTI/AAAAAAAAMnw/Fs0XVtf6E4cJWzuLdvbVZ5HVqbA4QYCsgCNcBGAsYHQ/s1600/1658455669574534-14.png) 

  

  

The first Android smartphone from Motorola Mobility is Motorola Droid that was well received by people in year 2009 but it has physical keypad that's no more required as iPhone have touchscreen qwerty keyboard which is very easy and convenient to use so eventually Motorola Mobility made much better smartphones without outdated physical keyboard to fully compete with iPhone and other popular mobile companies.

  

 [![](https://lh3.googleusercontent.com/-Co6_b9BrcU0/YtoGdrd4nPI/AAAAAAAAMns/wUsPNNmItFw0wKPnnWGBjV3LjxfvdMkoQCNcBGAsYHQ/s1600/1658455659403102-15.png)](https://lh3.googleusercontent.com/-Co6_b9BrcU0/YtoGdrd4nPI/AAAAAAAAMns/wUsPNNmItFw0wKPnnWGBjV3LjxfvdMkoQCNcBGAsYHQ/s1600/1658455659403102-15.png) 

  

  

Motorola Mobility made and released numerous Android powered smartphones from year 2009 to 2011 then Google aquired Motorola in year 2012 and made Moto X 1st generation a flagship Android smartphone fully developed by Google that recieved postive reviews but in same year Google closed it's acquisition of Motorola Mobility from then they started making thier own smartphones.

  

 [![](https://lh3.googleusercontent.com/-pzkfZx-RJ20/YtoGa7ZiITI/AAAAAAAAMno/T1nhP1uM1jUvbmCV-wH70nfe9syLNwFSACNcBGAsYHQ/s1600/1658455655847292-16.png)](https://lh3.googleusercontent.com/-pzkfZx-RJ20/YtoGa7ZiITI/AAAAAAAAMno/T1nhP1uM1jUvbmCV-wH70nfe9syLNwFSACNcBGAsYHQ/s1600/1658455655847292-16.png) 

  

  

Even though, Android powered smartphones are bit less expensive then Apple iPhones yet they are costly many popular mobiles companies like Samsung and HTC used to make high priced Android smartphones due to that most people especially in developing countries unable to afford Android powered smartphones as there monthly income is less then 100$ even much less in almost all African countries.

  

iPhone is expensive smarphone so only some people used to buy them it's major market is in USA and European countries so in developing countries iPhone market share is very low for ex : in india iPhone market share is just 5% as buying a iPhone become life goal for many people but luckily as Android is open source mobile companies around the Android started making it's own Android smartphones that leaded to competiton which eventually decreased the price of Android powered smartphones to make them affordable.

  

 [![](https://lh3.googleusercontent.com/-6Pv8h5fg24o/YtoGaHMRZ0I/AAAAAAAAMnk/OgFH5cmgiJgyUSQTmNR5tvVJqwvwk9MBQCNcBGAsYHQ/s1600/1658455651948804-17.png)](https://lh3.googleusercontent.com/-6Pv8h5fg24o/YtoGaHMRZ0I/AAAAAAAAMnk/OgFH5cmgiJgyUSQTmNR5tvVJqwvwk9MBQCNcBGAsYHQ/s1600/1658455651948804-17.png) 

  

  

In this competition among mobile companies, Motorola Mobility played major role in year 2013 they made and released Moto G 1st generation a budget series to reach smartphones to everyone and compete with high priced mobiles from iPhone, Samsung and HTC etc.

  

Moto G 1st generation got huge popularity within days and considered as one of the best budget Android smartphone globally thus Moto G 1st generation got thumping success so Lenova a American - chinese multinational technology company and one of the largest PC maker in the world 

acquired Motorola mobility on October 30, 2014 for US$2.91 billion since then Lenovo making and continuing Moto G, Moto E, Moto X series Android smartphones.

  

Lenovo is in smartphone business from long time they made many smartphones out of them some Lenovo smartphones got immense popularity and success especially Lenovo K3 Note in year 2013 that competed with Moto G 1st generation but didn't reached the level of hype that Motorola's Moto G 1st generation has worldwide which may be the reason Lenovo acquired Motorola Mobility.

  

 [![](https://lh3.googleusercontent.com/-LJiXP51C49Y/YtoGZKn9QbI/AAAAAAAAMng/5-4sM-VvgOojqZvhdacaUOyBb9zeALJqACNcBGAsYHQ/s1600/1658455648641695-18.png)](https://lh3.googleusercontent.com/-LJiXP51C49Y/YtoGZKn9QbI/AAAAAAAAMng/5-4sM-VvgOojqZvhdacaUOyBb9zeALJqACNcBGAsYHQ/s1600/1658455648641695-18.png) 

  

  

Meanwhile, a china mobile company Xiaomi inc. in year 2014 released Redmi Note a budget friendly low price Android smartphone that has flagship features thus most people who were unable to afford high price Android smartphones from HTC and samsung etc started buying Xiaomi Redmi Note series quality and feature rich affordable smartphones.

  

 [![](https://lh3.googleusercontent.com/-ALcXtohuisM/YtoGYRNatOI/AAAAAAAAMnc/xxWzXCqpTZg2-GURcDeVWvFu9PkSmPEXwCNcBGAsYHQ/s1600/1658455645305257-19.png)](https://lh3.googleusercontent.com/-ALcXtohuisM/YtoGYRNatOI/AAAAAAAAMnc/xxWzXCqpTZg2-GURcDeVWvFu9PkSmPEXwCNcBGAsYHQ/s1600/1658455645305257-19.png) 

  

  

There is big competition between Xiaomi and Motorola smartphones but at the end Xiaomi smartphones has better price and features then Motorola so most people even Moto G smartphone users shifted to Xiaomi Redmi Note smartphone series especially when Xiaomi released Redmi Note 3 in year 2015 with MediaTek processor for china and Qualcomm Snapdragon in year 2016 for US and other countries like India it one of the best mid-range smartphone in Redmi series lineup from Xiaomi inc.

  

Lenovo continued the legacy of Moto E, G and X series but they didn't have essense and quality of orginal Motorola Mobility smartphones so Lenovo's Motorola smartphones are unable to compete with Xiaomi smartphones to full extent in sense Xiaomi always had upper hand in low and mid range smartphones and with in few years Xiaomi also beat Moto X flagship smartphones with Mix series.

  

Most people who buyed Motorala Mobility smartphones prior 2014 bit disappointed with the quality and features of new Motorola smartphones from Lenovo most people and some developers from XDA felt Lenovo ruined Motorola smartphones it's true but Lenovo continued Motorola smartphones with increased features accordingly to compete Xiaomi and other mobile companies smartphones.

  

However, after the entry of china mobile company Xiaomi with it's smartphones globally and got success many china mobile companies inspired by Xiaomi started entering in global mobile market with budget smartphones to make profits like Oppo, Vivo, OnePlus, iQOO, Meizu, ZTE, RealMe etc that later compete with Xiaomi which pushed Xiaomi to make even better low price smartphones.

  

 [![](https://lh3.googleusercontent.com/-eXrjQC8AeLg/YtoGXqGJ5DI/AAAAAAAAMnY/jMWhv5Ucu20yzLdncPBhiPM7sY15mM1_wCNcBGAsYHQ/s1600/1658455641733440-20.png)](https://lh3.googleusercontent.com/-eXrjQC8AeLg/YtoGXqGJ5DI/AAAAAAAAMnY/jMWhv5Ucu20yzLdncPBhiPM7sY15mM1_wCNcBGAsYHQ/s1600/1658455641733440-20.png) 

  
  

Xiaomi even started providing flagship Qualcomm Snapdragon 800 processor and features with it's new sub-brand POCO at midrange smartphone price thus POCO smartphones got immense popularity as most people who are unable to afford expensive Qualcomm Snapdrahon 800 processor smartphones started buying POCO smartphones from then it has become super hard for any mobile company to surpass Xiaomi smartphones.

  

The extreme competitive low price of Xiaomi smartphones become difficulty for Lenovo yet somehow they managed to make Motorola smartphones that are competive to Xiaomi smartphones but still Xiaomi smartphones performed better and has more features then Lenovo's Motorola smartphones thus most people prefered Xiaomi smartphone over Lenovo's Motorola smartphones.

  

 [![](https://lh3.googleusercontent.com/-hjO771j6lt8/YtoGWppePfI/AAAAAAAAMnU/M51k6pqGzJ0_HeFAT5tWHt6Km070DFTsACNcBGAsYHQ/s1600/1658455638073304-21.png)](https://lh3.googleusercontent.com/-hjO771j6lt8/YtoGWppePfI/AAAAAAAAMnU/M51k6pqGzJ0_HeFAT5tWHt6Km070DFTsACNcBGAsYHQ/s1600/1658455638073304-21.png) 

  

  

HTC a Taiwanese mobile company and Samsung a south korea mobile company are leading manufacturers of mobiles who used to make high priced smartphones but from 2013 with the entry of Motorola Mobility Moto G series and in year 2014 Xiaomi and other china mobile companies entry in global mobile market reduced the dominance and large market percentage of Samsung and HTC in developing countries as most people preffering to buy low price value for money smartphones. 

  

The reason Xiaomi able to make smartphones at very low price is because Xiaomi take very low profit margin like 2% to 4% even they don't spend much money on advertising as they depend on organic reach through people while Motorola Mobility take high profit margin or not they are able to pull out potential low price budget smartphone that can compete with Xiaomi and other china mobile company smartphones.

  

Both Xiaomi and Lenovo's Motorola used to focus only on online market and over the years they are able to get strong hold of online market while Samsung and HTC etc are highly concentrated in offline retail market where they have to give some percentage of commission to retailers when they sell thier products to customers including that Samsung and HTC etc spend billions of dollors on advertising it's smartphones thus Samsung and HTC take high profit margin then china mobile companies like Xiaomi.

  

There are some china mobile companies which specifically focus on offline retail market like Oppo and Vivo and got success now a days it is important to sell smartphones in both offline and online market to sell smartphones as there are large percentage of people who are not used to buy smartphone in online market thus Xiaomi, Motorola and other china mobile company also entered into offline retail market to sell thier smartphones due to that the domination of Samsung, HTC,  indian mobile companies offline retail market sells reduced exponentially.

  

Majority of global smartphone companies like Samsung, HTC and indian mobile companies like Micromax, Lava, Celkon, Karbonn, etc who used to import smartphones from china then brand thier logo to sell in india struggled to beat Lenovo's Motorola, Xiaomi and other china mobile company mid-range budget friendly affordable smartphones.

  

But, HTC, Samsung and indian mobile companies didn't stopped releasing thier old and outdated mid-range smartphones even though they didn't sell well in online and offline market while HTC totally stopped making mid range smartphones in case of Samsung they keep on listening requests from thier regular customers who frequently ask Samsung to make value for money feature rich quality and powerful smartphones like Lenovo's Motorola, Xiaomi and other china mobile company smartphones.

  

Indian mobile companies like Micromax, Karbonn, Celkon, Lava etc who once made huge profits by selling imported keypad mobile phones and smartphones from china companies with added high profits margins now totally lost both offline and online market to china mobile companies in india and overseas but they are trying to revive back in that process Micromax world's 10th largest Indian phone brand made IN series that didn't go well and now Lava international came up with india's first 5G smartphone Agni that seems to have strength to compete with global and china mobile company smartphones.

  

When Samsung finally realised that in order to sustain in developing countries mobile market they have to make smartphones at low price like Motorola, Xiaomi and other china mobile companies so they made and released online exclusive Samsung Galaxy M series budget smartphones line up on February 5, 2019 since then Samsung is giving tough competition to Xiaomi, Lenovo's Motorola and other china mobile company smartphones.

  

 [![](https://lh3.googleusercontent.com/-IfmtgPY7mOo/YtoGVyy-KaI/AAAAAAAAMnQ/IhGGOkHdWw45CWSzd-Nbiblh3G6SYCviwCNcBGAsYHQ/s1600/1658455635026823-22.png)](https://lh3.googleusercontent.com/-IfmtgPY7mOo/YtoGVyy-KaI/AAAAAAAAMnQ/IhGGOkHdWw45CWSzd-Nbiblh3G6SYCviwCNcBGAsYHQ/s1600/1658455635026823-22.png) 

  

  

Samsung M series able to slowly recover Samsung's lost grip on mid range mobile market but the amazing re-entry of Samsung in mid-range mobile market has become another blockage to Lenovo as it's already struggling to beat Xiaomi and other china mobile companies with it's Motorola smartphones.

  

 [![](https://lh3.googleusercontent.com/-1Mww-EOSN7A/YtoGUw5Hy3I/AAAAAAAAMnM/9jsaqzDj220HnpsWANZb3YR5YoB_25MbgCNcBGAsYHQ/s1600/1658455631374554-23.png)](https://lh3.googleusercontent.com/-1Mww-EOSN7A/YtoGUw5Hy3I/AAAAAAAAMnM/9jsaqzDj220HnpsWANZb3YR5YoB_25MbgCNcBGAsYHQ/s1600/1658455631374554-23.png) 

  

  

Motorola Mobility like any other mobile company also make keypad mobile phones even though they are busy with smartphones yet they didn't leave keypad mobile phones market since beginnings but Samsung and Nokia is top keypad mobile phone manufacturer for decades that has large percentage of customers still Motorola from past few years made and released A series keypad mobile phones with nice features phones at reasonable price range.

  

Motorola A series keypad mobile phones is in profits or not but it's better for any mobile company to not just totally depend on smartphones as there is still big market for keypad mobile phones many people around the world who unable to afford aor or don't know how to use multi-touch smartphones still use keypad mobile phones so Motorola Mobility very likely continue to make and sell Motorola A series keypad mobile phones worldwide as atleast if they can make some profits on them then that will balance the losses of Lenovo's Motorola smartphones 

  

 [![](https://lh3.googleusercontent.com/-_7PgSmrd3w0/YtoGTwM5yxI/AAAAAAAAMnI/JLFBr-ag5cc5nR7aDFDg-zSxGqf9SDaMwCNcBGAsYHQ/s1600/1658455627252158-24.png)](https://lh3.googleusercontent.com/-_7PgSmrd3w0/YtoGTwM5yxI/AAAAAAAAMnI/JLFBr-ag5cc5nR7aDFDg-zSxGqf9SDaMwCNcBGAsYHQ/s1600/1658455627252158-24.png) 

  

Nokia, a finland mobile company is most popular and largest manufacturer of keypad mobile phones and biggest competitor to Samsung didn't made Android smartphones instead they depended on it's own keypad mobile operating system Symbian that didn't go well for various factors so after few years Nokia partnered with Microsoft and made Nokia Lumia a closed source mobile Window operating system smartphone that struggled and failed to beat Android powered smartphones due to lack of support from people and developers.

  

 [![](https://lh3.googleusercontent.com/-speC6nDLMFY/YtoGS0rzXDI/AAAAAAAAMnE/9o0BBdq4aOgeo6RHSlLr374Y8JzVC86RwCNcBGAsYHQ/s1600/1658455622911692-25.png)](https://lh3.googleusercontent.com/-speC6nDLMFY/YtoGS0rzXDI/AAAAAAAAMnE/9o0BBdq4aOgeo6RHSlLr374Y8JzVC86RwCNcBGAsYHQ/s1600/1658455622911692-25.png) 

  

  

Lumia series of Nokia got big losses thus they stopped manufacturing Nokia Lumia smartphones and recently Microsoft also stopped softwares updates to Nokia Lumia smartphones but Nokia is still top manufacturer of keypad mobiles phones and then Nokia ex-employees taking Nokia trademark rights started a new company named HMD global which is making and selling Nokia smartphones with Android operating system from 25th February, 2018 so Nokia customers and fans are very much buying Nokia smartphones over other mobile company smartphones.

  

Now Nokia become another big competitor to Lenovo's Motorola after Samsung and china mobile companies yet Lenovo keep on working to make feature rich Motorala smartphones at best price they recently even reduced profit margin on budget smartphones to compete with Samsung, Nokia and other china mobile company smartphones especially Xiaomi.

  

Lenovo tried to preserve the originality of Motorola smartphones they didn't change software since first Motorola smartphone it has pure stock Android operating system with enhancements like Motorola OEM apps and some extra features to improve user experience on smartphone so most people who like stock Android OS prefer Motorola smartphones over custom skin Android OS like MIUI available on Xiaomi smartphones.

  

 [![](https://lh3.googleusercontent.com/-yI_xs7AUH80/YtoGR-EbKoI/AAAAAAAAMnA/ikdr5SNNoFUjCKJLYj6GEckg1bknLrWrQCNcBGAsYHQ/s1600/1658455619254184-26.png)](https://lh3.googleusercontent.com/-yI_xs7AUH80/YtoGR-EbKoI/AAAAAAAAMnA/ikdr5SNNoFUjCKJLYj6GEckg1bknLrWrQCNcBGAsYHQ/s1600/1658455619254184-26.png) 

  

  

Atlast, Motorala Mobility always used Qualcomm Snapdragon processors on it's smartphones but Lenovo recently started  using Mediatek processors on some smartphones even though both Qualcomm Snapdragon and Mediatek are powerful and advanced processors yet Qualcomm Snapdragon source code is public so it's developer friendly while Mediatek didn't released it's source code so most people who want to install custom roms like to use Qualcomm Snapdragon smartphones over Mediatek processor smartphones.

  

The shift of Motorola to Mediatek processors didn't worked out well as there are reports that Motorola Mediatek processor smarphones become slow and laggy even there is power management issues, in comparison Samsung Exynos processor and Qualcomm Snapdragon performed better even existing Motorola customers prefer Qualcomm Snapdragon processor over Mediatek processors.

  

Most Mediatek processors has no issues because there are many smartphones that has Mediatek processors and they are working super fine so most likely Motorola may not optimized it's hardware and software to run Mediatek processor well that can rise issues and there is a myth that Qualcomm Snapdragon processor are better then Mediatek processors but it's not true yet most people in USA like to use Qualcomm Snapdragon smartphones.

  

If Lenovo want to sell Motorola smartphones in US mobile market then for sure they have make Qualcomm Snapdragon processor smarphones while in china Mediatek processors are widely used on most smartphones so it's better if Lenovo release Mediatek processor smarphones in china and Qualcomm Snapdragon processor smarphones in other countries like Xiaomi to gain customers quickly.

  

Anyway, Lenovo is smartly pushing Motorola smartphones providing best possible features at less price using various marketing plans and strategies which is why Lenovo's Motorola smartphones is still in race with Samsung, Nokia, Xiaomi other china mobile phone company smartphones but some Motorola smartphones are not impressive especially Moto C series.

  

 [![](https://lh3.googleusercontent.com/-gL3OD4YZEQc/YtoGQxcT-XI/AAAAAAAAMm8/FO783dUXr9gWCANR6Dz15oMH8uRTi-gmgCNcBGAsYHQ/s1600/1658455613480218-27.png)](https://lh3.googleusercontent.com/-gL3OD4YZEQc/YtoGQxcT-XI/AAAAAAAAMm8/FO783dUXr9gWCANR6Dz15oMH8uRTi-gmgCNcBGAsYHQ/s1600/1658455613480218-27.png) 

  

  

Right now, Almost all mobile companies are trying to make best 5G smartphone at low price possible Lenovo already made many 5G smartphones to be up to date in that Motorola Moto Edge 30 is slimmest and thinnest flagship 5G smartphone with Qualcomm Snapdragon 830 processor so far it seems best but battery is just 4,500 Mah so if you want bigger longer then you may have to choose other smartphones but if you prefer Motorola smartphones then wait as there is huge competition to make best 5G smartphone between mobile companies Lenova is constantly working to release new and better low price Motorola 5G smartphones soon.

  

Finally, this is success, struggle and revival of Motorola, are you an existing user of Motorola, Google's Motorola or Lenovo's Motorola smartphones? If yes do say your experience and mention which company made best Motorola smartphones in terms of quality and features in our comment section below, see ya :)