---
title: 'How Reliance Revolutionized Telecom Industry of India'
date: 2019-12-31T22:44:00.001+05:30
draft: false
url: /2019/12/how-reliance-revolutionized-telecom.html
tags: 
- Jio
- technology
- Industry
- Telecom
- Relaince
---

 [![](https://lh3.googleusercontent.com/-lTzPsjRfVJQ/Xg2cpmSvS-I/AAAAAAAAAb0/MB2SF24MPcsQidzfWkiYXzpHaYpXc9x-ACLcBGAsYHQ/s1600/1577950366880951-0.png)](https://lh3.googleusercontent.com/-lTzPsjRfVJQ/Xg2cpmSvS-I/AAAAAAAAAb0/MB2SF24MPcsQidzfWkiYXzpHaYpXc9x-ACLcBGAsYHQ/s1600/1577950366880951-0.png) 

  

Hi, Relaince a well know trusted conglomerate in india started by bussiness magnate Dhirubhai ambani started as textile industry later get into smartphone and telecom industry. relaince mainly focus on quality, value for money, customer happiness as the products that mainly launched for indian public relaince telecom started as inbuild sim for relaince mobiles for easy usage and for indian audience.  

After the death of Dhirubhai ambani in 2002 property issues arise between his sons in that case wife of Dhirubhai ambani shared the property to both of them and put an expiry date for the bussiness involvement as petroleum and other oil and textile industries given to first son and other telecom and digital industries given to second son.

Petreoleum is going for large profits for mukesh ambani while telecom and other industries manged by Anil Ambani was unable to cope up with the industries that he got in property shareand put the comapany in losses as mukesh ambani has to save the company couple of times still the industries that anil amabani managed is in loss.

There is a years of block that both of them has not to get in each other business unless the time period ends in 2015 the time period ended that mukesh ambani wanted himself to get into telecom industry mukesh ambani started working on this plan before it's launch mukesh ambani taught to get the newer upgraded network 4g adding volte which gives ability to call in hd that feature is not available at the time added advantage he completely planted necessary things in several areas before it's launch.

Mukesh Ambani launched jio sim in 2017 that with the offers that mindblown everyone jio gives you free 3months of free 4g data that to 4gb of data with unlimited calls and unlimited network with 64kbps fup.

That was the time when airtel and other networks used to provide 100mb for 20rs and people used to limit thier usage for extending thier network time not only that thier were plans for 1gb 300rs that to with 1month validity from several other providers that can be said loot and that's a different story as the same providers now completely changed thier plans to compete relaince that they never done when needed including that increased prices that other countries data prices is very less compared to only india.

Then after the relaince launched everyone rushed to relaince stores including me 😂

I don't wanna that airtel loot me more that the prices is to high to cope up that waiting hours to get the jio sim in store.

Jio goal is to reach as many people as much and went with a slogan digitalized india as the government wanted from them as relaince done thier big part to digitalize india.

Jio customer growth has at lightening speed and everyone using jio sim all that data benefits , sms, fup and data completely changing the viewing aspect and daily usage of internet and services.

Jio not only given data at no price but also given options like prime benefits after 3months several times relaince extended 3months on occassion of festivals and finally when free offers got to end jio launched low prices as people not even expected and it was mind blown again.

Pricing was for 3months at rate of 500rs etc with 2gb data that to with vouchers including free services prime benefits like jio music , jiotv, jio cinema etc with added advantage of unlimited data at night time from 2am to 5am as an added advantage but removed later after some month's.

Relaince not only digitalized india thier right time approach changed the data usage and topped the world rank 1 in few years including that jio offers made people to buy a new 4g lte device and many people who not used smartphone buyed for the first time and it does made company's to release budget 4g lte devices in india.

Many users got 4g handsets and jio offers and it does made many youtubers get popular like technical Hindi and many more channels that thier subscribers base viewership not only that youtube viewers from india and content creators.

Relaince offered discounts on thier lyf sub brand with jio sim but however it didn't worked well rather the sells of other company went high as the other company's like Xiaomi , motorola provides more features and value for money.

Relaince jio recently changed thier iuc charges to cope up with telecom authority of India aftr the expiry of iuc charges has to be removed until then relaince has to charge 6paise per minute to manage that relaince giving 1gb data for every iuc recharge.

Relaince striving to provide more speed and quality and quantity interms of data calls and other services in upcoming years.

Indian users has to thankful for relaince and appreciate the right time approach And available and big thanks from us.

Conclusion :

Relaince property issues put a division and onhold in industry's share but after the onhold and rules set by mother ends mukesh ambani got into telecom his future idea and work helped jio after the launch it mindblown everyone the offers that not only digitalized everyone but also ranked 1 in global in internet usage and become one of the most subscriber base in few years still growing and right time approach in india after many hard years from airtel etc looters. Relaince going with the mindblown offers today and future to hope so and new statement and new things releasing from relaince are interesting and increasing the hypes.

Keep supporting : TechTracker.in