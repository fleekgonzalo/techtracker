---
title: '5 Facebook Plugins For Blogger'
date: 2020-01-30T23:22:00.001+05:30
draft: false
url: /2020/01/5-facebook-plugins-for-blogger.html
tags: 
- technology
- Page
- Blogger
- SocialMedia
- Facebook
- Plugin
---

**  

[![](https://lh3.googleusercontent.com/-WDfCMxLjACs/Xjb9RNp6WdI/AAAAAAAABBU/ByJ3h0xpc-UaKEeMgtbvFny_ph09ZUhAwCLcBGAsYHQ/s1600/IMG_20200202_220103_505.jpg)](https://lh3.googleusercontent.com/-WDfCMxLjACs/Xjb9RNp6WdI/AAAAAAAABBU/ByJ3h0xpc-UaKEeMgtbvFny_ph09ZUhAwCLcBGAsYHQ/s1600/IMG_20200202_220103_505.jpg)

**

**5 Facebook Plugins For Blogger **  

  

Blogger I's one of the simple and most advanced platform if we use it right.

  

If you made a amazing blog with loads of content and you are unable to get it to work for your social media gain.

  

**Then its a drawback..**

  

So if you are trying to use your blogger audience to direct them towards your social media without extra tab or leaving website.

  

Cool right. Now we will present you 5 Facebook plugins to increase viewer engagement and followers base.

  

**•1** **Facebook** **Developers**

This was one of the best official plugin support from facebook, If you don't want some third party code on your blogger. and with loaded features.

  

• Enter your page name 

  

• Enter Width and Height - 500/0 as per my page. you can use your own size

  

• Add tabs , remove covers, small header.

  

**\- 2** [Elfsight.com](https://www.blogger.com/Elfsight.com)

  

• Go to the website

  

• Signup and get amazing plugins for social media feed and other blogger plugins.

  

• But you have to connect to your fb account to authorise.

  

• You can add anywhere in your site even the team helps and do it in your site if you are unable to so.

  

• But plugin size is high than other plugins I have seen.

  

• Good Support from elfsight will feel more centric.

  

**\- 3** [www.power.io](https://www.blogger.com/www.power.io)

  

This is another site that offers many useful plugins for blogger.

  

 Go to the site - signup - get fb widget code and add to your site.

  

**\- 4** [www.sharethis.com](https://www.blogger.com/www.sharethis.com)

  

This is one of the best blogger and other

platforms plugin's site.

  

\- Go to website, tap on facebook feed widget and enter your fb URL.

  

Get the code and Install anywhere you like to.

  

\- 5 **FaceBook Plugin **

  

If you added facebook js SDK in your template.

  

Then go to your template control panel.

  

Add below code in your widget where you want to display facebook page.

<br />  <span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;"><div id='fb-root'/></span><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;"> </span><br /> <span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;"><script> </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">//<!\[CDATA\[ </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">(function(d, s, id) { </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">  var js, fjs = d.getElementsByTagName(s)\[0\]; </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">  if (d.getElementById(id)) return; </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">  js = d.createElement(s); js.id = id; </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">  js.src = "//connect.facebook.net/en\_US/sdk.js#xfbml=1&version=v2.3"; </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">  fjs.parentNode.insertBefore(js, fjs); </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">}(document, 'script', 'facebook-jssdk')); </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;">//\]\]> </span><br style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;" /><span style="background-color: #f9f9f9; color: #737373; font-family: "Open Sans", arial; font-size: 15px;"></script></span><div> <span style="color: #737373; font-family: Open Sans, arial;"><span style="font-size: 15px;"><iframe/></span></span><br /> <br /> <blockquote> <div id="fb-root"> <span style="color: #666666; font-size: 16px; white-space: pre-wrap;">Save your template, you can even add directly to your template by editing the template HTML.</span></div> </blockquote> <div> <br /></div> <div> But above method working flawlessly.</div> <div> <br /></div> <div> <b>Αντίο</b> - Bye Bye In Greek</div> </div> </div>

  

If you have any issue with plugin's you can comment down below.