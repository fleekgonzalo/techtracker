---
title: 'Things That You Have To Avoid In Internet.'
date: 2019-12-26T22:49:00.001+05:30
draft: false
url: /2019/12/things-that-you-have-to-avoid-in.html
---

  

  

  

  

[![](https://lh3.googleusercontent.com/-nFxsAyzqPeg/XhADnW4PkfI/AAAAAAAAAhs/WTIOloQJGo8JJxJ6-2kxTaK87YCAQPZfQCLcBGAsYHQ/s1600/IMG_20200104_084500_843.jpg)](https://lh3.googleusercontent.com/-nFxsAyzqPeg/XhADnW4PkfI/AAAAAAAAAhs/WTIOloQJGo8JJxJ6-2kxTaK87YCAQPZfQCLcBGAsYHQ/s1600/IMG_20200104_084500_843.jpg)

  

Hi, Internet this thing given humankind development in technology at the same time given pros and cons that are growing day by day we are totally depended on internet from weather to location while it is useful if you use in correvt way or else it can ditch you to.

  

Everybody alot of things will appear and make buzz as there is bad and good in internet and most highly internet is becoming a portal for criminals and illegal people using internet for thier benefits.

  

There are some things that you have avoid to keep yourself safe and things that can harm you.

  

First, internet is filled up with hackers and there are three type of hackers, white hat, black hat and grey hat and many more.. if you encountered with a white hat Hacker then it's a no problem but if you encountered a black hat Hacker then he may more likey get you in trouble if you have share any information with him.

  

Second, Avoid unknown messages from different people with messages of 3000rs iphone etc and they are scammers they steal your money and don't send you any product as they use fake numbers they can't be tracked.

  

Third, visiting unknown or unsecure website it's better to avoid or use some antivirus or even a link checker from playstore that may contain virus or trojans chrome does give you a warning message if it does noticed anything and if you still sure the website legit than only it's better to continue.

  

Fourth, sharing locations or numbers with unknowm persons can get you into trouble in several ways if you have done something like that take necessary solutions.

  

Fifth. Dark web there are many controversies regarding this are circled around the internet stories do feel horror and interesting and it's filled with physchos, criminals social against people so completely avoid visiting that law enforcement agencies watch you.

  

Sixth, Piracy, as per some state watching and downloading piracy movie or software was illegal if you knowingly or unknowingly do that can get fine or imprisonment according to state rules.

  

Seventh, Piracy there are several types of piracy and indulging into certain thing knowingly or unknowingly can put you in trouble. So always keep away from and avoiding it is best option, while telegram is a different thing.

  

Eight, installing unknown apps giving permissions to whatevet the app prompting can gives access to your privacy files so have a look before giving any permission's so avoid giving unecessary permissions based on app

  

Nine, never pay in a unsecured payement portal and it can rob your money and do check SSL and security authority and website authenticity.

  

Ten, Using same passwords in most of the website which have no big name or network can also get you into trouble so make sure while creating passwords based on website.

  

Keep supporting : techtracker.in