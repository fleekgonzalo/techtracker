---
title: 'The Truth Of Apple&#39;s Qwerty Keyboard'
date: 2019-12-13T22:43:00.001+05:30
draft: false
url: /2019/12/the-truth-of-apples-qwerty-keyboard.html
tags: 
- technology
- apple
- iOS
- keyboard
---

  

  

[![](https://lh3.googleusercontent.com/-umgGJ7QRUYs/Xg-ehugBhjI/AAAAAAAAAfg/wv4olhwun-INNgaceyQ1aNco7-vd5HoSQCLcBGAsYHQ/s1600/IMG_20200104_013300_400.jpg)](https://lh3.googleusercontent.com/-umgGJ7QRUYs/Xg-ehugBhjI/AAAAAAAAAfg/wv4olhwun-INNgaceyQ1aNco7-vd5HoSQCLcBGAsYHQ/s1600/IMG_20200104_013300_400.jpg)

  

Apple's Qwerty Keyboard, Yes you heard it right.

QwertyKeyboard that you in your devices either it's android and windows or another software that using that was patented by apple's.

  

The story goes back in time when Steve jobs and apple engineering developing apple iOS phones.

  

Steve jobs being an inspiration of entrepreneurs and being an amazing entrepreneur himself, he got the nerve beat and mindset of the people, as there is a sad story behind the apple inc Steve jobs left the apple company as the other team members decided they taught Steve jobs ideas getting bad so it will effect majorly to the company in the race of Microsoft windows and apple's I Mac.

  

When these unexpected problem in front of Steve jobs, however he accepted it and left the company with a minor share. So he could watch and join in the metting and know about the company, later he joined after apple was in losses after request of share holders.

  

You may think... Why I'm highlighting keyboard while there are many other inventions that was patented by apple like multitouch etc.

  

Now you'll know, apple was started in a car garage and company started by selling Steve jobs own van with this friend who was inventor of  advanced keyboard that was later adapted by other companies and it still in use till now and continuing...

  

When apple was looking for an alternative for hardware qwerty keyboard that's already being used by Nokia and Samsung etc.

  

The apple ecosystem is all in a touch screen interface, whatever that needed to do should have to be done in 3.5 inch screen ( which is big screen considered at the time ) so they are in dailema of finding an alternative and well adapting to apples iOS software, the development process has been started and ordered apples engineer to work on it.

  

The other software and hardware things are adding and modifying stage, apples engineers have be showing up and presenting their methods none of them really satisfied Steve jobs,

  

One fine day a engineer of applè came up with the qwerty keyboard and it amazed everyone including Steve jobs, it was fast, easy to use, sleek and well adapted to iOS ecosystem and its a big advancement for any multi touch device and forth coming devices.

  

Later qwerty keyboard have become a computer keyboard for everyone and it make forgot of computer keyboards another major reason being  public waiting in lines for days infront of smartphone and apple vendors.

  

After the buzzing slowed down, android adapted it in their eco system which later got features like voice, emojis and write and text emojis and some years after dark and lights mode skins etc. 

  

This looks simple but the advancement it was done is marlavellous it changed human day life and everything you doing in internet must require a qwerty keyboard without that you have been using old style hardware buttons.

  

There is no doubt you won't see any other alternative for qwerty keyboard in years for any software either its android or apple even kai is to use this as default the better things has not yet popped up or either it will can't guaranteed, google was working on fuschia os for using four apps at a time, do we get some thing like qwerty can't say until a complete fuschis os release.

  

Let's keep using qwerty keyboard until then... 

  

Moreover a big thanks to the engineer from us.

  

Conclusion : old style bored new things needed for apple when need for keyboard for utilising multi touch search started development orders passed engineers worked day and night none of them impressed Steve jobs, a engineer all of a sudden presented it mindblowed everyone and later got adapted by every ecosystem, that made an revolution like never before never again you in 2019 using it and not finding an alternative for your phone software, you have only option its none other than qwerty keyboard.

  

Keep Supporting : TechTracker.in