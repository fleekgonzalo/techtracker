---
title: 'Task Mate by google  - Earn money from home for free now available in India to !'
date: 2020-12-10T21:59:00.000+05:30
draft: false
url: /2020/12/task-mate-by-google-earn-money-from.html
tags: 
- bucks
- home
- Apps
- Taskmate
- google
- Earn
---

 [![](https://lh3.googleusercontent.com/-IM_SznTqCQ8/X9JM7h9zcDI/AAAAAAAACSU/xqehKZ4MLaAI6EbtGYsykRJfOItMbWRWgCLcBGAsYHQ/s1600/1607617770728005-0.png)](https://lh3.googleusercontent.com/-IM_SznTqCQ8/X9JM7h9zcDI/AAAAAAAACSU/xqehKZ4MLaAI6EbtGYsykRJfOItMbWRWgCLcBGAsYHQ/s1600/1607617770728005-0.png) 

  

We know google for various useful utilities like gmail, google search, google docs, google PDF and many more.  

  

But google never known for any task based money earning app they have google opinion rewards which will give play credits to purchase paid apps in discount which doesn't give you real money in bank.

  

Now, a new pop-up from google app named task mate which recently made available in India via beta version it's still in testing you need refferal code to work else you can't login.

  

Task mate is very simple to use but currently it was only available for selected users who have refferal code and it can't extend further invites.

  

° **Task Mate - Earn money through simple tasks**.

  

**•** Take a photo of nearby restaurant.

  

**•** answer survey questions

  

**•** help translate sentences to local language

  

You will be paid in local currency for the tasks that you complete accurately and you will need an account with a third party payments processor. When you’re ready to cash out, simply register your e-wallet or account with our payment partner in our app, then visit your profile page and hit the “cash out” button. You can then withdraw your earnings in your local currency.  

  

Note : the app is still beta don't expect fortunes instantly they are still in learning phase to provide additional earning opportunities through crowdsourcing.

  

Finally, google trying to give opportunity to many people in India to utilise this app to earn money in this pandemic situation this move by google does work fine, do mention your thoughts regarding this app in our comment section below, see ya :-)