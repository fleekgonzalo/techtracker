---
title: 'What are smart glasses and how they work? Apple vs Google again?'
date: 2022-11-12T12:00:00.001+05:30
draft: false
url: /2022/11/what-are-smart-glasses-and-how-they.html
tags: 
- Virtual
- technology
- Smart glass
- Augmented
- What
---

 [![](https://lh3.googleusercontent.com/-8Ek0LEHC5d0/Y3AOU9UYjiI/AAAAAAAAO28/WAtWfZzd3PUp5XVejuzhvqvD2yW_9nyYwCNcBGAsYHQ/s1600/1668288080405888-0.png)](https://lh3.googleusercontent.com/-8Ek0LEHC5d0/Y3AOU9UYjiI/AAAAAAAAO28/WAtWfZzd3PUp5XVejuzhvqvD2yW_9nyYwCNcBGAsYHQ/s1600/1668288080405888-0.png) 

  

Eyes, are one of the main parts of human beings which let you see each and every details of physical objects then instantly process it to brain at more then speed of light where you can not only analyse but  also recognise to understand everything that you see and view accordingly based up on your IQ Intelligence Quotient right?.

  

Which is why eyes are very important as without them world will go black that's why humans who are known as people in modern society since ancient times not only invented and used number of eye exercises and ways but also revolutionary products and surgeries to fix or protect and safeguard them on the go.

  

 [![](https://lh3.googleusercontent.com/-RCBjiX8_r-c/Y3B_QasdobI/AAAAAAAAO38/iHnFDJUaS5cX4W0YRwIpd3e_uGQRR-ACACNcBGAsYHQ/s1600/1668316988640300-0.png)](https://lh3.googleusercontent.com/-RCBjiX8_r-c/Y3B_QasdobI/AAAAAAAAO38/iHnFDJUaS5cX4W0YRwIpd3e_uGQRR-ACACNcBGAsYHQ/s1600/1668316988640300-0.png) 

  

Especially, when people found way to get glass by heating and cooling rocks and sands which is basically pure transparent that not only work as mirror to let you see yourself but also view physical objects in numerous ways based on it's structure and quality etc at first they created magnifying glasses that will not only let you see long distance physical objects clearly but also putting them and focusing them at direct sun light rays for some time can burn raw materials like wood, isn't amazing?

  

Fortunately, many inventors figured out that concave and convex glasses can fix improper eyes vision known as sight that usually caused due to disturbed light entry reflection into retina of eyes since then the glasses are also widely utilised to fix long and short eye sightedness as well but later on large percentage of people also started using different types of glasses to protect eyes from dust or any other materials like chemicals and heat sparks etc.

  

 [![](https://lh3.googleusercontent.com/-WX7a37ZpP2o/Y3B_PYiefWI/AAAAAAAAO34/e2jgDUf3VD42DnQrG8_DpSE7ToH00eAFACNcBGAsYHQ/s1600/1668316984198227-1.png)](https://lh3.googleusercontent.com/-WX7a37ZpP2o/Y3B_PYiefWI/AAAAAAAAO34/e2jgDUf3VD42DnQrG8_DpSE7ToH00eAFACNcBGAsYHQ/s1600/1668316984198227-1.png) 

  

Thankfully, majority of companies for personal or commercial reasons as glass look and feel premium and precious since ancient times started making and selling by products like glass doors or tables even to fill up water or juices etc including that glass also Integrated with other materials like computers and television etc because of glass people comfort and convenience increased immensely so it was being used in most products everywhere globally.

  

 [![](https://lh3.googleusercontent.com/-MDl6EKRkCrk/Y3B_OHG0-pI/AAAAAAAAO30/ppumrt_rP1QByk174uFIwdJFxjMBJ9_6QCNcBGAsYHQ/s1600/1668316980329128-2.png)](https://lh3.googleusercontent.com/-MDl6EKRkCrk/Y3B_OHG0-pI/AAAAAAAAO30/ppumrt_rP1QByk174uFIwdJFxjMBJ9_6QCNcBGAsYHQ/s1600/1668316980329128-2.png) 

  

Even though, there are millions of glass byproducts out there in this world but the one to close to your eyes are spectacle glasses isn't? at first as said earlier they are mainly used to fix improper vision and to protect from eye damaging materials but eventually by the time we entered in modern era number of people begin using glass extensively to make many personal fashion products like in jewellery in that process we got different size and shape cool spectacle glasses that are basically designed for stylish look and show off.

  

 [![](https://lh3.googleusercontent.com/-mNwH4bJA93Y/Y3B_NBfZAzI/AAAAAAAAO3w/AUk1uy4ndeQlQdoQNKRfDJO90VcparD4QCNcBGAsYHQ/s1600/1668316976157304-3.png)](https://lh3.googleusercontent.com/-mNwH4bJA93Y/Y3B_NBfZAzI/AAAAAAAAO3w/AUk1uy4ndeQlQdoQNKRfDJO90VcparD4QCNcBGAsYHQ/s1600/1668316976157304-3.png) 

  

However, we do have spectacle glasses like concave and convex glasses which not only give desired trendy look and feel but also will safeguard your eyes like for instance we have sun and anti glare glasses which will protect your eyes from sun UV aka ultra violet rays can be used by people who are relaxing in beaches or working so much in direct sunlight for long time including that we have cool glasses which will cool your eyes not letting much heat pass through it ain't this spectacle glasses amazed you?.

  

 [![](https://lh3.googleusercontent.com/-Wi9o7krva5o/Y3B_MDyPC4I/AAAAAAAAO3s/iHE2ADFrd2ILW_xZVqpygeCcBKh8lF-3wCNcBGAsYHQ/s1600/1668316972092685-4.png)](https://lh3.googleusercontent.com/-Wi9o7krva5o/Y3B_MDyPC4I/AAAAAAAAO3s/iHE2ADFrd2ILW_xZVqpygeCcBKh8lF-3wCNcBGAsYHQ/s1600/1668316972092685-4.png) 

  

But, now a days majority of people using spectacle glasses to fix vision clarity as large percentage of people in this 21st century of modern world full-filled with revolutionary digital technologies not training thier eyes at both short and long distances for instance alot of people now staying indoor by using PC aka personal computers or smarphones etc that can eventually cause short sightedness due to that only near physical objects are clearly visible and distant objects may look blurry so if you not aware be careful from now.

  

Meanwhile, some people go outside frequently to focus on physical objects at long distances forgetting that they also have to give equal balanced importance to short physical distance objects due to that they are getting far sightedness which is why now there are different types of lens spectacle glasses used by 1 in 100 people that's why it's better if you properly take care giving training at both short and long distance to your eyes exposing it to indoor and outdoor scenarios so that you may not get health problems in future.

  

 [![](https://lh3.googleusercontent.com/-T1prHDi69DA/Y3B_LJoTxmI/AAAAAAAAO3o/gyNTXNB3MjcVlLSRqjnJMIoWgsib5E44QCNcBGAsYHQ/s1600/1668316967325035-5.png)](https://lh3.googleusercontent.com/-T1prHDi69DA/Y3B_LJoTxmI/AAAAAAAAO3o/gyNTXNB3MjcVlLSRqjnJMIoWgsib5E44QCNcBGAsYHQ/s1600/1668316967325035-5.png) 

  

Anyhow, many people either they have sight spectacle glasses or not once in while use trendy fashion glasses isn't? ain't you one of them? but at the end they have limitations despite fixing eye vision and protecting it or to show off designs and beauty to people, eye glasses usually don't have more capabilities yet still used by people worldwide isn't disappointing?   

  

What if? spectacle glasses can do more stuff it will be super cool right? this idea circled around the world for decades so few companies to make this happen build and released revolutionary smart glasses that're basically Integrated with electronic several hardware components and digital operating system basically software build using number of programming languages to run tasks electronically and digitally.

  

 [![](https://lh3.googleusercontent.com/-U2JiPgv01iY/Y3B_J1Pqg1I/AAAAAAAAO3k/Z3HMftN6CRU3VXQEFWt1J55mhmF30EKXgCNcBGAsYHQ/s1600/1668316962110400-6.png)](https://lh3.googleusercontent.com/-U2JiPgv01iY/Y3B_J1Pqg1I/AAAAAAAAO3k/Z3HMftN6CRU3VXQEFWt1J55mhmF30EKXgCNcBGAsYHQ/s1600/1668316962110400-6.png) 

  

The main speciality here is if you ever seen spectacle glasses then you may probably know you won't get much space to fit anything into it isn't? except two corner frames with support to balance above your ears yet still thanks to rapid technology advancements happened from past few decades due to them inventors managed to Integrate powerful hardware and advanced software so that you'll be able to perform all tasks easily.

  

 [![](https://lh3.googleusercontent.com/-8fJWVOuYAD4/Y3B_IDchwII/AAAAAAAAO3g/7yWOllA9DLYF82z4bfHnPeTNIOoBF04OgCNcBGAsYHQ/s1600/1668316952515471-7.png)](https://lh3.googleusercontent.com/-8fJWVOuYAD4/Y3B_IDchwII/AAAAAAAAO3g/7yWOllA9DLYF82z4bfHnPeTNIOoBF04OgCNcBGAsYHQ/s1600/1668316952515471-7.png) 

  

Smart glasses are evolution of personal computers and mainly smartphones and smartwatches but it doesn't have big display or keyboard including that it don't come with multi-touch technology instead it was Integrated with VR aka virtual and AR aka augmented reality that will simply increase its potential and functionalities with professional level for sure.

  

**[\+ The evolution of Computer to PCs and Laptops, Tecno Megabook T1.](https://www.techtracker.in/2022/09/the-evolution-of-computer-to-pcs-and.html)**

  

You may already know or listened about VR and AR technologies isn't? they are also Integrated and named as mixed and xtended realty, if you are not aware then for you in simple they let you enter into any virtual world but also let virtual world enter into reality digitally with immersive vivid experience everywhere which is why now we're using VR and AR technologies on every possible electronic devices and digital softwares to use in numerous sectors as they have huge potential and capabilities to let you execute real life tasks more comfortably and conveniently.

  

 [![](https://lh3.googleusercontent.com/-hfusj8DkON8/Y3B_GIbuUiI/AAAAAAAAO3c/Vw_bC8epPi4Uw3nE7UoPh8nQmD0MeJbpQCNcBGAsYHQ/s1600/1668316946505353-8.png)](https://lh3.googleusercontent.com/-hfusj8DkON8/Y3B_GIbuUiI/AAAAAAAAO3c/Vw_bC8epPi4Uw3nE7UoPh8nQmD0MeJbpQCNcBGAsYHQ/s1600/1668316946505353-8.png) 

  

In sense, to be exact when you use virtual reality you can enter into desired virtual reality digitally that feels approximately real thanks to sensors like for instance you may virtually go to shopping mall where you can select and wear dresses and buy them simply, and then comes augmented reality where you can place virtual world into reality digitally which you can only see through lens or camera but smart glasses surely use either MR aka   

mixed or XR aka extended reality.  

  

[**\+ What is augmented and virtual reality? on PC and smartphones.**](https://www.techtracker.in/2022/09/what-is-augmented-and-virtual-reality.html)  

  

MR and XR is mix of virtual and augmented due to that you'll get both worlds on smart glasses that extend usage possibilities for instance to name few with VR you can watch movies like in big screen to get theater experience or get real life training even meet or attend any interviews in virtual world and then comes AR with that you can see digital operating systems in reality digitally via through the lens which is one of the main reason many people like to buy smart glasses.

  

 [![](https://lh3.googleusercontent.com/-aVQj_8Nv30E/Y3B_EviXycI/AAAAAAAAO3Y/NzGxunNuS2ImsUCGtrQdQMp1kWqs6Oj6wCNcBGAsYHQ/s1600/1668316942114742-9.png)](https://lh3.googleusercontent.com/-aVQj_8Nv30E/Y3B_EviXycI/AAAAAAAAO3Y/NzGxunNuS2ImsUCGtrQdQMp1kWqs6Oj6wCNcBGAsYHQ/s1600/1668316942114742-9.png) 

  

When you use MR and XR technologies on smartglasses you can see softwares in reality digitally which you can control and use with your eye movements don't need keyboard or mouse etc including that developers already created number of MR and AR apps but for AR and VR headsets which are more well known and popular with attention and recognition worldwide.

  

VR and AR or MR and XR headsets are mainly designed for gaming which require you to connect smarphones that was totally not required on smart glasses as over there lens are the smartphones but definitely headsets as they are equipped with smartphones are more powerful and advanced then smart glasses right now but it may change in next few decades.

  

 [![](https://lh3.googleusercontent.com/-R4RNEJ0B8cc/Y3B_DsICGFI/AAAAAAAAO3U/MJ9a5L7R1d4__YS2LUTBmFdiBJGKgdgPgCNcBGAsYHQ/s1600/1668316937862067-10.png)](https://lh3.googleusercontent.com/-R4RNEJ0B8cc/Y3B_DsICGFI/AAAAAAAAO3U/MJ9a5L7R1d4__YS2LUTBmFdiBJGKgdgPgCNcBGAsYHQ/s1600/1668316937862067-10.png) 

  

Anyway, currently smart glasses are not available in full scale even though we have some from popular companies yet right now they are super expensive and basic so you can't really do much but the future possibilities are endless at present on smart glasses using XR compatible map apps you will be able to get live directions of location structurally or you may digitally project movie on public space or theatre and take video calls with inbuild camera and microphone etc, fabulous right?.

  

 [![](https://lh3.googleusercontent.com/-gSLxFpWMUrU/Y3B_Cmw-7ZI/AAAAAAAAO3Q/JP8D5udBQxU3OjEjm0K-boEbmil5LDDJQCNcBGAsYHQ/s1600/1668316933490732-11.png)](https://lh3.googleusercontent.com/-gSLxFpWMUrU/Y3B_Cmw-7ZI/AAAAAAAAO3Q/JP8D5udBQxU3OjEjm0K-boEbmil5LDDJQCNcBGAsYHQ/s1600/1668316933490732-11.png) 

  

Google is one of the early companies to make smart glasses back in year 2016 they developed and released Google smart glasses that recieved exciting hype but failed commercially as it's super costly no one really seems interesting in buying it instead most people went with MR or XR technologies headsets and smartphones but Google didn't give up they continously working on it's smart glasses due to that now we have it's updated and upgraded version Glass enterprise edition 2.

  

 [![](https://lh3.googleusercontent.com/-nbG5Km0Y6NE/Y3B_BRqiYXI/AAAAAAAAO3M/1DabJBnAMMgKXGxPMzLkynen1S8n4hxNQCNcBGAsYHQ/s1600/1668316926806616-12.png)](https://lh3.googleusercontent.com/-nbG5Km0Y6NE/Y3B_BRqiYXI/AAAAAAAAO3M/1DabJBnAMMgKXGxPMzLkynen1S8n4hxNQCNcBGAsYHQ/s1600/1668316926806616-12.png) 

  

  

In fact smart glasses from Google is flop still the technology is awesome and already there are many competitors entered this recent years mainly from Apple inc. a popular PC maker founded by Steve Jobs known for innovation may as per strong rumours on world wide web of build thier own light weight 3D integrated smart glass that seems better and best alternative to Google Smart glass.

  

 [![](https://lh3.googleusercontent.com/-XzzVF54VY4Y/Y3B-_4JZ7NI/AAAAAAAAO3I/y_Q0ZIIKYIYG0hAbQwdMw0n6yCvFTUEQQCNcBGAsYHQ/s1600/1668316921541142-13.png)](https://lh3.googleusercontent.com/-XzzVF54VY4Y/Y3B-_4JZ7NI/AAAAAAAAO3I/y_Q0ZIIKYIYG0hAbQwdMw0n6yCvFTUEQQCNcBGAsYHQ/s1600/1668316921541142-13.png) 

  

Apple inc. glasses as per rumours may come with 8 hours battery life with tweaked operating systems known as RealityOS including that they developed a smart ring that detect movements and let you conveniently crawl Internet smoothly including that few more rumors states that Apple inc. build and patented a lens technology which will auto adust to fix vision of people who have far or short sightedness simply, I believe it is possible what do you think?  

  

 [![](https://lh3.googleusercontent.com/-I5v9hxpk2V4/Y3B--QvgfbI/AAAAAAAAO3E/K1DFq-2GAGg6ClFgP6y3lSX88O0BL_0CwCNcBGAsYHQ/s1600/1668316916195071-14.png)](https://lh3.googleusercontent.com/-I5v9hxpk2V4/Y3B--QvgfbI/AAAAAAAAO3E/K1DFq-2GAGg6ClFgP6y3lSX88O0BL_0CwCNcBGAsYHQ/s1600/1668316916195071-14.png) 

  

We got to see many more rumors on Apple inc. smart glasses like they may use Sony OLED displays and explored few ways for privacy of people seems to be thinking to make re-movable camera module thus places like theatres can restrict them or embedded camera that only work with key including that Apple inc. may remove background images in live and created a projetion to beam images into eye directly etc even if few above stated rumours came true then they may make same impact they done with iPhones.

  

Right now, smart glass of Apple inc. not available it is expected to be launched in upcoming few years until then we don't have many worthy competitors except Google smart glasses but once Apple inc. smart glasses released even if it's super expensive like they always price expected to be below 1000$ then Google and number of companies mainly from china inspired or copy it to make thier own smart glasses at cheap or affordable budget prices adding more thier own or third party revolutionary latest awesome technologies.

  

Finally, this are smart glasses and yeah we may see another device line up and new technology where Apple inc. and Google soon compete with each other extremely in friendly atmosphere, are you an existing user of smart glasses? If yes do say your experience and mention what do you think about future of smart glasses in our comment section below, see ya :)