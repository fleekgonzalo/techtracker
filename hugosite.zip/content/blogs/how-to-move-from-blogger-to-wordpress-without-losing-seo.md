---
title: 'How to move from Blogger to WordPress without losing SEO.'
date: 2022-05-07T23:14:00.001+05:30
draft: false
url: /2022/05/how-to-move-from-blogger-to-wordpress.html
tags: 
- How
- Move
- technology
- Wordpress
- Blogger
---

 [![](https://lh3.googleusercontent.com/-ReD3zWTwm5E/YnawCeNINnI/AAAAAAAAKx4/oIMyNTSesKYGD-jGPXex2_xvl9iOePelgCNcBGAsYHQ/s1600/1651945477030442-0.png)](https://lh3.googleusercontent.com/-ReD3zWTwm5E/YnawCeNINnI/AAAAAAAAKx4/oIMyNTSesKYGD-jGPXex2_xvl9iOePelgCNcBGAsYHQ/s1600/1651945477030442-0.png) 

  

  

When you want to create a website or blog there are two options available either you code website and host it on your pc or smartphone or use online cms - content management platforms like Blogger or WordPress where you just have to setup and connect your domain to write content and publish them on world wide web instantly for free.

  

Blogger by Google and WordPress by Automatic Inc are most popular content management systems in the world but WordPress offer advanced and powerful plugins to do almost anything on website thus users who manage heavy resources website use WordPress, while blogger is simple with basic widgets with no hosting charges thus blogger is preffered by those who are new to websites and blogging.

  

In sense, Blogger is biggest competitor to WordPress, Eventhough, both Blogger and WordPress are used by professionals yet beginners who want to super customize and upgrade thier blog or site eventually move from Blogger to WordPress but the problem here is Blogger don't have any option to migrate to WordPress.

  

If you want to transfer your Blogger website to WordPress then you have to do that carefully as anything wrong you perform will impact SEO, fortunately Blogger has option to backup content in .xml format so by using that .xml file you can easily switch from Blogger to WordPress in 3 steps, isn't cool?

  

However, Blogger over the years got numerous modern themes, widgets and scripts with many useful settings to give edge to edge competition to WordPress including that you can connect Blogger with Cloudflare to get WordPress type features, anyway if you still want to transfer your Blogger website to WordPress then let's get started.

  

**• How to transfer your Blogger website to WordPress •**

 **[![](https://lh3.googleusercontent.com/-4dhx4mFo2Z4/YnawBPenaKI/AAAAAAAAKx0/iU2Yvpxxjj82wIyCC-kI9fgmmbtUbVUbQCNcBGAsYHQ/s1600/1651945472000703-1.png)](https://lh3.googleusercontent.com/-4dhx4mFo2Z4/YnawBPenaKI/AAAAAAAAKx0/iU2Yvpxxjj82wIyCC-kI9fgmmbtUbVUbQCNcBGAsYHQ/s1600/1651945472000703-1.png)** 

  

\- First buy hosting and add custom domain then login into your Cpanel.

  

\- In Cpanel, tap on **Softaculous Apps Installer.**  

  

 **[![](https://lh3.googleusercontent.com/-S5zXKJcEi0s/Ynav_0PgGlI/AAAAAAAAKxs/EQQonUaqeak5lT0-8jqh0PXCCmZCuerQACNcBGAsYHQ/s1600/1651945467480391-2.png)](https://lh3.googleusercontent.com/-S5zXKJcEi0s/Ynav_0PgGlI/AAAAAAAAKxs/EQQonUaqeak5lT0-8jqh0PXCCmZCuerQACNcBGAsYHQ/s1600/1651945467480391-2.png)** 

  

\- Tap on **WordPress** from list.

  

 [![](https://lh3.googleusercontent.com/-ej-RBwH5Xps/Ynav-wvRFKI/AAAAAAAAKxo/vH7KCrB-0GEEeyEeHjitFl3uF_-AM55dQCNcBGAsYHQ/s1600/1651945462582969-3.png)](https://lh3.googleusercontent.com/-ej-RBwH5Xps/Ynav-wvRFKI/AAAAAAAAKxo/vH7KCrB-0GEEeyEeHjitFl3uF_-AM55dQCNcBGAsYHQ/s1600/1651945462582969-3.png) 

  

\- Tap on **Install Now**

 **[![](https://lh3.googleusercontent.com/-H57hqqMbN8w/Ynav9vnCpaI/AAAAAAAAKxk/Ep27UV5oMiw7KK18zwcD3aQc9gZF5_tPwCNcBGAsYHQ/s1600/1651945458322055-4.png)](https://lh3.googleusercontent.com/-H57hqqMbN8w/Ynav9vnCpaI/AAAAAAAAKxk/Ep27UV5oMiw7KK18zwcD3aQc9gZF5_tPwCNcBGAsYHQ/s1600/1651945458322055-4.png)** 

 [![](https://lh3.googleusercontent.com/-aS1LtLwTzTI/Ynav8o--YzI/AAAAAAAAKxg/QGm3cNDb7HU-JREP6GeM5qfUS0b2SZ46QCNcBGAsYHQ/s1600/1651945454808614-5.png)](https://lh3.googleusercontent.com/-aS1LtLwTzTI/Ynav8o--YzI/AAAAAAAAKxg/QGm3cNDb7HU-JREP6GeM5qfUS0b2SZ46QCNcBGAsYHQ/s1600/1651945454808614-5.png) 

  

 [![](https://lh3.googleusercontent.com/-sqNNmEERm_I/Ynav7uwgivI/AAAAAAAAKxc/sNEk8B-5P4cQ0ryevBUKXeW8y0Ly0NkuQCNcBGAsYHQ/s1600/1651945451029063-6.png)](https://lh3.googleusercontent.com/-sqNNmEERm_I/Ynav7uwgivI/AAAAAAAAKxc/sNEk8B-5P4cQ0ryevBUKXeW8y0Ly0NkuQCNcBGAsYHQ/s1600/1651945451029063-6.png) 

  

 [![](https://lh3.googleusercontent.com/-Ic01HeSZpds/Ynav6uRBYUI/AAAAAAAAKxY/5UbYhTNnH_w7qTDD0kmvc3MnqO8cv-MAwCNcBGAsYHQ/s1600/1651945446352852-7.png)](https://lh3.googleusercontent.com/-Ic01HeSZpds/Ynav6uRBYUI/AAAAAAAAKxY/5UbYhTNnH_w7qTDD0kmvc3MnqO8cv-MAwCNcBGAsYHQ/s1600/1651945446352852-7.png) 

  

  

\- Fill required details and select WordPress theme then tap on **Install**

 **[![](https://lh3.googleusercontent.com/-gls0AdR8DJY/Ynav5r7b6vI/AAAAAAAAKxU/6N31N4CcX4g31dg8rVDe_XmCf8dJp_BSgCNcBGAsYHQ/s1600/1651945441852656-8.png)](https://lh3.googleusercontent.com/-gls0AdR8DJY/Ynav5r7b6vI/AAAAAAAAKxU/6N31N4CcX4g31dg8rVDe_XmCf8dJp_BSgCNcBGAsYHQ/s1600/1651945441852656-8.png)** 

\- It will start installing WordPress.

  

 [![](https://lh3.googleusercontent.com/-wU_Tx7v0KYs/Ynav4YEquqI/AAAAAAAAKxQ/Kb8yFBP2HZ8VEbsRGszTH7AdZ4S_RDn8ACNcBGAsYHQ/s1600/1651945437198330-9.png)](https://lh3.googleusercontent.com/-wU_Tx7v0KYs/Ynav4YEquqI/AAAAAAAAKxQ/Kb8yFBP2HZ8VEbsRGszTH7AdZ4S_RDn8ACNcBGAsYHQ/s1600/1651945437198330-9.png) 

  

\- Once installed, Go to yourwebsite/wp-admin/ to login.

  

 [![](https://lh3.googleusercontent.com/-cCWhgvvUei4/Ynav3Ynn1UI/AAAAAAAAKxM/bZzxTueamCYOdWggph3GNfSExwpxCFqiwCNcBGAsYHQ/s1600/1651945432988352-10.png)](https://lh3.googleusercontent.com/-cCWhgvvUei4/Ynav3Ynn1UI/AAAAAAAAKxM/bZzxTueamCYOdWggph3GNfSExwpxCFqiwCNcBGAsYHQ/s1600/1651945432988352-10.png) 

  

\- Enter your Username or Email Address, Password then tap on **Log in.**

 **[![](https://lh3.googleusercontent.com/-v0Ekm20PCWI/Ynav2E3A8LI/AAAAAAAAKxI/0dBulJhhlysR8m4d-y_ZFHq1VdAaRNIZgCNcBGAsYHQ/s1600/1651945427839217-11.png)](https://lh3.googleusercontent.com/-v0Ekm20PCWI/Ynav2E3A8LI/AAAAAAAAKxI/0dBulJhhlysR8m4d-y_ZFHq1VdAaRNIZgCNcBGAsYHQ/s1600/1651945427839217-11.png)** 

\- You're in WordPress, Tap on **≡**

 **[![](https://lh3.googleusercontent.com/-DvPBQ6Fr99g/Ynav05mX1wI/AAAAAAAAKxE/TwIaGyUiTDkF3WmAr_Y5BCA-yu7brDangCNcBGAsYHQ/s1600/1651945424150106-12.png)](https://lh3.googleusercontent.com/-DvPBQ6Fr99g/Ynav05mX1wI/AAAAAAAAKxE/TwIaGyUiTDkF3WmAr_Y5BCA-yu7brDangCNcBGAsYHQ/s1600/1651945424150106-12.png)** 

\- Tap on Settings then tap on Permalinks.

  

 [![](https://lh3.googleusercontent.com/-5l8clyuZBzQ/Ynavz0YODoI/AAAAAAAAKxA/3S02Pz9Vl-k-4Hg6IVH7CRkPR8-kgy_kQCNcBGAsYHQ/s1600/1651945419070427-13.png)](https://lh3.googleusercontent.com/-5l8clyuZBzQ/Ynavz0YODoI/AAAAAAAAKxA/3S02Pz9Vl-k-4Hg6IVH7CRkPR8-kgy_kQCNcBGAsYHQ/s1600/1651945419070427-13.png) 

  

\- Select Day and name \[ Blogger Format \] it's essential for SEO and no errors.

  

 [![](https://lh3.googleusercontent.com/-qexeUHTtibk/YnavygKL-fI/AAAAAAAAKw4/pyNmtsupofEt8S3mN_e-kOswGiwjPt7bQCNcBGAsYHQ/s1600/1651945413649168-14.png)](https://lh3.googleusercontent.com/-qexeUHTtibk/YnavygKL-fI/AAAAAAAAKw4/pyNmtsupofEt8S3mN_e-kOswGiwjPt7bQCNcBGAsYHQ/s1600/1651945413649168-14.png) 

  

\- Scroll down then tap on **Save Changes**

 **[![](https://lh3.googleusercontent.com/-kwMC4eKhVL4/YnavxSmBubI/AAAAAAAAKw0/uiz4K92OucIeBP2snG5QmEVHnzn_EEA7QCNcBGAsYHQ/s1600/1651945409573536-15.png)](https://lh3.googleusercontent.com/-kwMC4eKhVL4/YnavxSmBubI/AAAAAAAAKw0/uiz4K92OucIeBP2snG5QmEVHnzn_EEA7QCNcBGAsYHQ/s1600/1651945409573536-15.png)** 

\- Tap on  **≡ **

  

\- Tap on **Tools** then tap on **Import**.

  

 [![](https://lh3.googleusercontent.com/-uQAR5OXQhZQ/YnavwUIyZCI/AAAAAAAAKww/DSr2MCy5-3QcU3DzGNLd1k1caTVzYo4zgCNcBGAsYHQ/s1600/1651945404594090-16.png)](https://lh3.googleusercontent.com/-uQAR5OXQhZQ/YnavwUIyZCI/AAAAAAAAKww/DSr2MCy5-3QcU3DzGNLd1k1caTVzYo4zgCNcBGAsYHQ/s1600/1651945404594090-16.png) 

  

\- Tap on **Blogger Install Now**

 **[![](https://lh3.googleusercontent.com/-Yyll2mzvxp8/YnavvGDYAOI/AAAAAAAAKws/U4L6HKZUUZYA5XxVfCZ_nqmi5OMMMhmTACNcBGAsYHQ/s1600/1651945399417986-17.png)](https://lh3.googleusercontent.com/-Yyll2mzvxp8/YnavvGDYAOI/AAAAAAAAKws/U4L6HKZUUZYA5XxVfCZ_nqmi5OMMMhmTACNcBGAsYHQ/s1600/1651945399417986-17.png)** 

\- Importer installed successfully, now tap on **Run Importer**

 **[![](https://lh3.googleusercontent.com/-ndULuKeBO7Y/Ynavt0RTj0I/AAAAAAAAKwo/2iSsFtbyJ4MfzJiPG571h4MX4xbwO-vbACNcBGAsYHQ/s1600/1651945394432852-18.png)](https://lh3.googleusercontent.com/-ndULuKeBO7Y/Ynavt0RTj0I/AAAAAAAAKwo/2iSsFtbyJ4MfzJiPG571h4MX4xbwO-vbACNcBGAsYHQ/s1600/1651945394432852-18.png)** 

  

\- Now, Login to your Blogger Dashboard

  

\- Tap on **≡** then tap on **Settings**

 **[![](https://lh3.googleusercontent.com/-zmyR8GQ3peY/YnavskSiv4I/AAAAAAAAKwk/bOUISND-d1kc4r84V2pHS_XXwoMw1ydNACNcBGAsYHQ/s1600/1651945390719163-19.png)](https://lh3.googleusercontent.com/-zmyR8GQ3peY/YnavskSiv4I/AAAAAAAAKwk/bOUISND-d1kc4r84V2pHS_XXwoMw1ydNACNcBGAsYHQ/s1600/1651945390719163-19.png)** 

\- Scroll down, In Manage Blog tap on **Back up content.**

 **[![](https://lh3.googleusercontent.com/-wgGivkE8R9k/Ynavrh-I9CI/AAAAAAAAKwc/SaZmE_dDdYocaPatJ3g2tZkSWYONp27AACNcBGAsYHQ/s1600/1651945386552655-20.png)](https://lh3.googleusercontent.com/-wgGivkE8R9k/Ynavrh-I9CI/AAAAAAAAKwc/SaZmE_dDdYocaPatJ3g2tZkSWYONp27AACNcBGAsYHQ/s1600/1651945386552655-20.png)** 

\- Tap on **Download** 

  

 [![](https://lh3.googleusercontent.com/-aNSzPB_JWm0/YnavqXH7bBI/AAAAAAAAKwY/jm9BFIpEo4g-TBhUERE1gh5DZQcJBtMgwCNcBGAsYHQ/s1600/1651945381514980-21.png)](https://lh3.googleusercontent.com/-aNSzPB_JWm0/YnavqXH7bBI/AAAAAAAAKwY/jm9BFIpEo4g-TBhUERE1gh5DZQcJBtMgwCNcBGAsYHQ/s1600/1651945381514980-21.png) 

  

\- Once content is backed up, head back to WordPress then tap on Choose File.

  

\- Select blogger backup .xml file then tap on Upload file and import

  

 [![](https://lh3.googleusercontent.com/-6TWAZpNyySk/YnavpRF7-yI/AAAAAAAAKwU/GgEufel73NIe_7EV2Ow2uWqB-zSGVOSkQCNcBGAsYHQ/s1600/1651945377953376-22.png)](https://lh3.googleusercontent.com/-6TWAZpNyySk/YnavpRF7-yI/AAAAAAAAKwU/GgEufel73NIe_7EV2Ow2uWqB-zSGVOSkQCNcBGAsYHQ/s1600/1651945377953376-22.png) 

  

\- Done, Tap on **≡**

 **[![](https://lh3.googleusercontent.com/-dgVpAttsHzw/YnavofxooNI/AAAAAAAAKwQ/cNj1c0uiweI3OPP2aDt5x1GiPR2FiaFxQCNcBGAsYHQ/s1600/1651945370811787-23.png)](https://lh3.googleusercontent.com/-dgVpAttsHzw/YnavofxooNI/AAAAAAAAKwQ/cNj1c0uiweI3OPP2aDt5x1GiPR2FiaFxQCNcBGAsYHQ/s1600/1651945370811787-23.png)** 

\- Tap on Plugins then tap on **Add New**

 **[![](https://lh3.googleusercontent.com/-7Bu7BZA-Mv4/YnavmqZED2I/AAAAAAAAKwM/aoRFaNbALc8Qi_gEpldV_d69fRFEHhErACNcBGAsYHQ/s1600/1651945360366729-24.png)](https://lh3.googleusercontent.com/-7Bu7BZA-Mv4/YnavmqZED2I/AAAAAAAAKwM/aoRFaNbALc8Qi_gEpldV_d69fRFEHhErACNcBGAsYHQ/s1600/1651945360366729-24.png)** 

 **[![](https://lh3.googleusercontent.com/-Kyo-7LRVIp4/YnavjydOowI/AAAAAAAAKwI/jM30jy47xVUyW11uibuw58pdDPIHN7TlQCNcBGAsYHQ/s1600/1651945355251344-25.png)](https://lh3.googleusercontent.com/-Kyo-7LRVIp4/YnavjydOowI/AAAAAAAAKwI/jM30jy47xVUyW11uibuw58pdDPIHN7TlQCNcBGAsYHQ/s1600/1651945355251344-25.png)** 

\- Search for Blogger To WordPress plugin by rtCamp then Install and activate it.

  

 [![](https://lh3.googleusercontent.com/-CaWfkO6XZ-c/YnavirEAeAI/AAAAAAAAKwE/oKDPtDL7Ui8qpdLVlvgmjegZIrxpFdLPACNcBGAsYHQ/s1600/1651945350930157-26.png)](https://lh3.googleusercontent.com/-CaWfkO6XZ-c/YnavirEAeAI/AAAAAAAAKwE/oKDPtDL7Ui8qpdLVlvgmjegZIrxpFdLPACNcBGAsYHQ/s1600/1651945350930157-26.png) 

  

\- Now, tap on **≡**

\- Tap on Tools then tap on **Blogger To WordPress Redirection.**

 **[![](https://lh3.googleusercontent.com/-Yxt4NXwPNBk/Ynavhoxy9hI/AAAAAAAAKwA/JNX0LgWHNXY9q6o6rKLVU7SRV4G-GBAjgCNcBGAsYHQ/s1600/1651945346424511-27.png)](https://lh3.googleusercontent.com/-Yxt4NXwPNBk/Ynavhoxy9hI/AAAAAAAAKwA/JNX0LgWHNXY9q6o6rKLVU7SRV4G-GBAjgCNcBGAsYHQ/s1600/1651945346424511-27.png)** 

\- Tap on **Start Configuration** then tap on **Get Code.**

 **[![](https://lh3.googleusercontent.com/-_Y4l0YipPrM/YnavggQ75vI/AAAAAAAAKv8/rfKbIMVBAic-B8cjZAE0sLr0nP7zNn25ACNcBGAsYHQ/s1600/1651945342284460-28.png)](https://lh3.googleusercontent.com/-_Y4l0YipPrM/YnavggQ75vI/AAAAAAAAKv8/rfKbIMVBAic-B8cjZAE0sLr0nP7zNn25ACNcBGAsYHQ/s1600/1651945342284460-28.png)** 

\- Copy template code and go to Blogger Dashboard.

  

 [![](https://lh3.googleusercontent.com/-BLjhHfA8ghU/YnavfWMHP7I/AAAAAAAAKv4/mkIJ1nl7Vs8bauftTa6Px0UTEFKp0v79gCNcBGAsYHQ/s1600/1651945338340972-29.png)](https://lh3.googleusercontent.com/-BLjhHfA8ghU/YnavfWMHP7I/AAAAAAAAKv4/mkIJ1nl7Vs8bauftTa6Px0UTEFKp0v79gCNcBGAsYHQ/s1600/1651945338340972-29.png) 

  

\- In Themes, Tap on **Switch to first generation Classic theme.**

 **[![](https://lh3.googleusercontent.com/-QHT8HonsM_c/YnavesMwN6I/AAAAAAAAKv0/hPDrPU0KPAAjiVgnI3SfiP1aPBOuPCZMACNcBGAsYHQ/s1600/1651945334415186-30.png)](https://lh3.googleusercontent.com/-QHT8HonsM_c/YnavesMwN6I/AAAAAAAAKv0/hPDrPU0KPAAjiVgnI3SfiP1aPBOuPCZMACNcBGAsYHQ/s1600/1651945334415186-30.png)** 

\- Tap on **BACKUP AND SWITCH**, it will automatically backup existing theme.

 **[![](https://lh3.googleusercontent.com/-AO8c1j8U2VI/YnavdSeH2XI/AAAAAAAAKvw/BSdCDKtDvAUdqmeLs0nNDfo_HW4SsA7PwCNcBGAsYHQ/s1600/1651945330494468-31.png)](https://lh3.googleusercontent.com/-AO8c1j8U2VI/YnavdSeH2XI/AAAAAAAAKvw/BSdCDKtDvAUdqmeLs0nNDfo_HW4SsA7PwCNcBGAsYHQ/s1600/1651945330494468-31.png)** 

\- Tap on **Edit HTML**

 **[![](https://lh3.googleusercontent.com/-9ql-mD8C3s0/Ynavce_GecI/AAAAAAAAKvs/569EXBLwgiE5oao64zmtWAu_F1k8ISTYwCNcBGAsYHQ/s1600/1651945325579739-32.png)](https://lh3.googleusercontent.com/-9ql-mD8C3s0/Ynavce_GecI/AAAAAAAAKvs/569EXBLwgiE5oao64zmtWAu_F1k8ISTYwCNcBGAsYHQ/s1600/1651945325579739-32.png)** 

\- Remove existing code and paste that code you copied earlier from Blogger to WordPress plugin then save it.

  

 [![](https://lh3.googleusercontent.com/-vd0eiloM4IU/YnavbAIVa5I/AAAAAAAAKvo/sMKMUqq0hCI8WXo8exOUGgW-YO2vwYDRQCNcBGAsYHQ/s1600/1651945318743902-33.png)](https://lh3.googleusercontent.com/-vd0eiloM4IU/YnavbAIVa5I/AAAAAAAAKvo/sMKMUqq0hCI8WXo8exOUGgW-YO2vwYDRQCNcBGAsYHQ/s1600/1651945318743902-33.png) 

  

\- Go back to WordPress, then tap on **Verify Configuration.**

That's it, you successfully imported blogger website to WordPress.

  

Atlast, this are just highlighted features of WordPress there may be many hidden features in-build that provides you external benefits to give the ultimate usage experience, anyway if you want to move from Blogger to WordPress then this is right now best method for sure.

  

Overall, It is very easy to move from Blogger to Wordpress thanks to clean and simple intuitive interface of WordPress that ensures user friendly experience, but in any project there is always space for improvement so let's wait and see will WordPress get any major UI changes in future to make it even more better, as of now WordPress is fantastic.

  

Moreover, it is definitely worth to mention if you use custom domain on Blogger then make sure you first remove custom domain on Blogger then add that Custom domain on your WordPress hosting platform to move from Blogger to WordPress with no errors.

  

Finally, This is how you can transfer your Blogger website to WordPress in 3 simple steps, are you an existing user of this method? If yes do say your experience and mention if you know any better method to move from Blogger to WordPress in our comment section below, see ya :)