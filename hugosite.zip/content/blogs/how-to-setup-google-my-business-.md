---
title: 'How To Setup Google My Business! '
date: 2021-02-26T00:00:00.001+05:30
draft: false
url: /2021/02/how-to-setup-google-my-bussiness.html
tags: 
- How
- bussiness
- technology
- My
- setup
- google
---

[![](https://telegra.ph/file/b463bfdabb8f061880a9c.jpg)](https://telegra.ph/file/b463bfdabb8f061880a9c.jpg)

  

  

If you starting your own business or you already own a business there are alot of things you need to do to increase profits for your bussiness by getting more visitors to your website and customers to your bussiness will help you get feedback and reviews which you can learn to improve your services and grow your business.

  

These days bussines require alot of advertising many bussiness owners hire digital marketers to promote their bussiness on internet to get more exposure to their business through that they can Increase brand value and get more brand identity which will help thier brand to grow in future.

  

Most digital marketers use different tricks and techniques to grow bussiness of thier clients while most tricks and techniques are well known to public but some tricks and techniques are hidden based on the company very own methods but all the digital marketers usually use google my bussiness and google ads which likely work in very less time and bring more exposure and sells or vistors to thier bussines clients.

  

Yes, today most digital marketers use google my bussines to grow bussines of thier clients, if they can why don't you? It is very simple and easy to setup google my business and get more vistors to your website and customers to your business which will help you get sells and reviews so that you can learn statistics of sells and reviews to grow your business.

  

By adding your bussines on google my bussiness will make your bussines name and portfolio appear on google search which will give more impression and attention from google searches and through google my businesls you can post your products and many more.

  

Google my business also gives you free website where you can post your new products offers and more.. Google my bussiness gives you .**business.site** sub- domain for free from google, if you don't like the sub-domain you can buy top level domain as well.

  

• **How to setup google my business •**

 **[![](https://lh3.googleusercontent.com/--RtOho76wq8/YDk-SpVxIcI/AAAAAAAADWo/mHyF7RdOEacwRQJvE8u-BaMaqzpgq-yDgCLcBGAsYHQ/s1600/1614364230845879-0.png)](https://lh3.googleusercontent.com/--RtOho76wq8/YDk-SpVxIcI/AAAAAAAADWo/mHyF7RdOEacwRQJvE8u-BaMaqzpgq-yDgCLcBGAsYHQ/s1600/1614364230845879-0.png)** 

  

\- Go to [Google My Bussiness](https://www.google.com/intl/en_in/business/)

  

 [![](https://lh3.googleusercontent.com/-N0jNClmiK6Y/YDk-RqvjfJI/AAAAAAAADWk/8W5xymis_vAI9d3rERQXdx4ORC05EEd9wCLcBGAsYHQ/s1600/1614364226698957-1.png)](https://lh3.googleusercontent.com/-N0jNClmiK6Y/YDk-RqvjfJI/AAAAAAAADWk/8W5xymis_vAI9d3rERQXdx4ORC05EEd9wCLcBGAsYHQ/s1600/1614364226698957-1.png) 

  

\- Tap on **Sign in**  

 **[![](https://lh3.googleusercontent.com/-OPtYpcRm6cw/YDk-QmeJlNI/AAAAAAAADWg/A5CGaoYtTskvuT3_pv2SI1o9OocUzfUtQCLcBGAsYHQ/s1600/1614364222403015-2.png)](https://lh3.googleusercontent.com/-OPtYpcRm6cw/YDk-QmeJlNI/AAAAAAAADWg/A5CGaoYtTskvuT3_pv2SI1o9OocUzfUtQCLcBGAsYHQ/s1600/1614364222403015-2.png)** 

**\-** Tap  on **Add your bussiness to Google**

 **[![](https://lh3.googleusercontent.com/-PsFwBhSwaYU/YDk-PTGXBlI/AAAAAAAADWc/4Of2-3xSdPEeDx44LWTpQgnQflCr7UoyACLcBGAsYHQ/s1600/1614364218401771-3.png)](https://lh3.googleusercontent.com/-PsFwBhSwaYU/YDk-PTGXBlI/AAAAAAAADWc/4Of2-3xSdPEeDx44LWTpQgnQflCr7UoyACLcBGAsYHQ/s1600/1614364218401771-3.png)** 

**\-** Type your bussiness **NAME** and tap on Create a bussiness with this name and press on **NEXT**

 **[![](https://lh3.googleusercontent.com/-x-CQPWtCeiI/YDk-Ok0fjrI/AAAAAAAADWY/AWcdcG7qmScO8YxYjiXXpaPguGRrLyMmQCLcBGAsYHQ/s1600/1614364214683685-4.png)](https://lh3.googleusercontent.com/-x-CQPWtCeiI/YDk-Ok0fjrI/AAAAAAAADWY/AWcdcG7qmScO8YxYjiXXpaPguGRrLyMmQCLcBGAsYHQ/s1600/1614364214683685-4.png)** 

**\- ENTER** your **Category** and press on **NEXT**

 **[![](https://lh3.googleusercontent.com/-Gev6haKYGBo/YDk-NmQtfQI/AAAAAAAADWU/Gtp9pdji2YcSBB0I7CPau_WFmBC9B74egCLcBGAsYHQ/s1600/1614364210815992-5.png)](https://lh3.googleusercontent.com/-Gev6haKYGBo/YDk-NmQtfQI/AAAAAAAADWU/Gtp9pdji2YcSBB0I7CPau_WFmBC9B74egCLcBGAsYHQ/s1600/1614364210815992-5.png)** 

**\-** You can add your bussiness or office location or you can deny by tapping on **No**

 **[![](https://lh3.googleusercontent.com/-avISX7U5RFY/YDk-MlLGRwI/AAAAAAAADWQ/k8EAGsOVfEoPf3xt3c7sjgj8-kxJ6skrgCLcBGAsYHQ/s1600/1614364206974757-6.png)](https://lh3.googleusercontent.com/-avISX7U5RFY/YDk-MlLGRwI/AAAAAAAADWQ/k8EAGsOVfEoPf3xt3c7sjgj8-kxJ6skrgCLcBGAsYHQ/s1600/1614364206974757-6.png)** 

**\- Add** exact location of your bussiness, eventhough it's optional enter locations details carefully if you like to addadd and press on **NEXT**

  

 [![](https://lh3.googleusercontent.com/-gSBBtq3N3OI/YDk-Luy50cI/AAAAAAAADWM/E8tlfVu2HToBjA7C_L9_cyAnv0jDuUXAgCLcBGAsYHQ/s1600/1614364202921916-7.png)](https://lh3.googleusercontent.com/-gSBBtq3N3OI/YDk-Luy50cI/AAAAAAAADWM/E8tlfVu2HToBjA7C_L9_cyAnv0jDuUXAgCLcBGAsYHQ/s1600/1614364202921916-7.png) 

  

\- Important Enter your bussiness Country Carefully here itself, changing later can get you some inconvenience and issues and press on **NEXT**

 **[![](https://lh3.googleusercontent.com/-4KEh16rpMHY/YDk-Kq9_FPI/AAAAAAAADWI/D42yV3Mo72swEGSRt65ya4fNBFYsh-agwCLcBGAsYHQ/s1600/1614364198764185-8.png)](https://lh3.googleusercontent.com/-4KEh16rpMHY/YDk-Kq9_FPI/AAAAAAAADWI/D42yV3Mo72swEGSRt65ya4fNBFYsh-agwCLcBGAsYHQ/s1600/1614364198764185-8.png)** 

\- Enter **Contact No**, **Website URL**, select I don't need a website if you don't want, or select get a free website based on your info and press on **Next**

 **[![](https://lh3.googleusercontent.com/-9au_T5fl-PE/YDk-JtOIMMI/AAAAAAAADWE/6eBgY-ngi4gVYm4v07lj504WOJrHVsz0QCLcBGAsYHQ/s1600/1614364194580522-9.png)](https://lh3.googleusercontent.com/-9au_T5fl-PE/YDk-JtOIMMI/AAAAAAAADWE/6eBgY-ngi4gVYm4v07lj504WOJrHVsz0QCLcBGAsYHQ/s1600/1614364194580522-9.png)** 

\- Want updates press **Yes** else **No**

 **[![](https://lh3.googleusercontent.com/-QO0g5Y_TZt8/YDk-IfyUL-I/AAAAAAAADWA/vE-YbJEztkIQ-8G7l8inGmlBJLq2OygBACLcBGAsYHQ/s1600/1614364189591669-10.png)](https://lh3.googleusercontent.com/-QO0g5Y_TZt8/YDk-IfyUL-I/AAAAAAAADWA/vE-YbJEztkIQ-8G7l8inGmlBJLq2OygBACLcBGAsYHQ/s1600/1614364189591669-10.png)** 

**\- Now** Tap on **Finish** and now you done all the basics to get stared! Congrats! 

  

 [![](https://lh3.googleusercontent.com/-QgYcPX06mnA/YDqd2F-l36I/AAAAAAAADXw/QepnqTXd79ADfHz_k0d_JfSfTRAwe23UwCLcBGAsYHQ/s1600/1614454226915256-0.png)](https://lh3.googleusercontent.com/-QgYcPX06mnA/YDqd2F-l36I/AAAAAAAADXw/QepnqTXd79ADfHz_k0d_JfSfTRAwe23UwCLcBGAsYHQ/s1600/1614454226915256-0.png) 

  

\- Enter your postal address to verify or you can verify later! 

  

 [![](https://lh3.googleusercontent.com/-J5JZu2DLd-k/YDqd0nPar1I/AAAAAAAADXs/CmH-W4QwzTcJ9vIXoSWl919vo0IfNY30ACLcBGAsYHQ/s1600/1614454222194735-1.png)](https://lh3.googleusercontent.com/-J5JZu2DLd-k/YDqd0nPar1I/AAAAAAAADXs/CmH-W4QwzTcJ9vIXoSWl919vo0IfNY30ACLcBGAsYHQ/s1600/1614454222194735-1.png) 

  

\- Enable your opening days and tap on **SAVE** or tap on skip if you don't have any opening days. 

  

 [![](https://lh3.googleusercontent.com/-DTJ0PTxeCRQ/YDqdzf7bQII/AAAAAAAADXo/T-j2R8JQJio-rOkK_XUQxgGwCHiNC3zxACLcBGAsYHQ/s1600/1614454217094091-2.png)](https://lh3.googleusercontent.com/-DTJ0PTxeCRQ/YDqdzf7bQII/AAAAAAAADXo/T-j2R8JQJio-rOkK_XUQxgGwCHiNC3zxACLcBGAsYHQ/s1600/1614454217094091-2.png) 

  

\- **Enable**, Accept messages to let customers message your business on google for free. 

  

 [![](https://lh3.googleusercontent.com/-OWf86BpWaLg/YDqdyPY_9UI/AAAAAAAADXk/xm450gyaIpcUQKYERE6IDn_a-SpoFPK_ACLcBGAsYHQ/s1600/1614454212630907-3.png)](https://lh3.googleusercontent.com/-OWf86BpWaLg/YDqdyPY_9UI/AAAAAAAADXk/xm450gyaIpcUQKYERE6IDn_a-SpoFPK_ACLcBGAsYHQ/s1600/1614454212630907-3.png) 

  

\- Add business description, so that your customers find out more about your bus- issiness. 

  

 [![](https://lh3.googleusercontent.com/-n5x6aP8qoic/YDqdxMf2WGI/AAAAAAAADXg/DWC3Ixw4tj0wje7lwqgfu2XKYqpDZpfmACLcBGAsYHQ/s1600/1614454205595691-4.png)](https://lh3.googleusercontent.com/-n5x6aP8qoic/YDqdxMf2WGI/AAAAAAAADXg/DWC3Ixw4tj0wje7lwqgfu2XKYqpDZpfmACLcBGAsYHQ/s1600/1614454205595691-4.png) 

  

\- Add photos of your business, show off your products or services and let customers peek inside your business and tap on **Next** or **Skip** if you don't like to add. 

  

 [![](https://lh3.googleusercontent.com/--t_5j68TgE8/YDqdvbxElTI/AAAAAAAADXc/Hg4e2xNO04cmH-pUERuL2lYokN_xc6JGACLcBGAsYHQ/s1600/1614454200123142-5.png)](https://lh3.googleusercontent.com/--t_5j68TgE8/YDqdvbxElTI/AAAAAAAADXc/Hg4e2xNO04cmH-pUERuL2lYokN_xc6JGACLcBGAsYHQ/s1600/1614454200123142-5.png) 

  

\- **Now**, yours business profile is almost ready, you can later edit your profile any time, your edits will be visible to your customers on google after you been verified. 

  

 [![](https://lh3.googleusercontent.com/-9VE6m4Tvwzw/YDqdtzlLTMI/AAAAAAAADXY/d6a5QGSOGQ4vh5pEwDYzi4axnzVwylYdwCLcBGAsYHQ/s1600/1614454191704077-6.png)](https://lh3.googleusercontent.com/-9VE6m4Tvwzw/YDqdtzlLTMI/AAAAAAAADXY/d6a5QGSOGQ4vh5pEwDYzi4axnzVwylYdwCLcBGAsYHQ/s1600/1614454191704077-6.png) 

  

\- Welcome to Google My Business. By using the application, you agree to the terms of service and privacy policy, tap on **Get started** to use Google my business. 

  

 [![](https://lh3.googleusercontent.com/-am_yM6xiauI/YDtl8iC-TKI/AAAAAAAADYQ/vQqCdsKJHLEYlAd07vKHpcLWm3pwc6hmQCLcBGAsYHQ/s1600/1614505441397194-0.png)](https://lh3.googleusercontent.com/-am_yM6xiauI/YDtl8iC-TKI/AAAAAAAADYQ/vQqCdsKJHLEYlAd07vKHpcLWm3pwc6hmQCLcBGAsYHQ/s1600/1614505441397194-0.png) 

  

\-  Atlast, tap on verify now, now you will receive 5 digit code to the address that you given to google my bussines which you need to enter in google my bussines for successful verification, later google my bussines will connect your bussines to google. 

  

Overall, Google My Bussines website is simple and easy to use, you can add all the details easily in their website and feels pleasent which gives you clean user experience and all the features merged perfectly in website which makes things easy and make you to use more. 

  

Moreover, Google My Bussines also have dedicated app where you can follow the same procedure and setup google my bussines, Google My Bussines is better then web version but most people use website version so we used website version to reach more audience. 

  

Finally, Google My Bussines is a great platform by google for new startups and bussines to get exposure from people, you can also create free bussines site from Google My Business which is exceptional, do you registered in google my business or you already user of google business, if yes which feature you like most do mention in our comment section below, see ya :)